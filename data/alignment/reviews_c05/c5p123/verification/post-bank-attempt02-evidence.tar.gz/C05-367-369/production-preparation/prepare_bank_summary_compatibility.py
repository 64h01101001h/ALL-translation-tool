"""Create an attributed external metadata view; preserve the actual bank output."""
from pathlib import Path
import copy,hashlib,json
L=Path(__file__).resolve().parents[1];W=L.parent.parent/'campaign-worktree'
def pin(p):r=p.read_bytes();return {'path':str(p),'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
original_path=W/'data/alignment/reviews_c05/c5p123/verification/summary.json'
original_bytes=original_path.read_bytes();original=json.loads(original_bytes)
review_path=L/'semantic-review/review.json';original_review=json.loads(review_path.read_bytes())
view_path=L/'review-native-compatibility/review.json';view=json.loads(view_path.read_bytes())
assert pin(view_path)['sha256']=='eb00fb41fa539d78d1caa56db78c51962a7dc3be9be1e95b6bd9c1888911b3a0'
assert original['semantic_review']==original_review
aliases={'original_pairs':6,'new_reconciler_pairs':2,'exact_english_reused_pairs':1,'actual_unique_pairs':8,'selected_angle_segment_views':9,'reviewer_generator_runs':0,'reviewer_resolver_runs':0}
stripped=copy.deepcopy(view)
for k,v in aliases.items():
 assert k not in original_review['native_history']
 assert type(stripped['native_history'][k]) is int and stripped['native_history'].pop(k)==v
assert stripped==original_review
result=copy.deepcopy(original);result['semantic_review']=view
recovered=copy.deepcopy(result);recovered['semantic_review']=original_review;assert recovered==original
out=L/'bank-summary-native-compatibility';out.mkdir(exist_ok=False)
f=out/'summary.json';f.write_text(json.dumps(result,indent=2)+'\n')
assert original_path.read_bytes()==original_bytes
proof={'status':'PASS_METADATA_ONLY_BANK_SUMMARY_VIEW','role':'Mechanical complete bank-summary compatibility view; not a new bank execution or semantic approval','original_bank_summary':pin(original_path),'original_frozen_review':pin(review_path),'independent_review_view':pin(view_path),'summary_view':pin(f),'only_changed_field':'semantic_review','seven_aliases':aliases,'all_other_summary_fields_unchanged':True,'removing_review_aliases_recovers_complete_original_review':True,'restoring_original_semantic_review_recovers_complete_original_summary':True,'original_bank_bytes_unchanged':True,'limits':'Original W summary/archive/manifest and all semantic/source/native/production results remain unchanged. Inherited PASS records the original bank outcome; this view only provides the separately attributed review metadata expected by unchanged closure.'}
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
