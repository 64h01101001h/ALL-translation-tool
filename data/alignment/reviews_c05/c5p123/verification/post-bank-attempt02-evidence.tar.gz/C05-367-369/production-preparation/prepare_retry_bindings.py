"""Explicit metadata-only retry plan, retaining first closure and archive bytes."""
from pathlib import Path
import hashlib,json
L=Path(__file__).resolve().parents[1];A=L.parent;W=A.parent/'campaign-worktree'
def pin(p):r=p.read_bytes();return {'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()}
old_path=L/'closure-config.json';old=json.loads(old_path.read_bytes())
assert pin(old_path)['sha256']=='e77f3a147bf1ac7be18ec4088a1d42539651225adcdbfa46873ce7efa7c46667'
adoption=L/'root-native-compatibility-and-ledger-adoption.json';assert pin(adoption)['sha256']=='47f1fefa94ea147372d6cf075bb167c79b66018ffd805a2706d5699b91c7df22'
p={k:v for k,v in old.items() if k not in ('artifacts','callers')}
p['artifacts']={k:v['path'] for k,v in old['artifacts'].items()};a=p['artifacts']
p['callers']={k:str(L/k) for k in old['callers']}
for key in ('review','bank_summary','post_bank_archive','post_bank_manifest','ledger_template','current_root_ledger_reading','closure_preparation_plan'):
 a['attempt01_'+key]=a[key]
a['review']=str(L/'review-native-compatibility/review.json')
a['bank_summary']=str(L/'bank-summary-native-compatibility/summary.json')
a['post_bank_archive']=str(W/'data/alignment/reviews_c05/c5p123/verification/post-bank-attempt02-evidence.tar.gz')
a['post_bank_manifest']=str(W/'data/alignment/reviews_c05/c5p123/verification/post-bank-attempt02-manifest.json')
a['ledger_template']=str(L/'landing/root-ledger-entry-template-attempt02.md')
a['current_root_ledger_reading']=str(adoption)
a['closure_preparation_plan']=str(L/'closure-plan-attempt02.json')
a['attempt01_config']=str(old_path);a['attempt01_root_approval']=str(L/'root-closure-approval.json')
a['attempt01_failure']=str(L/'compact-closure/failure.json')
a['attempt01_preservation']=str(L/'production-preparation/closure-attempt01-preservation.json')
a['attempt01_post_bank_plan']=str(L/'post-bank-plan.json')
a['attempt01_production_handoff']=str(L/'production-closure-handoff.json')
a['current_metadata_adoption']=str(adoption)
a['bank_summary_compatibility_proof']=str(L/'bank-summary-native-compatibility/proof.json')
a['bank_summary_compatibility_method']=str(L/'production-preparation/prepare_bank_summary_compatibility.py')
a['metadata_retry_method']=str(Path(__file__))
a['metadata_retry_dispatch']=str(L/'closure-retry-dispatch.json')
a['post_bank_plan']=str(L/'post-bank-plan-attempt02.json')
for name in ('freeze.json','compatibility-addendum.json','final-review.json'):
 a['independent_native_compatibility_'+name.replace('.','_')]=str(L/'review-native-compatibility'/name)
native=('command.json','execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt')
for name in native:
 a['retry_bindings_caller_'+name.replace('.','_')]=str(A/'L-retry-bindings-caller'/name)
 a['attempt01_final_binder_'+name.replace('.','_')]=str(A/'L-final-config-caller'/name)
for name in ('compact-closure-caller','bank-summary-compatibility-caller','post-bank-pack-attempt02-caller','post-bank-stage-attempt02-caller'):
 p['callers'][name]=str(L/name)
p['historical_failures']['compact-closure-caller']={'exit':1,'reason':'Actual first closure stopped before commits on missing original_pairs in independently frozen review.native_history. Exact original caller/output/config/approval retained; adopted additive independent review and coupled external bank-summary metadata views provide seven strict aliases without changing original judgments, bytes, methods or successful production evidence.'}
p['active_caller']='compact-closure-attempt02-caller';assert p['post_freeze']==[]
assert not (L/'compact-closure-attempt02').exists()
recorder=['python3','-B',str(A/'record_external_step.py')]
pack=['python3','-B',str(A/'reusable-batch-closure-p-profile-candidate/pack_post_bank.py'),a['post_bank_plan'],a['post_bank_archive'],a['post_bank_manifest']]
stage=['git','add','--',str(Path(a['post_bank_archive']).relative_to(W)),str(Path(a['post_bank_manifest']).relative_to(W))]
bind=['python3','-B',str(A/'reusable-batch-closure-p-retry-candidate/bind_config.py'),str(L/'closure-plan-attempt02.json'),str(L/'closure-config-attempt02.json')]
dispatch={'status':'ROOT_AUTHORIZED_METADATA_ONLY_RETRY_PACK_STAGE_BIND','steps':[{'caller':'post-bank-pack-attempt02-caller','record_with':recorder+[str(L/'post-bank-pack-attempt02-caller'),str(W)],'argv':pack},{'caller':'post-bank-stage-attempt02-caller','record_with':recorder+[str(L/'post-bank-stage-attempt02-caller'),str(W)],'argv':stage},{'caller':'L-final-config-attempt02-caller','record_with':recorder+[str(A/'L-final-config-attempt02-caller'),str(W)],'argv':bind}],'root_only':{'active_caller':p['active_caller'],'output':str(L/'compact-closure-attempt02'),'approval':str(L/'root-closure-approval-attempt02.json'),'profile':a['native_reuse_profile']},'limits':'Stop on first failure. No production, bank, whitespace or successful prior stage replay. Root alone executes final closure.'}
(L/'closure-plan-attempt02.json').open('x').write(json.dumps(p,indent=2)+'\n')
(L/'closure-retry-dispatch.json').open('x').write(json.dumps(dispatch,indent=2)+'\n')
# Use the existing explicit packer plan schema. The original W archive/manifest
# are direct immutable sources; no intermediate large copies are needed.
files={old_path,L/'root-closure-approval.json',L/'landing/root-ledger-entry-template-attempt02.md',adoption,Path(__file__),L/'closure-plan-attempt02.json',L/'closure-retry-dispatch.json',L/'production-preparation/closure-attempt01-preservation.json',L/'production-preparation/prepare_bank_summary_compatibility.py',L/'bank-summary-native-compatibility/summary.json',L/'bank-summary-native-compatibility/proof.json',L/'production-closure-handoff.json',L/'post-bank-plan.json'}
files.update(Path(r['path']) for r in json.loads((L/'production-preparation/closure-attempt01-preservation.json').read_text())['files'])
frozen=json.loads((L/'review-native-compatibility/freeze.json').read_bytes());files.add(L/'review-native-compatibility/freeze.json')
for rel,row in frozen['files'].items():
 f=L/'review-native-compatibility'/rel;assert pin(f)==row;files.add(f)
for name in native:
 files.add(L/'bank-summary-compatibility-caller'/name);files.add(A/'L-final-config-caller'/name)
rows=[]
for f in sorted(files):
 assert f.is_file() and not f.is_symlink()
 if f.is_relative_to(A):member=str(f.relative_to(A))
 else:
  assert f==Path(a['attempt01_post_bank_archive']) or f==Path(a['attempt01_post_bank_manifest'])
  member='C05-367-369/preserved-attempt01-post-bank/'+f.name
 rows.append({'original':str(f),'member':member,**pin(f)})
assert len({r['member'] for r in rows})==len(rows)
plan={'schema':'c05-current-post-bank-plan-v1','status':'UNAPPROVED_PLAN','batch':str(L),'earlier_bank_manifest':{'path':a['bank_manifest'],**pin(Path(a['bank_manifest']))},'members':rows,'scope':'Root-authorized exact metadata retry evidence: complete original214-member post-bank archive/manifest, actual first closure/callers/config/approval, independent review and coupled summary views, amended ledger and root adoption. Existing packer verifies every full byte string; original sources and all production evidence are unchanged.'}
Path(a['post_bank_plan']).open('x').write(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'status':'PASS_RETRY_METADATA_PLAN_PREPARED','artifacts':len(a),'callers':len(p['callers']),'members':len(rows),'post_freeze':p['post_freeze'],'active_caller':p['active_caller'],'historical_failures':p['historical_failures']},indent=2))
