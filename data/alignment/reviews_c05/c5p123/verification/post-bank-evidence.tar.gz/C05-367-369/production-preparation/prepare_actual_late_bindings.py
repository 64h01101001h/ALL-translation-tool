"""Refresh only actual L late paths and reviewed v6 failure/success bindings."""
from pathlib import Path
import copy,json
L=Path(__file__).resolve().parents[1];A=L.parent
p=json.loads((L/'closure-plan-v3.json').read_text());d=json.loads((L/'production-dispatch-plan-v3.json').read_text())
a=p['artifacts']
for key in ('whitespace_preparation','whitespace_pin_method','whitespace_method_review','whitespace_method_review_freeze','whitespace_method_tests'):
 a['previous_'+key]=a[key]
a['whitespace_preparation']=str(L/'landing/whitespace-v6-preparation/whitespace-pin-preparation.json')
a['whitespace_pin_method']=str(A/'prepare_review_whitespace_pins_v6.py')
a['whitespace_method_review']=str(A/'whitespace-v6-independent-review-binding.json')
a['whitespace_method_review_freeze']=str(A/'whitespace-v6-independent-review/freeze.json')
a['whitespace_method_tests']=str(A/'whitespace-v6-independent-review/test-results.json')
new={
 'whitespace_v6_candidate_freeze':A/'whitespace-v6-candidate/candidate-freeze.json',
 'whitespace_v6_candidate_diff':A/'whitespace-v6-candidate/exact-v5-to-v6.diff',
 'whitespace_v6_candidate_tests':A/'whitespace-v6-candidate/test-results.json',
 'whitespace_v6_candidate_test_method':A/'whitespace-v6-candidate/test_changed_boundaries.py',
 'whitespace_v6_history_pins':A/'whitespace-v6-candidate/actual-history-and-output-pins.json',
 'whitespace_v6_actual_review':A/'whitespace-v6-independent-review/review.json',
 'whitespace_v6_root_adoption':A/'whitespace-v6-root-adoption.json',
 'whitespace_v6_fresh_pins':L/'landing/whitespace-v6-preparation/review-whitespace-exact-pins.json',
 'whitespace_actual_first_failure':L/'production-preparation/whitespace-v12-attempt01-failure.json',
 'production_reproduction_checkpoint':L/'production-reproduction-checkpoint.json',
 'root_dispatch_approval':L/'root-dispatch-review.json',
 'actual_late_bindings_method':Path(__file__),
 'previous_closure_plan_v3':L/'closure-plan-v3.json',
 'previous_production_dispatch_v3':L/'production-dispatch-plan-v3.json',
 'post_bank_plan':L/'post-bank-plan.json',
}
for name in ('review-whitespace-exact-pins.json','whitespace-pin-preparation.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit'):
 new['whitespace_first_'+name.replace('.','_').replace('-','_')]=L/'production-preparation/whitespace-attempt01-preserved'/name
native=('command.json','execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt')
for root,label in ((A/'whitespace-v6-candidate/tests-caller','v6_author_test'),(A/'whitespace-v6-independent-review/tests-caller','v6_independent_test'),(A/'L-post-bank-plan-caller','post_bank_plan_caller')):
 for name in native:new[label+'_'+name.replace('.','_')]=root/name
for key,path in new.items():a[key]=str(path)
a['closure_preparation_plan']=str(L/'closure-plan-v4.json');a['production_dispatch_plan']=str(L/'production-dispatch-plan-v4.json')
for name in ('whitespace-pins-v6-caller','whitespace-pins-v6-activation-caller','whitespace-audit-attempt02-caller','late-bindings-caller'):
 p['callers'][name]=str(L/name)
p['historical_failures']['whitespace-audit-caller']={'exit':1,'reason':'Actual v12 attempt01 rejected the sole independently frozen governance-diff context-space line omitted by v5 basename selection. Original zero-pin proof, six-file failure and five preimages preserved; separately reviewed v6 and unchanged-v12 attempt02 succeeded, with no source/index normalization or successful-call replay.'}
p['required_roles']['whitespace']='whitespace-audit-attempt02-caller'
for s in d['sequential_steps']:
 caller=L/s['caller']
 if (caller/'execution.json').exists():
  ex=json.loads((caller/'execution.json').read_text());s['status']='COMPLETED_DO_NOT_REPLAY' if ex['exit']==0 else 'ACTUAL_FAILED_PRESERVED_REPLACED_BY_REVIEWED_RETRY'
for s in d['sequential_steps'][17:]:assert s['status']=='NOT_RUN'
d['completed_whitespace_correction']={'v5_success_preserved':str(L/'whitespace-pins-v5-caller'),'failed_v12':str(L/'whitespace-audit-caller'),'v6_success':str(L/'whitespace-pins-v6-caller'),'activation':str(L/'whitespace-pins-v6-activation-caller'),'passed_v12':str(L/'whitespace-audit-attempt02-caller'),'new_preparation':a['whitespace_preparation'],'source_and_index_unchanged':True}
d['bind_only_after_all_actual_outputs'][3]=str(L/'closure-plan-v4.json')
old_extra=set(d['post_bank_plan_argv'][i+1] for i,x in enumerate(d['post_bank_plan_argv']) if x=='--extra')
exclude={str(L/'post-bank-plan.json')}|{str(A/'L-post-bank-plan-caller'/n) for n in native}
extra=old_extra|{v for v in a.values() if Path(v).is_relative_to(A) and v not in exclude}
argv=d['post_bank_plan_argv'][:7]
for v in sorted(extra):argv+=['--extra',v]
argv+=['--output',str(L/'post-bank-plan.json')];d['post_bank_plan_argv']=argv
d['post_bank_plan_record_with']=['python3','-B',str(A/'record_external_step.py'),str(A/'L-post-bank-plan-caller'),p['repository']]
for path,obj in ((L/'closure-plan-v4.json',p),(L/'production-dispatch-plan-v4.json',d)):
 path.open('x').write(json.dumps(obj,indent=2)+'\n')
missing=[str(Path(v)) for v in extra if not Path(v).is_file()]
assert missing==[],missing
assert p['active_caller']=='compact-closure-caller'
assert p['required_roles']['whitespace'] not in p['historical_failures']
print(json.dumps({'status':'PASS_EXPLICIT_LATE_BINDINGS_PREPARED','artifacts':len(a),'callers':len(p['callers']),'failures':p['historical_failures'],'extra_files':len(extra),'limits':'No packing, staging, binding or closure performed by this script.'},indent=2))
