"""One bounded artifact-only K/L dispatch comparison; no production or receipt invocation."""
from pathlib import Path
import ast,copy,datetime,difflib,hashlib,json,re,shutil
P=Path(__file__).resolve().parent;B=P.parent;A=B.parent;K=A/'C05-364-366';W=A.parent/'campaign-worktree'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
kd=read(K/'production-dispatch-plan-v2.json');ld=read(B/'production-dispatch-plan-v2.json');kc=read(K/'closure-plan-v2.json');lc=read(B/'closure-plan-v2.json')
replacements={str(K):str(B),'C05-364-366':'C05-367-369','e4da4c94f59f4af61de90fde63127890130c5902':'1be02f91d0c7546f4997d25cafd19c976ba4db3e','1be02f91d0c7546f4997d25cafd19c976ba4db3e':'ddfc2e56beb3245e821c351be7cfe087c782cb78','c5p121':'c5p122','c5p122':'c5p123','compact-reproduction-through366':'compact-reproduction-through369','baseline-through363-caller':'baseline-through366-caller','K-final-config-caller':'L-final-config-caller'}
pattern=re.compile('|'.join(re.escape(k)for k in sorted(replacements,key=len,reverse=True)))
def normalize(s):return {'364':'367','365':'368','366':'369','122':'123'}.get(s,pattern.sub(lambda m:replacements[m.group()],s))
assert len(kd['sequential_steps'])==len(ld['sequential_steps'])==19
command_rows=[]
for a,b in zip(kd['sequential_steps'],ld['sequential_steps']):
 assert a['caller']==b['caller']
 assert [normalize(x)for x in a['argv']]==b['argv'],b['caller']
 assert [normalize(x)for x in a['record_with']]==b['record_with'] and a['cwd']==b['cwd']==str(W)
 assert 'Stop on first nonzero' in b['execution_rule']
 if b['argv'][:3]==['python3','-B','-c']:
  ast.parse(b['argv'][-1]);code=ast.parse(b['argv'][-1]);vals=[x.value for x in ast.walk(code)if isinstance(x,ast.Constant)and isinstance(x.value,str)and x.value in ['\n','\\n']];assert vals==['\n']
 else:assert shutil.which(b['argv'][0]),b['argv'][0]
 command_rows.append(dict(caller=b['caller'],command_logic='UNCHANGED',changed_argv_indexes=[i for i,(u,v)in enumerate(zip(a['argv'],b['argv']))if u!=v],normalized_argument_identity=True))
assert kd['root_approval_contract']==ld['root_approval_contract']
assert [normalize(x)for x in kd['root_only_closure_argv']]==ld['root_only_closure_argv']
assert kc['required_roles']==lc['required_roles'] and lc['active_caller']=='compact-closure-caller'and lc['historical_failures']=={}and lc['post_freeze']==[]and lc['retrospective']is None
assert set(lc['callers'])==set(x['caller']for x in ld['sequential_steps'])|{'source-preparation-caller','proposal-origin-caller','baseline-through366-caller'}
assert all(v==str(B/k)for k,v in lc['callers'].items())
# Current ROOT-owned input already completed; bind actual receipt and never schedule it again.
C=B/'root-input-caller';ex=read(C/'execution.json');assert ex['exit']==0 and(C/'exit.txt').read_text()=='0\n'and(C/'stderr.bin').read_bytes()==b''
for name in ['stdout','stderr']:
 p=C/(name+'.bin');assert len(p.read_bytes())==ex[name+'_bytes']and pin(p)['sha256']==ex[name+'_sha256']
recon=B/'reconciled/freeze.json';assert pin(recon)==dict(bytes=30707,sha256='fa0eec3e44466c3f3c1f8bdf1f6cc6c22f8ac48447af044aacd47b69126cef17')
assert ex['argv']==['python3','-B',str(B/'root-input-receipt.py'),pin(recon)['sha256']]
for name in ['root-input-receipt','root-acceptance-receipt']:
 assert(B/(name+'.py')).read_bytes()==(P/(name+'.candidate-v2.py')).read_bytes()
proof=read(B/'root-current-inputs/proof.json');assert proof['status']=='PASS_ROOT_INPUTS' and proof['final_spans']==88 and proof['baseline']=='ddfc2e56beb3245e821c351be7cfe087c782cb78'
completed=dict(status='ALREADY_COMPLETED_REUSE_NO_RERUN',execution=dict(path=str(C/'execution.json'),**pin(C/'execution.json')),actual_argv=ex['argv'],exit=0,stdout_bytes=136,stderr_bytes=0,proof=dict(path=str(B/'root-current-inputs/proof.json'),**pin(B/'root-current-inputs/proof.json')))
nd=copy.deepcopy(ld);nc=copy.deepcopy(lc)
step=next(s for s in nd['sequential_steps']if s['caller']=='root-input-caller');step['status']='ALREADY_COMPLETED_REUSE_NO_RERUN';step['argv']=ex['argv'];step['actual_completion']=completed
nd['completed_prerequisites']['root-input-caller']=completed;nd['historical_captures']['root-input-caller']='Actual ROOT input passed once; reuse its complete existing caller and proof. Never execute this step again.'
nd['resolved_arguments']={'REQUIRED_ACTUAL_RECONCILIATION_FREEZE_SHA256':dict(path=str(recon),**pin(recon))};nd['dynamic_arguments'].pop('REQUIRED_ACTUAL_RECONCILIATION_FREEZE_SHA256')
nd['bind_only_after_all_actual_outputs'][3]=str(B/'closure-plan-v3.json')
nc['artifacts']['production_dispatch_plan']=str(B/'production-dispatch-plan-v3.json');nc['artifacts']['closure_preparation_plan']=str(B/'closure-plan-v3.json')
nc['artifacts']['prior_dispatch_v2']=str(B/'production-dispatch-plan-v2.json');nc['artifacts']['prior_closure_plan_v2']=str(B/'closure-plan-v2.json')
nc['artifacts']['current_dispatch_delta_review']=str(P/'dispatch-delta-review.json');nc['artifacts']['current_dispatch_delta_note']=str(P/'dispatch-delta-review.md');nc['artifacts']['current_dispatch_delta_method']=str(Path(__file__));nc['artifacts']['current_dispatch_delta_paths']=str(P/'dispatch-path-snapshot.json');nc['artifacts']['current_preparation_handoff']=str(P/'handoff.json')
for name in ['command.json','execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt']:nc['artifacts']['dispatch_delta_caller_'+name.replace('.','_')]=str(P/'dispatch-delta-review-caller'/name)
nc['artifacts']['dispatch_raw_delta']=str(P/'dispatch-K-v2-to-L-v2.diff');nc['artifacts']['closure_plan_raw_delta']=str(P/'closure-plan-K-v2-to-L-v2.diff')
# Refresh just exact late extras; unchanged existing pack/plan/bind methods and first closure semantics.
extras=sorted(set(v for v in nc['artifacts'].values()if v.startswith(str(A))))
nd['post_bank_plan_argv']=['python3','-B',nc['artifacts']['post_bank_plan_method'],'--batch',str(B),'--bank-manifest',nc['artifacts']['bank_manifest']]+[z for p in extras for z in ['--extra',p]]+['--output',str(B/'post-bank-plan.json')]
assert nd['root_only_closure_argv'][-1]==str(B/'compact-closure')and not(B/'compact-closure').exists()
assert str(B/'root-closure-approval.json')in nd['root_only_closure_argv']and not(B/'root-closure-approval.json').is_relative_to(B/'compact-closure')
pathrows={};missing=[]
for key,value in lc['artifacts'].items():
 p=Path(value);assert p.is_absolute();assert p.is_relative_to(A)or p.is_relative_to(W)or str(p).startswith('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through369/')
 if p.is_file():
  p.open('rb').close();pathrows[key]=dict(path=value,status='EXISTS_READABLE',**pin(p))
 else:pathrows[key]=dict(path=value,status='PENDING_ACTUAL_OUTPUT');missing.append(key)
method_keys=['closure_method','method_review','candidate_freeze','registration_method','whitespace_method','whitespace_pin_method','whitespace_method_review','semantic_acceptance_method','post_bank_plan_method','post_bank_pack_method','binder_method','native_reuse_profile','native_reuse_core_copy','native_reuse_candidate_freeze','native_reuse_independent_review','native_reuse_independent_freeze']
for key in method_keys:assert lc['artifacts'][key]==kc['artifacts'][key]and pathrows[key]['status']=='EXISTS_READABLE'
assert pin(Path(lc['artifacts']['closure_method']))==ld['root_approval_contract']['method']and pin(Path(lc['artifacts']['native_reuse_profile']))==ld['root_approval_contract']['profile_method']
artifact_changes=[dict(key=k,old=kc['artifacts'][k],current=v,normalized_parameter_only=normalize(kc['artifacts'][k])==v)for k,v in lc['artifacts'].items()if k in kc['artifacts']and kc['artifacts'][k]!=v]
# All verification above precedes writing the new review/version outputs.
put(P/'dispatch-path-snapshot.json',dict(status='READ_ONLY_PREPARATION_PATH_SNAPSHOT',artifacts=pathrows,pending=missing,limit='Pending review/production files are not credited as current results; final binding must wait for all required actual outputs. Newly emitted review and version files are separately pinned below.'))
put(B/'production-dispatch-plan-v3.json',nd);put(B/'closure-plan-v3.json',nc)
for label,old,new in [('dispatch',K/'production-dispatch-plan-v2.json',B/'production-dispatch-plan-v2.json'),('closure-plan',K/'closure-plan-v2.json',B/'closure-plan-v2.json')]:
 (P/(label+'-K-v2-to-L-v2.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new))))
record=dict(status='PASS_BOUNDED_DISPATCH_DELTA_REVIEW',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Artifact-only author-side mechanical delta review; no independent semantic approval or production execution.',requested_predecessors={str(p):pin(p)for p in [K/'production-dispatch-plan-v2.json',K/'closure-plan-v2.json']},actual_closure_construction_reference=dict(path=str(K/'closure-plan-v3.json'),**pin(K/'closure-plan-v3.json'),note='L preparation actually used the successful K closure-plan-v3 graph. Requested v2 comparison also recorded exactly; K v3 only reflected its late ledger receipt/evidence refresh.'),reviewed_versions={str(p):pin(p)for p in [B/'production-dispatch-plan-v2.json',B/'closure-plan-v2.json']},parameter_substitutions=replacements,counts=dict(page=123,previous_page=122,source_origin_through=363,actual_baseline_through=366,final_segments=[367,368,369],final_spans=88,nonnull_d5=61,d7=1,nulls=2,original_spans=175,original_members=272,original_questions=0),commands=command_rows,changed_production_command_logic=[],root_adapter_delta='Root already approved the separately pinned candidate-v2 diffs: L literals/zero questions and only explicit369/T/w11→p37 depth5→6 under the exact root-decision hash. No other method logic changed.',closure_graph=dict(shared_method_paths_unchanged=method_keys,required_roles_unchanged=True,active_caller='compact-closure-caller',historical_failures={},artifact_edge_changes=artifact_changes,added_keys=sorted(set(lc['artifacts'])-set(kc['artifacts'])),removed_keys=sorted(set(kc['artifacts'])-set(lc['artifacts'])),caller_names=sorted(lc['callers'])),stop_on_failure='All19 steps explicitly require a separately inspected recorded call and stop on first nonzero. This is a dispatch document, not an automatic executable driver; runtime enforcement is the future executor responsibility. No chained shell, automatic rerun, receipt execution or production execution was performed by this review.',path_snapshot=pin(P/'dispatch-path-snapshot.json'),path_counts=dict(total=len(pathrows),existing=len(pathrows)-len(missing),pending=len(missing)),root_input_already_completed=completed,reconciliation_freeze=dict(path=str(recon),**pin(recon)),final_semantic_review='Still unresolved: no final review hash supplied or acceptance executed by this role.',new_active_versions={str(p):pin(p)for p in [B/'production-dispatch-plan-v3.json',B/'closure-plan-v3.json']},version3_delta='Marks actual root-input-caller completed and non-runnable; supplies actual immutable reconciliation hash; updates only current plan and bounded review/late-evidence edges. All later production argv unchanged. Final review remains pending.',worktree_writes=0,production_executions=0,receipt_executions=0)
put(P/'dispatch-delta-review.json',record)
(P/'dispatch-delta-review.md').write_text('K-v2 → L-v2 dispatch comparison passed: all19 recorded production argv are byte-identical after explicit batch/page/origin/baseline substitutions. No production-command logic changed.\nShared core/profile, fifteen required roles, exact approval literals, explicit git-add scope and archive methods remain unchanged; L uses first compact-closure-caller with no inherited K failure mapping.\nThe root-approved adapter delta is only current constants/zero source questions and exact369/T/w11 depth5→6. Raw diffs and all132 current artifact paths are banked; absent final review/production outputs remain pending.\nUse production-dispatch-plan-v3.json and closure-plan-v3.json now: actual root-input-caller already passed once and MUST NOT run again. Actual reconciliation freeze fa0eec3e44466c3f3c1f8bdf1f6cc6c22f8ac48447af044aacd47b69126cef17 is supplied; final semantic review remains pending.\nEach future call must stop on first failure before another dependency. This document has no executable driver and claims no runtime enforcement from prose alone. No receipts, source/native engines, production, tests, reproduction, staging or W mutation ran in this review.\nRoot retains sole production/closure authority pending explicit acceptance. Version3 changes only completed-input status/known reconciliation pin/current evidence edges; version2 and original preparation failures remain preserved.\n')
print(json.dumps(dict(status=record['status'],commands=len(command_rows),changed_command_logic=0,current_paths=record['path_counts'],review=pin(P/'dispatch-delta-review.json'),dispatch_v3=pin(B/'production-dispatch-plan-v3.json'),closure_plan_v3=pin(B/'closure-plan-v3.json'),root_input_status='COMPLETED_REUSE_NO_RERUN',production_executions=0),indent=2))
