"""Artifact-only literal K-to-L preparation; never invokes production or writes W."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,re
R=Path(__file__).resolve().parents[3];A=R/'campaign-artifacts';K=A/'C05-364-366';B=A/'C05-367-369';P=B/'production-preparation';W=R/'campaign-worktree'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base=read(B/'baseline.json');origin=read(B/'proposal-baseline.json');choices=read(B/'root-reconciliation-decisions.json')
assert base['commit']=='ddfc2e56beb3245e821c351be7cfe087c782cb78' and base['course_boundary']==366
assert origin['commit']=='1be02f91d0c7546f4997d25cafd19c976ba4db3e' and origin['course_boundary']==363
assert pin(B/'root-reconciliation-decisions.json')==dict(bytes=40713,sha256='9c4eeb79811704ff57b9088cf01491fff27af98edbe31fb18394d8828b6c6158')
assert choices['expected']==dict(total_spans=88,segments={'367':25,'368':28,'369':35},total_nulls=2,total_word_pairs=61,total_d5=61,total_d7=1,proposed_errata=0)
assert choices['native_plan']['reuse_entire_english_segments']==[368] and choices['native_plan']['changed_segments']==[367,369]
oldbase='1be02f91d0c7546f4997d25cafd19c976ba4db3e';oldorigin='e4da4c94f59f4af61de90fde63127890130c5902'
replacements={str(K):str(B),'C05-364-366':'C05-367-369',oldbase:base['commit'],oldorigin:origin['commit'],'c5p121':'c5p122','c5p122':'c5p123','compact-reproduction-through366':'compact-reproduction-through369','baseline-through363-caller':'baseline-through366-caller','K-final-config-caller':'L-final-config-caller'}
pattern=re.compile('|'.join(re.escape(k)for k in sorted(replacements,key=len,reverse=True)))
def textadapt(s):return pattern.sub(lambda m:replacements[m.group()],s)
def adapt(x):
 if isinstance(x,str):return {'364':'367','365':'368','366':'369','122':'123'}.get(x,textadapt(x))
 if isinstance(x,list):return[adapt(v)for v in x]
 if isinstance(x,dict):return{k:adapt(v)for k,v in x.items()}
 return x
# Exact executed predecessor helpers, with current literals and zero-question interface.
method_rows=[]
for name in ['root-input-receipt.py','root-acceptance-receipt.py']:
 old=(K/name).read_text();s=textadapt(old)
 for a,b in [('range(364,367)','range(367,370)'),('(364,365,366)','(367,368,369)'),('[364,365,366]','[367,368,369]'),("'365-","'368-"),('f\'365-','f\'368-'),("'english/365/","'english/368/"),("'reconciled/365/","'reconciled/368/"),('changed364/366','changed367/369'),('English365','English368')]:
  s=s.replace(a,b)
 # Scalar source and incoming boundaries are intentionally separate.
 s=s.replace("base['course_boundary']==363 and origin['course_boundary']==357","base['course_boundary']==366 and origin['course_boundary']==363")
 s=s.replace("['later_baseline_accepted_through']==363","['later_baseline_accepted_through']==366")
 s=s.replace("dict(bytes=34675,sha256='4724e72c779e0711059107a0bcfe29c416ccd9442247c75bd8719733521d8bd4')","dict(bytes=40713,sha256='9c4eeb79811704ff57b9088cf01491fff27af98edbe31fb18394d8828b6c6158')")
 s=s.replace("dict(total_spans=70,segments={'364':31,'365':10,'366':29},total_nulls=1,total_word_pairs=42,total_d5=42,total_d7=9,proposed_errata=0)","dict(total_spans=88,segments={'367':25,'368':28,'369':35},total_nulls=2,total_word_pairs=61,total_d5=61,total_d7=1,proposed_errata=0)")
 s=s.replace('[70,1,42,9]','[88,2,61,1]').replace('[31,10,29]','[25,28,35]').replace('dict(spans=70,nulls=1,nonnull_d5=42,total_d5=42,d7=9)','dict(spans=88,nulls=2,nonnull_d5=61,total_d5=61,d7=1)')
 s=re.sub(r'\b135\b','175',s);s=re.sub(r'\b243\b','272',s);s=re.sub(r'\b70\b','88',s)
 if name=='root-input-receipt.py':
  start=s.index("questions=[dict(angle='english'");end=s.index("save(B/'root-reconciliation-verification",start)
  s=s[:start]+"questions=[]\nfor seq in (367,368,369):\n    assert read(B/f'english/{seq}/errata-review.json')['source_questions']==[]\n    assert read(B/f'tibetan/{seq}/source-questions.json')==[]\n    for angle in ('english','tibetan'):assert read(B/angle/str(seq)/'errata.json')==[]\n"+s[end:]
 else:
  s=s.replace("len(inputs['original_source_questions'])==1","len(inputs['original_source_questions'])==0")
  s=s.replace('exact K selected_id','exact L selected_id').replace('Approve the70 provisional spans31/10/29','Approve the88 provisional spans25/28/35')
  start=s.index("errata_decision='");end=s.index("',errata=[],allowances",start)
  s=s[:start]+"errata_decision='No new errata or head allowance. Both immutable original angles have zero source-question objects and empty errata. Preserve all original five-ground screens and root evidence corrections, including literal HTG2016 deed versus an inaccurate mined-tier description and the third/fourth ordinal glossary limitation. Ordinary empty-errata production must retain all204 register entries unchanged between source origin363 and actual baseline366."+s[end:]
 s=s.replace('changed364/366','changed367/369').replace('English365','English368').replace('spans31/10/29','spans25/28/35')
 if name=='root-input-receipt.py':
  oldline="    sp=dict(matches[0]);sp['id']=selected_id;assert sp==item['span']"
  newline="""    sp=dict(matches[0]);sp['id']=selected_id
    if 'root_adaptation' in item:
        a=item['root_adaptation']
        assert (seq,angle,sid,selected_id)==(369,'tibetan','w11','p37')
        assert set(a)=={'field','original','selected','reason'} and a['field']=='d'
        assert a['original']==sp['d']==5 and a['selected']==item['span']['d']==6 and a['reason'].strip()
        sp['d']=a['selected']
    assert sp==item['span']"""
  assert oldline in s;s=s.replace(oldline,newline)
 ast.parse(s);q=P/name.replace('.py','.candidate-v2.py');assert not q.exists();q.write_text(s);df=P/name.replace('.py','.diff-v2.txt');df.write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(K/name),tofile=str(q))));method_rows.append(dict(previous=str(K/name),previous_pin=pin(K/name),candidate=str(q),candidate_pin=pin(q),diff=str(df)))
# Data-only adaptation of the proven dispatch. No speculative execution or final receipt.
d=adapt(read(K/'production-dispatch-plan-v2.json'));d.update(status='PREPARATION_ONLY_NOT_AUTHORIZED_TO_RUN',page=123,segments=[367,368,369],source_origin=origin['commit'],actual_baseline=base['commit'],paired_actual_data_commit='ffbce5b73f36390b0732dc58edbd40aa98fc641f',root_choices=dict(path=str(B/'root-reconciliation-decisions.json'),**pin(B/'root-reconciliation-decisions.json')),expected_counts=dict(spans=88,by_segment=[25,28,35],nonnull_d5=61,total_d5=61,d7=1,nulls=2,new_errata=0,new_links_including_three_segment_anchors=91,original_spans=175,original_frozen_members=272,original_source_questions=0))
for step in d['sequential_steps']:
 step['status']='NOT_RUN';step['execution_rule']='Execute this single recorded argv only after explicit root authorization and all dependencies succeeded; inspect recorder exit before any following step. Stop on first nonzero; preserve streams and do not replay completed callers.'
 if step['caller']=='root-input-caller':step['prerequisites']=['Root adopts the exact current candidate or supplies its own helper after immutable reconciliation; verify all272 original members,175 original spans and zero original question objects.']
 if step['caller']=='reproduction-caller':step['prerequisites']=['All earlier production calls passed once.','Use the actual through366 incoming main-CSV seed; fresh compact-reproduction-through369 destination.']
 if step['caller']=='stage-data-caller':step['scope']='Explicit L stage scope: seven generated outputs, previous122 navigation/current123 page, index/spec/review tree, builder registration. No errata-register or allowance edits; preserve all unrelated tracked/untracked work.'
 if step['caller']=='compact-bank-caller':step['prerequisites']=['Actual current seven-output reproduction proof is complete; root reads it and supplies current method-review receipt before banking.']
 if step['caller']=='post-bank-pack-caller':step['prerequisites']=['Root reads the actual measured ledger; current root-ledger-reading.json receipt exists.','Refresh explicit plan with all actual late/current/failure callers and files, then run post-bank plan generation and this one fresh pack. Preserve every suffix and successful prior calls.']
d['historical_captures']={};d['completed_prerequisites']={}
for name in ['source-preparation-caller','proposal-origin-caller','baseline-through366-caller']:
 C=B/name;ex=read(C/'execution.json');assert ex['exit']==0 and (C/'exit.txt').read_text().strip()=='0' and (C/'stderr.bin').read_bytes()==b''
 d['historical_captures'][name]='Actual completed caller: reuse exact capture, never replay. No top-level L prerequisite failure observed.'
 d['completed_prerequisites'][name]=dict(status='ALREADY_COMPLETED_REUSE_NO_RERUN',execution=dict(path=str(C/'execution.json'),**pin(C/'execution.json')),actual_argv=ex['argv'],exit=ex['exit'],stderr_bytes=0)
d['native_semantic_execution_scope']='Six original pairs plus changed367/369 pairs = eight unique executions per kind. Whole English368 spec/note/body/ranges and five-file native pair are copied exactly, giving nine views. Root/reviewer do not generate or resolve.'
d['refresh_before_late_bank']='Derive a successor only if actual late paths change; bind all actual L source/proposal/reconciliation/review/root/production evidence and failures, preserving every suffix. No K retry or preparation-error history is inherited. Shared adopted method lineage is pinned independently; successful stages are not repeated for packaging.'
d['root_approval_preflight']='Root copies verdict and reviewed_scope literals exactly, asserts actual final config/core/profile pins and its completed reading, and stores root-closure-approval.json outside absent compact-closure output. First L compact-closure-caller; no inherited prior-batch failures.'
d['stop_on_failure']='Each production command is a separate inspected invocation, or subprocess.run(...,check=True) if root later chooses a checked driver. No unguarded shell chain or unrecorded retry is permitted. This preparation executes none.'
# Keep the shared method/artifact graph; drop every K-specific late/history edge and rebuild L actual paths.
c=adapt(read(K/'closure-plan-v3.json'));c['batch']=str(B);c['historical_failures']={};c['active_caller']='compact-closure-caller';c['post_freeze']=[];c['retrospective']=None
basekeys=list(read(K/'closure-plan-v3.json')['artifacts'])[:65];c['artifacts']={k:c['artifacts'][k]for k in basekeys};c['artifacts']['production_read_only_inspection_history']=str(P/'read-only-inspection-history.json');c['artifacts']['preparation_newline_ast_inspection']=str(P/'newline-ast-inspection-v2.json');c['artifacts']['preparation_method']=str(Path(__file__))
for p in sorted(B.glob('root-*.json')):c['artifacts']['current_'+p.stem.replace('-','_')]=str(p)
for key,rel in {'current_root_assembled_reading':'root-assembled-reading.json','current_root_final_review_reading':'root-final-review-reading.json','current_root_reconciliation_intake':'root-reconciliation-intake.json','current_root_semantic_disposition':'root-semantic-disposition.json','current_root_ledger_reading':'root-ledger-reading.json','root_reconciliation_resolved_spans':'root-reconciliation-verification/resolved-spans.json'}.items():c['artifacts'][key]=str(B/rel)
c['callers']={s['caller']:str(B/s['caller'])for s in d['sequential_steps']}
for n in d['completed_prerequisites']:c['callers'][n]=str(B/n)
assert 'source-preparation-attempt02-caller' not in c['callers'];assert all(v.startswith(str(B))for v in c['callers'].values())
for key,rel in {'production_dispatch_plan':'production-dispatch-plan-v2.json','closure_preparation_plan':'closure-plan-v2.json','preparation_inventory':'closure-preparation-inventory-v2.json','preparation_ledger':'production-preparation/root-ledger-entry-template.preparation-v2.md','prepared_root_input_candidate':'production-preparation/root-input-receipt.candidate-v2.py','prepared_root_acceptance_candidate':'production-preparation/root-acceptance-receipt.candidate-v2.py','prepared_root_input_diff':'production-preparation/root-input-receipt.diff-v2.txt','prepared_root_acceptance_diff':'production-preparation/root-acceptance-receipt.diff-v2.txt','preparation_review':'production-preparation/readiness-v2.json','preparation_notes':'production-preparation/README-v2.md','preparation_newline_ast_inspection':'production-preparation/newline-ast-inspection-v2.json'}.items():c['artifacts'][key]=str(B/rel)
for i,p in enumerate(sorted(P.rglob('*'))):
 if p.is_file() and 'preparation-attempt02-caller' not in str(p):c['artifacts']['preserved_preparation_'+str(i)]=str(p)
for name in ['command.json','execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt']:c['artifacts']['preparation_success_caller_'+name.replace('.','_')]=str(P/'preparation-attempt02-caller'/name)
c['artifacts']['original_preparation_dispatch']=str(B/'production-dispatch-plan.json');c['artifacts']['original_preparation_closure_plan']=str(B/'closure-plan.json')
d['ledger_preparation']=str(P/'root-ledger-entry-template.preparation-v2.md')
# Explicit late plan is generated only after the current bank and root readings exist.
extras=sorted(set(v for v in c['artifacts'].values()if v.startswith(str(A))) - {c['artifacts'][k]for k in ['post_bank_archive','post_bank_manifest']})
d['post_bank_plan_argv']=['python3','-B',c['artifacts']['post_bank_plan_method'],'--batch',str(B),'--bank-manifest',c['artifacts']['bank_manifest']]+[z for p in extras for z in ['--extra',p]]+['--output',str(B/'post-bank-plan.json')]
d['bind_only_after_all_actual_outputs']=['python3','-B',c['artifacts']['binder_method'],str(B/'closure-plan-v2.json'),str(B/'closure-config.json')]
ledger='''PREPARATION ONLY — this is not the live append-only campaign entry.

Planned C05:367–369 (page123) uses source origin1be02f91d0c7546f4997d25cafd19c976ba4db3e through363 and actual acceptance baseline @BASE@ through366 (DOCS ddfc2e56beb3245e821c351be7cfe087c782cb78; paired DATA ffbce5b73f36390b0732dc58edbd40aa98fc641f).
Root selected88 provisional spans25/28/35,61 nonnull d5,1 d7,2 nulls and0 errata; these expected counts are not a production outcome. Six original pairs plus two changed367/369 pairs give eight unique pairs and nine views with whole English368 reuse, subject to exact final input checking.
After actual root acceptance and production, write landing/root-ledger-entry-template.md with measured coverage/retention/seven outputs/17 tests/reproduction/whitespace/integration limits and actual failures. The final three ledgers must append the identical entry using exact @DATA@, @BASE@ and @UTC@ placeholders. Do not copy this pending prose into a completion claim.
No source/master/hgm_gloss changes, paid calls, releases, MAIN merge or device acceptance are authorized here.
'''
(P/'root-ledger-entry-template.preparation-v2.md').write_text(ledger)
save(B/'closure-plan-v2.json',c);save(B/'production-dispatch-plan-v2.json',d)
# Meaningful preparation inspection: parsed actual commands, current selection interface, actual newline constants.
originals={};members=0;original_count=0
for angle in ['english','tibetan']:
 f=read(B/angle/'freeze.json');members+=len(f['files'])
 for seq in [367,368,369]:
  spans=read(B/angle/str(seq)/'spec.json')['segments'][0]['spans'];original_count+=len(spans)
  for sp in spans:originals[(seq,angle,sp['id'])]=sp
assert members==272 and original_count==175
for item in choices['selected_original_items']:
 sp=dict(originals[(item['seq'],item['original_angle'],item['original_id'])]);sp['id']=item['selected_id']
 if 'root_adaptation' in item:
  a=item['root_adaptation'];assert (item['seq'],item['original_angle'],item['original_id'],item['selected_id'])==(369,'tibetan','w11','p37');assert set(a)=={'field','original','selected','reason'}and a['field']=='d'and a['original']==sp['d']==5 and a['selected']==item['span']['d']==6 and a['reason'].strip();sp['d']=a['selected']
 assert sp==item['span']
assert len(choices['selected_original_items'])==88
for seq in [367,368,369]:
 assert read(B/f'english/{seq}/errata-review.json')['source_questions']==[] and read(B/f'tibetan/{seq}/source-questions.json')==[]
line_checks=[]
for name in ['root-input-receipt.candidate-v2.py','root-acceptance-receipt.candidate-v2.py']:
 tree=ast.parse((P/name).read_text());vals=[n.value for n in ast.walk(tree)if isinstance(n,ast.Constant)and isinstance(n.value,str)and n.value in ['\n','\\n']];assert vals==['\n'];line_checks.append(dict(path=str(P/name),constants=[list(map(ord,v))for v in vals],pin=pin(P/name)))
inline=next(s for s in d['sequential_steps']if s['caller']=='frozen-copy-completeness-caller')['argv'][-1];tree=ast.parse(inline);vals=[n.value for n in ast.walk(tree)if isinstance(n,ast.Constant)and isinstance(n.value,str)and n.value in ['\n','\\n']];assert vals==['\n'];line_checks.append(dict(path='production-dispatch-plan.json:frozen-copy-completeness-caller argv[-1]',constants=[list(map(ord,v))for v in vals]))
assert ".open('xb').write(raw)"in inline and 'suffix_filter_used' in inline
stage=next(s for s in d['sequential_steps']if s['caller']=='stage-data-caller')['argv'];assert stage[:3]==['git','add','--'] and len(stage)==16
assert 'data/alignment/pages_c05/c5p122.html'in stage and 'data/alignment/pages_c05/c5p123.html'in stage and 'data/alignment/reviews_c05/c5p123'in stage
assert not any('errata_register' in x or 'span_head_allow' in x for x in stage)
for k in ['method','profile_method']:
 path=c['artifacts']['closure_method'if k=='method'else'native_reuse_profile'];assert pin(Path(path))==d['root_approval_contract'][k]
assert d['root_approval_contract']['reviewed_scope']=='C05 three-segment private closure; no semantic or integration approval inferred'
assert not (B/'compact-closure').exists() and not (B/'compact-closure-caller').exists()
save(P/'newline-ast-inspection-v2.json',dict(status='PASS_PREPARATION_AST_ONLY',checks=line_checks,expected_ordinal=10,not_literal_backslash_n=True,production_executed=False))
(P/'README-v2.md').write_text('Artifact-only L367–369 preparation; no root acceptance or production execution.\nUse production-dispatch-plan.json and closure-plan.json after root inspects the candidate input/acceptance adapters and supplies exact immutable final hashes.\nRoot alone executes its receipt helpers and closure. Skip any already completed caller; preserve every actual failure and stop before the next dependency.\nShared adopted core/profile are unchanged. Page123, previous122, actual366 baseline/source363, 88 final/175 original spans,272 original members, zero source questions, whole E368 reuse.\nThree already completed neutral/origin/baseline callers are retained once. Final ledger and complete late graph must reflect actual results; no inherited K failures or speculative final pins.\nExplicit JSON newline AST is ordinal10. All frozen files and manifests are checked without suffix filtering before stage. Two archive paths are staged only after actual root ledger reading and late pack.\nOne earlier read-only schema-inspection snippet failed SyntaxError before imports or reads. Preparation attempt01 then failed the K full-original-equality gate on explicit root-adapted369/T/w11 depth5→6; the successor admits only that exact typed transformation. Both real histories and preimages are retained. No production method, old test, reproduction, native source/query or receipt was run for this preparation.\n')
known={k:dict(path=v,**pin(Path(v)))for k,v in c['artifacts'].items()if Path(v).is_file() and k not in ['preparation_inventory','preparation_review']}
pending={k:v for k,v in c['artifacts'].items()if not Path(v).is_file()and k not in ['preparation_inventory','preparation_review']}
save(B/'closure-preparation-inventory-v2.json',dict(status='PREPARATION_KNOWN_IDENTITIES_AND_EXPLICIT_PENDING',source_origin=origin['commit'],actual_baseline=base['commit'],methods=method_rows,known=known,pending=pending,actual_completed_callers=d['completed_prerequisites'],scope='Only current existing bytes pinned. Missing immutable final review/reconciliation/production/root receipts remain pending, never fabricated. No W mutation or execution.'))
save(P/'readiness-v2.json',dict(status='PREPARATION_READY_FOR_ROOT_REVIEW_NOT_AUTHORIZED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),root_choices=pin(B/'root-reconciliation-decisions.json'),baseline=pin(B/'baseline.json'),source_origin=pin(B/'proposal-baseline.json'),selected_original_items_checked=88,original_span_count=175,original_freeze_member_count=272,original_source_questions=0,planned_steps=[s['caller']for s in d['sequential_steps']],expected_counts=d['expected_counts'],stage_paths=stage[3:],fresh_first_closure_output=True,core=d['root_approval_contract']['method'],profile=d['root_approval_contract']['profile_method'],newline_ast=pin(P/'newline-ast-inspection-v2.json'),future_hashes=d['dynamic_arguments'],preparation_read_only_inspection_failures=1,preparation_attempt01_failures=1,production_executions=0,worktree_writes=0,pending_artifacts=pending))
print(json.dumps(dict(status='PREPARATION_READY_FOR_ROOT_REVIEW',dispatch=pin(B/'production-dispatch-plan-v2.json'),closure_plan=pin(B/'closure-plan-v2.json'),methods=method_rows,artifact_edges=len(c['artifacts']),planned_callers=len(c['callers']),pending=len(pending),production_executions=0),indent=2))
