PREPARATION ONLY — this is not the live append-only campaign entry.

Planned C05:367–369 (page123) uses source origin1be02f91d0c7546f4997d25cafd19c976ba4db3e through363 and actual acceptance baseline @BASE@ through366 (DOCS ddfc2e56beb3245e821c351be7cfe087c782cb78; paired DATA ffbce5b73f36390b0732dc58edbd40aa98fc641f).
Root selected88 provisional spans25/28/35,61 nonnull d5,1 d7,2 nulls and0 errata; these expected counts are not a production outcome. Six original pairs plus two changed367/369 pairs give eight unique pairs and nine views with whole English368 reuse, subject to exact final input checking.
After actual root acceptance and production, write landing/root-ledger-entry-template.md with measured coverage/retention/seven outputs/17 tests/reproduction/whitespace/integration limits and actual failures. The final three ledgers must append the identical entry using exact @DATA@, @BASE@ and @UTC@ placeholders. Do not copy this pending prose into a completion claim.
No source/master/hgm_gloss changes, paid calls, releases, MAIN merge or device acceptance are authorized here.
