"""Prepare exact frozen physical-byte/diff pins without changing sources or gates.

Usage: python3 -B prepare_review_whitespace_pins_v5.py PAGE FIRST [OUTPUT_DIRECTORY] [--freeze-name NAME]
Default output is the batch landing directory. Existing pin/proof files refuse.
Every frozen extension is considered, including text stored in .bin files.
Unclassified whitespace remains subject to the unchanged v8 audit.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, re, sys

A=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('page',type=int)
parser.add_argument('first',type=int)
parser.add_argument('output_directory',nargs='?')
parser.add_argument('--freeze-name',choices=('review-freeze.json','freeze.json'),default='review-freeze.json')
args=parser.parse_args()
page,first=args.page,args.first
assert page==(first-1)//3+1 and first%3==1
B=A/f'C05-{first}-{first+2}'
S=B/'semantic-review'
O=Path(args.output_directory).resolve() if args.output_directory else B/'landing'
O.mkdir(parents=True,exist_ok=True)
target=O/'review-whitespace-exact-pins.json'
proof=O/'whitespace-pin-preparation.json'
assert not target.exists() and not proof.exists()
pin=lambda b:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
freeze=json.loads((S/args.freeze_name).read_bytes())
manifest=json.loads((S/'original-to-copy-manifest.json').read_bytes())
witnesses={}
for r in manifest:
    p=Path(r['original'])
    if not str(p).endswith('ReadingASCII.txt'): continue
    raw=p.read_bytes()
    assert pin(raw)=={k:r[k] for k in ('bytes','sha256')}
    copied=(S/r['copy']).read_bytes()
    assert raw==copied
    key=(len(raw),hashlib.sha256(raw).hexdigest())
    witnesses.setdefault(key,[]).append((p,raw))
ordered=[]
for group in witnesses.values():
    group.sort(key=lambda x:(x[0].name!='C05ReadingASCII.txt',str(x[0])))
    p,raw=group[0]
    ordered.append((p,raw,[str(x[0]) for x in group]))
ordered.sort(key=lambda x:(x[0].name!='C05ReadingASCII.txt',str(x[0])))
pins={}; seen=set(); complete=[]; any_frozen_crlf=False
records = freeze['files']
if isinstance(records, dict):
    records = [dict(path=path, **value) for path, value in records.items()]
assert isinstance(records, list)
for r in records:
    rel=r['path']; p=S/rel
    assert p.resolve().is_relative_to(S.resolve()) and rel not in seen
    seen.add(rel); raw=p.read_bytes()
    assert pin(raw)=={k:r[k] for k in ('bytes','sha256')}
    any_frozen_crlf |= b'\r\n' in raw
    if (len(raw),hashlib.sha256(raw).hexdigest()) in witnesses:
        complete.append(rel)
        continue  # Existing v8 already recognizes complete original identities.
    if raw and b'\r\n' in raw:
        for witness,source,aliases in ordered:
            if len(raw)>=len(source): continue
            offset=source.find(raw)
            if offset<0: continue
            assert source[offset:offset+len(raw)]==raw
            pins[rel]=dict(kind='physical_bytes',**pin(raw),
                witness=dict(path=str(witness),**pin(source)),
                byte_range=[offset,offset+len(raw)],identical_witness_paths=aliases)
            break
    if rel not in pins and raw.endswith(b'\n\n'):
        pins[rel]=dict(kind='blank_eof',**pin(raw))
    if rel not in pins:
        for witness,source,aliases in ordered:
            if raw != source.decode('latin1').encode('utf8'): continue
            assert raw.decode('utf8').encode('latin1') == source
            pins[rel]=dict(kind='reversible_latin1_utf8_view',**pin(raw),
                witness=dict(path=str(witness),**pin(source)))
            break
    if rel not in pins and (rel.endswith('historical-final-differences.txt') or
            re.fullmatch(r'origin-to-through[0-9]+-governance\.diff\.txt', Path(rel).name)):
        lines=raw.split(b'\n')
        warning_lines=[x for x in lines if x.endswith((b' ',b'\t',b'\r'))]
        if warning_lines:
            assert all(x==b' ' for x in warning_lines)
            assert any(x.startswith(b'--- ') for x in lines) and any(x.startswith(b'+++ ') for x in lines)
            pins[rel]=dict(kind='diff_context',**pin(raw))
assert witnesses or not any_frozen_crlf, 'CRLF frozen evidence requires fully pinned physical original witnesses'
result=dict(status='EXACT_V12_PINS_PREPARED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    page=page,segments=list(range(first,first+3)),freeze=pin((S/args.freeze_name).read_bytes()),
    method=pin(Path(__file__).read_bytes()),frozen_files_verified=len(seen),
    complete_physical_files=complete,pins=pins,
    limit='Preparation is mechanical, not semantic approval or a passed whitespace audit. Other warning classes remain fail-closed in v12. No source or review bytes edited.')
target.write_text(json.dumps(pins,indent=2)+'\n')
proof.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],pins=len(pins),physical_files=len(complete),proof=str(proof)),indent=2))
