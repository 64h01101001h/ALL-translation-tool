"""Tiny isolated fixtures for the newly admitted frozen governance-diff basename."""
from pathlib import Path
import hashlib,json,subprocess,sys
C=Path(__file__).resolve().parent;A=C.parent
method=A/'prepare_review_whitespace_pins_v6.py'
recorder=A/'record_external_step.py'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
actual=A/'C05-367-369/semantic-review/evidence/origin-to-through366-governance.diff.txt'
assert pin(actual.read_bytes())=={'bytes':8715,'sha256':'ff44385660bf6c68d9fbfdf61480a7424805b607a3c441e645f139800001082d'}
diff=b'--- a/sample\n+++ b/sample\n@@ -1,1 +1,2 @@\n \n+new\n'
cases=[
 ('actual_frozen_governance','evidence/origin-to-through366-governance.diff.txt',actual.read_bytes(),False,'pin'),
 ('legacy_name_unchanged','evidence/historical-final-differences.txt',diff,False,'pin'),
 ('nondigit_boundary_unclassified','evidence/origin-to-throughabc-governance.diff.txt',diff,False,'empty'),
 ('suffix_near_miss_unclassified','evidence/origin-to-through366-governance.diff.txt.extra',diff,False,'empty'),
 ('nonblank_trailing_space_refused','evidence/origin-to-through366-governance.diff.txt',diff+b'+new trailing \n',False,'refuse'),
 ('missing_diff_header_refused','evidence/origin-to-through366-governance.diff.txt',b' \nno diff headers\n',False,'refuse'),
 ('tampered_frozen_hash_refused','evidence/origin-to-through366-governance.diff.txt',diff,True,'refuse'),
]
results=[]
for name,rel,raw,tamper,expected in cases:
 case=C/'cases'/name;art=case/'artifacts';s=art/'C05-367-369/semantic-review';s.mkdir(parents=True,exist_ok=False)
 copy=art/method.name;copy.write_bytes(method.read_bytes())
 source=s/rel;source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(raw)
 record=pin(raw)
 if tamper:record['sha256']='0'*64
 (s/'freeze.json').write_text(json.dumps({'files':{rel:record}})+'\n')
 (s/'original-to-copy-manifest.json').write_text('[]\n')
 out=case/'output';capture=case/'native'
 argv=[sys.executable,'-B',str(copy),'123','367',str(out),'--freeze-name','freeze.json']
 run=subprocess.run([sys.executable,'-B',str(recorder),str(capture),str(case)]+argv,capture_output=True)
 (case/'recorder.stdout').write_bytes(run.stdout);(case/'recorder.stderr').write_bytes(run.stderr)
 pins=out/'review-whitespace-exact-pins.json';proof=out/'whitespace-pin-preparation.json'
 if expected=='refuse':
  assert run.returncode==1 and not pins.exists() and not proof.exists(),name
 else:
  assert run.returncode==0 and (capture/'stderr.bin').read_bytes()==b'',name
  got=json.loads(pins.read_text());prepared=json.loads(proof.read_text())
  wanted={rel:{'kind':'diff_context',**pin(raw)}} if expected=='pin' else {}
  assert got==wanted and prepared['pins']==wanted and prepared['method']==pin(method.read_bytes()),name
  assert prepared['frozen_files_verified']==1,name
 assert source.read_bytes()==raw,name
 results.append({'case':name,'expected':expected,'exit':run.returncode,'status':'PASS','native_execution':str(capture/'execution.json'),'method':pin(method.read_bytes())})
 print(name+' PASS',flush=True)
(C/'test-results.json').write_text(json.dumps({'status':'PASS','count':len(results),'cases':results,'scope':'Isolated fixtures only; deliberate refusals are expected test outcomes; no L preparation/audit/production run.'},indent=2)+'\n')
