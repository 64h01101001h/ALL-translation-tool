"""Independent bounded v7 filename/content probes adapted from reviewed v6 fixtures."""
from pathlib import Path
import hashlib,json,subprocess,sys
C=Path(__file__).resolve().parent;A=C.parent
method=A/'prepare_review_whitespace_pins_v7.py'
recorder=A/'record_external_step.py'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
actual=A/'C05-370-372/semantic-review/evidence/source-origin-to-through369.diff.txt'
assert pin(actual.read_bytes())=={'bytes':18252,'sha256':'9a68b0a225c5260ee261e13e687c294c1ddbfca7e96726d4973d1fc9a3a2f42f'}
assert actual.read_bytes().split(b'\n')[6]==b' ' and not actual.read_bytes().endswith(b'\n\n')
legacy=A/'C05-367-369/semantic-review/evidence/origin-to-through366-governance.diff.txt'
assert pin(legacy.read_bytes())=={'bytes':8715,'sha256':'ff44385660bf6c68d9fbfdf61480a7424805b607a3c441e645f139800001082d'}
diff=b'--- a/sample\n+++ b/sample\n@@ -1,1 +1,2 @@\n \n+new\n'
cases=[
 ('actual_M_source_origin','evidence/source-origin-to-through369.diff.txt',actual.read_bytes(),False,'pin'),
 ('actual_L_governance','evidence/origin-to-through366-governance.diff.txt',legacy.read_bytes(),False,'pin'),
 ('historical_route','evidence/historical-final-differences.txt',diff,False,'pin'),
 ('nondigit_boundary','evidence/source-origin-to-throughabc.diff.txt',diff,False,'empty'),
 ('prefix_near_miss','evidence/extra-source-origin-to-through369.diff.txt',diff,False,'empty'),
 ('suffix_near_miss','evidence/source-origin-to-through369.diff.txt.extra',diff,False,'empty'),
 ('unicode_digits','evidence/source-origin-to-through٣٦٩.diff.txt',diff,False,'empty'),
 ('tab_warning','evidence/source-origin-to-through369.diff.txt',diff+b'\t\n',False,'refuse'),
 ('nonblank_trailing_space','evidence/source-origin-to-through369.diff.txt',diff+b'+bad \n',False,'refuse'),
 ('missing_header','evidence/source-origin-to-through369.diff.txt',b'--- a/sample\n \n',False,'refuse'),
 ('tampered_hash','evidence/source-origin-to-through369.diff.txt',diff,True,'refuse'),
]
results=[]
for name,rel,raw,tamper,expected in cases:
 case=C/'cases'/name;art=case/'artifacts';s=art/'C05-367-369/semantic-review';s.mkdir(parents=True,exist_ok=False)
 copy=art/method.name;copy.write_bytes(method.read_bytes())
 source=s/rel;source.parent.mkdir(parents=True,exist_ok=True);source.write_bytes(raw)
 record=pin(raw)
 if tamper:record['sha256']='0'*64
 (s/'freeze.json').write_text(json.dumps({'files':{rel:record}})+'\n')
 (s/'original-to-copy-manifest.json').write_text('[]\n')
 out=case/'output';capture=case/'native'
 argv=[sys.executable,'-B',str(copy),'123','367',str(out),'--freeze-name','freeze.json']
 run=subprocess.run([sys.executable,'-B',str(recorder),str(capture),str(case)]+argv,capture_output=True)
 (case/'recorder.stdout').write_bytes(run.stdout);(case/'recorder.stderr').write_bytes(run.stderr)
 pins=out/'review-whitespace-exact-pins.json';proof=out/'whitespace-pin-preparation.json'
 if expected=='refuse':
  assert run.returncode==1 and not pins.exists() and not proof.exists(),name
 else:
  assert run.returncode==0 and (capture/'stderr.bin').read_bytes()==b'',name
  got=json.loads(pins.read_text());prepared=json.loads(proof.read_text())
  wanted={rel:{'kind':'diff_context',**pin(raw)}} if expected=='pin' else {}
  assert got==wanted and prepared['pins']==wanted and prepared['method']==pin(method.read_bytes()),name
  assert prepared['frozen_files_verified']==1,name
 assert source.read_bytes()==raw,name
 results.append({'case':name,'expected':expected,'exit':run.returncode,'status':'PASS','native_execution':str(capture/'execution.json'),'method':pin(method.read_bytes())})
 print(name+' PASS',flush=True)
(C/'test-results.json').write_text(json.dumps({'status':'PASS','count':len(results),'cases':results,'scope':'Isolated fixtures only; deliberate refusals are expected test outcomes; no actual M or L preparation/audit/production run.'},indent=2)+'\n')
