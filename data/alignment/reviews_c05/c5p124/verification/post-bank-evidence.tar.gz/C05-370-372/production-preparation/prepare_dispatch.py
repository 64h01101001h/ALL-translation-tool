"""Prepare M parameters from the successful K normal path; execute no receipt or production."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,re
M=Path(__file__).resolve().parents[1];A=M.parent;K=A/'C05-364-366';P=M/'production-preparation'
BASE='ec517ce4977078348a41f087dd03a894e3dbc380';ORIGIN='1be02f91d0c7546f4997d25cafd19c976ba4db3e'
R='dd62dc7c4fe71c958547bee41d8fb50e65716047753a947e06bdd602a2776f5e'
def pin(p):b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(p.read_bytes())
def save(p,x):assert not p.exists();p.write_text(json.dumps(x,indent=2)+'\n')
assert pin(M/'root-reconciliation-decisions.json')==dict(bytes=26599,sha256=R)
choices=read(M/'root-reconciliation-decisions.json');assert choices['actual_baseline']==BASE and choices['source_origin']==ORIGIN
mapping={str(K):str(M),'1be02f91d0c7546f4997d25cafd19c976ba4db3e':BASE,'e4da4c94f59f4af61de90fde63127890130c5902':ORIGIN,'4724e72c779e0711059107a0bcfe29c416ccd9442247c75bd8719733521d8bd4':R,'C05-364-366':'C05-370-372','compact-reproduction-through366':'compact-reproduction-through372','c5p121':'c5p123','c5p122':'c5p124','baseline-through363':'baseline-through369','34675':'26599'}
rx=re.compile('|'.join(re.escape(k) for k in sorted(mapping,key=len,reverse=True)))
def common(s):
 s=rx.sub(lambda m:mapping[m.group()],s)
 return re.sub(r'\b(357|363|364|365|366|367|122)\b',lambda m:{'357':'363','363':'369','364':'370','365':'371','366':'372','367':'373','122':'124'}[m.group()],s)
def tree(x):
 if isinstance(x,str):return common(x)
 if isinstance(x,list):return [tree(v) for v in x]
 if isinstance(x,dict):return {common(k):tree(v) for k,v in x.items()}
 return x
input_old=(K/'root-input-receipt.py').read_text();s=common(input_old)
s=s.replace('original_spans==135 and len(resolved)==70','original_spans==98 and len(resolved)==49').replace("==8\n    a=B/'english/native'/f'371-{mode}-v1';b=B/'reconciled/native'/f'371-{mode}-v1'\n    for name in('execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt'):\n        assert (a/name).read_bytes()==(b/name).read_bytes()\nassert (B/'english/371/spec.json').read_bytes()==(B/'reconciled/371/spec.json').read_bytes()", "==7\n    for reused in (370,372):\n        a=B/'english/native'/f'{reused}-{mode}-v1';b=B/'reconciled/native'/f'{reused}-{mode}-v1'\n        for name in('execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt'):\n            assert (a/name).read_bytes()==(b/name).read_bytes()\nfor reused in (370,372):assert (B/f'english/{reused}/spec.json').read_bytes()==(B/f'reconciled/{reused}/spec.json').read_bytes()")
s=s.replace('==243','==312').replace('english/370/errata-review.json','english/372/errata-review.json')
s=s.replace('verified_native_generations=8,verified_native_resolvers=8','verified_native_generations=7,verified_native_resolvers=7').replace('reconciler_generations=2,reconciler_resolvers=2,reused_english_pairs=1','reconciler_generations=1,reconciler_resolvers=1,reused_english_pairs=2')
s=s.replace('original_spans=135,final_spans=70,original_frozen_members=243','original_spans=98,final_spans=49,original_frozen_members=312').replace('unique_executions_per_kind=8,original_spans=135,final_spans=70','unique_executions_per_kind=7,original_spans=98,final_spans=49')
s=s.replace('Nine selected capture views per kind contain eight unique executions: six originals plus changed364/366 pairs; unchanged English365 pair is copied byte-for-byte, not rerun.','Nine selected views per kind contain seven unique executions: six originals plus changed371; whole English370 and372 pairs are copied byte-for-byte, not rerun.')
# Common parameter conversion leaves this prose's embedded digits unchanged.
s=s.replace('Nine selected capture views per kind contain eight unique executions: six originals plus changed370/372 pairs; unchanged English371 pair is copied byte-for-byte, not rerun.','Nine selected views per kind contain seven unique executions: six originals plus changed371; whole English370 and372 pairs are copied byte-for-byte, not rerun.')
s=re.sub(r" count_scope='[^']*',", " count_scope='Nine selected views per kind contain seven unique executions: six originals plus changed371; whole English370 and372 pairs are copied byte-for-byte, not rerun.',",s)
assert 'for reused in (370,372)'in s and '==312'in s and 'verified_native_generations=7'in s
accept_old=(K/'root-acceptance-receipt.py').read_text();t=common(accept_old)
t=t.replace('exact K selected_id','exact M selected_id').replace("dict(total_spans=70,segments={'370':31,'371':10,'372':29},total_nulls=1,total_word_pairs=42,total_d5=42,total_d7=9,proposed_errata=0)","dict(total_spans=49,segments={'370':6,'371':21,'372':22},total_nulls=2,total_word_pairs=31,total_d5=31,total_d7=3,proposed_errata=0)")
t=t.replace('==[70,1,42,9]','==[49,2,31,3]').replace("inputs['verified_native_generations']==8 and inputs['verified_native_resolvers']==8","inputs['verified_native_generations']==7 and inputs['verified_native_resolvers']==7").replace("inputs['original_spans']==135 and inputs['final_spans']==70 and inputs['original_frozen_members']==243","inputs['original_spans']==98 and inputs['final_spans']==49 and inputs['original_frozen_members']==312").replace('==[31,10,29]','==[6,21,22]').replace('dict(spans=70,nulls=1,nonnull_d5=42,total_d5=42,d7=9)','dict(spans=49,nulls=2,nonnull_d5=31,total_d5=31,d7=3)')
old_errata=t[t.index("errata_decision='")+len('errata_decision='):t.index(",errata=[],allowances=")]
t=t.replace(old_errata,repr('No new errata or head allowance. Preserve the complete English372 final-application source question unfiled and all original E111-class, verse-line and possessive claims with their explicit root corrections. Do not infer a source edit from the glossary or repeated C16 lineage. Ordinary empty-errata production retains all204 register entries unchanged.'))
start=t.index("native_history='")+len('native_history=');end=t.index(",\n limits=",start)
t=t[:start]+repr('Seven unique generator/resolver pairs: six originals plus changed371. Whole English370 and372 specs/notes/body/ranges and five-file pairs are reused exactly, giving nine views per kind. No root/reviewer native reruns; retain all actual original and assembly history.')+t[end:]
t=t.replace('Approve the70 provisional spans31/10/29','Approve the49 provisional spans6/21/22')
needle="freeze=read(S/'freeze.json');review=read(S/'review.json')"
counts={'original_pairs':6,'new_reconciler_pairs':1,'exact_english_reused_pairs':2,'actual_unique_pairs':7,'selected_angle_segment_views':9,'reviewer_generator_runs':0,'reviewer_resolver_runs':0}
gate="\n# Reject missing/ambiguous native metadata before any production dispatch.\nfor key,value in "+repr(counts)+".items():\n    assert key in review['native_history'] and type(review['native_history'][key]) is int and review['native_history'][key]==value,key\n"
assert t.count(needle)==1;t=t.replace(needle,needle+gate)
for code in (s,t):ast.parse(code)
# Current original selections are checked structurally; no linguistic decisions.
for item in choices['selected_original_items']:
 original=[x for x in read(M/item['original_angle']/str(item['seq'])/'spec.json')['segments'][0]['spans'] if x['id']==item['original_id']];assert len(original)==1
 obj=dict(original[0]);obj['id']=item['selected_id'];assert obj==item['span']
assert sum(len(read(M/a/str(q)/'spec.json')['segments'][0]['spans'])for a in ('english','tibetan')for q in (370,371,372))==98
assert sum(len(read(M/a/'freeze.json')['files']) for a in ('english','tibetan'))==312
assert [sum(i['seq']==q for i in choices['selected_original_items']) for q in (370,371,372)]==[6,21,22]
assert len(read(M/'english/372/errata-review.json')['source_questions'])==1
for name,code,oldcode in [('root-input-receipt',s,input_old),('root-acceptance-receipt',t,accept_old)]:
 (P/(name+'.candidate.py')).open('x').write(code)
 (P/(name+'.diff.txt')).open('x').write(''.join(difflib.unified_diff(oldcode.splitlines(True),code.splitlines(True),fromfile=str(K/(name+'.py')),tofile=str(P/(name+'.candidate.py')))))
# Normal K dispatch, without historical retry or late-preparation state.
d=tree(read(K/'production-dispatch-plan-v2.json'));d['page']=124;d['segments']=[370,371,372]
d['expected_counts']={'spans':49,'by_segment':[6,21,22],'nonnull_d5':31,'total_d5':31,'d7':3,'nulls':2,'new_errata':0,'new_links_including_three_segment_anchors':52,'original_spans':98,'original_frozen_members':312,'original_source_questions':1}
d['source_origin']=dict(commit=ORIGIN,course_boundary=363);d['actual_baseline']=dict(commit=BASE,course_boundary=369,pin=pin(M/'baseline.json'));d['root_choices']=dict(path=str(M/'root-reconciliation-decisions.json'),**pin(M/'root-reconciliation-decisions.json'))
d['status']='PREPARATION_ONLY_NOT_AUTHORIZED_FOR_PRODUCTION';d['completed_prerequisites']={};d['historical_captures']=['source-preparation-caller PASS','proposal-origin-caller actual SyntaxError exit1 before imports','proposal-origin-attempt02-caller PASS','baseline-through369-caller PASS']
d['native_semantic_execution_scope']='Future final input check must show seven unique pairs: six originals plus changed371; exact English370/372 reuse and nine views. No engine or receipt runs performed by this preparation.'
d['stop_on_failure']='Separate inspected recorded invocations or subprocess.run(...,check=True); stop on first nonzero, preserve actual native evidence, never replay completed callers.'
for step in d['sequential_steps']:
 step['status']='NOT_RUN';step['execution_rule']=d['stop_on_failure']
 if step['caller']=='whitespace-pins-v5-caller':
  step['caller']='whitespace-pins-v6-caller';step['argv']=[x.replace('prepare_review_whitespace_pins_v5.py','prepare_review_whitespace_pins_v6.py') for x in step['argv']];step['record_with']=[x.replace('whitespace-pins-v5-caller','whitespace-pins-v6-caller')for x in step['record_with']]
d['sequential_steps'][12]['prerequisites']=['All prior production calls passed once.','Use actual through369 baseline seed; fresh compact-reproduction-through372 output.']
d['sequential_steps'][14]['scope']='Explicit M stage: seven outputs, previous123/current124 page, index/spec/review tree and builder registration only.'
for key in ('ledger_preparation','actual_future_ledger'):d[key]=str(P/'root-ledger-entry-template.preparation.md') if key=='ledger_preparation' else str(M/'landing/root-ledger-entry-template.md')
d['bind_only_after_all_actual_outputs'][3]=str(M/'closure-plan.json');d['final_bind_record_with'][3]=str(A/'M-final-config-caller')
p=tree(read(K/'closure-plan-v3.json'));p['artifacts']={k:v for k,v in p['artifacts'].items()if k in list(read(K/'closure-plan-v3.json')['artifacts'])[:65]}
a=p['artifacts'];a.update(whitespace_pin_method=str(A/'prepare_review_whitespace_pins_v6.py'),whitespace_method_review=str(A/'whitespace-v6-independent-review-binding.json'),whitespace_method_review_freeze=str(A/'whitespace-v6-independent-review/freeze.json'),whitespace_method_tests=str(A/'whitespace-v6-independent-review/test-results.json'),whitespace_root_adoption=str(A/'whitespace-v6-root-adoption.json'),production_dispatch_plan=str(M/'production-dispatch-plan.json'),closure_preparation_plan=str(M/'closure-plan.json'),preparation_inventory=str(P/'readiness.json'),preparation_review=str(P/'readiness.json'),preparation_notes=str(P/'README.md'))
for key in ('prepared_root_input_candidate','prepared_root_acceptance_candidate','prepared_root_input_diff','prepared_root_acceptance_diff','preparation_ledger'):
 assert Path(a[key]).parent==P
for f in sorted(M.glob('root-*.json')):a['current_'+f.stem.replace('-','_')]=str(f)
for name in ('root-assembled-reading.json','root-final-review-reading.json','root-reconciliation-intake.json','root-semantic-disposition.json','root-ledger-reading.json'):
 a['current_'+Path(name).stem.replace('-','_')]=str(M/name)
a['root_reconciliation_resolved_spans']=str(M/'root-reconciliation-verification/resolved-spans.json');a['preparation_method']=str(Path(__file__));a['preparation_newline_ast_inspection']=str(P/'newline-ast-inspection.json');a['actual_neutral_history']=str(M/'preparation-history.json')
p['callers']={step['caller']:str(M/step['caller']) for step in d['sequential_steps']}
for name in ('source-preparation-caller','proposal-origin-caller','proposal-origin-attempt02-caller','baseline-through369-caller'):p['callers'][name]=str(M/name)
p['historical_failures']={'proposal-origin-caller':{'exit':1,'reason':'Actual first fixed-origin inline script had if370 without a separating space: SyntaxError before imports/Git/read/query/write, stdout0/stderr296. Exact original caller retained; proposal-origin-attempt02 passed after the sole syntax-space correction. No source-preparation replay.'}}
p['active_caller']='compact-closure-caller';p['post_freeze']=[];p['retrospective']=None
# Static newline proof inspects actual Python AST constants, not JSON display escapes.
inline=next(x['argv'][-1] for x in d['sequential_steps'] if x['caller']=='frozen-copy-completeness-caller')
newlines=[]
for label,code in [('input_candidate',s),('acceptance_candidate',t),('frozen_copy_argv',inline)]:
 nodes=[n for n in ast.walk(ast.parse(code)) if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='write_text']
 vals=[n.args[0].right.value for n in nodes if n.args and isinstance(n.args[0],ast.BinOp)and isinstance(n.args[0].right,ast.Constant)]
 assert vals and all(v=='\n'for v in vals),(label,vals);newlines.append({'source':label,'terminator_ordinals':[ord(v)for v in vals]})
save(P/'newline-ast-inspection.json',{'status':'PASS_STATIC_ACTUAL_AST','values':newlines})
(P/'root-ledger-entry-template.preparation.md').write_text('PREPARATION ONLY. After actual production, record measured M370–372 coverage, retention,17 tests, seven outputs and integration limits. Planned49 spans31d5/3d7/2nulls/0errata; source origin363 versus actual baseline369. Preserve actual origin SyntaxError and retry; no L failure inheritance. Live identical ledger tokens must be @DATA@, @BASE@ and @UTC@. No completion outcome is claimed.\n')
(P/'README.md').write_text('Artifact-only M preparation from the successful K normal path. No receipt, semantic acceptance, W write or production run occurred. Candidates preserve existing native/source/root-reading guards, adapt two exact English reuse pairs and one retained English372 source question, and now refuse missing or noninteger values in all seven adopted review.native_history fields before production. Final reconciliation/review freeze hashes remain future requirements. Adopted v6 preparation and its real independent binding replace v5; unchanged v12/core/profile remain pinned. Use first compact closure only with a fresh absent output and external root approval. Read actual caller states before dispatch; root input/intake must never replay once completed.\n')
# Initial late list is explicit and refreshed with actual late/root receipts later.
exclude={'post_bank_archive','post_bank_manifest','post_bank_plan'}
extra={v for k,v in a.items() if k not in exclude and Path(v).is_relative_to(A)}
d['post_bank_plan_argv']=['python3','-B',str(A/'reusable-batch-closure-p-profile-candidate/post_bank_plan.py'),'--batch',str(M),'--bank-manifest',a['bank_manifest']]+[x for v in sorted(extra)for x in ('--extra',v)]+['--output',str(M/'post-bank-plan.json')]
save(M/'closure-plan.json',p);save(M/'production-dispatch-plan.json',d)
ready={'status':'PASS_SCOPED_PREPARATION_PENDING_FINAL_RECONCILIATION_REVIEW_ROOT_ACCEPTANCE','source_origin':ORIGIN,'actual_baseline':BASE,'root_decisions':pin(M/'root-reconciliation-decisions.json'),'original_spans':98,'original_frozen_members':312,'selected_spans':49,'original_source_questions':1,'native_history_required_exact_ints':counts,'current_final_reconciliation_exists':(M/'reconciled/freeze.json').exists(),'current_final_review_exists':(M/'semantic-review/freeze.json').exists(),'unknown_final_hashes_not_asserted':True,'native_and_production_invocations':0,'stop_on_failure':d['stop_on_failure'],'candidate_pins':{n:pin(P/n)for n in ('root-input-receipt.candidate.py','root-acceptance-receipt.candidate.py')},'limits':'Static structure/parameter/AST checks only; no live helper acceptance or actual completed final native history inferred.'}
save(P/'readiness.json',ready)
print(json.dumps(ready,indent=2))
