"""Exercise only the newly added native-count assertion; no receipt execution."""
from pathlib import Path
import ast,copy,json
P=Path(__file__).resolve().parent
module=ast.parse((P/'root-acceptance-receipt.candidate.py').read_text())
loops=[n for n in module.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and isinstance(n.iter.func,ast.Attribute) and isinstance(n.iter.func.value,ast.Dict)]
assert len(loops)==1
node=loops[0];expected=ast.literal_eval(node.iter.func.value);assert len(expected)==7
code=compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'actual-candidate-native-count-guard','exec')
results=[]
for label,mutation,accept in [('exact',{},True),('missing_original_pairs',{'original_pairs':None},False),('boolean_zero',{'reviewer_generator_runs':False},False),('wrong_new_count',{'new_reconciler_pairs':2},False)]:
 d=copy.deepcopy(expected)
 for k,v in mutation.items():
  if v is None:del d[k]
  else:d[k]=v
 try:exec(code,{'review':{'native_history':d}});actual=True
 except AssertionError:actual=False
 assert actual==accept,label;results.append({'case':label,'expected_accept':accept,'actual_accept':actual,'status':'PASS'})
out={'status':'PASS_FOUR_ISOLATED_NATIVE_METADATA_CASES','cases':results,'required_exact_integer_counts':expected,'limits':'Executed only the copied AST of the new assertion loop. No root receipt, semantic review, native generator/resolver, W or production execution.'}
(P/'native-count-guard-check.json').open('x').write(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
