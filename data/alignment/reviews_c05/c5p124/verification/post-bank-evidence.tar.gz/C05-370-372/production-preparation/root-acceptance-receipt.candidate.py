"""Prepare root acceptance from the future exact independent review; not run by author.

Usage (root only, after actual reading): root-acceptance-receipt.py REVIEW_FREEZE_SHA256
Existing receipt adapted to exact M selected_id/root choices and empty-errata policy; root executes only after actual complete final reading.
"""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path('/Users/adamderickandrade/Documents/ChatGPT/Geshe Michael Roach Tib _ Eng Alignment/campaign-artifacts/C05-370-372');S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert (B/'root-final-review-reading.json').is_file() and (B/'root-assembled-reading.json').is_file()
assert pin(B/'root-reconciliation-decisions.json')==dict(bytes=26599,sha256='dd62dc7c4fe71c958547bee41d8fb50e65716047753a947e06bdd602a2776f5e')
choices=read(B/'root-reconciliation-decisions.json')
assert choices['expected']==dict(total_spans=49,segments={'370':6,'371':21,'372':22},total_nulls=2,total_word_pairs=31,total_d5=31,total_d7=3,proposed_errata=0)
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
# Reject missing/ambiguous native metadata before any production dispatch.
for key,value in {'original_pairs': 6, 'new_reconciler_pairs': 1, 'exact_english_reused_pairs': 2, 'actual_unique_pairs': 7, 'selected_angle_segment_views': 9, 'reviewer_generator_runs': 0, 'reviewer_resolver_runs': 0}.items():
    assert key in review['native_history'] and type(review['native_history'][key]) is int and review['native_history'][key]==value,key

for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
    assert obj['source_origin_git_commit']=='1be02f91d0c7546f4997d25cafd19c976ba4db3e'
    assert obj['later_supplied_acceptance_baseline']=='ec517ce4977078348a41f087dd03a894e3dbc380'
    assert obj['later_baseline_accepted_through']==369
    assert [obj[k] for k in ('total_spans','total_nulls','total_word_pairs','total_d7')]==[49,2,31,3]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert base==choices['actual_baseline']=='ec517ce4977078348a41f087dd03a894e3dbc380'
assert origin==choices['source_origin']=='1be02f91d0c7546f4997d25cafd19c976ba4db3e'
inputs=read(B/'root-current-inputs/proof.json')
assert inputs['status']=='PASS_ROOT_INPUTS' and inputs['baseline']==base and inputs['source_origin']==origin
assert inputs['verified_native_generations']==7 and inputs['verified_native_resolvers']==7
assert inputs['original_spans']==98 and inputs['final_spans']==49 and inputs['original_frozen_members']==312 and len(inputs['original_source_questions'])==1
resolved=read(S/'resolved-spans.json');assert resolved==read(B/'root-reconciliation-verification/resolved-spans.json')
assert [sum(x['seq']==s for x in resolved)for s in (370,371,372)]==[6,21,22]
expected=[dict(seq=i['seq'],**{k:i['span'][k]for k in('id','d','tib','eng')},tib_range=i['tib_range'],eng_range=i['eng_range'])for i in choices['selected_original_items']]
assert all(i['selected_id']==i['span']['id']for i in choices['selected_original_items']) and resolved==expected
counts=dict(spans=len(resolved),nulls=sum(x['eng']is None for x in resolved),nonnull_d5=sum(x['d']==5 and x['eng']is not None for x in resolved),total_d5=sum(x['d']==5 for x in resolved),d7=sum(x['d']==7 for x in resolved))
assert counts==dict(spans=49,nulls=2,nonnull_d5=31,total_d5=31,d7=3)
assembled=read(B/'root-assembled-reading.json');final=read(B/'root-final-review-reading.json')
assert assembled['status']=='ROOT_ASSEMBLED_READING_BOUND_TO_IMMUTABLE_RECONCILIATION'
assert assembled['reconciliation_freeze']==pin(B/'reconciled/freeze.json')
for rel,p in assembled['files'].items():assert pin(B/rel)==p,rel
assert all(f'reconciled/{s}/{n}'in assembled['files']for s in (370,371,372)for n in ('spec.json','final-rationales.json','omissions.json'))
assert final['status']=='ROOT_PERSONAL_FINAL_REVIEW_READING_COMPLETE'
assert final['review_freeze']==pin(S/'freeze.json') and final['review']==pin(S/'review.json')
assert assembled['reading'].strip() and final['reading'].strip()
reading='Root assembled reading: '+assembled['reading']+' Final independent-review reading: '+final['reading']+' These are actual root-authored receipts; no material-object reading count is inferred from hash checks or the independent reviewer inventory.'
assert read(S/'bank-ready-errata.json')==[]
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
for seq in (370,371,372):assert read(S/f'reviewed-final/{seq}/errata.json')==[]
utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 reading=reading,semantic_files_verified=len(freeze['files']),limits='Exact immutable identity plus separately completed root reading; production checks still follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,source_origin=origin,page='c5p124',segments=[370,371,372],counts=counts,
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading.json'),final_independent_reading=pin(B/'root-final-review-reading.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision='Approve the49 provisional spans6/21/22 selected by the exact root decisions and subsequently independently reviewed. All root rulings, adopted rationale corrections and retained omissions remain in their immutable records.',
 root_rulings=choices['rulings'],errata_decision='No new errata or head allowance. Preserve the complete English372 final-application source question unfiled and all original E111-class, verse-line and possessive claims with their explicit root corrections. Do not infer a source edit from the glossary or repeated C16 lineage. Ordinary empty-errata production retains all204 register entries unchanged.',errata=[],allowances={'pages_c05':{}},
 native_history='Seven unique generator/resolver pairs: six originals plus changed371. Whole English370 and372 specs/notes/body/ranges and five-file pairs are reused exactly, giving nine views per kind. No root/reviewer native reruns; retain all actual original and assembly history.',
 limits='Provisional only; no source/master correction, hgm_gloss promotion, MAIN application or phone acceptance. This receipt does not execute production or closure.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[370,371,372],semantic_files=len(freeze['files']))))
