"""Preserve bounded current root methods and actual failures before banking."""
from pathlib import Path
import datetime, hashlib, json, shutil
B=Path(__file__).resolve().parent; A=B.parent
def read(p): return json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes(); return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
    assert not p.exists(); p.write_text(json.dumps(v,indent=2)+'\n')
dest=B/'landing/root-current-method'; dest.mkdir(exist_ok=False)
files=[Path(__file__).resolve(),B/'accept_root_semantics.py',B/'verify_root_reconciliation_inputs.py',B/'root-reconciliation-intake.json',B/'root-semantic-disposition.json',B/'root-reconciliation-reading.json',B/'root-three-critical-master-records.json',B/'registration-format-adaptation.json',A/'register_reviewed_page_v4.py',A/'register_reviewed_page_v5.py',A/'prepare_review_whitespace_pins_v3.py',A/'audit_staged_source_whitespace_v11.py']
for folder in ['root-reconciliation-inputs','root-reconciliation-inputs-caller-attempt02','root-intake-schema-correction','format-adapters']:
    files.extend(p for p in (B/folder).rglob('*') if p.is_file())
I=A/'integration'
files.extend([I/'through309-root-disposition.json']+[I/'through309-current-assessment'/n for n in ['freeze.json','review.md','assessment.json','future-reuse-method.md']])
records=[]
for p in sorted(set(files)):
    rel=p.relative_to(A); t=dest/rel; t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);assert t.read_bytes()==p.read_bytes()
    records.append(dict(original=str(p),copy=str(t.relative_to(dest)),**pin(p)))
save(dest/'manifest.json',records)
failure=read(Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through312/proof.json'))
assert failure['status']=='FAILED' and failure['runs']==[]
save(dest/'reproduction-preflight-failure.json',dict(actual_proof=failure,actual_caller=str(B/'root-compact-reproduction-caller'),reason='Root scheduled reproduction concurrently with its required retention-proof producer. The missing input stopped preparation before any native builder invocation. Waited for actual retention PASS, then started a fresh preserved destination. This dependency is sequential for future batches; no successful native result was repeated.'))
review=B/'compact-reproduction-review';review.mkdir(exist_ok=False)
save(review/'method-review.json',dict(verdict='APPROVE_REUSE_UNCHANGED_REPRODUCTION_METHOD',methods={n:pin(A/n) for n in ['reproduce_generated_outputs.py','run_reproduction_readonly.py']},prior_passing_proof=str(A/'C05-307-309/compact-closure/proof.json'),current_proof='/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through312-attempt02/proof.json',judgment='Unchanged source-copy, incoming CSV seed, read-only source guard, seven whole-output equality and unchanged-input checks. Actual retention dependency failure precedes all native builder work; fresh attempt02 passed once.',limits='Production/source fidelity only; no MAIN runtime or device acceptance.'))
entry='''

### 2026-09-14 — independently reviewed C05:310–312; private coverage 312/511

- Accepted 110 provisional spans, one null, 73 nonnull depth-5 pairs (74 total d5), 16 depth-7 members and three source anchors:113 new layer links. Per310:40/1/25;311:13/0/7;312:57/0/41 (spans/nulls/nonnull d5).199 C05 segments remain313–511. C06 waits for complete C05; C13 remains blocked upstream.
- Historical source origin51d73c889a3f175b90e4c466f3dc4b1f7af3bca5 through306; actual acceptance baseline @BASE@ through309. Originals88/111 files, reconciliation359 files, fresh semantic442 files. Fresh SPEC and QUALITY APPROVE, no open findings, freeze5d255ecbb1c8acd37afbea717859d3f9851fd1aac5520583c6f66eecf589e6d9. All599 original-copy records verified before and after landing. All195 original dispositions,110 final source-specific decisions,20 material omissions and six complete five-ground screens are banked. No new errata or head allowances;194 register entries unchanged.
- Root independently checked all305 original/final canonical source resolutions,41 corpus queries,190 complete master objects,289 complete corpus objects and six physical extents. Root read all source/spec/report/decision interfaces plus31 full critical master records and complete critical corpus witnesses; broad metadata identity checks are not claimed as separate linguistic reading. Fresh reviewer generated three final bodies once, exact with empty stderr. Six original replay proofs and root's earlier checks reused only for unchanged inputs. Entire extent supersedes the earlier extent draft with both successful versions preserved.
- Sole null310 lus has no separate body/bodily English exponent. Distributed negative force, shared311 med par, first312 validity recast, mi bzod/imperceptibility and the full near-god cupful relation remain unbanked with reasons. Keep lexical consequence thal, occurrence-specific necessity, three visual faculties and original HGM-supported ocean depths/entire extent. GMR/source bytes remain verbatim; no machine correspondence enters hgm_gloss.
- Canonical production builders ran once in14.174221s. All17 fidelity tests passed in11.40s. All prior46,458 links,22,865 CSV rows, notes, trees, evidence, ACIP and references retained. Current measured totals46,571 links/11,975 nulls/1,648 notes/11 trees/7,140 heads/15,761 pairs;7,137 heads carry ACIP proof. CSV22,902 main/22,562 reverse/24,529 course/37 changes. Inherited42 display depth shortfalls and28 trimming calls remain; view diagnostic11,976 skipped links differs from full-layer null count.
- All seven complete outputs independently reproduced exactly from558 registered pages and the actual incoming CSV seed. Passing proof: /Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through312-attempt02/proof.json. Actual failed first preparation remains at compact-reproduction-through312: missing retention proof due root dependency ordering, zero native builder runs. No passing production/test/reproduction was rerun for packaging.
- Actual root master-wrapper schema failure and registration v4 format rejection remain banked. Successful source preflight attempt02 normalized only record/entry wrappers; registration v5 supports the actual v1 review schema and dictionary manifest while keeping exact baseline/source/freeze gates. Whitespace preparation v3 and audit v11 only normalize manifest representation; existing warning classes and byte checks are unchanged. Every staged whitespace diagnostic is checked and retained in late evidence; frozen source/review bytes are not normalized.
- Fixed private DATA @DATA@ follows @BASE@. Exact staged-tree and source/review/output bindings precede that commit; this same append-only entry is separately committed to all three ledgers. Completion @UTC@. Closure proof retains actual Git streams, parents/tree, clean tracked state and preexisting untracked caption alias.
- Desktop-consumable outputs through312 are verified in isolation. The complete through309 MAIN applicability assessment is now root accepted:314 actual native whole-file partitions,38,782 paths,3502 frozen evidence files. Its prior audit-patch gap is closed. This batch references the preserved1.235GB compressed patch proof once; it does not claim a new312 MAIN applicability assessment. MAIN is not applied; native rendering, QSettings and merged runtime remain open. Phone pack remains FAILED_UNACCEPTED for four inherited C01 mappings; no install, historical installedthrough171 unchanged. External evidence drive required; preserve all other work.
- Next313–315 has both originals and730-file reconciliation frozen; fresh independent semantic review active. Both316–318 independent original proposals run separately. Original source309 is distinct from future acceptance312/315. Existing one-minute automation remains active through2026-09-15 07:00 America/Denver, then pause. No paid generation, releases or external account actions.
'''
p=B/'landing/root-ledger-entry-template.md';assert not p.exists();p.write_text(entry)
print(json.dumps(dict(status='PREPARED',method_files=len(records),ledger_bytes=p.stat().st_size),indent=2))
