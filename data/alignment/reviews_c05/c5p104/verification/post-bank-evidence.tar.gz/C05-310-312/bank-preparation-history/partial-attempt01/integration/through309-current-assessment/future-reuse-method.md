# Future outer-assessment reuse guidance

This is guidance for a later assessment, not an unperformed current proof.

Retain this 309 freeze and its complete native whole-file partition proofs. At the next fixed FINAL, derive candidate patches from original campaign base `455c92d6171bf3628dd0e81a2dcc4ceaa7594f2d` to that next FINAL using the same explicit Git diff options. MAIN has not received 309; a raw `309 → next` patch must not be checked against MAIN as if 309 were installed.

An unchanged complete whole-file patch may reuse its passing 309 partition proof only after verifying its exact patch bytes, fixed old/new Git identities and modes, and relevant current MAIN file bytes/mode/presence, path and ancestor identities against this assessment. Retain the mapping from every reused file to the frozen passing partition and lossless native input. Check new or changed complete whole-file patches natively against then-current MAIN. Recompute full path coverage, destinations, ancestor/prefix and case-fold interactions across both reused and new sets; evaluate interactions together if they arise. MAIN changes invalidate any affected reuse even if the candidate patch is unchanged.

Keep the preserved 1,235,324,013 compressed patch bytes once and reference their exact frozen hashes. Avoid another complete audit-patch copy or production test/build repeat unless material changes require it. Continue complete before/after MAIN and fixture/caption preservation checks and state the exact reused versus newly checked sets. Native applicability remains separate from actual application, consumer behavior and root disposition.
