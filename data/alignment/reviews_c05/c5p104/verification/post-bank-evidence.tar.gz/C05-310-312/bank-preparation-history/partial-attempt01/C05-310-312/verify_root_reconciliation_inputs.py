"""Root's source/occurrence intake; fresh semantic acceptance is a later step.

Reuse the reconciler's actual generator executions. Independently resolve all
original/final spans with unchanged canonical functions, and recheck the full
source records and source-count claims. No production writes or generation.
"""
from pathlib import Path
from collections import Counter
import datetime, gzip, hashlib, importlib.util, json, os, re, sqlite3, subprocess, sys

B = Path(__file__).resolve().parent
Q = B / 'reconciled'
W = B.parent.parent / 'campaign-worktree'
OUT = B / 'root-reconciliation-inputs'
assert not OUT.exists()
def read(p): return json.loads(p.read_bytes())
def pin(b): return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def expected(p): return {k: p[k] for k in ('bytes', 'sha256')}
def git(*args): return subprocess.check_output(['git', *args], cwd=W)
def freeze(base, name, want):
    assert pin((base/name).read_bytes())['sha256'] == want
    f = read(base/name)
    items = f['files'].items() if isinstance(f['files'], dict) else [(r['path'], r) for r in f['files']]
    n = 0
    for rel, record in items:
        p = base/rel
        assert p.resolve().is_relative_to(base.resolve())
        assert pin(p.read_bytes()) == expected(record), rel
        n += 1
    return n

freeze_counts = {}
for angle, name, sha in [
    ('tibetan', 'freeze-manifest.json', 'c7631740582c0b98e79f396e9af4890660ac58b8708cc5877c8f7a076683d9f3'),
    ('english', 'freeze.json', 'ba3a7180dc87ad0adf7a4e9738f77936b655f135afaa26915cad01f3b2a61f22'),
    ('reconciled', 'freeze.json', 'bb799b6c6c307429b266d98efb096f58f25bd6553b17e20d64d1069319456d6c')]:
    freeze_counts[angle] = freeze(B/angle, name, sha)
origin = read(B/'proposal-baseline.json')
baseline = read(B/'baseline.json')
assert git('rev-parse', 'HEAD').decode().strip() == baseline['commit'] == '8575edf1e0de695677194c1fde60f1d9e2c2f204'
assert baseline['course_boundary'] == 309
assert origin['commit'] == '51d73c889a3f175b90e4c466f3dc4b1f7af3bca5'
assert not git('status', '--porcelain', '--untracked-files=no')
for p in origin['source_pins'].values(): assert pin(Path(p['path']).read_bytes()) == expected(p)
for rel, p in origin['governing_git_pins'].items():
    assert pin(git('show', origin['commit']+':'+rel)) == expected(p)
    assert pin((Q/'evidence/pinned'/rel).read_bytes()) == expected(p)
copy_records = read(Q/'evidence/original-copy-map.json')
for m in copy_records:
    o = m['original']
    raw = git('show', o['git_commit']+':'+o['path']) if isinstance(o, dict) else Path(o).read_bytes()
    assert pin(raw) == expected(m), o
    if m['copy'] is not None: assert (Q/m['copy']).read_bytes() == raw
for p in read(Q/'evidence/access.json'): assert os.access(p['path'], os.R_OK)

# Load the exact historical dependency; use the current generator only after
# proving it is the identical canonical file used for these proposals.
P = Q/'evidence/pinned'
sys.path.insert(0, str(P/'engines'))
bs = importlib.util.spec_from_file_location('build_alignment_layer', P/'tools/build_alignment_layer.py')
builder = importlib.util.module_from_spec(bs)
sys.modules[bs.name] = builder
bs.loader.exec_module(builder)
assert pin((W/'tools/gen_alignment_page.py').read_bytes()) == expected(origin['governing_git_pins']['tools/gen_alignment_page.py'])
gs = importlib.util.spec_from_file_location('root_canonical_generator', W/'tools/gen_alignment_page.py')
g = importlib.util.module_from_spec(gs)
gs.loader.exec_module(g)
db = sqlite3.connect(Path(origin['source_pins']['spine']['path']).as_uri()+'?mode=ro', uri=True)
db.row_factory = sqlite3.Row
db.execute('PRAGMA query_only=ON')
sources = {r['seq']: dict(r) for r in db.execute('SELECT * FROM corpus_segments WHERE course=? AND seq BETWEEN ? AND ? ORDER BY seq', ('C05',310,312))}
for row in read(B/'source.json'): assert all(sources[row['seq']][k] == v for k,v in row.items())
for row in read(B/'context.json'):
    actual = dict(db.execute('SELECT * FROM corpus_segments WHERE course=? AND seq=?', (row['course'],row['seq'])).fetchone())
    assert all(actual[k] == v for k,v in row.items())

resolved = {}; executions = []; reports = []
for angle in ('tibetan', 'english', 'final'):
    for seq in range(310,313):
        directory = Q/str(seq) if angle == 'final' else B/angle/str(seq)
        proof = read(Q/str(seq)/'mechanical-proof.json') if angle == 'final' else None
        native = Q/proof['generator_proof'] if proof else Q/'native'/f'{angle}-{seq}-generate-once'
        resolver = Q/proof['resolver_proof'] if proof else Q/'native'/f'{angle}-{seq}-resolve'
        raw = (directory/'spec.json').read_bytes(); body = (directory/'body.html').read_bytes()
        spec = json.loads(raw); assert spec['course'] == 'C05' and len(spec['segments']) == 1
        seg = spec['segments'][0]; assert seg['seq'] == seq
        for n in (native, resolver):
            assert (n/'stdin.json').read_bytes() == raw
            assert (n/'stderr').read_bytes() == b'' and (n/'exit.txt').read_bytes() == b'0\n'
            ex = read(n/'execution.json'); inv = read(n/'invocation.json')
            assert ex['exit'] == 0 and ex['stdin_sha256'] == pin(raw)['sha256']
            for stream in ('stdout', 'stderr'):
                p = pin((n/stream).read_bytes())
                assert p['bytes'] == ex[stream+'_bytes'] and p['sha256'] == ex[stream+'_sha256']
            assert inv['cwd'] == str(W) and inv['env_additions']['PYTHONDONTWRITEBYTECODE'] == '1'
            assert '-B' in inv['argv']
        assert (native/'stdout').read_bytes() == body
        observed = read(resolver/'stdout')['segments'][0]
        assert observed['original_row'] == sources[seq]
        assert observed['eng_order'] == seg['eng_order']
        spans = seg['spans']; byid = {s['id']:s for s in spans}; assert len(byid) == len(spans)
        tr = g.resolve(sources[seq]['wylie'],spans,'tib',seq)
        er = g.resolve(sources[seq]['english'],g.with_members(spans,[byid[i] for i in seg['eng_order']],sources[seq]['english']),'eng',seq)
        rows = []; parent = None
        for s,o in zip(spans,observed['resolved'],strict=True):
            if s['d'] != 7: parent = s['id'] if s['d'] == 5 else None
            row = dict(seq=seq,**{k:s[k] for k in ('id','d','tib','eng')},tib_range=list(tr[s['id']]),eng_range=list(er[s['id']]) if s['eng'] is not None else None)
            assert all(o[k] == v for k,v in s.items())
            assert all(o[k] == row[k] for k in ('tib_range','eng_range'))
            assert o['parent'] == (parent if s['d']==7 else None)
            rows.append(row)
        resolved[(angle,seq)] = rows
        executions.append(dict(angle=angle,seq=seq,native=str(native),resolver=str(resolver),spec=pin(raw),body=pin(body),generator_exit=0,root_action='Reused actual generator streams; independently called canonical resolver'))
        if angle == 'final':
            tuples = read(directory/'final-ordered-tuples.json')['tuples']
            assert rows == [dict(seq=seq,**{k:t[k] for k in ('id','d','tib','eng','tib_range','eng_range')}) for t in tuples]
            for k,v in proof['files'].items(): assert pin((directory/k).read_bytes()) == expected(v)
            assert read(directory/'errata.json') == []
            reports.append(dict(seq=seq,spans=len(rows),nulls=sum(s['eng'] is None for s in spans),nonnull_d5=sum(s['d']==5 and s['eng'] is not None for s in spans),d7=sum(s['d']==7 for s in spans),depths=dict(Counter(s['d'] for s in spans))))

dispositions = Counter(); differences = []
for seq in range(310,313):
    finals = {t['id']:t for t in read(Q/str(seq)/'final-ordered-tuples.json')['tuples']}
    d = read(Q/str(seq)/'original-dispositions.json')
    assert len(d['dispositions']) == d['original_proposal_spans']
    seen = set()
    for x in d['dispositions']:
        orig = resolved[(x['angle'],seq)][x['original_index']]
        assert (x['angle'],x['original_index']) not in seen
        seen.add((x['angle'],x['original_index']))
        assert all(orig[k] == x['original_seven_key_tuple'][k] for k in ('id','d','tib','eng','tib_range','eng_range'))
        assert read(Path(x['original_spec_path']))['segments'][0]['spans'][x['original_index']] == x['original_span_object']
        for fid, t in zip(x['final_ids'],x['final_seven_key_tuples'],strict=True): assert all(finals[fid][k] == v for k,v in t.items())
        reason = x['independent_disposition']
        assert reason == ' '.join(finals[fid]['independent_judgment'] for fid in x['final_ids'])
        exact = any(all(orig[k] == finals[fid][k] for k in ('d','tib','eng','tib_range','eng_range')) for fid in x['final_ids'])
        assert exact == (x['status']=='RETAIN_EXACT_CORRESPONDENCE')
        dispositions[x['status']] += 1
        if not exact: differences.append(x)
assert sum(dispositions.values()) == 195

master = json.load(gzip.open(origin['source_pins']['master']['path'],'rt'))
corpus = json.load(gzip.open(origin['source_pins']['corpus']['path'],'rt'))
master_indices = {}; full_master = set(); full_corpus = set()
for section in ('unified_entries','curated_entries','glossary_entries'):
    values = master[section]
    values = list(values.values()) if isinstance(values,dict) else values
    master_indices[section] = values
def master_query(term,section):
    return [dict(index=i,record=r) for i,r in enumerate(master_indices[section]) if isinstance(r,dict) and (r.get('wylie')==term or term in (r.get('wylie_variants') or []))]
for x in read(Q/'evidence/independent-master-records.json'):
    for section,rows in x['sections'].items():
        assert rows == master_query(x['term'],section)
        assert len(rows) == x['counts'][section]
        full_master.update((section,r['index']) for r in rows)
for x in read(Q/'evidence/original-master-requeries.json'):
    normalized = []
    for row in x['full_records']:
        assert set(row) in ({'index','entry'}, {'index','record'})
        normalized.append(dict(index=row['index'],record=row['entry'] if 'entry' in row else row['record']))
    assert normalized == master_query(x['term'],x['section'])
    assert x['count'] == len(x['full_records'])
    full_master.update((x['section'],r['index']) for r in x['full_records'])
def corpus_row(row):
    assert json.loads(row['raw']) == corpus[row['id']-1]
    assert all(corpus[row['id']-1][k] == row[k] for k in ('course','acip','wylie','english'))
    full_corpus.add(row['id'])
queries = read(Q/'evidence/independent-corpus-queries.json')
for q in queries:
    actual = [dict(r) for r in db.execute(q['sql'],q['parameters'])]
    assert actual == q['rows'] and len(actual) == q['count']
    for row in actual: corpus_row(row)
for q in read(Q/'evidence/independent-original-corpus-records.json'):
    src = sources[q['seq']]
    actual = [dict(index=i,record=r,equal_fields=[k for k in ('acip','wylie','english') if r.get(k)==src[k]]) for i,r in enumerate(corpus) if any(r.get(k)==src[k] for k in ('acip','wylie','english'))]
    assert q['rows'] == actual and q['count'] == len(actual)
physical = Path(origin['source_pins']['physical']['path']).read_bytes()
for x in read(Q/'evidence/independent-physical-extents.json'):
    raw = physical[slice(*x['range'])]
    assert pin(raw) == expected(x) and raw.decode('latin1') == x['latin1_reversible']
    assert ' '.join(raw.decode('ascii').split()) == ' '.join(sources[x['seq']][x['field']].split())
register = read(P/'docs/errata_register.json'); reg_by_id = {r['item_id']:r for r in register}
def occurrences(text,quote): return [[m.start(),m.start()+len(quote)] for m in re.finditer('(?='+re.escape(quote)+')',text)]
screens = 0
for seq in range(310,313):
    for s in read(Q/str(seq)/'errata-five-grounds.json')['screens']:
        screens += 1
        assert s['refuted_for_filing'] and s['proposed_correction'] is None
        a=s['ground_a_exact_original_quotes']; assert a['original_full_source_row']==sources[seq]
        for q in a['quotes']:
            assert occurrences(sources[seq][q['field']],q['quote'])==q['occurrences'] and len(q['occurrences'])==q['count']
        c=s['ground_c_registered_classes']; assert c['historical_register_entries']==len(register)
        assert c['register_sha256']==pin((P/'docs/errata_register.json').read_bytes())['sha256']
        assert c['english_characters']==len(sources[seq]['english']) and not c['duplicate_this_segment']
        for rec in c['full_reviewed_class_records']: assert reg_by_id[rec['item_id']]==rec
        for q in s['ground_e_counts_and_evidence']['original_local_quote_counts']:
            measured=occurrences(sources[seq][q['field']],q['quote'])
            if 'reported_count' in q: assert len(measured)==q['reported_count']==q['measured_count']
            else: assert measured==q['measured_occurrences'] and q['reported_range'] in measured
    omissions=read(Q/str(seq)/'material-omissions.json')
    assert omissions['material_omission_count']==len(omissions['omissions'])
    for o in omissions['omissions']:
        assert not o['null_proposed']
        for q in o['exact_original_evidence']: assert occurrences(sources[seq][q['field']],q['quote'])==q['occurrences'] and len(q['occurrences'])==q['count']
db.close()
assert screens == 6
finals = sum((resolved[('final',seq)] for seq in range(310,313)),[])
assert len(finals)==110 and sum(r['nulls'] for r in reports)==1 and sum(r['nonnull_d5'] for r in reports)==73
OUT.mkdir()
def save(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
save('resolved-spans.json',finals);save('original-resolved-spans.json',[dict(angle=a,seq=s,rows=v) for (a,s),v in resolved.items() if a!='final'])
save('execution-reuse.json',executions);save('report.json',reports);save('changed-original-dispositions.json',differences)
proof=dict(status='PASS_ROOT_RECONCILIATION_INPUTS_PENDING_FRESH_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=baseline['commit'],source_origin=origin['commit'],frozen_files=freeze_counts,copy_records=len(copy_records),root_generator_runs=0,reused_original_generator_runs=6,reused_reconciled_generator_runs=3,root_canonical_resolved_spans=sum(len(v) for v in resolved.values()),dispositions=dict(dispositions),five_ground_screens=screens,actual_SQL_queries=len(queries),complete_master_objects=len(full_master),complete_corpus_objects=len(full_corpus),physical_extents=6,reconciliation_freeze=pin((Q/'freeze.json').read_bytes()),limits=['Fresh skeptical review not consumed by this step.','No production acceptance or repository/source modification.','Historical dictionary/register counts remain historical; only explicitly rederived queries are current.'])
save('proof.json',proof)
print(json.dumps(proof,indent=2))
