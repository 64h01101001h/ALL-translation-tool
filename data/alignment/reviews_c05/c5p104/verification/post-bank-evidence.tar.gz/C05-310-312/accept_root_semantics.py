"""Bind the separately read root semantic judgment to the exact fresh review.

Reuse completed root source/native checks only for their unchanged inputs.
The subsequent standard acceptance gate verifies all original copy records.
"""
from pathlib import Path
import datetime, hashlib, json, subprocess, shutil
B = Path(__file__).resolve().parent
S = B / 'semantic-review'
W = B.parents[1] / 'campaign-worktree'
def read(p): return json.loads(p.read_bytes())
def pin(p):
    b = p.read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def put(p, value):
    assert not p.exists(), p
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
f = read(S/'freeze.json'); m = read(S/'review.json')
assert pin(S/'freeze.json')['sha256'] == '5d255ecbb1c8acd37afbea717859d3f9851fd1aac5520583c6f66eecf589e6d9'
assert f['verdict'] == f['spec_verdict'] == f['quality_verdict'] == m['verdict'] == 'APPROVE'
assert f['open_findings'] == m['open_findings'] == []
assert len(f['files']) == f['file_count'] == 442
for rel, expected in f['files'].items():
    p = S/rel
    assert p.resolve().is_relative_to(S.resolve())
    assert pin(p) == expected, rel
for row in f['operational_helpers_with_exact_frozen_mirrors']:
    assert (S/row['path']).read_bytes() == (S/row['exact_frozen_copy']).read_bytes()
old = read(B/'root-reconciliation-inputs/proof.json')
assert old['status'] == 'PASS_ROOT_RECONCILIATION_INPUTS_PENDING_FRESH_SEMANTIC_ACCEPTANCE'
assert old['reconciliation_freeze'] == pin(B/'reconciled/freeze.json')
for folder, name in [('tibetan','freeze-manifest.json'),('english','freeze.json'),('reconciled','freeze.json')]:
    frozen = read(B/folder/name)
    assert len(frozen['files']) == old['frozen_files'][folder]
    for rel, expected in frozen['files'].items():
        assert pin(B/folder/rel) == expected, (folder,rel)
resolved = read(B/'root-reconciliation-inputs/resolved-spans.json')
assert resolved == read(S/'resolved-spans.json') and len(resolved) == 110
decisions = read(S/'all-span-decisions.json')
assert [{k:r[k] for k in resolved[0]} for r in decisions] == resolved
assert len(read(S/'all-original-disposition-decisions.json')) == 195
assert len(read(S/'all-omission-decisions.json')) == 20
assert len(read(S/'errata-five-grounds.json')) == 6
assert read(S/'bank-ready-errata.json') == []
assert read(S/'span-head-allow-needed.json') == {'pages_c05':{}}
assert (m['total_spans'],m['total_nulls'],m['total_word_pairs'],m['total_d7']) == (110,1,73,16)
native=[]
for seq in [310,311,312]:
    spec=B/f'reconciled/{seq}/spec.json'; body=B/f'reconciled/{seq}/body.html'
    for mode in ['generate','resolve']:
        p=S/f'native/final-{seq}-{mode}-01'
        assert read(p/'stdin.json') == read(spec)
        assert (p/'stdin.json').read_bytes() == spec.read_bytes()
        assert (p/'stderr.txt').read_bytes() == b'' and int((p/'exit.txt').read_text()) == 0
        invocation=read(p/'invocation.json')
        assert invocation['pinned_origin'] == old['source_origin']
        assert invocation['cwd'] == str(W)
        if mode=='generate': assert (p/'stdout.txt').read_bytes() == body.read_bytes()
        else: assert read(p/'stdout.txt') == [r for r in resolved if r['seq']==seq]
        native.append(dict(seq=seq, mode=mode, path=str(p), files={x.name:pin(x) for x in p.iterdir() if x.is_file()}))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert head == old['baseline'] == read(B/'baseline.json')['commit']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W)
compat=B/'root-reconciliation-verification'; compat.mkdir(exist_ok=False)
shutil.copy2(B/'root-reconciliation-inputs/resolved-spans.json',compat/'resolved-spans.json')
reading='Root read complete final fresh report and all110 fresh source-specific decisions, all20 fresh omission judgments, all6 fresh five-ground judgment texts and actual failure/limit disclosures. Previous root reading covers all source texts, six original reports/specs,195 original dispositions, all final ranges/reasons,31 complete critical master records and three complete critical corpus witnesses; whole190 master/289 corpus objects were independently verified. Broad repeated evidence metadata was identity-checked without claiming fresh linguistic reading of every string.'
intake=dict(status='PASS_ROOT_CURRENT_INTAKE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=head,source_origin=old['source_origin'],frozen_file_counts={**old['frozen_files'],'semantic':442},reading=reading,prior_root_checks=pin(B/'root-reconciliation-inputs/proof.json'),prior_root_reading=pin(B/'root-reconciliation-reading.json'),root_canonical_resolution_spans=305,root_generator_executions=0,independent_final_native_executions_reused=3,original_native_replays_reused=6,semantic_report=pin(S/'review.md'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),fresh_native_identity=native,limits=['Original-to-copy manifest is checked by the next standard acceptance gate before landing.','One read-only inspection incorrectly expected reviewer resolver output to be an object; actual output is a seven-key tuple list. No native execution or alignment changed.','Initial root master-wrapper comparison failure and actual passing attempt02 are retained.'])
put(B/'root-reconciliation-intake.json',intake)
out=dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),page='c5p104',segments=[310,311,312],counts=dict(spans=110,nulls=1,nonnull_d5=73,total_d5=74,d7=16),source_origin=old['source_origin'],actual_baseline=head,review=pin(S/'review.md'),review_json=pin(S/'review.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),read_evidence=reading,semantic_decision='Accept the complete conditional at d2; established compounds and their16 contained members; occurrence-specific birth, experience and three visual faculties. thal expresses lexical consequence in have to/must. Preserve nominal gnas/place, whole instrumental blos/think and two residence predicates at E418 and721. Ocean nang/depths and tshad/entire extent are supported by full original HGM evidence; later constitutive gro/be has full SVN:1167 construction support. Necessity predicates retain only their own English occurrences. Keep uncertain first-validity recast, mi bzod/imperceptibility and near-god cupful relation unbanked with reasons.',null_decisions='Only310 lus: body/bodily has no separate English exponent; myong owns experiencing. Negative exclusion and shared311 med par remain distributed omissions, never positive existence or uncertain nulls.',errata='Six complete five-ground screens produce no bankable errata; digital repeats establish no publication independence. Actual partial P7:47 and extra-heading C16:848 remain distinguished from exact witnesses.',execution_reuse='All305 original/final canonical source resolutions and prior original/reconciliation native proofs reused only after exact current identities. Three fresh reviewer generators and resolver streams exactly match accepted source specs and bodies. Normal aggregate production generation, fidelity checks and independent reproduction follow.',limits='Provisional machine acceptance only; no hgm_gloss promotion, human editorial approval, MAIN application, merged runtime or device acceptance.')
put(B/'root-semantic-disposition.json',out)
print(json.dumps({k:v for k,v in out.items() if k not in ['read_evidence','semantic_decision']},indent=2))
