"""Adapt the verified309 private closure to the actual312 evidence boundary."""
from pathlib import Path
import difflib, hashlib, json, datetime
B=Path(__file__).resolve().parent; A=B.parent
old=(A/'close_c05_309_compact.py').read_text(); new=old
changes={
"B = A / 'C05-307-309'":"B = A / 'C05-310-312'",
"BASE = '51d73c889a3f175b90e4c466f3dc4b1f7af3bca5'":"BASE = '8575edf1e0de695677194c1fde60f1d9e2c2f204'",
'compact-reproduction-through309':'compact-reproduction-through312-attempt02',
"B/'semantic-review/review-freeze.json'":"B/'semantic-review/freeze.json'",
"(frozen['counts']['spans'],frozen['counts']['nulls'],frozen['counts']['nonnull_d5_word_pairs'])==(129,4,75)":"(frozen['total_spans'],frozen['total_nulls'],frozen['total_word_pairs'])==(110,1,73)",
"for row in frozen['files']:":"for relative, value in frozen['files'].items():\n    row=dict(path=relative,**value)",
"reviewroot/'review-freeze.json'":"reviewroot/'freeze.json'",
'(307,308,309)':'(310,311,312)',
"'root-register-caller'":"'root-register-attempt02-caller'",
"'root-compact-reproduction-caller'":"'root-compact-reproduction-attempt02-caller'",
"'root-whitespace-audit-attempt02-caller'":"'root-whitespace-audit-caller'",
'segments 307–309':'segments 310–312',
'through segment 309':'through segment 312',
'coverage=309,remaining=202':'coverage=312,remaining=199',
"'data/alignment/span_head_allow.json',":"",
}
for before,after in changes.items():
    assert before in new,before
    new=new.replace(before,after)
new=new.replace('c5p103','__CURRENT_PAGE__').replace('c5p102','c5p103').replace('__CURRENT_PAGE__','c5p104')
start=new.index("assert read(B/'root-whitespace-audit-caller/execution.json')['exit']==1")
end=new.index("assert read(B/'landing/registration/proof.json')",start)
new=new[:start]+'''assert read(B/'format-adapters/review.json')['verdict']=='APPROVE'
adapter=read(B/'format-adapters/review.json')['changes']
assert len(adapter)==2
for row in adapter:
    assert sha((A/row['old']).read_bytes())==row['old_sha256']
    assert sha((A/row['new']).read_bytes())==row['new_sha256']
assert read(B/'root-register-caller/execution.json')['exit']==1
assert read(B/'root-compact-reproduction-caller/execution.json')['exit']==1
assert read(B/'root-bank-preparation-caller/execution.json')['exit']==1
assert read(B/'root-bank-preparation-attempt02-caller/execution.json')['exit']==0
assert read(B/'root-reconciliation-inputs-caller-attempt02/execution.json')['exit']==0
assert (B/'root-reconciliation-inputs-caller-attempt02/exit.txt').read_bytes()==b'0\\n'
assert read(B/'root-semantic-disposition.json')['verdict']=='APPROVE_ROOT_SEMANTIC_ACCEPTANCE'
assert read(B/'root-reconciliation-intake.json')['review_freeze']==pin((B/'semantic-review/freeze.json').read_bytes())
''' +new[end:]
start=new.index("inputs.extend([Path(__file__).resolve(),B/'prepare_compact_closure.py'")
end=new.index('inputs=sorted(set(inputs)); members=[]',start)
new=new[:start]+'''inputs.extend([Path(__file__).resolve(),B/'prepare_compact_closure.py',B/'closure-method-review.json',B/'closure-method.diff.txt',B/'root-semantic-disposition.json',B/'root-reconciliation-intake.json',B/'verify_root_reconciliation_inputs.py',B/'accept_root_semantics.py'])
inputs.extend([A/'audit_staged_source_whitespace_v6.py',A/'audit_staged_source_whitespace_v7.py',A/'audit_staged_source_whitespace_v8.py',A/'audit_staged_source_whitespace_v11.py',A/'C05-286-288/compact-reproduction-review/whitespace-v7-review.json',A/'C05-292-294/whitespace-v8-root-review.json'])
inputs.extend([A/'register_reviewed_page_v4.py',A/'register_reviewed_page_v5.py',A/'prepare_review_whitespace_pins_v3.py',B/'registration-format-adaptation.json'])
# All442 fresh frozen files are readable in the current semantic package. Broad
# through309 integration native evidence remains once at its original location.
inputs.extend([A/'integration/through309-root-disposition.json',A/'integration/through309-current-assessment/review.md',A/'integration/through309-current-assessment/assessment.json',A/'integration/through309-current-assessment/freeze.json'])
for folder in ('format-adapters','bank-preparation-history','root-bank-preparation-caller','root-bank-preparation-attempt02-caller','root-register-caller','root-register-attempt02-caller','root-reconciliation-inputs-caller-attempt02'):
    inputs.extend(p for p in (B/folder).rglob('*') if p.is_file())
''' +new[end:]
out=A/'close_c05_312_compact.py';assert not out.exists();compile(new,str(out),'exec');out.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='close_c05_309_compact.py',tofile=out.name))
(B/'closure-method.diff.txt').write_text(diff)
print(diff)
