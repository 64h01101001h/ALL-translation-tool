C05:328 — Codex TIBETAN-FIRST, PROVISIONAL proposal. Source origin daad5db6ea6207085dc820101b3a2e9aaf942417, through324 only.
The distributive gsum gsum remains omitted: each and three are discontinuous; thams cad cannot borrow the unrelated all.
Raw srog gcod ba/killing is supported by full HTG2016 entry25722. Completion and the polar question are d3 recasts.
Three local comes/from pairs resolve to the desire, dislike and ignorance clauses; las/action and lam/paths stay inside las lam.
Two nulls assert only the missing outline ordinal and first list conjunction. No erratum is proposed after the five-ground screen.
Original decisions, all omissions and exact occurrence ranges: original-decisions.json; five-ground-screens.json records every errata ground.
Complete shared originals and reading scope: ../evidence/original-to-copy-manifest.json and ../reading-receipt.json; query replays and full entries are preserved once.
Measured: 23 spans; 2 nulls; 12 nonnull d5 word pairs; 13 total d5; 2 d7; 0 errata.
Generator EXIT=0; stderr empty; body 4250 bytes; SHA256 32c4de6b97179366f9ef105db75916d65254f53192dc274f863c1dabd648c254.
Resolver EXIT=0; stderr empty; resolved-spans.json exactly matches ../intended-ranges.json. Both native directories preserve actual argv/stdin/stdout/stderr/exit.
Spec 4164 bytes; SHA256 e919ef5888a8322e1f361b26c9ca792a4fbce238b0bb9b616173c86e711bd071. Generator stdout equals body.html byte-for-byte; both unwrapped source fields match the frozen source.
