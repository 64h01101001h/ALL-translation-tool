from pathlib import Path
import json
T=Path(__file__).resolve().parent
ranges=json.loads((T/'intended-ranges.json').read_text())
def write(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
decisions={
328:[
 ('w1','gnyis pa names the second outline item. English begins Now but never gives its ordinal; the null records only the missing numeral.'),
 ('w2,w11','mdo is the quoted sutra, made the subject of states. gsungs supplies the speech predicate; there is no separate English from for the first source-attribution las.'),
 ('w3','Raw srog gcod ba is killing in this exact three-type classification. Complete HTG2016 entry25722 attests that raw form; entry21037 gives the pa comparison, without requiring a correction.'),
 ('w4','This is the gsum immediately after killing, paired with the first English three at32–37. The later roots numeral is part of gsum gsum and is not claimed.'),
 ('w5,p1,w6','First birth clause: desire is the root and the implicit killing-type is what comes from it. comes67–72/from73–77/desiring78–86 belong together; something is supplied.'),
 ('p2','First dang ends the desire item; English uses its list comma. Only the later dang owns the actual and.'),
 ('w7,p3,w8','Second birth clause: dislike is the root. comes109–114/from115–119/disliking120–129 belong together. Entry16268 is only medium-confidence auto-aligned intersection evidence, not binding correction authority.'),
 ('p4,w9,p5,w10','Third birth clause: and141–144 opens the ignorance member. comes156–161/from162–166/ignorant173–181 attach to that member. The full inflected skyes pas is kept; no agentive s is split. being and of things are unwrapped.'),
 ('w12,m1,m2','las lam is the established path-of-action compound. Its members resolve within the actual parent230–245: las/action239–245 and lam/paths230–235. They cross only in English, and do not claim a different las/from.'),
 ('w13','rtsa ba belongs to the roots in the completion question, hence roots292–297. It does not own all non-virtue, which is explanatory English.'),
 ('f1','mthar phyin par byed pa is the complete causative completion construction. brought to completion255–276 is its passive recast, at d3; this is not a dictionary word or compound.'),
 ('f2,f3','yin nam min is the positive/negative polar question, compressed as whether210–217. zhe na is the quotative question frame, realized as ask201–204. Both are phrases at d3; One may then are left unwrapped.'),
],
329:[
 ('w1','min answers no to completion by each root in328. Only not28–31 is selected; the English answer subject and copular frame are supplied.'),
 ('w2,p1,w3','The Tibetan nominalized statement from sutra is recast as statement37–46/from47–51/sutra52–57. p1 cannot drift to the later from159–163.'),
 ('w4,w5','srog gcod pa is the deed example, killing146–153, and comparative lta bu supplies such as138–145. The genitive suffix is omitted; deeds is an explanatory English head.'),
 ('w6','sbyor ba names the technical undertaking stage, not generic preparation. Its whole English label includes stages108–128; full HTG2016 entry13634 includes the singular stage label. There is only one occurrence here.'),
 ('w7,w8,p2,w9','rtsa ba gsum is the root three168–178 from which the undertakings come154–158/from159–163. These pairs do not borrow the source-attribution from earlier in the sentence.'),
 ('p3,w10','dgongs is the intentional reference relation narrowed by this completion/undertaking distinction. The nominal recast reference77–86 is kept at d5; la governs its target as to87–89. Complete entry2394 includes referring and only-with-reference expressions, but supplied only/with/the fact that remain unwrapped.'),
],
330:[
 ('w1,w2,w3','The first noun phrase is the undertaking stages63–83 of the ten91–94 non-virtues95–106. mi dge ba is kept as one compound; no unapproved non affix span or invented word-pair is created.'),
 ('w4,w5,p1,w6','The opening general statement has come107–111/from112–116/three121–126/roots127–132. The later three motive clauses have different comes/from occurrences.'),
 ('f1','ji lta bu zhe na asks what the process is like. ask for a description of the process13–49 is a complete English question recast and is retained only as d3. One may next and by which remain unwrapped.'),
 ('w7,w8','The first srog gcod pa introduces killing176–183 in a separate English sentence; its genitive is distributed into the following of this type of act. The following sbyor ba is the second technical label189–208. Neither owns the repeated undertaking stage later supplied in the dislike and ignorance examples.'),
 ('w9,p2,w10','Desire example: comes229–234/from235–239/desire240–246 belongs to killing for flesh, not the general introductory non-virtues.'),
 ('w11,p3,w12,m1,w13','sha is flesh332–337, while phyir du gives the purpose in order to312–323. The second killing expression is take the life281–294, with only srog/life290–294 as a tighter member. The actual first example lta bu supplies for example264–275. Participants, get and to eat expand the local flesh-purpose explanation and are not separate Tibetan lexemes here.'),
 ('p4,w14,w15,w16,w17','The dislike clause has raw zhe sngang, which is omitted, then comes375–380/from381–385 and kill413–417/enemy423–428. Its final lta bu is recast as instance349–357 at the front of this same sentence. No span claims desire-clause for example or a different kill.'),
 ('w18,p5,w19,w23,w24','Ignorance is the final motive: comes469–474/from475–479/ignorant486–494, then kill524–528. The final lta bu owns case436–440 in this final sentence, not the earlier case249–253 belonging to the desire setup. Whole local sentence inspection selects this occurrence.'),
 ('w20,p6,w21','bsod nams is meritorious576–587 in the professed good intention, not an assertion that killing is virtuous. It is not prayer-register goodness. kyi has no separate English exponent in adjectival premodification; its one null explicitly records that fusion. blos supplies intent588–594 as the whole inflected substantive, without splitting the agentive s; out of some remains unwrapped.'),
 ('w22','Raw pham is the father-or-mother compound at265–269 and English547–563. Complete HTG2016 entry24043 directly records father or mother, as does comparison entry11546 for pha ma. The source form remains unchanged; no internal pham split or your participant is claimed.'),
]}
omissions={
328:[
 {'tib':'[iv.272-6]','reason':'Citation apparatus, not translation.'},
 {'tib':'ni; first las; ste; na','reason':'Outline topic, source attribution, enumeration and conditional framing are recast across the English; no asserted independent word correspondence.'},
 {'tib':'thams cad','reason':'Totality is recast with various in the path phrase. The later all modifies non-virtue, not paths, so it cannot be borrowed. No null is used for this distributed content.'},
 {'tib':'gsum gsum','reason':'The reduplicated distributive is realized discontinuously as each249–253 and three286–291. Assigning one repeated gsum to each would turn a construction into a false word-equivalent; assigning only a guessed half to three would conceal the distribution.'},
 {'tib':'gyis','reason':'Instrumental relation contributes to the passive by these three roots. Standalone agentive by remains a standing policy question; omitted without claiming it is absent.'},
 {'eng':'Now; that there are; types of; that which; something; being; of things; One may; then; the various; are each; by these three; of all non-virtue','reason':'Supplied scaffolding, explanatory participants, or distributed constructions; the specific Tibetan reasons are recorded above.'},
],
329:[
 {'tib':"te; ni; 'i in lta bu'i; so",'reason':'Discourse, topic, genitive and final grammar are recast without defensible separate word ranges; omitted rather than guessed.'},
 {'eng':'The answer is that they are; The; was made only with; the fact that the; of deeds; the','reason':'Supplied explanation and grammar remain unwrapped. only is a context-sensitive narrowing, not automatically part of the lexical dgongs/reference pair.'},
],
330:[
 {'tib':"'o na; genitives in bcu'i, pa'i and sha'i; ni; final 'o",'reason':'Discourse and inflection are distributed into English clause framing or remain grammatically unexpressed. They are omitted without assigning another clause’s wording.'},
 {'tib':'zhe sngang','reason':'Probable spelling problem. The raw term is not silently corrected and is not banked as a false headword. Dislike remains unwrapped; a separate LOW/PROBABLE candidate is proposed.'},
 {'tib':'sogs','reason':'The inclusive exemplar relation is distributed across someone like and the surrounding example construction. No separate sogs/like atom is asserted, and no null falsely says the meaning is absent.'},
 {'tib':'agentive component of blos','reason':'The whole inflected word owns intent. The instrument/causal relation contributes to out of, but the final s cannot be split as an independent span.'},
 {'eng':'One may next; by which the; of the; of non-virtue; Let\'s start with the act of; The; of this type of act; in a case where; you; of another being; get its; to eat; An; where this stage; dislike; would be where you; your; And a; where the undertaking stage; being; of things; would be where you; someone like your; out of some','reason':'Supplied English, repeated anaphora, explanatory material or distributed grammar; no lexical coverage claim is made for these ranges.'},
]}
for seq,groups in decisions.items():
    write(T/str(seq)/'original-decisions.json',dict(producer='Codex',angle='TIBETAN-FIRST',status='PROVISIONAL PROPOSAL',source_origin_git_commit='daad5db6ea6207085dc820101b3a2e9aaf942417',decisions=[dict(ids=ids.split(','),rationale=reason,intended_ranges=[r for r in ranges if r['seq']==seq and r['id'] in ids.split(',')]) for ids,reason in groups],omissions=omissions[seq]))

screens=[
dict(seq=328,found='SROG GCOD BA',suggested_expected='SROG GCOD PA',disposition='NOT PROPOSED',grounds={
 'a':'Present verbatim in ACIP and the prepared physical extent; Wylie retains ba.',
 'b':'C16:853 repeats all three full text fields. AK:28 also uses srog gcod ba in a different killing passage, not a same-passage witness. Neither establishes independent publication.',
 'c':'No local duplicate in the196-entry frozen register; not a converter, cap, folio or heading class.',
 'd':'The raw form has direct HTG2016 killing attestation in full entry25722. The pa spelling exists separately in entry21037; that comparison does not establish a defect in this occurrence. Refute correction as unproved.',
 'e':'Exact full-field queries each return2 rows. Supplemental srog gcod ba substring query returns3 rows, C05:328/C16:853/AK:28. Both exact lexical queries return1 row. All replayed.'}),
dict(seq=328,found='GNYIS PA',suggested_expected='Unspecified English numbering',disposition='NOT PROPOSED',grounds={
 'a':'The source ordinal is present; no second appears in this English.',
 'b':'C16:853 repeats the outline condensation. No independent publication is established.',
 'c':'No local duplicate; source citation is ordinary apparatus rather than an erratum.',
 'd':'Omitting an outline number while introducing the discussion with Now is a defensible translation/editorial choice. The null records limited lexical absence, not a factual error.',
 'e':'Prepared full fields and source/context comparisons were replayed exactly.'}),
dict(seq=329,found=None,suggested_expected=None,disposition='NO ERRATUM IDENTIFIED',grounds={
 'a':'Complete ACIP, Wylie, English and physical extents read without silently correcting them.',
 'b':'C16:854 repeats all three fields; no independent publication proved.',
 'c':'No C05:329 duplicate in the196-entry register; no registered cap/header/converter pattern applies.',
 'd':'The negation and undertaking-only qualification follow the local question coherently. English nominal reference is a defensible recast of dgongs.',
 'e':'All three exact full-field queries return2 rows and were replayed; full lexical entries and raw source objects agree.'}),
dict(seq=330,found='PHAM',suggested_expected='PHA MA',disposition='NOT PROPOSED',grounds={
 'a':'PHAM is present in ACIP and physical extent; Wylie reads pham.',
 'b':'C16:855 repeats PHAM and the same full English. This establishes no independent publication or correction history.',
 'c':'No local duplicate or relevant registered class in the frozen register.',
 'd':'Full HTG2016 entry24043 gives father or mother for pham; entry11546 gives the same among the pha ma alternatives. The exact sentence clearly concerns the parent example. The raw lexical form is defensible for this provisional occurrence; no correction is required by these data.',
 'e':'Exact pham and pha ma queries each return1 full entry; full-field queries each2 rows; bsod nams kyi blos pham and distinctive parent-English substring queries each2. All replayed.'}),
dict(seq=330,found='ZHE SNGANG',suggested_expected='ZHE SDANG',disposition='PROPOSE LOW/PROBABLE FOR EDITORIAL REVIEW',grounds={
 'a':'ZHE SNGANG is exact in this ACIP and physical extent, with zhe sngang in Wylie. This is not inferred from a normalized spelling.',
 'b':'C16:855 repeats the full ACIP, Wylie and English. Searches include C16/P1/TCS with C13 excluded and provide no separately established independent publication or corrected same-passage witness. Identical digital fields do not prove an ingestion lineage.',
 'c':'The frozen196-entry register has no330/sngang duplicate. A lexical Tibetan spelling is outside the registered converter, cap, footnote, folio and heading classes.',
 'd':'The three parallel root clauses are desire, dislike and ignorance; the middle example kills an enemy. C05:328 and331–332 write zhe sdang for the corresponding dislike root. Exact zhe sngang has0 entries; zhe sdang has1 full entry, but its HGM string is provisional medium-confidence intersection mining, not correction authority. The local parallel grammar and neighboring raw spelling favor SDANG. No manuscript or authorial spelling has been established, so confidence remains PROBABLE and severity LOW; zhe sngang stays unbanked.',
 'e':'zhe sngang substring returns2 full records (C05:330,C16:855); exact330 ACIP/Wylie/English each2; exact zhe sngang lexical0 and zhe sdang lexical1. The distinctive enemy-English query returns2. All counts replayed against mode=ro spine.'}),
]
for seq in [328,329,330]:
    write(T/str(seq)/'five-ground-screens.json',[x for x in screens if x['seq']==seq])
    errata=[]
    if seq==330:
        errata=[dict(seq=330,kind='TIBETAN_SPELLING',found='ZHE SNGANG',expected='For human editorial review: ZHE SDANG; the original is retained.',evidence='Exact ACIP and the physical C05 extent read ZHE SNGANG, faithfully zhe sngang in Wylie. The parallel desire/dislike/ignorance structure and enemy-killing example favor SDANG, as written in C05:328 and331–332. C16:855 repeats all three330 text fields, but no independent publication or ingestion history is proved. Exact zhe sngang lexical query returns0 and zhe sdang1; the latter is only auto-aligned medium-confidence intersection evidence (support3 of6), not binding correction authority. Full source-field queries each return2 records, the zhe sngang substring2, and the distinctive enemy-English substring2. All counts were replayed. Frozen196-entry register has no duplicate; this is outside registered converter/header/footnote/folio/cap classes. No corrected same-passage or manuscript authority establishes the spelling. LOW/PROBABLE only; no source or hgm_gloss change, and raw zhe sngang is omitted from alignment. Complete material evidence is in ../evidence/ and all five grounds in five-ground-screens.json.',severity='LOW',confidence='PROBABLE')]
    write(T/str(seq)/'errata.json',errata)
write(T/'reading-receipt.json',dict(producer='Codex',angle='TIBETAN-FIRST',source_origin_git_commit='daad5db6ea6207085dc820101b3a2e9aaf942417',source_origin_through=324,reading_scope=['All3 frozen source rows and all15 C05:322–336 context rows, with complete original row objects checked against raw fields.','All16 prepared lexical query results and14 complete material master entries; raw duplicates verified equal.','All9 prepared exact parallel query results,18 returned occurrences representing6 distinct full records.','All6 complete prepared physical extents, including the blank line in330 English. Physical bytes are reused under root preparation hashes; no independent printed edition was inspected.','All5 supplemental complete corpus query results, including the different AK:28 killing passage.','Frozen AGENTS, alignment specification, proposal brief, course shape, generator implementation, errata register screen, shared proposal/output contracts.'],query_verification='evidence/source-query-verification.json; all25 prepared queries replayed exactly;15 context rows verified directly;5 supplemental queries executed.',evidence_identity_manifest='evidence/original-to-copy-manifest.json',limits=['No English-angle or reconciliation files read.','No source, shared-F, worktree, master or hgm_gloss writes.','No fabricated through327 acceptance.','Digital repetition is not evidence of publication independence or a particular ingestion history.','Prepared reader receipt is corroboration of preparation scope, not adopted semantic judgment.']))
print('Original Tibetan-first decisions and all five-ground screens recorded before native generation.')
