C05:328–330 source preparation reading only

I read all three captured source objects, all fifteen context objects (C05:322–336), their complete original corpus records, all sixteen lexical query results including fourteen complete master entries, all nine exact parallel-query results, and the complete text of all six captured physical extents. The source-preparation caller completed with exit 0. This note makes no alignment, erratum, correction, or semantic acceptance decision.

The English sequence poses the question about completion in 328, answers it in 329 with reference to undertaking stages, and gives three examples in 330. The surrounding text continues the examples before returning to completion. These are reading observations only; no span boundaries, lexical pairings, or explanatory additions are authorized here.

The capture preserves SROG GCOD BA in 328 and ZHE SNGANG and PHAM in 330. The prepared queries retain each raw form and its comparison form: srog gcod ba / srog gcod pa, zhe sngang / zhe sdang, and pham / pha ma. Both members of the first and third pairs have recorded glossary entries. The exact zhe sngang query and mthar phyin par byed pa query returned zero rows. Absence is limited to those exact queries. Whether any source form warrants an erratum remains undecided.

Evidence tiers matter: zhe sdang is recorded as auto-aligned, medium-confidence intersection mining (support 3 of 6), despite the hgm_gloss field name. It remains provisional evidence. The other captured lexical objects distinguish HTG2016 glossary evidence from the curated bsod nams register variant and from Hopkins, Sanskrit, pronunciation-card, and corpus metadata. None of those fields authorizes replacing GMR's wording or adding a correspondence.

Each of the nine exact parallel queries returned the current C05 row and a matching C16 row: 328/853, 329/854, and 330/855. That is eighteen returned occurrences representing six distinct full records, not eighteen independent witnesses. Digital identity alone establishes no independent publication.

All six recorded ASCII extents were read, including the physical blank line inside 330's English. Their producer proof records equality after ASCII whitespace collapse, original object equality, and exact query replays. Those checks are reused as captured evidence; I ran no database queries or generators. Local JSON comparisons confirmed that repeated displayed objects carry the same complete content. An initially truncated combined display was completed in smaller slices before this note.

No proposal, baseline, registration, dictionary change, or worktree write was made. N325–327 proposal angles were not inspected; only their raw source rows within this authorized context were read. Future proposal and independent semantic review remain outstanding.
