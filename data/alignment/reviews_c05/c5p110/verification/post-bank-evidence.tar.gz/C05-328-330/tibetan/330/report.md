C05:330 — Codex TIBETAN-FIRST, PROVISIONAL proposal. Source origin daad5db6ea6207085dc820101b3a2e9aaf942417, through324 only.
Challenge first the d3 question recast and lta bu/instance,case: all are local example frames, with the final case at436–440.
The four come/comes-from pairs and both kill occurrences were checked against their complete clauses before generation.
Raw pham/father or mother is retained whole on full HTG2016 entry24043; srog/life is the sole tighter member in take the life.
One genitive null records adjectival fusion. zhe sngang, sogs and agentive out of are omitted with explicit reasons.
One LOW/PROBABLE ZHE SNGANG spelling candidate is preserved; full evidence does not prove publication independence or authorial spelling.
Original decisions, all omissions and exact occurrence ranges: original-decisions.json; five-ground-screens.json records every errata ground.
Complete shared originals and reading scope: ../evidence/original-to-copy-manifest.json and ../reading-receipt.json; query replays and full entries are preserved once.
Measured: 32 spans; 1 nulls; 24 nonnull d5 word pairs; 24 total d5; 1 d7; 1 errata.
Generator EXIT=0; stderr empty; body 5895 bytes; SHA256 b29b44309b1856f8ede04289e5fe827c66652fb2976352945c5ebb36ed1db3c5.
Resolver EXIT=0; stderr empty; resolved-spans.json exactly matches ../intended-ranges.json. Both native directories preserve actual argv/stdin/stdout/stderr/exit.
Spec 5810 bytes; SHA256 c0e65bc853e547686e5dabd66e5ab1e71997b0a8d271d2f6db88fa62501e789e. Generator stdout equals body.html byte-for-byte; both unwrapped source fields match the frozen source.
