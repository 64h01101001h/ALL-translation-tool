from pathlib import Path
import json

T = Path(__file__).resolve().parent
sources = {r['seq']: r for r in json.loads((T/'evidence/source.json').read_text())}

def span(id, d, tib, eng, **kw):
    return dict(id=id,d=d,tib=tib,eng=eng,**kw)

specs = {
328: dict(title='three roots and completion', spans=[
    span('w1',5,'gnyis pa',None,nul='The second outline point is not numbered in this English.'),
    span('w2',5,'mdo','sutra'),
    span('w3',5,'srog gcod ba','killing'),
    span('w4',5,'gsum','three'),
    span('w5',5,"'dod chags",'desiring'),
    span('p1',6,'las','from',cls='case'),
    span('w6',5,'skyes pa','comes'),
    span('p2',6,'dang',None,nul='First list conjunction is expressed by punctuation, with no separate English conjunction.'),
    span('w7',5,'zhe sdang','disliking'),
    span('p3',6,'las','from',cls='case'),
    span('w8',5,'skyes pa','comes'),
    span('p4',6,'dang','and'),
    span('w9',5,'gti mug','ignorant'),
    span('p5',6,'las','from',cls='case'),
    span('w10',5,'skyes pas','comes'),
    span('w11',5,'gsungs','states'),
    span('w12',5,'las lam','paths of action'),
    span('m1',7,'las','action'),
    span('m2',7,'lam','paths'),
    span('w13',5,'rtsa ba','roots'),
    span('f1',3,'mthar phyin par byed pa','brought to completion'),
    span('f2',3,'yin nam min','whether'),
    span('f3',3,'zhe na','ask'),
], eng_order=['w2','w11','w4','w3','w6','p1','w5','w8','p3','w7','p4','w10','p5','w9','f3','f2','w12','f1','w13'],
note="Codex Tibetan-first PROVISIONAL machine alignment; no hgm_gloss change. Raw srog gcod ba is retained and is directly attested as killing in the HTG2016 glossary. The three birth clauses attach to their own desire, dislike and ignorance examples. gti mug owns only ignorant; supplied objects and auxiliaries remain unwrapped. gsum gsum has a distributed each / three realization, so it is omitted rather than assigning an arbitrary numeral to each. thams cad is not attached to the unrelated all in all non-virtue. The completion construction and polar question are phrase-level recasts; the source attribution and conditional/discourse particles are not forced into separate English words. C16:853 repeats ACIP, Wylie and English; digital identity establishes no independent publication."),
329: dict(title='undertakings rather than completion', spans=[
    span('w1',5,'min','not'),
    span('w2',5,'mdo','sutra'),
    span('p1',6,'las','from',cls='case'),
    span('w3',5,'gsungs pa','statement'),
    span('w4',5,'srog gcod pa','killing'),
    span('w5',5,'lta bu','such as'),
    span('w6',5,'sbyor ba','"undertaking" stages'),
    span('w7',5,'rtsa ba','root'),
    span('w8',5,'gsum','three'),
    span('p2',6,'las','from',cls='case'),
    span('w9',5,'skyes pa','come'),
    span('p3',6,'la','to',cls='case'),
    span('w10',5,'dgongs','reference'),
], eng_order=['w1','w3','p1','w2','w10','p3','w6','w5','w4','w9','p2','w7','w8'],
note="Codex Tibetan-first PROVISIONAL machine alignment; no hgm_gloss change. min negates completion by every root in the preceding question. gsungs pa is nominalized as statement; dgongs is recast as reference, with the governed la realized as to. Only the two local source-relation instances of from are paired. sbyor ba retains the technical stage label; deeds and the supplied English answer/explanation frame remain unwrapped. te, ni, the genitive suffix and final so are omitted rather than overinterpreted. C16:854 repeats ACIP, Wylie and English without demonstrated publication independence."),
330: dict(title='three motives for undertaking killing', spans=[
    span('w1',5,'mi dge ba','non-virtues'),
    span('w2',5,'bcu','ten'),
    span('w3',5,'sbyor ba','"undertaking" stages'),
    span('w4',5,'rtsa ba','roots'),
    span('w5',5,'gsum','three'),
    span('p1',6,'las','from',cls='case'),
    span('w6',5,'skyes pa','come'),
    span('f1',3,'ji lta bu zhe na','ask for a description of the process'),
    span('w7',5,'srog gcod pa','killing'),
    span('w8',5,'sbyor ba','"undertaking" stage'),
    span('w9',5,"'dod chags",'desire'),
    span('p2',6,'las','from',cls='case'),
    span('w10',5,'skyes pa','comes'),
    span('w11',5,'sha','flesh'),
    span('p3',6,'phyir du','in order to',cls='case'),
    span('w12',5,'srog gcod pa','take the life'),
    span('m1',7,'srog','life'),
    span('w13',5,'lta bu','for example'),
    span('p4',6,'las','from',cls='case'),
    span('w14',5,'skyes pa','comes'),
    span('w15',5,'dgra bo','enemy'),
    span('w16',5,'gsod pa','kill'),
    span('w17',5,'lta bu','instance'),
    span('w18',5,'gti mug','ignorant'),
    span('p5',6,'las','from',cls='case'),
    span('w19',5,'skyes pa','comes'),
    span('w20',5,'bsod nams','meritorious'),
    span('p6',6,'kyi',None,cls='case',nul='Genitive relation is fused into the adjectival premodifier meritorious; it has no separate English word.'),
    span('w21',5,'blos','intent'),
    span('w22',5,'pham','father or mother'),
    span('w23',5,'gsod pa','kill'),
    span('w24',5,'lta bu','case'),
], eng_order=['f1','w3','w2','w1','w6','p1','w5','w4','w7','w8','w10','p2','w9','w13','w12','p3','w11','w17','w14','p4','w16','w15','w24','w19','p5','w18','w23','w22','w20','w21'],
note="Codex Tibetan-first PROVISIONAL machine alignment; no hgm_gloss change. The introductory undertaking and three motive clauses use their own come/comes and from occurrences. lta bu is exemplification, rendered for example, instance and the final case in those three clauses. The question is retained as a phrase recast. Raw zhe sngang is preserved but omitted from alignment: the proposed ZHE SDANG spelling is only a LOW/PROBABLE editorial question, not a source edit or a dictionary headword. pham is paired whole with father or mother on direct HTG2016 evidence and this sentence; no spelling correction or internal parent split is asserted. srog gcod pa owns take the life without the supplied other being. bsod nams is meritorious in this prose intention context, not the prayer-register goodness. sogs and out of are distributed with exemplification and the inflected blos construction and remain unwrapped; intent is the lexical exponent of blos. Supplied participants, repeated undertaking anaphora, type of act and eating explanation remain unwrapped. C16:855 repeats the three source text fields without proven independent publication."),
}

intended=[]
for seq,seg in specs.items():
    folder=T/str(seq);folder.mkdir(exist_ok=True)
    seg=dict(seq=seq,**seg)
    (folder/'spec.json').write_text(json.dumps(dict(course='C05',segments=[seg]),ensure_ascii=False,indent=2)+'\n')
    # Proposed ranges are authored before calling the canonical resolver.
    source=sources[seq]; tr={};cur=0;parent=None
    for s in seg['spans']:
        if s['d']==7:
            i=source['wylie'].index(s['tib'],*parent)
        else:
            i=source['wylie'].index(s['tib'],cur);cur=i+len(s['tib'])
            if s['d']==5:parent=(i,cur)
        tr[s['id']]=[i,i+len(s['tib'])]
    er={};cur=0; by_id={s['id']:s for s in seg['spans']}
    for id in seg['eng_order']:
        s=by_id[id];i=source['english'].index(s['eng'],cur);cur=i+len(s['eng']);er[id]=[i,cur]
        pos=seg['spans'].index(s)+1
        while pos<len(seg['spans']) and seg['spans'][pos]['d']==7:
            child=seg['spans'][pos]
            if child['eng'] is not None:
                a=source['english'].index(child['eng'],i,cur);er[child['id']]=[a,a+len(child['eng'])]
            pos+=1
    for s in seg['spans']:
        intended.append(dict(seq=seq,id=s['id'],d=s['d'],tib=s['tib'],eng=s['eng'],tib_range=tr[s['id']],eng_range=er.get(s['id'])))
(T/'intended-ranges.json').write_text(json.dumps(intended,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({str(seq):len(seg['spans']) for seq,seg in specs.items()}))
