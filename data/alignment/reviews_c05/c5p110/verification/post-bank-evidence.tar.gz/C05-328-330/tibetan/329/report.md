C05:329 — Codex TIBETAN-FIRST, PROVISIONAL proposal. Source origin daad5db6ea6207085dc820101b3a2e9aaf942417, through324 only.
dgongs/reference and governed la/to preserve the local intentional-reference recast; only/with/the fact that remain unwrapped.
The two from spans belong respectively to statement-from-sutra and undertakings-from-root-three; their measured ranges are separate.
The technical sbyor ba label retains the stages wording; supplied deeds and answer framing remain unwrapped.
No null or erratum is proposed; the complete local negation answers the completion question in328.
Original decisions, all omissions and exact occurrence ranges: original-decisions.json; five-ground-screens.json records every errata ground.
Complete shared originals and reading scope: ../evidence/original-to-copy-manifest.json and ../reading-receipt.json; query replays and full entries are preserved once.
Measured: 13 spans; 0 nulls; 10 nonnull d5 word pairs; 10 total d5; 0 d7; 0 errata.
Generator EXIT=0; stderr empty; body 2602 bytes; SHA256 d484480cfec89ecf75fe84772f0e47a666c7bdd5b762c0151e43fd3fd2ea810a.
Resolver EXIT=0; stderr empty; resolved-spans.json exactly matches ../intended-ranges.json. Both native directories preserve actual argv/stdin/stdout/stderr/exit.
Spec 2536 bytes; SHA256 daeb911656b5ba58e92de4c229a7000089193756430b7a25acea328a6c3b41db. Generator stdout equals body.html byte-for-byte; both unwrapped source fields match the frozen source.
