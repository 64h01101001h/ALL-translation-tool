"""Direct caller of the unchanged canonical resolver; no new matching rules."""
from pathlib import Path
import importlib.util, json, sqlite3, sys
sys.dont_write_bytecode = True
T=Path(__file__).resolve().parent
W=T.parents[2]/'campaign-worktree'
spec=json.load(sys.stdin)
definition=importlib.util.spec_from_file_location('canonical_generator',W/'tools/gen_alignment_page.py')
G=importlib.util.module_from_spec(definition)
definition.loader.exec_module(G)
db=sqlite3.connect((W/'build/hgm_spine_v27_2.db').as_uri()+'?mode=ro',uri=True)
db.execute('PRAGMA query_only=ON')
rows=[]
for seg in spec['segments']:
    seq=seg['seq'];tib,eng=db.execute('SELECT wylie,english FROM corpus_segments WHERE course=? AND seq=?',(spec['course'],seq)).fetchone()
    spans=seg['spans'];byid={s['id']:s for s in spans}
    tr=G.resolve(tib,spans,'tib',seq)
    english=G.with_members(spans,[byid[x] for x in seg['eng_order']],eng)
    er=G.resolve(eng,english,'eng',seq)
    for s in spans:
        rows.append(dict(seq=seq,id=s['id'],d=s['d'],tib=s['tib'],eng=s['eng'],tib_range=list(tr[s['id']]),eng_range=list(er[s['id']]) if s['eng'] is not None else None))
db.close()
intended=[x for x in json.loads((T/'intended-ranges.json').read_text()) if x['seq'] in [s['seq'] for s in spec['segments']]]
assert rows==intended, 'Canonical ranges differ from the pre-generation intended ranges'
print(json.dumps(rows,ensure_ascii=False,indent=2))
