"""Capture the three real generator and direct canonical resolver executions."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
T=Path(__file__).resolve().parent
A=T.parents[1]; W=T.parents[2]/'campaign-worktree'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
def ident(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def execute(seq,kind,argv,raw):
    D=T/str(seq)/('native-'+kind);D.mkdir(exist_ok=False)
    (D/'stdin.bin').write_bytes(raw)
    record=dict(argv=argv,cwd=str(W),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),environment_overrides={'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'},inherited_environment=True,stdin=ident(D/'stdin.bin'),caller=ident(Path(__file__)),canonical_generator=ident(W/'tools/gen_alignment_page.py'),canonical_builder_dependency=ident(W/'tools/build_alignment_layer.py'))
    (D/'command.json').write_text(json.dumps(record,indent=2)+'\n')
    t=time.perf_counter();p=subprocess.run(argv,cwd=W,env=env,input=raw,capture_output=True)
    for n,b in [('stdout.bin',p.stdout),('stderr.bin',p.stderr),('exit.txt',(str(p.returncode)+'\n').encode())]:(D/n).write_bytes(b)
    record.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),wall_seconds=time.perf_counter()-t,exit=p.returncode,stdout=ident(D/'stdout.bin'),stderr=ident(D/'stderr.bin'),exit_file=ident(D/'exit.txt'))
    (D/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
    assert p.returncode==0 and p.stderr==b'',(kind,seq,p.returncode,p.stderr)
    return p.stdout
for seq in [328,329,330]:
    raw=(T/str(seq)/'spec.json').read_bytes()
    out=execute(seq,'generator',[sys.executable,'-B',str(A/'run_generator_readonly.py')],raw)
    (T/str(seq)/'body.html').write_bytes(out)
    resolved=execute(seq,'resolver',[sys.executable,'-B',str(T/'resolve.py')],raw)
    (T/str(seq)/'resolved-spans.json').write_bytes(resolved)
    print(json.dumps(dict(seq=seq,generator_exit=0,resolver_exit=0,body_bytes=len(out),body_sha256=hashlib.sha256(out).hexdigest(),spans=len(json.loads(resolved)))))
