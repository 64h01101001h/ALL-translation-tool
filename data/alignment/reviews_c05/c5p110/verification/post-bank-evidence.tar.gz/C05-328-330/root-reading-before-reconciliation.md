# Root reading before immutable final reconciliation

No semantic acceptance is made by this note. F's actual acceptance baseline is
662a74015519ea5f0616fa50700f873b96429675 through327; the original proposal/source
origin remains daad5db6ea6207085dc820101b3a2e9aaf942417 through324.

Root read all six original final specs/reports, English65 individual rationales
and omissions and Tibetan68 spans with grouped decisions/omissions; all three
source rows, context322–336 and all six complete physical source excerpts.
Root checked the101/93 original frozen inventories without equating hashes
with linguistic reading. English328's successful earlier ordinal-null version
is historical; final v2 omits the ordinal. Both actual successful captures stay
preserved. The one-line current builder delta adds c5p109 registration; it does
not change generator or resolution logic.

Additional reading covered all21 complete original master objects for11
material queries: srog gcod ba, zhe sdang, min, dgongs, blos, pham, pha ma,
sogs, gcod, gnyis pa, lta bu'i. All fields, HGM lists and provenance were read,
including reference comparanda and auto-aligned status where present. Root
also read all original Tibetan five-ground screens and all15 English category
screens, not just the retained spelling candidate. Complete AK:28 and C05:180
records, including raw corpus objects, were read; they are lexical/doctrinal
comparators rather than independent corrected witnesses to these sentences.
Source physical excerpts preserve the exact ZHE SNGANG spelling before ingest.

- At328, gnyis pa has complete HGM next/here next counterevidence. Now could
  carry its discourse transition, so the ordinal is uncertain and should be
  omitted rather than nulled. Whole gyis/by at d6 obeys the actual rule against
  splitting agentive suffixes; no special permission is needed. yin nam min
  can own the whole whether polarity question at d3. zhe na/ask is tighter
  than may ask. The first dang can be a null only with an affirmative note
  that coordination is expressed by list punctuation, with no separate word;
  the second dang owns the explicit and. srog gcod ba is directly HGM-attested
  killing and is not silently changed to pa.
- At329, min is a negative copula and the complete HGM record includes are
  not. The full negative copula is appropriate, retaining its negative scope.
  la dgongs/with reference to is an established complete intentional-reference
  recast assessed against all18 HGM glosses in the complete list; an isolated
  reference noun is not required. Bare lta bu is tighter than the inflected
  genitive form. The two ablative from occurrences must retain their owners.
- At330, zhe na can own ask, but the expanded description/process framing
  should not be attributed wholesale to ji lta bu. The take-the-life compound
  and its srog/life member are defensible; standalone gcod/take is uncertain
  because taking in this idiom does not prove a general taking verb. The full
  gcod glossary and sever/cut sense are retained as evidence, not a reason to
  invent a take gloss. sogs/like expresses the enumerative gesture; someone
  and your are supplied participants. Whole blos/intent is directly attested,
  without splitting agentive -s. pham/father or mother is a directly attested
  source form, not a defect inferred from the separate pha ma spelling.

The LOW/PROBABLE ZHE SNGANG question is supported by the parallel root clauses,
enemy example and neighboring sdang spelling; its full master counterpart
zhe sdang/dislike is auto-aligned medium-confidence intersection evidence,
not correction authority. Digital C16 duplication proves no independent
publication, and no corrected same-passage witness establishes a restoration.
Keep the original spelling and disputed alignment unbanked. C05:180 explicitly
supports the meritorious-intent parent example; no English factual correction
is justified. All final dispositions and the independent skeptic still require
root reading before acceptance.
