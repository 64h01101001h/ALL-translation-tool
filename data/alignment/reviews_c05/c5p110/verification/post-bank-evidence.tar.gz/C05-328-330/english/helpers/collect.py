import json,hashlib,subprocess,sqlite3,gzip,os
from pathlib import Path
A=Path(__file__).resolve().parents[1];B=A.parent;W=B.parent.parent/'campaign-worktree'
def put(p,x):
 p=A/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
base=json.loads((B/'proposal-baseline.json').read_text());put('evidence/proposal-baseline.json',base)
governance=[]
for name,pin in base['governing_git_pins'].items():
 data=subprocess.check_output(['git','show',base['commit']+':'+name],cwd=W);assert sha(data)==pin['sha256'] and len(data)==pin['bytes']
 p=A/'evidence/governance'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);governance.append({'original_git_object':base['commit']+':'+name,'local_path':str(p),'sha256':sha(data),'bytes':len(data)})
put('evidence/governance-pins.json',governance)
for name,pin in base['source_pins'].items():
 b=Path(pin['path']).read_bytes();assert sha(b)==pin['sha256'] and len(b)==pin['bytes'],name
 if name=='physical':(A/'evidence/C05ReadingASCII.txt').write_bytes(b)
put('evidence/source-identities.json',base['source_pins'])
db=sqlite3.connect('file:'+base['source_pins']['spine']['path']+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
context=json.loads((B/'context.json').read_text());source=json.loads((B/'source.json').read_text())
for row in context+source:
 actual=dict(db.execute('select id,course,seq,acip,wylie,english from corpus_segments where course=? and seq=?',(row['course'],row['seq'])).fetchone());assert row==actual
put('evidence/source-context.json',context)
put('evidence/source-query-verification.json',{'status':'PASS','sqlite_uri_mode':'ro','sql':'select id,course,seq,acip,wylie,english from corpus_segments where course=? and seq=?','parameters':[[r['course'],r['seq']]for r in context],'context_rows':len(context),'source_rows':len(source)})
master=json.load(gzip.open(base['source_pins']['master']['path'],'rt'));corpus=json.load(gzip.open(base['source_pins']['corpus']['path'],'rt'))
terms=['mdo','srog gcod ba','srog gcod pa','gsum',"'dod chags",'zhe sdang','zhe sngang','gti mug','skyes pa','gsungs','las lam','thams cad','rtsa ba','mthar phyin','mthar phyin par byed pa','min','gsungs pa','lta bu','sbyor ba','dgongs','mi dge ba','bcu','sha','dgra bo','gsod pa','bsod nams','blo','blos','pham','pha ma','sogs','phyir du','las','gyis','nam','zhe na']
lex=[]
for term in terms:
 sql='SELECT DISTINCT e.* FROM entries e LEFT JOIN entry_variants v ON v.entry_id=e.id WHERE e.wylie=? OR v.wylie=? ORDER BY e.id';rows=[dict(r)for r in db.execute(sql,(term,term))]
 matches=[{'collection':coll,'index':i,'entry':e}for coll in ['unified_entries','curated_entries','glossary_entries']for i,e in enumerate(master[coll])if e.get('wylie')==term or term in (e.get('wylie_variants') or [])]
 lex.append({'term':term,'sql':sql,'parameters':[term,term],'count':len(rows),'spine_rows':rows,'master_count':len(matches),'master_records':matches})
put('evidence/lexical.json',lex)
queries=[]
for row in source:
 for field in ['wylie','acip','english']:
  queries.append((field,'=',row[field],None))
for field,term in [('wylie','zhe sngang'),('wylie','srog gcod ba'),('wylie','pham sogs'),('wylie','pha ma sogs'),('wylie','bsod nams kyi blos'),('english','meritorious intent'),('english','undertaking'),('wylie','mthar phyin')]:queries.append((field,'instr',term,'C05' if term in ['undertaking','mthar phyin']else None))
out=[]
for field,op,term,course in queries:
 sql='SELECT * FROM corpus_segments WHERE '+(field+'=?' if op=='='else 'instr('+field+',?)>0')+(' AND course=?'if course else '')+' ORDER BY course,seq';params=[term]+([course]if course else []);rows=[dict(r)for r in db.execute(sql,params)]
 records=[{'corpus_index':i,'record':r}for i,r in enumerate(corpus)if(not course or r['course']==course)and(r[field]==term if op=='='else term in r[field])]
 assert len(rows)==len(records)
 for row in rows:assert json.loads(row['raw'])==corpus[row['id']-1]
 out.append({'field':field,'op':op,'sql':sql,'parameters':params,'count':len(rows),'rows':rows,'corpus_records':records})
put('evidence/corpus-queries.json',out)
reg=json.loads((A/'evidence/governance/docs/errata_register.json').read_text())
put('evidence/register-shape.json',{'type':type(reg).__name__,'keys':list(reg)if isinstance(reg,dict)else None})
print(json.dumps({'source':'PASS','master_collections':{k:len(master[k])for k in ['unified_entries','curated_entries','glossary_entries']},'lexical_queries':len(lex),'corpus_queries':[(q['field'],q['parameters'][0][:60],q['count'])for q in out]},ensure_ascii=False,indent=2))
