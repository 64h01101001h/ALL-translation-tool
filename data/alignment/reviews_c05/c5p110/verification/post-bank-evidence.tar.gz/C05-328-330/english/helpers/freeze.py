import json,hashlib,gzip,sqlite3,datetime
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not(A/'freeze.json').exists()
pins=load(A/'evidence/source-identities.json')
for name,p in pins.items():
 b=Path(p['path']).read_bytes();assert len(b)==p['bytes']and sha(b)==p['sha256'],name
db=sqlite3.connect('file:'+pins['spine']['path']+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;m=json.load(gzip.open(pins['master']['path'],'rt'));c=json.load(gzip.open(pins['corpus']['path'],'rt'));mr=set();cr=set();qc=0
for file in ['lexical.json','supplemental-lexical.json']:
 for q in load(A/'evidence'/file):
  actual=[dict(r)for r in db.execute(q['sql'],q['parameters'])];assert actual==q['spine_rows']and len(actual)==q['count'];term=q['term'];matched=[{'collection':coll,'index':i,'entry':e}for coll in ['unified_entries','curated_entries','glossary_entries']for i,e in enumerate(m[coll])if e.get('wylie')==term or term in(e.get('wylie_variants')or[])];assert q['master_records']==matched and q['master_count']==len(matched)
  for r in matched:mr.add((r['collection'],r['index']))
  qc+=1
for q in load(A/'evidence/corpus-queries.json'):
 actual=[dict(r)for r in db.execute(q['sql'],q['parameters'])];assert actual==q['rows']and len(actual)==q['count']==len(q['corpus_records'])
 for r in actual:assert json.loads(r['raw'])==c[r['id']-1]
 for r in q['corpus_records']:assert c[r['corpus_index']]==r['record'];cr.add(r['corpus_index'])
 qc+=1
for n,rec in load(A/'evidence/material-manifest.json').items():
 b=Path(rec['path']).read_bytes();assert len(b)==rec['bytes']and sha(b)==rec['sha256']
summary=load(A/'summary.json');proof={'status':'PASS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_source_pins_verified':list(pins),'complete_unique_master_records_verified':len(mr),'complete_unique_corpus_records_verified':len(cr),'recorded_sql_queries_rechecked':qc,'source_and_context_rows_verified':15,'generator_successes':4,'resolver_successes':4,'generator_or_resolver_failures':0,'final_versions':{'328':2,'329':1,'330':1},'packaging_failure':'One legacy-source UTF-8 decode failure preserved in failures/package-v1/failure.json with its exact combined tool output and original script; Latin-1 byte-preserving physical read resolved it.','native_evidence':'Every actual generator/resolver version retains exact stdin, stdout, stderr, exit and execution records. Only changed328 was regenerated.','limits':'Fidelity proof establishes byte identity and resolved ranges, not semantic acceptance.'};put(A/'evidence/final-evidence-verification.json',proof)
files={str(p.relative_to(A)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(A.rglob('*'))if p.is_file()and p.name!='freeze.json'}
freeze={'schema':'c05-independent-proposal-freeze-v1','producer':'Codex independent English-first proposal','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_origin_git_commit':summary['source_origin_git_commit'],'source_course_boundary':324,'segments':[328,329,330],'acceptance_baseline_consumed':None,'semantic_status':'PROPOSAL_ONLY; independent reconciliation and review required','files':files,'file_count':len(files),'counts':summary['total'],'original_external_sources':pins,'complete_evidence_strategy':'Complete relevant master and corpus objects stored once per angle with collection/index, query parameters/counts, original full-file hashes, and the complete physical ReadingASCII bytes; source/context rows verified against original read-only SQLite.'};put(A/'freeze.json',freeze)
print(json.dumps({'freeze_sha256':sha((A/'freeze.json').read_bytes()),'files':len(files),'counts':freeze['counts'],'evidence':proof},indent=2))
