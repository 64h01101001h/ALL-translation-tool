C05:329 — Codex independent English-first; PROVISIONAL proposal only.
Challenge la dgongs / with reference to first: the object particle and intention verb are retained as a d3 phrase; only and the fact that remain unwrapped.
Counts: 12 spans; 9 non-null d5 word pairs; 9 total d5; 0 d7; 0 nulls; 0 errata.
Source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324; no future acceptance baseline consumed.
Complete source/context rows322–336 were independently verified in SQLite URI mode=ro; physical full ACIP/English proof is ../evidence/physical-fields.json.
Source/context SHA256 53b0b8ce28c5de238cf3226126c9813ae543cd8af7b90241f2a9eaf658d286f9.
Full HGM/master and query evidence is indexed once in ../evidence/material-manifest.json; each exact field also matches C16:854, without a provenance-independence claim.
decisions.json records all measured occurrences and omissions; errata-review.json records five grounds for every category. Distributed or uncertain correspondences are omitted, not falsely nulled.
Final canonical generator EXIT=0; stdout/body=2376 bytes; stderr=0 bytes; body SHA256 818f695b24c36610cf178c490533c7deacfdc644ec1eb02ea49000ab3ca083b5.
Final canonical resolver EXIT=0; stderr=0 bytes; all intended ranges agree. Exact native streams: ../native/329-generator-v1 and ../native/329-resolver-v1.
Spec SHA256 05f403f9a68fbf13cac803cf30b39d305a8fa4ad04403f82f3c0abdd42cfb822; source text exact after removing markup and null annotation.
One canonical generator and resolver run; successful unchanged outputs were reused without regeneration.
No production/master edits, source correction, hgm_gloss promotion, or semantic-acceptance claim.
