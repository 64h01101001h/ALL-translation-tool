import json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1];rows={r['seq']:r for r in json.loads((A/'evidence/source-context.json').read_text())}
def put(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def build(seq,title,items,note,omissions,errata):
 r=rows[seq];sp=[];dec=[];cur=0;parent=None
 for i,item in enumerate(items,1):
  tib,eng,d,anchor,why,*extra=item;sid=('m'if d==7 else 'p'if d==6 else 'f'if d<5 else 'w')+str(i)
  at=r['wylie'].find(tib,parent[0]if d==7 else cur,parent[1]if d==7 else len(r['wylie']));assert at>=0,(seq,tib)
  tr=[at,at+len(tib)]
  if d!=7:cur=tr[1]
  if d==5:parent=tr
  er=None
  if eng is not None:
   start=r['english'].index(anchor)if anchor else 0;ea=r['english'].index(eng,start);er=[ea,ea+len(eng)]
  s={'id':sid,'d':d,'tib':tib,'eng':eng}
  if eng is None:s.update({'cls':'case'if d==6 else 'ellipsis','nul':why})
  sp.append(s);dec.append({**s,'seq':seq,'tib_range':tr,'eng_range':er,'english_clause_anchor':anchor,'rationale':why})
 order=[x['id']for x in sorted([x for x in dec if x['eng']is not None and x['d']!=7],key=lambda x:x['eng_range'][0])]
 put(A/str(seq)/'spec.json',{'course':'C05','segments':[{'seq':seq,'title':title,'spans':sp,'eng_order':order,'note':note}]})
 put(A/str(seq)/'decisions.json',{'producer':'Codex independent English-first','status':'PROVISIONAL','source_row':r,'spans':dec,'omissions':omissions})
 put(A/str(seq)/'errata.json',errata)
 print(seq,len(sp),'spans',sum(s['d']==5 and s['eng']is not None for s in sp),'word pairs',sum(s['eng']is None for s in sp),'nulls')

build(328,'three roots and completion',[
 ('gnyis pa',None,5,None,'The second outline point has no separately rendered ordinal; Now does not mean second.'),
 ('mdo','sutra',5,'Now sutra','The text cited is sutra.'),
 ('srog gcod ba','killing',5,'three types of killing','Exact ba spelling is HGM glossary-attested; do not correct it to pa.'),
 ('gsum','three',5,'three types of killing','First numeral counts types of killing; the later root numeral is omitted.'),
 ("'dod chags",'desiring',5,'that which comes from desiring','First root: desire; supplied something stays outside.'),
 ('las','from',6,'that which comes from desiring','Ablative source of the desire-root arising, not citation las or action las.'),
 ('skyes pa','comes',5,'that which comes from desiring','First arising predicate belongs to desire.'),
 ('zhe sdang','disliking',5,'that which comes from disliking','Second root: dislike; local clause and context support the provisional lexical reading.'),
 ('las','from',6,'that which comes from disliking','Second root ablative has the second English from.'),
 ('skyes pa','comes',5,'that which comes from disliking','Second arising predicate belongs to dislike.'),
 ('gti mug','ignorant',5,'and that which comes from being ignorant','Third root: ignorance; being and of things remain outside.'),
 ('las','from',6,'and that which comes from being ignorant','Third root ablative has the third English from.'),
 ('skyes pas','comes',5,'and that which comes from being ignorant','Third inflected arising word is retained whole; the final -s is not split.'),
 ('gsungs','states',5,'Now sutra','Speech predicate occurs late in Tibetan and early in English.'),
 ('las lam','paths of action',5,'One may ask then','Established compound, without supplied various.'),
 ('las','action',7,'paths of action','Unique action member inside las lam / paths of action.'),
 ('lam','paths',7,'paths of action','Unique path member inside the same d5 parent; English reverses the member order.'),
 ('rtsa ba','roots',5,'by these three roots','Roots of non-virtue; supplied English explanation of all non-virtue remains outside.'),
 ('gyis','by',6,'by these three roots','Instrumental marks the roots as agents of completion.'),
 ('mthar phyin par byed pa','brought to completion',3,'are each brought to completion','Complete causative completion phrase; it is not a d5 lexical entry.'),
 ('zhe na','may ask',3,'One may ask then','Question-introducing formula; One and then stay unwrapped.')
],
 'PROVISIONAL machine alignment by Codex, independent English-first proposal. The three comes/from pairs belong respectively to desire, dislike, and ignorance; skyes pas is kept whole. The HGM glossary attests srog gcod ba as killing. The ordinal gnyis pa has no separate English exponent. thams cad and distributive gsum gsum are omitted because various/each/three distribute their meaning without a defensible unique division; yin nam min is likewise distributed across whether and the copular question. mthar phyin par byed pa is a d3 causative phrase. English participants, articles, auxiliaries and explanations remain unwrapped. No source correction or hgm_gloss promotion.',
 [{'tib':'thams cad; gsum gsum','reason':'The complete clause distributes universal/distributive scope across various, each and three; no unique local word allocation is asserted.'},{'tib':'yin nam min','reason':'Positive/negative alternative is recast as whether plus an earlier copula; distributed, not absent.'},{'tib':'mdo las; ni; ste; dang; na','reason':'Unclaimed citation/topic/connective particles; no automatic nulls.'},{'english':'that which; something; being; of things; of all non-virtue','reason':'Supplied participants, auxiliaries and explanation stay unwrapped.'}],[])

build(329,'undertaking stages',[
 ('min','are not',5,'The answer is that they are not','Negative copula answers the completion question; are belongs to the copular meaning.'),
 ('mdo','sutra',5,'The statement from sutra','Named textual source.'),
 ('las','from',6,'The statement from sutra','Citation-source ablative, first from.'),
 ('gsungs pa','statement',5,'The statement from sutra','Nominalized speech predicate is statement.'),
 ('srog gcod pa','killing',5,'deeds such as killing','Single killing occurrence in the example.'),
 ("lta bu'i",'such as',5,'deeds such as killing','Established comparative expression retained with its genitive ending.'),
 ('sbyor ba','"undertaking" stages',5,'the "undertaking" stages','Technical stage name; the glossary explicitly attests the stage reading.'),
 ('rtsa ba','root',5,'the root three','Exact singular English root; do not modernize its order.'),
 ('gsum','three',5,'the root three','Counts the three roots, not stages or deeds.'),
 ('las','from',6,'come from the root three','Arising-source ablative, second from.'),
 ('skyes pa','come',5,'come from the root three','Plural stages come from the roots.'),
 ('la dgongs','with reference to',3,'only with reference to','Reference-object particle and intention verb form this complete English phrase; only is unclaimed.')
],
 'PROVISIONAL machine alignment by Codex, independent English-first proposal. min owns are not as a negative copula; the supplied answer formula and they stay unwrapped. Citation las owns the first from; root-source las owns the second. sbyor ba is the technical undertaking stage, and lta bu\'i is retained as an inflected comparative expression. la dgongs is kept at d3 for with reference to, without claiming only or the fact that. GMR\'s root three remains verbatim. No source correction or hgm_gloss promotion.',
 [{'tib':'te; ni; so','reason':'Discourse and closing particles omitted; no independent lexical correspondence asserted.'},{'english':'The answer is that they; was made only; the fact that; of deeds','reason':'Supplied framing, emphasis, participants and explication are not separately claimed.'}],[])

err=[{'seq':330,'kind':'TIBETAN_SPELLING','found':'ZHE SNGANG','expected':'Probably ZHE SDANG; preserve the source pending human ruling.','evidence':'C05:330 ACIP reads ZHE SNGANG (derived Wylie zhe sngang) beside English dislike. The complete physical C05ReadingASCII.txt line3297 has the same spelling. C16:855 has exactly equal ACIP, Wylie and English, but that textual identity establishes neither publication independence nor ingestion lineage. Exact zhe sngang yields only C05:330/C16:855 in the full corpus and no spine/master lexical record. C05:328,331,332,335,336 use ZHE SDANG for the matching dislike root, and the master zhe sdang record (unified index16267) has provisional auto-aligned HGM dislike plus separately labeled comparative evidence. The same desire/dislike/ignorance enumeration and enemy example make ZHE SDANG probable; no independent corrected witness for this complete sentence was found. No matching registered entry was found. The source and proposal English remain untouched. See evidence/lexical.json, evidence/corpus-queries.json, evidence/source-context.json and evidence/C05ReadingASCII.txt.','severity':'LOW','confidence':'PROBABLE'}]
build(330,'three roots of undertaking',[
 ('mi dge ba','non-virtues',5,'the ten non-virtues','Whole established negative compound; no negative-affix member is claimed.'),
 ('bcu','ten',5,'the ten non-virtues','Counts the non-virtues.'),
 ('sbyor ba','"undertaking" stages',5,'the "undertaking" stages','First stage name is plural and belongs to the general question.'),
 ('rtsa ba','roots',5,'the three roots of non-virtue','The roots in the general introductory question.'),
 ('gsum','three',5,'the three roots of non-virtue','Numeral in the introductory roots phrase.'),
 ('las','from',6,'come from the three roots','First source ablative, before all three particular examples.'),
 ('skyes pa','come',5,'come from the three roots','Introductory plural stages come from three roots.'),
 ('srog gcod pa','killing',5,"Let's start with the act of killing",'First killing compound names the act; supplied act of is left outside.'),
 ('sbyor ba','"undertaking" stage',5,'The "undertaking" stage of this type','Second explicit stage name belongs to the desire example; subsequent English stage repetitions are implicit in Tibetan.'),
 ("'dod chags",'desire',5,'comes from desire in a case','Desire is the first particular root.'),
 ('las','from',6,'comes from desire in a case','Second source ablative belongs to desire.'),
 ('skyes pa','comes',5,'comes from desire in a case','First singular comes belongs to desire.'),
 ('sha','flesh',5,'in order to get its flesh','The motive is flesh; its and to eat are supplied.'),
 ('phyir du','in order to',6,'in order to get its flesh','Purpose particle phrase, d6 by Tibetan function.'),
 ('srog gcod pa','take the life',5,'you take the life of another being','Second killing compound in the flesh example; another being is an added participant.'),
 ('srog','life',7,'take the life','Unique life member inside take the life / srog gcod pa.'),
 ('gcod','take',7,'take the life','Unique verb member; English order reverses the two members inside their parent.'),
 ("lta bu'o",'for example',5,'in a case where, for example','First comparative example expression, anchored to the flesh example.'),
 ('las','from',6,'An instance where this stage comes from dislike','Third source ablative belongs to the dislike example; the suspect root word itself is omitted.'),
 ('skyes pa','comes',5,'An instance where this stage comes from dislike','Second singular comes belongs to the enemy/dislike example.'),
 ('dgra bo','enemy',5,'you kill your enemy','Enemy is the object of the first kill; your is supplied.'),
 ('gsod pa','kill',5,'you kill your enemy','First kill is the enemy example, not the later parents example.'),
 ("lta bu'o",'instance',5,'An instance where this stage','Second example expression belongs to the enemy clause.'),
 ('gti mug','ignorant',5,'comes from being ignorant of things','Ignorance is the third root; being and of things remain unwrapped.'),
 ('las','from',6,'comes from being ignorant of things','Fourth source ablative belongs to ignorance.'),
 ('skyes pa','comes',5,'comes from being ignorant of things','Third singular comes belongs to the parents/ignorance example.'),
 ('bsod nams','meritorious',5,'out of some meritorious intent','Merit interpreted adjectivally in the intent phrase; HGM glossary and C05:180 support this exact register.'),
 ('kyi',None,6,None,'Genitive relation is fused into the English adjectival construction meritorious intent; there is no separate of here.'),
 ('blos','intent',5,'out of some meritorious intent','Inflected intent word retained whole; instrumental -s is not separated.'),
 ('pham','father or mother',5,'someone like your father or mother','Exact PHAM is explicitly HGM glossary-attested as father or mother; no spelling correction or invented segmentation.'),
 ('sogs','like',6,'someone like your father or mother','Enumerative particle licenses only like; someone and your remain unwrapped.'),
 ('gsod pa','kill',5,'you kill someone like your father','Second kill belongs to the parents/ignorance example.'),
 ("lta bu'o",'case',5,'And a case where the undertaking','Third example expression is the final case after enemy, not the earlier in a case where.')
],
 'PROVISIONAL machine alignment by Codex, independent English-first proposal. The introductory come/from and the three example comes/from pairs are separately anchored. Only the two explicit sbyor ba occurrences are linked; English repetitions of stage are supplied. srog gcod pa owns take the life without of another being. The three lta bu\'o examples map in order to for example, instance, and the final case. Exact pham is HGM glossary-attested as father or mother, and blos is retained whole. kyi has no separate exponent because its relation is fused into meritorious intent. zhe sngang is omitted as an uncertain lexical form and proposed separately as a probable ZHE SDANG spelling issue; no source is corrected. The expanded introductory question is omitted where its English correspondence is distributed. No hgm_gloss promotion.',
 [{'tib':"'o na; ji lta bu zhe na",'reason':'The introductory rhetorical question is expanded over One may next ask for a description of the process by which; no unique separate lexical atom is asserted.'},{'tib':'zhe sngang','reason':'Probable misspelling, without an independently corrected witness; omit instead of banking the corrected sense or falsely nulling it.'},{'tib':"ni; 'i endings; final 'o endings",'reason':'Particles left within their inflected words or omitted; no extra fragmentary members.'},{'english':'of non-virtue; act of; stage repetitions; another being; its; to eat; someone; your; out of some','reason':'Explanatory words, repeated implicit stages and supplied participants remain unwrapped; blos is not split to manufacture an instrumental atom.'}],err)
