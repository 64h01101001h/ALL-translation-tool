C05:330 — Codex independent English-first; PROVISIONAL proposal only.
Challenge gcod / take inside srog gcod pa / take the life first: this is an idiomatic compound-member match, not a free-standing glossary equivalent.
Counts: 33 spans; 24 non-null d5 word pairs; 24 total d5; 2 d7; 1 nulls; 1 errata.
Source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324; no future acceptance baseline consumed.
Complete source/context rows322–336 were independently verified in SQLite URI mode=ro; physical full ACIP/English proof is ../evidence/physical-fields.json.
Source/context SHA256 53b0b8ce28c5de238cf3226126c9813ae543cd8af7b90241f2a9eaf658d286f9.
Full HGM/master and query evidence is indexed once in ../evidence/material-manifest.json; each exact field also matches C16:855, without a provenance-independence claim.
decisions.json records all measured occurrences and omissions; errata-review.json records five grounds for every category. Distributed or uncertain correspondences are omitted, not falsely nulled.
Final canonical generator EXIT=0; stdout/body=5657 bytes; stderr=0 bytes; body SHA256 87a987e93c861b822286bf5f2d4398fec84511e766ae5bf839d351d0f23aacd0.
Final canonical resolver EXIT=0; stderr=0 bytes; all intended ranges agree. Exact native streams: ../native/330-generator-v1 and ../native/330-resolver-v1.
Spec SHA256 cc839864c5468ef2921d33bc81679657fa687a40f492dee732a6350609975b67; source text exact after removing markup and null annotation.
One canonical generator and resolver run; successful unchanged outputs were reused without regeneration.
No production/master edits, source correction, hgm_gloss promotion, or semantic-acceptance claim.
