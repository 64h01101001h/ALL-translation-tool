import json
from pathlib import Path
A=Path(__file__).resolve().parents[1];p=A/'328';s=json.loads((p/'spec.json').read_text());d=json.loads((p/'decisions.json').read_text());seg=s['segments'][0]
assert seg['spans'][0]['tib']=='gnyis pa' and seg['spans'][0]['eng']is None
seg['spans']=seg['spans'][1:];d['spans']=d['spans'][1:]
seg['note']=seg['note'].replace('The ordinal gnyis pa has no separate English exponent.','The outline expression gnyis pa is omitted: Now may recast its transition, so absence is not asserted.')
d['omissions'].append({'tib':'gnyis pa','reason':'Supplemental full HGM records attest here next/next for the ordinal expression; Now may carry that transitional use, but a precise local atom remains uncertain. Omit instead of asserting absence.'})
for name,obj in [('spec.json',s),('decisions.json',d)]: (p/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
(p/'revision.json').write_text(json.dumps({'reason':'Post-generation supplemental lexical review replaced the gnyis pa null with an omission because the local Now may reflect its transitional use. Native v1 inputs/streams remain unchanged; only328 requires resolver/generator v2.','reused_unchanged_segments':[329,330]},indent=2)+'\n')
print('328 revised: gnyis pa omitted; native v1 retained.')
