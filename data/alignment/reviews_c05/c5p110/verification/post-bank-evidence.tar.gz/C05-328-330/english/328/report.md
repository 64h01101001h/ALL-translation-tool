C05:328 — Codex independent English-first; PROVISIONAL proposal only.
Challenge the omitted thams cad/gsum gsum distribution first; various, each and three do not yield a unique honest split. The ordinal was changed from a null to omission after supplemental HGM evidence.
Counts: 20 spans; 12 non-null d5 word pairs; 12 total d5; 2 d7; 0 nulls; 0 errata.
Source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324; no future acceptance baseline consumed.
Complete source/context rows322–336 were independently verified in SQLite URI mode=ro; physical full ACIP/English proof is ../evidence/physical-fields.json.
Source/context SHA256 53b0b8ce28c5de238cf3226126c9813ae543cd8af7b90241f2a9eaf658d286f9.
Full HGM/master and query evidence is indexed once in ../evidence/material-manifest.json; each exact field also matches C16:853, without a provenance-independence claim.
decisions.json records all measured occurrences and omissions; errata-review.json records five grounds for every category. Distributed or uncertain correspondences are omitted, not falsely nulled.
Final canonical generator EXIT=0; stdout/body=3678 bytes; stderr=0 bytes; body SHA256 c41f65fb6d874a9a70850c4191dee70dd7c6b49deaeb091ab2a00acfd6b7bbb6.
Final canonical resolver EXIT=0; stderr=0 bytes; all intended ranges agree. Exact native streams: ../native/328-generator-v2 and ../native/328-resolver-v2.
Spec SHA256 94ac2920eed257caf9cf0f4253d723d33e6052c3d7f7aeefa30343a9422b9e05; source text exact after removing markup and null annotation.
Native v1 remains preserved; only the changed328 spec was regenerated at v2. The unchanged329/330 successes were reused.
No production/master edits, source correction, hgm_gloss promotion, or semantic-acceptance claim.
