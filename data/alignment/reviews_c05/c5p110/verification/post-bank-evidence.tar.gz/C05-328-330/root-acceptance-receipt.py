"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read complete source328–330, context322–336 and all six physical source excerpts; all six original specs/reports and133 current original span decisions plus omissions; all68 final rationales and13 omission decisions, all changed original-span dispositions and all70 grouped/note dispositions. Root read all material five-ground original and reconciled spelling assessments, complete original and supplemental master objects for the named material questions recorded in root-reading-before-reconciliation.md, plus complete gyis, nam, zhe na, dang, yin, ji lta bu, byed pa and kyi objects. Full AK28, C05:180 and C05:121 were read as local semantic comparators, never independent corrected witnesses. Root read the complete independent review,68 independent final-span judgments,13 independent omissions and the final spelling verdict. Existing frozen native results were verified by exact identity and source ranges, with no generator/resolver rerun. Inventory identity is not a claim to reading every gathered master object.'
decision='Approve68 provisional spans. In328 all three roots retain their own comes/from occurrences; gnyis pa/Now remains uncertain and unbanked, first dang is affirmative punctuation fusion while second dang owns and, whole gyis/by respects the no-split rule, and yin nam min/whether expresses the complete polar construction at d3. In329 min owns the complete negative copula are not, bare lta bu/such as stays tight, and the full governed la dgongs/with reference to is a d3 recast with only left unbanked. In330 zhe na/ask is narrow; ji lta bu and description/process framing stay unbanked. srog gcod pa/take the life keeps only transparent srog/life as a member; gcod/take is not independently supported. Each lta bu retains its own example occurrence, sogs owns only like, kyi is affirmative adjectival fusion in meritorious intent, whole blos stays intact and exact pham/father or mother is attested.'
errata='Retain one LOW/PROBABLE human-review spelling question about raw ZHE SNGANG. Physical ASCII and identical C16:855 preserve that form; local parallel roots and the enemy example favor ZHE SDANG, but no independent corrected witness or converter mechanism is established. The provisional auto-mined zhe sdang entry is not correction authority. Suspect wording remains unbanked and unchanged.'
utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p110',segments=[328,329,330],counts=dict(spans=68,nulls=2,nonnull_d5=45,total_d5=45,d7=3),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-reading-before-reconciliation.md')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Six selected final original and three reconciled generator/resolver results verified; successful superseded English328v1 remains separately preserved. No root input generator/resolver run.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[328,329,330],semantic_files=len(freeze['files']))))
