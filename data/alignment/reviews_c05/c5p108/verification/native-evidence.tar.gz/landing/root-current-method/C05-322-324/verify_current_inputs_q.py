"""Verify actual Q finalization delta while reusing the immutable preparation pass.
No generator, resolver or SQL query is invoked. No worktree writes.
"""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
B=Path(__file__).resolve().parent
S=B/'semantic-review';W=B.parents[1]/'campaign-worktree';D=B/'root-input-candidate'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block);n+=len(block)
 return dict(bytes=n,sha256=h.hexdigest())
def expected(r):return {k:r[k] for k in ('bytes','sha256')}
def inside(root,rel):
 assert isinstance(rel,str) and not Path(rel).is_absolute() and '..' not in Path(rel).parts
 p=root/rel;assert p.resolve().is_relative_to(root.resolve());return p
def save(p,d):
 with p.open('x') as f:f.write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
base=read(B/'baseline.json');origin=read(B/'proposal-baseline.json');f=read(S/'freeze.json');m=read(S/'review.json')
assert base['commit']==git('rev-parse','HEAD').decode().strip()=='36a978597787f0599357ff99ea8bd3f07895229a'
assert base['course_boundary']==321 and origin['course_boundary']==315 and origin['commit']=='af139c573f85aaf33278cd079719947ee9af8cdd'
assert not git('status','--porcelain','--untracked-files=no')
assert pin(S/'freeze.json')['sha256']=='8227d7751dec894ceba1371e75220be057c8f5cd1c4cfee73d91b69d82b58f60'
assert f['verdict']==m['verdict']=='APPROVE' and f['open_findings']==m['open_findings']==[]
assert m['spec_verdict']=='PASS' and m['quality_verdict']=='COMPLETE_NO_REQUIRED_CORRECTION'
assert f['source_origin_git_commit']==m['source_origin_git_commit']==origin['commit']
assert f['file_count']==len(f['files'])==860 and f['excludes']==['freeze.json']
assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}==set(f['files'])|{'freeze.json'}
for rel,r in f['files'].items():assert pin(inside(S,rel))==expected(r),rel
prep=read(D/'preparation-01/proof.json');prior=read(B/'root-preparation-method-review.json')
assert prior['verdict']=='APPROVE_ROOT_PREPARATION_METHOD_AND_REUSE' and prior['proof']==pin(D/'preparation-01/proof.json')
assert prior['method']==pin(D/'verify_root_inputs_q_v1.py')==expected(prep['method'])
assert prep['status']=='PASS_PREPARATION_INPUTS_ONLY' and prep['actual_acceptance_baseline_consumed'] is False and prep['acceptance_authorized'] is False
for rel,row in prep['outputs'].items():assert pin(D/'preparation-01'/rel)==expected(row)
assert prep['canonical_original_spans']==141 and prep['canonical_final_spans']==73
assert prep['original_lexical_queries']==100 and prep['distinct_sql_queries']==40 and prep['original_sql_queries']==47 and prep['external_query_records']==41
for label in ('tibetan','english','reconciled'):
 original=read(B/label/'freeze.json');receipt=prep['frozen_inputs'][label]
 assert pin(B/label/'freeze.json')==expected(receipt) and len(original['files'])==receipt['files_verified']
 for rel,row in original['files'].items():assert pin(inside(B/label,rel))==expected(row)
old_inventory=S/'checkpoint-inventory.json'
assert pin(old_inventory)==expected(prep['frozen_inputs']['semantic-review'])
old=read(old_inventory)
delta=read(S/'checkpoint-to-final-delta.json');bd=read(S/'finalization/baseline-delta-proof.json')
assert delta['status']=='PASS_EXPLICIT_CHECKPOINT_TO_FINAL_DELTA' and delta['original_checkpoint_inventory']==pin(old_inventory)
assert delta['original_files']==454 and delta['semantic_source_spec_body_rationale_errata_native_changes']==delta['generator_reruns']==delta['resolver_reruns']==0
assert delta['preparation_proof_reused_unchanged']==pin(D/'preparation-01/proof.json')
resolution=read(inside(S,delta['checkpoint_resolution']))
assert resolution['checkpoint_inventory']==pin(old_inventory) and set(resolution['files'])==set(old['files'])
assert set(delta['changed_metadata'])=={'review.json','review.md','interface-schema-note.md','original-to-copy-manifest.json'}
for rel,row in resolution['files'].items():
 assert expected(row)==expected(old['files'][rel]) and pin(inside(S,row['preserved_path']))==expected(row)
 if rel in delta['changed_metadata']:
  changed=delta['changed_metadata'][rel]
  assert row['changed_current_metadata'] is True and row['preserved_path']==changed['history']
  assert expected(row)==changed['before'] and pin(S/rel)==changed['after']
 else:assert row['changed_current_metadata'] is False and row['preserved_path']==rel
assert resolution['unchanged_files_retained_in_place']==450 and resolution['full_historical_tree_copied'] is False
copies=read(S/'original-to-copy-manifest.json')
old_copies=read(S/delta['changed_metadata']['original-to-copy-manifest.json']['history'])
assert len(copies)==408 and len(old_copies)==379 and copies[:379]==old_copies
for row in copies:
 copied=inside(S,row['copy']);assert pin(copied)==expected(row)
 if 'original_git_commit' in row:raw=git('show',row['original_git_commit']+':'+row['repository_relative_path'])
 else:raw=Path(row['original']).read_bytes()
 assert copied.read_bytes()==raw
receipt=m['actual_through321_baseline_receipt']
assert set(receipt)=={'commit','course_boundary','bytes','sha256','copy','verification_proof'}
assert receipt==f['actual_through321_baseline_receipt']==bd['actual_through321_baseline_receipt']
assert receipt['commit']==base['commit'] and receipt['course_boundary']==321 and expected(receipt)==pin(B/'baseline.json')
assert (S/receipt['copy']).read_bytes()==(B/'baseline.json').read_bytes()
assert receipt['verification_proof']=='finalization/baseline-delta-proof.json'
assert bd['status']=='PASS_SCOPED_BASELINE_GOVERNING_REGISTER_DELTA' and bd['source_origin_git_commit']==origin['commit']
assert bd['checkpoint_inventory']==pin(old_inventory) and bd['checkpoint_files_verified']==454
assert bd['preparation_proof']==pin(D/'preparation-01/proof.json') and bd['root_preparation_method_review']==pin(B/'root-preparation-method-review.json')
assert bd['generator_runs_during_finalization']==bd['resolver_runs_during_finalization']==bd['corpus_or_master_query_reruns']==0
for rel,row in bd['baseline_files'].items():assert pin(W/rel)==expected(row) and row['sha256']==base['sha256'][rel]
for label,row in origin['source_pins'].items():
 assert pin(Path(row['path']))==expected(row)==prep['source_identities'][label]==bd['original_source_identities_unchanged'][label]
changed=[]
for row in bd['governing']:
 p=inside(W,row['repository_relative_path']);assert pin(p)==expected(row) and p.read_bytes()==(S/row['copy']).read_bytes()
 assert git('rev-parse',base['commit']+':'+row['repository_relative_path']).decode().strip()==row['actual_baseline_blob']
 if row['changed']:changed.append(row['repository_relative_path'])
assert set(changed)=={'data/alignment/C05_CAMPAIGN.md','tools/build_alignment_layer.py'}
regcheck=read(S/bd['register_check']);register=read(W/'docs/errata_register.json');errata=read(S/'bank-ready-errata.json')
assert regcheck['current_count']==len(register)==194 and regcheck['complete_register_unchanged'] is True
assert regcheck['direct_batch_records']==[] and regcheck['exact_found_records']=={'322':[],'324':[]}
assert len(errata)==2 and [e['seq'] for e in errata]==[322,324]
assert all(e['severity']=='LOW' and e['confidence']=='PROBABLE' for e in errata)
assert not any((x['segment'],x['found'][:60])==(f"C05:{e['seq']}",e['found'][:60]) for x in register for e in errata)
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
reading=read(B/'root-semantic-reading-preparation.json')
for rel,row in reading['pins'].items():
 path=S/delta['changed_metadata'][rel]['history'] if rel in delta['changed_metadata'] else S/rel
 assert pin(path)==expected(row),rel
resolved=read(D/'preparation-01/resolved-spans.json');assert resolved==read(S/'resolved-spans.json')
assert len(resolved)==73 and sum(r['d']==5 for r in resolved)==50 and sum(r['d']==7 for r in resolved)==14 and all(r['eng'] is not None for r in resolved)
native=[]
for row in m['segments']:
 seq=row['seq'];spec=B/f'reconciled/{seq}/spec.json';body=B/f'reconciled/{seq}/body.html'
 assert pin(spec)==dict(bytes=row['spec_bytes'],sha256=row['spec_sha256']) and pin(body)==dict(bytes=row['body_bytes'],sha256=row['body_sha256'])
 assert (S/f'reviewed-final/{seq}/spec.json').read_bytes()==spec.read_bytes() and (S/f'reviewed-final/{seq}/body.html').read_bytes()==body.read_bytes()
 item=dict(seq=seq,root_generator_runs=0)
 for mode,field in [('generator','fresh_native_directory'),('resolver','fresh_resolver_directory')]:
  directory=S/row[field];assert row[field]==f'native/final-{seq}-{mode}-v1'
  ex=read(directory/'execution.json');assert ex['exit']==0 and (directory/'exit.txt').read_bytes()==b'0\n' and (directory/'stderr.bin').read_bytes()==b''
  for stream,r in ex['streams'].items():assert pin(directory/(stream+'.bin'))==expected(r)
  assert (directory/'stdin.bin').read_bytes()==spec.read_bytes()
  if mode=='generator':assert (directory/'stdout.bin').read_bytes()==body.read_bytes();item['execution']=ex
  else:assert read(directory/'stdout.bin')==[r for r in resolved if r['seq']==seq];item['resolver_execution']=ex
 native.append(item)
assert [r['seq'] for r in native]==[322,323,324]
# The mechanical operation is complete before any output advertises PASS.
out=B/'root-current-inputs';out.mkdir(exist_ok=False)
shutil.copy2(D/'preparation-01/resolved-spans.json',out/'resolved-spans.json')
save(out/'current-native-evidence.json',native)
proof=dict(status='PASS_ROOT_CURRENT_INPUTS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_baseline=base['commit'],source_origin=origin['commit'],method=pin(Path(__file__)),preparation_proof=pin(D/'preparation-01/proof.json'),final_review_freeze=pin(S/'freeze.json'),baseline_delta=pin(S/'finalization/baseline-delta-proof.json'),checkpoint_to_final_delta=pin(S/'checkpoint-to-final-delta.json'),canonical_original_spans=141,canonical_final_spans=73,root_generator_runs=0,range_verification='Reused immutable preparation PASS; no fresh resolver or query invocation.',final_files_verified=860,original_checkpoint_files_preserved=454,original_copy_records=408,root_reading=pin(B/'root-semantic-reading-preparation.json'),current_native_evidence=pin(out/'current-native-evidence.json'),source_files_checked=len(origin['source_pins']),limits='Mechanical finalization acceptance only. Root semantic decision is separately recorded before landing.')
save(out/'proof.json',proof);print(json.dumps(proof,indent=2))
