# Q compact current-method preparation

`prepare_current_bank_q.py --reproduction REPRODUCTION_DIR` creates only `landing/root-current-method/` and `landing/root-ledger-entry-template.md`. It does not bank, stage, run generators/tests/reproduction, commit, or write the worktree. Root inspection and execution are sufficient; this helper creates no approval receipt.

It reads the already completed current status/native records to derive the ledger, then copies an explicit bounded selection of Q root methods/proofs, failed method/disposition, original preparation attempts, corrected closure methods, registration methods, and small review/freeze manifests. The unchanged compact bank helper already archives landing, completed batch callers and external reproduction evidence, so these are not copied again. Frozen semantic review, old fixture trees and complete historical closure trees remain referenced. Every selected copy must be a regular nonsymlink file at most4MiB; total selection is capped at12MiB. Exact input identities are checked before output creation, copy bytes are verified, and a manifest plus preparation proof records the result. Partial I/O failures remain visible and existing outputs cannot be overwritten.

The ledger derives final counts and timings from current passing records. It retains provisional status, two LOW/PROBABLE E-195/E-196 questions and all194 prior entries; ZHI/four, gzugs/formless realm and isolated bral ba/eliminating remain unbanked. Source315 origin stays distinct from actual321 baseline. The current43/29 view limitation is also present in through315/321 native evidence; it is not a Q increase. Skipped diagnostic11980 differs from actualnull11979. The324 depth1 anchor/CSV retain65 Other Views on the Black and White; the heading is not trimmed by current patterns. MAIN remains unapplied and iOS unaccepted; no runtime/device acceptance is inferred. Only `@BASE@`, `@DATA@`, `@UTC@` remain for actual closure substitution.

After inspecting the four preparation files, run from the workspace root:

```sh
python3 -B campaign-artifacts/C05-322-324/prepare_current_bank_q.py --reproduction '/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through324'
```

Record that actual invocation as `current-bank-preparation-caller`. Then use unchanged `bank_compact_verification.py 108 322 REPRODUCTION_DIR`, followed by the existing staging/whitespace and post-bank packing steps. No new whitespace exception or closure implementation is introduced.

`closure-plan.json` is an explicit UNBOUND plan. It includes real Q artifact paths, the required future preparation/bank/stage/audit/post-bank caller paths, and the sole current historical failure `root-inputs-caller` exit1. Missing future artifacts are not passing results. Once all planned records exist, use the unchanged approved binder through:

```sh
python3 -B campaign-artifacts/C05-322-324/prepare_q_config.py --plan campaign-artifacts/C05-322-324/closure-plan.json --bind --output campaign-artifacts/C05-322-324/closure.config.json
```

The binder requires every artifact and six native caller files, rejects an unexpected exit, and writes a fresh exact config without approval. Record plan/binding commands outside Q's `*-caller` namespace so an in-progress planning recorder is not mistaken for completed closure evidence. If actual caller inventory changes, regenerate/review the plan. The completed preparation caller is bound from its real native files. Final config/root receipt and ledger inspection remain the existing closure gates; this preparation does not preclaim them.
