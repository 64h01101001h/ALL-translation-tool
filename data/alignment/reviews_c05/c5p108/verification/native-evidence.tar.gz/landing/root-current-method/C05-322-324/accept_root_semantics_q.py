"""Bind completed root linguistic reading to separately approved Q final inputs."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
B=Path(__file__).resolve().parent;S=B/'semantic-review';W=B.parents[1]/'campaign-worktree'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 r=p.read_bytes();return dict(bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
def save(p,d):
 with p.open('x') as f:f.write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
proof=read(B/'root-current-inputs/proof.json');f=read(S/'freeze.json');m=read(S/'review.json')
assert proof['status']=='PASS_ROOT_CURRENT_INPUTS' and proof['method']==pin(B/'verify_current_inputs_q_v2.py')
assert proof['final_review_freeze']==pin(S/'freeze.json') and proof['baseline_delta']==pin(S/'finalization/baseline-delta-proof.json')
assert proof['actual_baseline']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W)
assert f['verdict']==m['verdict']=='APPROVE' and m['spec_verdict']=='PASS' and m['quality_verdict']=='COMPLETE_NO_REQUIRED_CORRECTION'
assert f['open_findings']==m['open_findings']==[]
assert read(B/'root-inputs-attempt02-caller/execution.json')['exit']==0
assert proof['canonical_original_spans']==141 and proof['canonical_final_spans']==73
assert proof['original_checkpoint_files_preserved']==454 and proof['original_copy_records']==408
old=read(B/'root-semantic-reading-preparation.json')
assert proof['root_reading']==pin(B/'root-semantic-reading-preparation.json')
assert old['original_dispositions_read']==141 and old['original_omissions_read']==22 and old['final_rationales_and_fresh_judgments_read']==73 and old['five_ground_screens_read']==30
assert len(old['critical_full_master_objects_read'])==26 and len(old['critical_complete_corpus_rows_read'])==15
assert m['total_spans']==73 and m['total_nulls']==0 and m['total_word_pairs']==50 and m['total_d7']==14
resolved=read(B/'root-current-inputs/resolved-spans.json');assert resolved==read(S/'resolved-spans.json')
current=read(B/'root-current-inputs/current-native-evidence.json');assert pin(B/'root-current-inputs/current-native-evidence.json')==proof['current_native_evidence']
reading=dict(completed='Root read all141 original dispositions,22 original omissions,73 final rationales and independent judgments,30 original five-ground screens, complete source322–324/context313–327,26 critical complete master objects and15 complete corpus rows before finalization. Exact semantic evidence stayed unchanged. Root now read complete final review, actual baseline/governance/register proof and explicit454-file checkpoint delta, then verified all860 final files and408 original-copy records. Only four metadata records changed; prior records remain preserved.',preparation_reading=pin(B/'root-semantic-reading-preparation.json'),judgment=old['judgment'],editorial_questions=old['editorial_questions'],finalization='The source315 origin and actual321 baseline remain distinct. Prior316–321 ledger/registry additions do not change governing semantic rules. No individual generator, resolver or master/corpus query was repeated for this finalization.')
counts=dict(spans=73,nulls=0,nonnull_d5=50,total_d5=50,d7=14)
compat=B/'root-reconciliation-verification';compat.mkdir(exist_ok=False)
shutil.copy2(B/'root-current-inputs/resolved-spans.json',compat/'resolved-spans.json')
save(compat/'provenance.json',dict(source=str(B/'root-current-inputs/resolved-spans.json'),identity=pin(B/'root-current-inputs/resolved-spans.json'),actual_input_proof=pin(B/'root-current-inputs/proof.json'),meaning='Exact output transport for existing acceptance verifier; no new resolver invocation or replacement of original proof.'))
save(B/'root-reconciliation-reading.json',reading)
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=proof['actual_baseline'],source_origin=proof['source_origin'],prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,current_native_evidence=current,limits=['The original root input attempt failed on assumed allowance shape; actual Q{} is preserved. Exact v2 correction passed with no source/generator change.','Scoped semantic finalization preserved its actual first closure-tree interpretation failure and corrected second pass.']))
result=dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),page='c5p108',segments=[322,323,324],counts=counts,source_origin=proof['source_origin'],actual_baseline=proof['actual_baseline'],review=pin(S/'review.md'),review_json=pin(S/'review.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),read_evidence=reading,semantic_decision=old['judgment'],null_decisions='Zero nulls. Uncertain or distributed correspondences remain unbanked with reasons; phrase-level evidence preserves defensible full relations.',errata=read(S/'bank-ready-errata.json'),allowances=read(S/'span-head-allow-needed.json'),execution_reuse='Preparation canonical214 ranges and100 lexical/40distinctSQL/47originalSQL/41external checks reused by exact identity. All6 original and3 final generation records stay preserved. No root individual generation or resolver rerun.',limits='Provisional machine alignment acceptance only. Two LOW/PROBABLE editorial questions remain uncertain; no source/master correction, hgm_gloss promotion, human editorial acceptance, MAIN application or phone acceptance.')
save(B/'root-semantic-disposition.json',result)
print(json.dumps({k:result[k] for k in ('verdict','page','counts','review_freeze')},indent=2))
