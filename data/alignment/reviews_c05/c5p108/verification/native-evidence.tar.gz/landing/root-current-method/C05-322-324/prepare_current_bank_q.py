"""Prepare small current-method copies and an evidence-derived Q ledger; no W writes.

Run after root inspection and completed production gates. Detailed semantic,
registration, whole-output/index validation remains in the approved Q closure.
"""
from pathlib import Path
import argparse,datetime,json,re,shutil,subprocess,sys
B=Path(__file__).resolve().parent;A=B.parent;W=A.parent/'campaign-worktree'
C=A/'reusable-batch-closure-q-candidate'
sys.path.insert(0,str(C))
from closure import check_ctest,check_native,pin,save,sha
captured={}
def capture(p):
    raw=p.read_bytes()
    if p in captured:assert captured[p]==pin(raw),('Changed preparation input',p)
    captured[p]=pin(raw);return raw
def read(p):return json.loads(capture(p))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reproduction',required=True);args=p.parse_args();r=Path(args.reproduction).resolve()
    baseline=read(B/'baseline.json');base=baseline['commit']
    assert baseline['course_boundary']==321 and subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()==base
    review=read(B/'semantic-review/review.json');frozen=read(B/'semantic-review/freeze.json');decision=read(B/'root-semantic-disposition.json')
    assert decision['verdict']=='APPROVE_ROOT_SEMANTIC_ACCEPTANCE' and decision['actual_baseline']==base
    assert decision['review_freeze']==pin(capture(B/'semantic-review/freeze.json'))
    assert review['verdict']=='APPROVE' and review['open_findings']==[] and [x['seq'] for x in review['segments']]==[322,323,324]
    ret=read(B/'landing/retention-source-check.json');course=read(B/'landing/course-csv-check.json')
    build=read(B/'landing/canonical-builds-once.json');repro=read(r/'proof.json');reg=read(B/'landing/registration/proof.json')
    copies=read(B/'landing/review-copy-and-register-proof.json')
    assert build['status']==repro['status']==reg['status']=='PASS'
    assert all(x['baseline_commit']==base for x in (ret,course,build,repro,reg,copies))
    assert ret['segments']==repro['segments']==reg['segments']==[322,323,324] and ret['page']=='c5p108'
    assert ret['reviewed_analyst_spans']==review['total_spans'] and ret['added_links']==review['total_spans']+3
    assert ret['full_links']==ret['prior_links_retained']+ret['added_links'] and ret['prior_links_retained']==baseline['full_links']
    assert all(ret[k] is True for k in ('review_tuples_and_source_ranges_match','source_hashes_unchanged','prior_notes_trees_evidence_and_acip_retained','prior_csv_content_and_references_retained'))
    assert course['all_depths_counts_and_metadata_match_main_csv_refs'] is True
    assert len(repro['outputs'])==7 and all(x['complete_bytes_equal'] is True for x in repro['outputs']) and repro['all_original_inputs_unchanged'] is True
    assert len(build['runs'])==len(repro['runs'])==2 and all(x['exit']==0 for x in build['runs']+repro['runs'])
    assert reg['prior_errata_retained']==194 and [x['item_id'] for x in reg['errata']]==copies['added_errata']==['E-195','E-196']
    assert all(x['severity']=='LOW' and x['confidence']=='PROBABLE' for x in reg['errata']) and reg['head_allowances']==reg['requested_allowances']=={}
    repro_review=read(B/'compact-reproduction-review/method-review.json')
    assert repro_review['verdict']=='APPROVE_REUSE_UNCHANGED_REPRODUCTION_METHOD' and repro_review['current_proof_pin']==pin(capture(r/'proof.json'))
    for name,identity in repro_review['methods'].items():assert pin(capture(A/name))==identity
    method_review=read(B/'closure-root-method-review.json')
    assert method_review['verdict']=='APPROVE_ROOT_Q_CLOSURE_METHOD'
    assert method_review['methods']=={n:pin(capture(C/n)) for n in ('closure.py','q_profile.py')}
    assert method_review['candidate_freeze']==pin(capture(C/'candidate-freeze.json'))
    # Native completion and a small status gate, not a repeated production run.
    callers={};recorder=sha(capture(A/'record_external_step.py'))
    for d in sorted(B.glob('*-caller')):
        if d.name=='current-bank-preparation-caller':
            assert not (d/'execution.json').exists(),'Preparation caller already completed';continue
        expected=1 if d.name=='root-inputs-caller' else 0
        callers[d.name]=check_native(d,expected,recorder)
        for f in sorted(d.iterdir()):capture(f)
    required={'root-inputs-attempt02-caller','semantic-acceptance-caller','root-semantic-intake-caller','land-caller','landed-acceptance-caller','register-caller','copy-register-check-caller','builders-caller','ctest-17-caller','retention-caller','course-csv-caller','reproduction-caller'}
    assert required<=set(callers)
    tests=capture(B/'ctest-17-caller/stdout.bin');check_ctest(tests)
    timing=re.findall(rb'Total Test time \(real\) =\s*([0-9.]+) sec',tests);assert len(timing)==1
    diagnostics=capture(B/'landing/build-view.stderr').decode()
    shortfalls=re.findall(r'(\d+) published rows show less than the layer banked \(from (\d+) trim calls\)',diagnostics)
    skipped=re.findall(r'skipped (\d+) links with no English exponent',diagnostics);assert len(shortfalls)==len(skipped)==1
    elapsed=(datetime.datetime.fromisoformat(build['finished_at'])-datetime.datetime.fromisoformat(build['started_at'])).total_seconds();assert elapsed>=0
    # Explicit small files only. Landing/native/current callers are already included
    # by unchanged bank_compact_verification.py and are not copied here again.
    names=['prepare_current_bank_q.py','prepare_q_config.py','closure-plan.json','bank-preparation-method.md',
      'closure-root-method-review.json','registration-root-method-review.json','root-preparation-method-review.json',
      'verify_current_inputs_q.py','verify_current_inputs_q_v2.py','accept_root_semantics_q.py',
      'root-inputs-failure-disposition.json','workflow-efficiency-note.json','config-independent-review/integration-limit-proof.json','root-current-inputs/proof.json','root-current-inputs/resolved-spans.json',
      'root-semantic-disposition.json','root-reconciliation-intake.json','root-semantic-reading-preparation.json',
      'root-reconciliation-reading.json','root-preparation-proof.json','root-lexical-preparation.json','root-parallel-preparation.json',
      'root-input-candidate/verify_root_inputs_q_v1.py','root-input-candidate/candidate.json','root-input-candidate/interface-note.md',
      'root-input-candidate/reference-to-candidate.diff','root-input-candidate/preparation-01/proof.json',
      'root-input-candidate/preparation-01/canonical-native-identity.json']
    files=[B/n for n in names]
    files += [f for f in (B/'root-input-candidate/attempts').rglob('*') if f.is_file()]
    choices={
      'reusable-batch-closure-q-candidate':['closure.py','q_profile.py','core-hooks.diff','candidate-freeze.json','preparation-failure.json','q_profile-before-interface-review.py.txt'],
      'reusable-batch-closure-q-independent-review':['freeze.json','report.md','initial-findings.json','static-scope-proof.json','test-evidence-proof.json'],
      'registration-with-errata-q-candidate':['register_reviewed_page_with_errata_q.py','exact-method.diff','candidate-freeze.json','prior-evidence-reuse.json'],
      'registration-with-errata-q-independent-review':['freeze.json','report.md','method-review.json'],
      'reusable-batch-closure-p-profile-candidate':['post_bank_plan.py','pack_post_bank.py'],
      'reusable-batch-closure-p-retry-candidate':['bind_config.py']}
    files += [A/folder/n for folder,names in choices.items() for n in names]
    files += [A/n for n in ['verify_semantic_acceptance_v2.py','prepare_review_whitespace_pins_v4.py','audit_staged_source_whitespace_v12.py','C05-313-315/whitespace-latin1-independent-review.json']]
    assert len(files)==len(set(files))
    for f in files:assert f.is_file() and not f.is_symlink() and f.stat().st_size<=4*1024*1024,f;capture(f)
    assert sum(captured[f]['bytes'] for f in files)<=12*1024*1024,'Current-method package exceeds bound'
    date=datetime.datetime.fromisoformat(build['finished_at']).date().isoformat()
    entry=f'''

### {date} — independently reviewed C05:322–324; verified coverage324/511

- Accepted {review['total_spans']} provisional spans, {review['total_nulls']} nulls, {review['total_word_pairs']} nonnull d5 pairs and {review['total_d7']} d7 members, plus3 source anchors: {ret['added_links']} new links. Coverage324/511 leaves187 segments325–511. C06 waits for complete C05; C13 remains blocked upstream.
- Source/proposal origin {review['source_origin_git_commit']} through315 remains distinct from actual acceptance @BASE@ through321. Final independent APPROVE retains SPEC PASS and QUALITY COMPLETE_NO_REQUIRED_CORRECTION with zero open findings. All{frozen['file_count']} frozen semantic files and{len(read(B/'semantic-review/original-to-copy-manifest.json'))} original-copy records remain exact; root acceptance covered141 original dispositions,22 original omissions,73 final decisions and all30 original five-ground screens. Individual generation and source queries were not repeated for finalization or packaging.
- E-195 and E-196 add only two LOW/PROBABLE human editorial questions, retaining all194 prior records and exact evidence/counterevidence. ZHI/four and gzugs/formless realm remain unbanked pairs; bral ba/eliminating is withheld as an isolated pair while its defensible full d3 relation is retained. No source/master correction, hgm_gloss promotion or supplied-head allowance is applied. Machine alignments remain provisional; no human editorial acceptance is claimed.
- Production passed once in {elapsed:.6f}s; all17 named fidelity tests passed in {timing[0].decode()}s. All{ret['prior_links_retained']} prior links and{ret['prior_csv_rows_retained']} prior main-CSV rows, notes, trees, evidence, ACIP and references remain retained. Actual totals: {ret['full_links']} links/{ret['null_exponents']} nulls/{ret['evidence_headwords']} evidence heads/{ret['evidence_pairs']} evidence pairs/{ret['current_csv_rows']} main-CSV rows/{course['current_course_depth_groups']} course-depth groups. Seven whole outputs reproduced once from {repro['registered_pages']} registered pages and incoming seed SHA{repro['seed']['sha256']}. External proof: {r/'proof.json'}.
- Full current build-view.stderr remains preserved: {shortfalls[0][0]} published rows show less than the layer banked, from{shortfalls[0][1]} trim calls. The same43/29 appears in actual through315/321 logs; older42/28 ledger prose was stale, so no Q increase is claimed. The broader skipped-link diagnostic is{skipped[0]}, distinct from actual null count{ret['null_exponents']}. Separately, source324 depth1 anchor and CSV retain verbatim65 Other Views on the Black and White; current patterns do not trim that heading. Source-formatting/rendering concerns remain unresolved. No new MAIN/runtime/device tests are claimed.
- The actual root-input failure used P's empty allowance shape; old method and real exit1 are preserved beside v2 and its actual passing attempt02. The closure profile's two initial interface assumptions and corrected method/review remain preserved. Canonical registrar, native streams, owned-source-copy cleanup and exact current-method manifests remain readable; historical test/semantic trees are referenced by their existing freezes, not recopied.
- Private DATA @DATA@ is based on @BASE@; separately validated closure supplies @UTC@. Staged source audit, exact Git modes/blobs/tree, parent checks and identical append-only three-ledger updates remain mandatory closure gates. This ledger preparation does not stage, commit or preclaim those results.
- Isolated desktop-consumable outputs are verified through324. MAIN remains unapplied; no new applicability/runtime claim. iOS remains FAILED_UNACCEPTED for four inherited C01 mappings, with no installation; historical installed through171 is unchanged. External evidence drive remains required. No release, API or paid generation occurred.
'''
    assert set(re.findall(r'@[A-Z0-9_]+@',entry))=={'@BASE@','@DATA@','@UTC@'}
    destination=B/'landing/root-current-method';ledger=B/'landing/root-ledger-entry-template.md'
    assert not destination.exists() and not ledger.exists()
    for f,identity in list(captured.items()):assert pin(f.read_bytes())==identity,f
    destination.mkdir();manifest=[]
    for f in sorted(files):
        target=destination/f.relative_to(A);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,target)
        assert pin(target.read_bytes())==captured[f]
        manifest.append(dict(original=str(f),copy=str(target.relative_to(destination)),**captured[f]))
    save(destination/'manifest.json',manifest)
    with ledger.open('x') as f:f.write(entry)
    save(destination/'preparation-proof.json',dict(status='PREPARED_CURRENT_BANK_INPUTS',baseline_commit=base,source_origin=review['source_origin_git_commit'],segments=[322,323,324],
      method=pin(capture(Path(__file__))),method_files=len(manifest),ledger=pin(ledger.read_bytes()),
      prerequisites=[dict(path=str(f),**v) for f,v in sorted(captured.items())],actual_totals={k:ret[k] for k in ('full_links','null_exponents','evidence_headwords','evidence_pairs','current_csv_rows')},
      actual_course_groups=course['current_course_depth_groups'],staging_performed=False,closure_performed=False,worktree_writes=False))
    print(json.dumps(dict(status='PREPARED_CURRENT_BANK_INPUTS',method_files=len(manifest),ledger_bytes=ledger.stat().st_size)))

if __name__=='__main__':main()
