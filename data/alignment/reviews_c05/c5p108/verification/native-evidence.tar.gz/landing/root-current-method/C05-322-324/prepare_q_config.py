"""Create an explicit unapproved Q closure plan; bind only completed exact inputs."""
from pathlib import Path
import argparse,importlib.util,json,sys
B=Path(__file__).resolve().parent;A=B.parent;W=A.parent/'campaign-worktree'
C=A/'reusable-batch-closure-q-candidate'
sys.path.insert(0,str(C))
from closure import SCHEMA,save
spec=importlib.util.spec_from_file_location('approved_config_binder',A/'reusable-batch-closure-p-retry-candidate/bind_config.py')
binder=importlib.util.module_from_spec(spec);spec.loader.exec_module(binder)
ROLES=dict(root_inputs='root-inputs-attempt02-caller',semantic_acceptance='semantic-acceptance-caller',
 root_intake='root-semantic-intake-caller',landing='land-caller',landed_semantic_acceptance='landed-acceptance-caller',
 registration='register-caller',registered_copy='copy-register-check-caller',builders='builders-caller',tests='ctest-17-caller',
 retention='retention-caller',course_csv='course-csv-caller',reproduction='reproduction-caller',bank='compact-bank-caller',
 stage='stage-data-caller',whitespace='whitespace-audit-caller')
FAILURES={'root-inputs-caller':dict(exit=1,reason='Actual Q root-input attempt used the P empty allowance shape; preserved method/caller/disposition. v2 changed only the comparison to actual frozen{}; attempt02 passed without generator/resolver/query rerun.')}
BATCH_ARTIFACTS={
 'baseline':'baseline.json','proposal_baseline':'proposal-baseline.json','semantic_freeze':'semantic-review/freeze.json',
 'reconciliation_freeze':'reconciled/freeze.json','review':'semantic-review/review.json',
 'original_copies':'semantic-review/original-to-copy-manifest.json','root_inputs':'root-current-inputs/proof.json',
 'root_intake':'root-reconciliation-intake.json','root_disposition':'root-semantic-disposition.json',
 'errata':'semantic-review/bank-ready-errata.json','head_allowances':'semantic-review/span-head-allow-needed.json',
 'profile_baseline_delta':'semantic-review/finalization/baseline-delta-proof.json',
 'profile_reconciliation_summary':'reconciled/summary.json',
 'profile_preparation_proof':'root-input-candidate/preparation-01/proof.json',
 'profile_preparation_native':'root-input-candidate/preparation-01/canonical-native-identity.json',
 'profile_root_input_method':'verify_current_inputs_q_v2.py','profile_root_reading':'root-semantic-reading-preparation.json',
 'profile_resolved':'semantic-review/resolved-spans.json',
 'build':'landing/canonical-builds-once.json','retention':'landing/retention-source-check.json',
 'course_csv':'landing/course-csv-check.json','registration':'landing/registration/proof.json',
 'whitespace':'landing/source-whitespace-proof.json','whitespace_stdout':'landing/staged-diff-check.stdout',
 'whitespace_stderr':'landing/staged-diff-check.stderr','whitespace_exit':'landing/staged-diff-check.exit',
 'whitespace_preparation':'landing/whitespace-pin-preparation.json','whitespace_pins':'landing/review-whitespace-exact-pins.json',
 'ledger_template':'landing/root-ledger-entry-template.md','bank_preparation_method':'prepare_current_bank_q.py',
 'bank_preparation_proof':'landing/root-current-method/preparation-proof.json',
 'current_method_manifest':'landing/root-current-method/manifest.json',
 'root_input_failure_disposition':'root-inputs-failure-disposition.json',
 'root_closure_method_review':'closure-root-method-review.json','root_registration_method_review':'registration-root-method-review.json',
 'current_reproduction_method_review':'compact-reproduction-review/method-review.json'}


def plan(reproduction):
    r=Path(reproduction).resolve();v=W/'data/alignment/reviews_c05/c5p108/verification'
    paths={k:str(B/p) for k,p in BATCH_ARTIFACTS.items()}
    paths.update({k:str(A/p) for k,p in {
     'recorder':'record_external_step.py','profile_method':'reusable-batch-closure-q-candidate/q_profile.py',
     'closure_method':'reusable-batch-closure-q-candidate/closure.py',
     'closure_candidate_freeze':'reusable-batch-closure-q-candidate/candidate-freeze.json',
     'closure_independent_review':'reusable-batch-closure-q-independent-review/freeze.json',
     'closure_preparation_failure':'reusable-batch-closure-q-candidate/preparation-failure.json',
     'closure_preserved_initial_profile':'reusable-batch-closure-q-candidate/q_profile-before-interface-review.py.txt',
     'registration_method':'registration-with-errata-q-candidate/register_reviewed_page_with_errata_q.py',
     'registration_candidate_freeze':'registration-with-errata-q-candidate/candidate-freeze.json',
     'registration_independent_review':'registration-with-errata-q-independent-review/freeze.json',
     'whitespace_method':'audit_staged_source_whitespace_v12.py','whitespace_pin_method':'prepare_review_whitespace_pins_v4.py',
     'whitespace_method_review':'C05-313-315/whitespace-latin1-independent-review.json'}.items()})
    paths.update({k:str(v/p) for k,p in {'bank_summary':'summary.json','bank_archive':'native-evidence.tar.gz',
      'bank_manifest':'archive-manifest.json','post_bank_archive':'post-bank-evidence.tar.gz','post_bank_manifest':'post-bank-manifest.json'}.items()})
    paths['reproduction_proof']=str(r/'proof.json');paths['reproduction_inputs']=str(r/'input-manifest.json')
    # These future paths are plans, never claims of completed native execution.
    names=set(ROLES.values())|set(FAILURES)|{'current-bank-preparation-caller','whitespace-pins-caller','post-bank-pack-caller','post-bank-stage-caller'}
    names|={p.name for p in B.glob('*-caller') if p.is_dir() and p.name!='compact-closure-caller'}
    return dict(schema=SCHEMA,repository=str(W),batch=str(B),reproduction=str(r),artifacts=paths,
      callers={n:str(B/n) for n in sorted(names)},required_roles=ROLES,historical_failures=FAILURES,
      active_caller='compact-closure-caller',post_freeze=[],retrospective=None)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reproduction');p.add_argument('--plan')
    p.add_argument('--output',required=True);p.add_argument('--bind',action='store_true');a=p.parse_args()
    if a.plan:
        assert a.reproduction is None,'Use the exact existing plan or create a new plan, not both'
        value=json.loads(Path(a.plan).read_bytes())
    else:
        assert a.reproduction,'--reproduction required for a new plan';value=plan(a.reproduction)
    save(a.output,binder.bind(value) if a.bind else value)

if __name__=='__main__':main()
