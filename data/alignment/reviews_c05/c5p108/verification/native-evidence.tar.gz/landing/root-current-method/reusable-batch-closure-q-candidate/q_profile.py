"""Candidate explicit Q322–324 closure; existing production gates remain shared.

The Q evidence remains in its original schemas. No generation or test invocation.
"""
from pathlib import Path
import argparse
import json
import stat
from closure import (Closure, Invalid, check_scope, exact, need, pin, read,
                     relpath, save, selected, sha, under)

SIDECAR='docs/errata_register.json'
PROSE='docs/ERRATA_REGISTER.md'
ALLOW='data/alignment/span_head_allow.json'
OUTPUT_REGISTERS={SIDECAR,PROSE}
GUARDED={SIDECAR,PROSE,ALLOW,'tools/build_alignment_layer.py','data/alignment/pages_c05/index.html'}
FIELDS=('kind','found','expected','evidence','severity','confidence')

class QClosure(Closure):
    def verify_review_metadata(self,d,proposal,baseline):
        need(not self.retrospective,'Q currently supports live closure only')
        need(d['verdict']=='APPROVE' and d['open_findings']==[], 'Q final independent approval')
        if d['schema']=='c05-independent-semantic-review-v1':
            need(d['spec_verdict']=='PASS' and d['quality_verdict']=='COMPLETE_NO_REQUIRED_CORRECTION',
                 'Q actual retained semantic judgment')
        else:
            need(d['schema']=='c05-independent-semantic-review-freeze-v1','Q explicit semantic schema')
        need(d['source_origin_git_commit']==proposal['commit'] and proposal['course_boundary']==315,
             'Q original source boundary')
        receipt=d['actual_through321_baseline_receipt']
        need(type(receipt) is dict and set(receipt)=={'commit','course_boundary','bytes','sha256','copy','verification_proof'},
             'Q six-key actual receipt')
        need(receipt['commit']==self.base==baseline['commit'] and receipt['course_boundary']==baseline['course_boundary']==321,
             'Q actual acceptance boundary')
        need(selected(receipt)==self.checked['baseline'],'Q original baseline pin')
        need(exact(under(self.b/'semantic-review',receipt['copy']),receipt)==self.artifact('baseline'),
             'Q exact receipt copy')
        need(receipt==self.doc('review')['actual_through321_baseline_receipt'],'Q review/freeze receipt equality')
        need(under(self.b/'semantic-review',receipt['verification_proof']).read_bytes()==self.artifact('profile_baseline_delta'),
             'Q actual baseline-delta proof binding')

    def verify_reconciliation_metadata(self,rec,proposal,seqs):
        summary=self.doc('profile_reconciliation_summary')
        need(pin(self.artifact('profile_reconciliation_summary'))==selected(rec['files']['summary.json']),
             'Q original reconciliation summary frozen identity')
        need(rec['source_origin_git_commit']==summary['source_origin_git_commit']==proposal['commit']
             and rec['source_boundary']==summary['source_boundary']==315,'Q reconciliation source origin')
        need(rec['later_acceptance_baseline'] is None and summary['later_acceptance_baseline'] is None,
             'Q reconciliation preparation must stay historical')
        need([r['seq'] for r in summary['segments']]==seqs==[322,323,324], 'Q reconciliation segments')
        for row in summary['segments']:
            need(row['generator_exit']==row['resolver_exit']==0 and row['final_generator_runs']==1,
                 'Q reconciliation original native gate')
            need(exact(self.b/f"reconciled/{row['seq']}/spec.json",row['spec'])==
                 (self.b/f"semantic-review/reviewed-final/{row['seq']}/spec.json").read_bytes(),'Q final spec identity')

    def reconciliation_total(self,rec,count_name,legacy_field):
        key={'spans':'spans','nulls':'nulls','nonnull_d5':'nonnull_d5','d7':'d7'}[count_name]
        return sum(r[key] for r in self.doc('profile_reconciliation_summary')['segments'])

    def verify_root_inputs(self,root,proposal,sequences):
        prep=self.doc('profile_preparation_proof')
        need(root['status']=='PASS_ROOT_CURRENT_INPUTS' and root['actual_baseline']==self.base
             and root['source_origin']==proposal['commit'],'Q actual root input acceptance')
        need(root['preparation_proof']==self.checked['profile_preparation_proof']
             and root['method']==pin(self.artifact('profile_root_input_method')),'Q actual root method/preparation binding')
        need(prep['status']=='PASS_PREPARATION_INPUTS_ONLY' and prep['actual_acceptance_baseline'] is None
             and prep['actual_acceptance_baseline_consumed'] is False and prep['acceptance_authorized'] is False,
             'Q preserve preparation-only scope')
        need(root['root_generator_runs']==0 and prep['fresh_generator_runs']==0
             and root['canonical_original_spans']==prep['canonical_original_spans']==141
             and root['canonical_final_spans']==prep['canonical_final_spans']==self.totals['spans']==73,
             'Q complete canonical range reuse')
        need(root['final_review_freeze']==self.checked['semantic_freeze']
             and root['baseline_delta']==pin(self.artifact('profile_baseline_delta')),
             'Q current finalization delta binding')
        native=self.doc('profile_preparation_native')
        need(self.checked['profile_preparation_native']==prep['outputs']['canonical-native-identity.json'],
             'Q preparation native evidence identity')
        rows=native['existing_native_records']
        need(len(rows)==18 and native['fresh_canonical_resolver_specs']==9 and native['fresh_generator_runs']==0,
             'Q six originals and three finals: nine generators/nine resolvers')
        for r in rows:
            directory=Path(r['directory'])
            need(directory.is_relative_to(self.b),'Q native directory scope')
            execution=read(directory/'execution.json')
            need(pin((directory/'execution.json').read_bytes())==r['execution'], 'Q original native execution pin')
            self.native_execution(directory,execution)

    def native_execution(self,directory,execution):
        need(set(p.name for p in directory.iterdir())=={'execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt'},
             'Q native five-file inventory')
        need(read(directory/'execution.json')==execution and execution['exit']==0
             and (directory/'exit.txt').read_bytes()==b'0\n','Q actual native pass')
        for stream in ('stdin','stdout','stderr'):
            exact(directory/(stream+'.bin'),execution['streams'][stream])
        need((directory/'stderr.bin').read_bytes()==b'','Q native warning refusal')

    def profile_gate(self,root,intake,decision,frozen,review,reconciliation):
        need(self.seqs==[322,323,324] and self.page==108 and self.c['post_freeze']==[], 'Q exact batch/no invented exclusion')
        need(root['baseline_delta']==self.checked['profile_baseline_delta'],'Q checked current delta')
        need(decision['read_evidence']['preparation_reading']==pin(self.artifact('profile_root_reading')),
             'Q exact completed root reading provenance')
        need(len(intake['current_native_evidence'])==3 and [r['seq'] for r in intake['current_native_evidence']]==self.seqs,
             'Q all current native evidence')
        for row,item in zip(review['segments'],intake['current_native_evidence']):
            need(item['root_generator_runs']==0,'Q no repeated individual generation')
            generator=under(self.b/'semantic-review',row['fresh_native_directory'])
            resolver=under(self.b/'semantic-review',row['fresh_resolver_directory'])
            need(row['fresh_native_directory']==f"native/final-{row['seq']}-generator-v1"
                 and row['fresh_resolver_directory']==f"native/final-{row['seq']}-resolver-v1",'Q exact native paths')
            self.native_execution(generator,item['execution']);self.native_execution(resolver,item['resolver_execution'])
            need(item['execution']['streams']['stdin']=={'bytes':row['spec_bytes'],'sha256':row['spec_sha256']}
                 and item['execution']['streams']['stdout']=={'bytes':row['body_bytes'],'sha256':row['body_sha256']},
                 'Q current generator spec/body')
            need((generator/'stdin.bin').read_bytes()==(resolver/'stdin.bin').read_bytes(),'Q resolver exact spec')
            need(read(resolver/'stdout.bin')==[r for r in self.doc('profile_resolved') if r['seq']==row['seq']],
                 'Q existing native ranges')

    def verify_policy_inputs(self):
        incoming=self.doc('errata')
        need(type(incoming) is list and len(incoming)==2 and [r['seq'] for r in incoming]==[322,324],
             'Q exact two editorial questions')
        for item in incoming:
            need(set(item)=={'seq',*FIELDS} and item['severity']=='LOW' and item['confidence']=='PROBABLE',
                 'Q tentative editorial scope')
        need(self.doc('head_allowances')=={},'Q no new allowance')
        before=self.git('show',self.base+':'+SIDECAR)
        old=json.loads(before)
        need(before==json.dumps(old,ensure_ascii=False,indent=1).encode(),'Q canonical old register bytes')
        need(len(old)==194,'Q actual incoming194 records')
        ids=[int(r['item_id'][2:]) for r in old]
        need(len(set(ids))==len(ids),'Q unique prior errata IDs')
        signatures={(r['segment'],r['found'][:60]) for r in old}
        expected=[]
        for n,r in enumerate(incoming,max(ids)+1):
            signature=(f"C05:{r['seq']}",r['found'][:60])
            need(signature not in signatures,'Q no duplicate register signature');signatures.add(signature)
            expected.append(dict(item_id=f'E-{n:03d}',course='C05',segment=f"C05:{r['seq']}",
                **{k:r[k] for k in FIELDS},note='filed from the alignment batch, spine-verified on merge'))
        after=under(self.w,SIDECAR).read_bytes()
        need(after==json.dumps(old+expected,ensure_ascii=False,indent=1).encode()
             and after[:len(before)-2]==before[:-2],'Q exact canonical additions/prior bytes retained')
        self.expected_errata=expected;self.work_identity(SIDECAR,after)
        unchanged=under(self.w,ALLOW).read_bytes()
        need(unchanged==self.git('show',self.base+':'+ALLOW),'Q allowance unchanged');self.work_identity(ALLOW,unchanged)

    def verify_registration_scope(self,reg):
        need(reg['errata']==self.expected_errata and reg['prior_errata_retained']==194
             and reg['head_allowances']==reg['requested_allowances']=={},'Q exact registration delta')
        need(reg['accepted_cli_pins']=={'errata_sha256':self.checked['errata']['sha256'],
                                      'review_freeze_sha256':self.checked['semantic_freeze']['sha256']},'Q exact accepted CLI pins')
        folder=self.b/'landing/registration'
        canonical=read(folder/'canonical-proof.json')
        need(canonical['status']=='PASS' and canonical['baseline_commit']==self.base
             and canonical['expected_added']==self.expected_errata,'Q actual canonical register pass')
        cleanup=read(folder/'staging-spine-cleanup.json')
        need(cleanup['status']=='REMOVED_VERIFIED_OWNED_COPY','Q actual staging source identity')
        for relative,row in cleanup['retained_files'].items():exact(under(folder,relative),row)
        native=folder/'native'
        labels={'baseline-prose','merge-dry-run','merge-apply','new-prose','quotes-hold','witnesses-named','prose-reproduction'}
        need(set(p.name for p in native.iterdir())==labels,'Q seven actual canonical invocations')
        for label in labels:
            d=native/label
            need(set(p.name for p in d.iterdir())=={'command.json','stdin.bin','stdout.bin','stderr.bin','exit'},'Q canonical native inventory')
            need((d/'exit').read_bytes()==b'0\n' and (d/'stdin.bin').read_bytes()==b'', 'Q canonical native exit/stdin')
            command=read(d/'command.json')
            need(command['stdin_bytes']==0 and Path(command['cwd'])==folder/'canonical-stage/campaign-worktree',
                 'Q actual canonical invocation cwd')
        for path in OUTPUT_REGISTERS:
            raw=(folder/'canonical-stage/campaign-worktree'/path).read_bytes()
            need(raw==(folder/'after'/path).read_bytes()==under(self.w,path).read_bytes(),'Q canonical output exact current bytes')
            self.work_identity(path,raw)

    def verify_registration_inputs(self,reg):
        rows=reg['files'];need(type(rows) is list and len(rows)==5 and {r['path'] for r in rows}==GUARDED,
                              'Q five guarded preimages')
        outputs={r['path']:r for r in rows}
        changed=[r['path'] for r in rows if r['before_sha256']!=r['after_sha256']]
        need(set(changed)==GUARDED-{ALLOW} and reg['written_files']==reg['attempted_files']==changed
             and reg['recovery']==[],'Q exactly four successful writes and no recovery')
        seen=set()
        for row in reg['inputs']:
            p=Path(row['path']);relative=str(p.relative_to(self.w)) if p.is_relative_to(self.w) else None
            if relative in outputs:
                need(relative not in seen,'Q duplicate registration input');seen.add(relative)
                out=outputs[relative];before=self.git('show',self.base+':'+relative);after=under(self.w,relative).read_bytes()
                need(pin(before)==selected(row) and sha(before)==out['before_sha256'] and sha(after)==out['after_sha256'],
                     'Q exact before/after registration identities')
                need(out['mode']==stat.S_IMODE(under(self.w,relative).stat().st_mode)==(0o755 if relative=='tools/build_alignment_layer.py' else 0o644),
                     'Q unchanged guarded mode')
                self.work_identity(relative,after)
            else:exact(p,row)
        need(seen==GUARDED,'Q all guarded input preimages')

    def check_staged_scope(self,paths):
        need(OUTPUT_REGISTERS<=set(paths),'Q registered sidecar/prose must be staged')
        check_scope([p for p in paths if p not in OUTPUT_REGISTERS],self.page)

    def approval(self,receipt):
        d=read(receipt);need(d['profile_method']==pin(Path(__file__).read_bytes()),'Q exact profile approval')
        super().approval(receipt)
        (self.o/'executed-profile.py.txt').write_bytes(Path(__file__).read_bytes())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('staged','execute'))
    p.add_argument('--config',required=True);p.add_argument('--root-review',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();run=QClosure(a.config,a.output,retrospective=False)
    try:
        run.approval(a.root_review)
        result=run.execute() if a.mode=='execute' else dict(run.verify(),status='PASS_Q_LIVE_STAGED_VERIFICATION',tree=run.staged())
        save(run.o/'proof.json',result);print(json.dumps(result,indent=2))
    except (Invalid,KeyError,OSError,ValueError) as exc:
        save(run.o/'failure.json',{'status':'FAIL_CLOSED','error':str(exc),'mode':a.mode});raise

if __name__=='__main__':main()
