"""Focused capture-boundary tests; no source helpers, generators, builds or closure run."""
from pathlib import Path
import copy
import importlib.util
import json
import shutil
import tempfile
import unittest

C = Path(__file__).resolve().parent
A = C.parent
spec = importlib.util.spec_from_file_location('raw_candidate', C / 'closure.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
ACTUAL = A / 'C05-349-351'


def dump(p, d):
    p.write_text(json.dumps(d, indent=2) + '\n')


def pins(d):
    return {p.name: m.pin(p.read_bytes()) for p in sorted(d.iterdir())}


class RawSourceBoundary(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.a = self.root / 'campaign-artifacts'
        self.b = self.a / 'C05-349-351'
        self.w = self.root / 'campaign-worktree'
        self.b.mkdir(parents=True)
        self.w.mkdir()
        self.seqs = [349, 350, 351]
        for name in m.RAW_SOURCE_NAMES:
            shutil.copytree(ACTUAL / name, self.b / name)
            helper = m.RAW_SOURCE_HELPERS[name][0]
            shutil.copyfile(A / helper, self.a / helper)
            d = self.b / name
            for f in ['command.json', 'execution.json']:
                doc = m.read(d / f)
                doc['cwd'] = str(self.w)
                doc['argv'][2] = str(self.a / helper)
                if name == 'source-preparation-caller':
                    doc['argv'][-1] = str(self.b / 'exploratory-terms.json')
                dump(d / f, doc)
        self.callers = {n: pins(self.b / n) for n in m.RAW_SOURCE_NAMES}
        self.opt = {'schema': m.RAW_SOURCE_SCHEMA,
                    'environment_limit': m.RAW_SOURCE_ENVIRONMENT_LIMIT,
                    'callers': {n: {'directory': str(self.b / n), 'files': copy.deepcopy(v)}
                                for n, v in self.callers.items()}}
        self.roles = {'landing': 'land-caller'}
        self.failures = {}

    def refresh(self, name):
        self.callers[name] = pins(self.b / name)
        self.opt['callers'][name]['files'] = copy.deepcopy(self.callers[name])

    def edit(self, file, key, value, name='source-preparation-caller'):
        p = self.b / name / file
        doc = m.read(p)
        doc[key] = value
        dump(p, doc)
        self.refresh(name)

    def run_boundary(self):
        p = self.b / 'raw-opt-in.json'
        dump(p, self.opt)
        run = object.__new__(m.Closure)
        run.b, run.w, run.seqs = self.b, self.w, self.seqs
        run.checked, run.expected_work, run.retrospective = {}, {}, False
        run.c = {'artifacts': {'raw_source_native_opt_in': {'path': str(p), **m.pin(p.read_bytes())}},
                 'callers': self.callers, 'required_roles': self.roles, 'historical_failures': self.failures}
        rows = run.raw_source_callers()
        for name in rows:
            m.check_raw_source_native(self.b / name, self.callers[name], self.b, self.w, self.seqs)
        return rows

    def rejected(self):
        with self.assertRaises((m.Invalid, ValueError, KeyError)):
            self.run_boundary()

    def test_actual_source_preparation(self):
        d = ACTUAL / 'source-preparation-caller'
        self.assertEqual(m.check_raw_source_native(d, pins(d), ACTUAL, A.parent / 'campaign-worktree', self.seqs)['exit'], 0)

    def test_actual_proposal_origin(self):
        d = ACTUAL / 'proposal-origin-caller'
        self.assertEqual(m.check_raw_source_native(d, pins(d), ACTUAL, A.parent / 'campaign-worktree', self.seqs)['exit'], 0)

    def test_valid_explicit_pair(self):
        self.assertEqual(set(self.run_boundary()), m.RAW_SOURCE_NAMES)

    def test_argv_mismatch(self):
        d = m.read(self.b / 'source-preparation-caller/execution.json')
        d['argv'][-2] = '354'
        self.edit('execution.json', 'argv', d['argv'])
        self.rejected()

    def test_both_argv_wrong_batch(self):
        for f in ['command.json', 'execution.json']:
            d = m.read(self.b / 'proposal-origin-caller' / f)
            d['argv'][-1] = '352'
            self.edit(f, 'argv', d['argv'], 'proposal-origin-caller')
        self.rejected()

    def test_both_argv_wrong_helper(self):
        for f in ['command.json', 'execution.json']:
            d = m.read(self.b / 'source-preparation-caller' / f)
            d['argv'][2] = str(self.a / 'other.py')
            self.edit(f, 'argv', d['argv'])
        self.rejected()

    def test_wrong_interpreter(self):
        for f in ['command.json', 'execution.json']:
            d = m.read(self.b / 'proposal-origin-caller' / f)
            d['argv'][0] = 'python3'
            self.edit(f, 'argv', d['argv'], 'proposal-origin-caller')
        self.rejected()

    def test_cwd_mismatch(self):
        self.edit('execution.json', 'cwd', str(self.root))
        self.rejected()

    def test_both_cwd_wrong(self):
        for f in ['command.json', 'execution.json']:
            self.edit(f, 'cwd', str(self.root))
        self.rejected()

    def test_time_mismatch(self):
        self.edit('execution.json', 'utc', '2026-09-15T03:19:18+00:00')
        self.rejected()

    def test_timestamp_without_timezone(self):
        self.edit('execution.json', 'utc', '2026-09-15T03:19:17')
        self.edit('command.json', 'started_at', '2026-09-15T03:19:17')
        self.rejected()

    def test_nonempty_actual_stdin_even_with_updated_pin(self):
        name = 'source-preparation-caller'
        d = self.b / name
        (d / 'stdin.bin').write_bytes(b'x')
        ex = m.read(d / 'execution.json')
        ex['streams']['stdin'] = m.pin(b'x')
        dump(d / 'execution.json', ex)
        self.refresh(name)
        self.rejected()

    def test_stdout_stream_corruption_even_with_new_outer_pin(self):
        name = 'source-preparation-caller'
        (self.b / name / 'stdout.bin').write_bytes(b'changed')
        self.refresh(name)
        self.rejected()

    def test_stderr_stream_corruption_even_with_new_outer_pin(self):
        name = 'proposal-origin-caller'
        (self.b / name / 'stderr.bin').write_bytes(b'changed')
        self.refresh(name)
        self.rejected()

    def test_nonzero_exit(self):
        self.edit('execution.json', 'exit', 1)
        self.rejected()

    def test_nonzero_exit_and_exit_file(self):
        name = 'proposal-origin-caller'
        (self.b / name / 'exit.txt').write_bytes(b'1\n')
        self.edit('execution.json', 'exit', 1, name)
        self.rejected()

    def test_stale_file_pin(self):
        (self.b / 'source-preparation-caller/stdout.bin').write_bytes(b'changed')
        self.rejected()

    def test_opt_in_pin_differs_from_standard_caller(self):
        self.opt['callers']['source-preparation-caller']['files']['stdout.bin']['sha256'] = '0' * 64
        self.rejected()

    def test_required_production_role_forbidden(self):
        self.roles['landing'] = 'source-preparation-caller'
        self.rejected()

    def test_failure_bypass_forbidden(self):
        self.failures['proposal-origin-caller'] = {'exit': 1, 'reason': 'not permitted'}
        self.rejected()

    def test_unapproved_caller_name(self):
        self.opt['callers']['other-caller'] = self.opt['callers'].pop('proposal-origin-caller')
        self.rejected()

    def test_third_caller_forbidden(self):
        self.opt['callers']['other-caller'] = copy.deepcopy(self.opt['callers']['proposal-origin-caller'])
        self.rejected()

    def test_missing_pair_member(self):
        del self.opt['callers']['proposal-origin-caller']
        self.rejected()

    def test_wrong_directory(self):
        self.opt['callers']['proposal-origin-caller']['directory'] = str(self.b / 'elsewhere')
        self.rejected()

    def test_helper_bytes_changed(self):
        (self.a / 'capture_proposal_origin.py').write_bytes(b'changed')
        self.rejected()

    def test_execution_schema_extra_field(self):
        self.edit('execution.json', 'invented_recorder_field', True)
        self.rejected()

    def test_sidecar_schema_extra_field(self):
        self.edit('command.json', 'independently_captured_environment', True)
        self.rejected()

    def test_environment_limit_must_remain_explicit(self):
        self.opt['environment_limit'] = 'Environment independently captured'
        self.rejected()

    def test_bad_duration(self):
        self.edit('execution.json', 'elapsed_seconds', float('inf'))
        self.rejected()

    def test_default_has_no_raw_exception(self):
        run = object.__new__(m.Closure)
        run.c = {'artifacts': {}}
        self.assertEqual(run.raw_source_callers(), {})
        with self.assertRaises(m.Invalid):
            m.check_native(ACTUAL / 'source-preparation-caller', 0, m.sha((A / 'record_external_step.py').read_bytes()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
