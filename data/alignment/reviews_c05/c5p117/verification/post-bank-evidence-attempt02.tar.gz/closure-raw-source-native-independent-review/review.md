APPROVE the frozen raw-source capture method and exact proposed F opt-in. The two named original captures remain fully pinned and cannot satisfy production roles or failure bypasses. All ordinary caller, production and root approval gates remain unchanged. Missing raw environment capture stays explicit.

The 30 author tests and 50 independent boundary checks passed. All 14 candidate members and the unchanged errata profile were verified. G already has standard recorder captures; both pass the unchanged standard validator, so G must omit this opt-in. The first read-only attempt to apply the raw validator to G failed at its strict schema check and is preserved as resolved input-classification history.

No source queries, alignment engines, builders, fidelity tests, closure actions or worktree writes were performed. Separate root approval of the exact live configuration remains required.
