"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert (B/'root-final-review-reading.json').is_file() and (B/'root-assembled-reading.json').is_file()
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root personally read all127 original span/range/rationale records,25 omissions,six notes,30 error-category judgments and both source-specific five-ground assessments;45 complete master objects,8 complete corpus wrappers and5 current register objects, plus source/context/six physical extents, are separately pinned. Final66 tuples and rationale/omission/disposition records were read using exact personally read originals plus all changed root rulings. Independent source/original preassessment preceded root choices. Root-final-review-reading.json records actual final independent reading before this acceptance; reviewer143master/43corpus inventory is not root reading. Frozen hashes and native verification do not substitute for semantics.'
decision='Approve66 provisional spans22/26/18,44nonnullD5,4D7,1null.349 keeps bare BSAMS BZHIN, ZHE NA/ask, LA/where and separates MA/no from inflected BSAMS PAR/intent using complete lexical attestation.350 narrows both DNGOS GZHI parents to literal technical names, retaining distinct hyphen spacing and DNGOS/actual children; local John/Joe roles stay distinct. Keep local NAS/because, first GYI/of, LA/where and whole self-killing phrase. Terminal TO is an affirmative punctuation-fusion d6 null.351 keeps flat possession/take and whole negative undetected/improper-to-perform phrases. Uncertain superior/desire/sex and the four-types wording carried into English352 remain unbanked with reasons, no false null.'
errata='Zero new errata or head allowances. Preserve English350 LOW/PROBABLE existing-class hyphen-space note and Tibetan351 LOW/UNCERTAIN MA NOR PAR versus BAR question with full grounds and no filing. C16 duplicate readings are not independent restorations. Preserve English351 revised exact352 quotation, first freeze/report and correction history. Existing202 records remain unchanged. No source/master correction, normalized pairing or hgm_gloss promotion.'
assert read(S/'bank-ready-errata.json')==[]
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p117',segments=[349,350,351],counts=dict(spans=66,nulls=1,nonnull_d5=44,total_d5=44,d7=4),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading.json'),final_independent_reading=pin(B/'root-final-review-reading.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Eight actual unique native pairs:6original and2changed349350reconciler; unchanged351 reuses exact English spec/body/ranges/native. Nine selected capture views include1duplicate; root/reviewer0newnative runs. Exact root349350specs and original/final notes and all original histories are preserved; no superseded candidate generation or production rerun.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[349,350,351],semantic_files=len(freeze['files']))))
