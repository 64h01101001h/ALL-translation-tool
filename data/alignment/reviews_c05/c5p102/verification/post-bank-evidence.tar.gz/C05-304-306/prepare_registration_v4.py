"""Prepare an additive exact-manifest binding for the independently frozen v2 schema."""
from pathlib import Path
import difflib, hashlib, json
B=Path(__file__).resolve().parent;A=B.parent
p=A/'register_reviewed_page_v3.py';old=p.read_text();new=old
changes=[
('import ast\n','import ast\nimport argparse\n'),
('    page, first = map(int, sys.argv[1:])\n', '''    parser = argparse.ArgumentParser()
    parser.add_argument('page', type=int)
    parser.add_argument('first', type=int)
    parser.add_argument('--freeze-name', choices=('review-freeze.json', 'freeze.json'), required=True)
    parser.add_argument('--review-freeze-sha256', required=True)
    arguments = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{64}', arguments.review_freeze_sha256)
    page, first = arguments.page, arguments.first
'''),
("    freeze = read(review / 'review-freeze.json')\n    assert freeze['verdict'] == 'APPROVE' and freeze['open_findings'] == []\n    governing = freeze.get('governing_git_commit', freeze.get('source_origin_commit'))\n", '''    freeze_name = arguments.freeze_name
    freeze = read(review / freeze_name)
    assert pin(capture(review / freeze_name))['sha256'] == arguments.review_freeze_sha256
    if freeze_name == 'review-freeze.json':
        assert freeze['verdict'] == 'APPROVE' and freeze['open_findings'] == []
        governing = freeze.get('governing_git_commit', freeze.get('source_origin_commit'))
    else:
        assert freeze['schema'] == 'c05-independent-semantic-review-freeze-v2'
        assert freeze['verdict'] == freeze['spec_verdict'] == freeze['quality_verdict'] == 'APPROVE'
        assert type(freeze['open_findings']) is int and freeze['open_findings'] == 0
        assert freeze['actual_acceptance_baseline_commit'] == head
        assert freeze['actual_acceptance_course_boundary'] == first - 1
        assert freeze['actual_acceptance_baseline_sha256'] == pin(capture(batch / 'baseline.json'))['sha256']
        assert freeze['reconciliation_input_freeze_sha256'] == pin(capture(batch / 'reconciled/freeze.json'))['sha256']
        assert freeze['file_count'] == len(freeze['files'])
        for field in ('total_spans', 'total_nulls', 'total_word_pairs'):
            assert freeze[field] == meta[field]
        governing = freeze['source_governance_origin']
        assert governing == meta['source_governance_origin']
'''),
("    assert capture(banked / 'review-freeze.json') == capture(review / 'review-freeze.json')\n", "    assert capture(banked / freeze_name) == capture(review / freeze_name)\n")]
for before,after in changes:
    assert new.count(before)==1,before
    new=new.replace(before,after,1)
new=new.replace('Usage: python3 -B register_reviewed_page_v2.py PAGE FIRST','Usage: python3 -B register_reviewed_page_v4.py PAGE FIRST --freeze-name NAME --review-freeze-sha256 SHA',1)
compile(new,str(A/'register_reviewed_page_v4.py'),'exec')
out=A/'register_reviewed_page_v4.py';assert not out.exists();out.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=p.name,tofile=out.name));(B/'registration-v4.diff').write_text(diff)
print(diff)
