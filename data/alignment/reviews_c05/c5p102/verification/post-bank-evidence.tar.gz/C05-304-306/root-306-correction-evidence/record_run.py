"""Losslessly record one actual process. Existing successful evidence is reusable."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
def pin(b): return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def run(directory,argv,cwd,stdin=b''):
    d=Path(directory);d.mkdir(parents=True,exist_ok=False)
    (d/'stdin.bin').write_bytes(stdin)
    command={'argv':list(map(str,argv)),'cwd':str(cwd),'environment_overrides':{'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'},'inherited_environment':True,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recorder':str(Path(__file__).resolve()),'recorder_pin':pin(Path(__file__).read_bytes())}
    put(d/'command.json',command)
    p=subprocess.run(command['argv'],cwd=cwd,input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,**command['environment_overrides']})
    (d/'stdout.bin').write_bytes(p.stdout);(d/'stderr.bin').write_bytes(p.stderr);(d/'exit.txt').write_text(str(p.returncode)+'\n')
    put(d/'execution.json',{**command,'exit':p.returncode,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'streams':{k:pin(v) for k,v in [('stdin',stdin),('stdout',p.stdout),('stderr',p.stderr)]}})
    return p
if __name__=='__main__':
    d,cwd,*argv=sys.argv[1:];p=run(d,argv,cwd);sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);raise SystemExit(p.returncode)
