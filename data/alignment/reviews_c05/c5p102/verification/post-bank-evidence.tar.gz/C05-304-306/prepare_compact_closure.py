"""Adapt the previously reviewed exact-tree closure to the actual306 boundary."""
from pathlib import Path
import difflib
B=Path(__file__).resolve().parent;A=B.parent
old=(A/'close_c05_303_compact.py').read_text();new=old
replacements={
"B = A / 'C05-301-303'":"B = A / 'C05-304-306'",
"BASE = 'b5047596859f6537b71f259c1e7df2e70f867fb2'":"BASE = 'f1651c64b0ad9b0c7ea85f9961332ac1a3787e83'",
"compact-reproduction-through303":"compact-reproduction-through306",
"B/'semantic-review/review-freeze.json'":"B/'semantic-review/freeze.json'",
"frozen['open_findings']==[]":"type(frozen['open_findings']) is int and frozen['open_findings']==0",
"(104,6,57)":"(75,12,43)",
"reviewroot/'review-freeze.json'":"reviewroot/'freeze.json'",
"(301,302,303)":"(304,305,306)",
"'root-register-caller'":"'root-register-attempt02-caller'",
",'root-v9-pin-preparation-caller','root-whitespace-audit-attempt02-caller'":",'root-whitespace-audit-caller'",
"segments 301–303":"segments 304–306",
"through segment 303":"through segment 306",
"coverage=303,remaining=208":"coverage=306,remaining=205",
",'docs/errata_register.json','docs/ERRATA_REGISTER.md'":"",
}
for before,after in replacements.items():
    assert before in new,before;new=new.replace(before,after)
# Page paths are substituted simultaneously to avoid cascading predecessor edits.
new=new.replace('c5p101','__CURRENT_PAGE__').replace('c5p100','c5p101').replace('__CURRENT_PAGE__','c5p102')
start=new.index("assert read(B/'whitespace-v9-root-review.json')")
end=new.index("assert sha((B/'landing/staged-diff-check.stdout')",start)
new=new[:start]+"assert read(B/'root-register-caller/execution.json')['exit']==1\nassert read(B/'landing/registration/proof.json')['status']=='PASS'\n"+new[end:]
start=new.index('# Archive only evidence produced after the first compact bank, once.')
end=new.index('inputs=sorted(set(inputs)); members=[]',start)
archive='''# Archive only late evidence and bounded current method/history bindings.
inputs=[B/'landing'/n for n in ('source-whitespace-proof.json','review-whitespace-exact-pins.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit','root-ledger-entry-template.md')]
for caller in ('root-whitespace-audit-caller','root-compact-bank-caller','root-stage-data-caller','root-retention-caller','root-compact-reproduction-caller'):
    inputs.extend(sorted(p for p in (B/caller).rglob('*') if p.is_file()))
inputs.extend([Path(__file__).resolve(),B/'prepare_compact_closure.py',B/'closure-method-review.json',B/'closure-method.diff.txt',B/'root-semantic-disposition.json',B/'root-scoped-306-intake.json'])
inputs.extend([A/'audit_staged_source_whitespace_v6.py',A/'audit_staged_source_whitespace_v7.py',A/'audit_staged_source_whitespace_v8.py',A/'C05-286-288/compact-reproduction-review/whitespace-v7-review.json',A/'C05-292-294/whitespace-v8-root-review.json'])
inputs.extend([B/'registration-v4-root-review.json',B/'registration-v4.diff',A/'register_reviewed_page_v3.py',A/'register_reviewed_page_v4.py',B/'prepare_registration_v4.py',A/'prepare_review_whitespace_pins_v2.py',B/'whitespace-pin-v2-root-review.json',B/'whitespace-pin-v2.diff'])
inputs.extend([B/'reconciliation-history/v1-before-306-member-correction/original-to-history.json',B/'root-306-correction-evidence/completion-proof.json',B/'root-306-correction-evidence/changed-original-to-history.json'])
inputs.extend([p for p in (B/'root-306-correction-evidence').iterdir() if p.is_file() and p.suffix=='.py'])
# Original/reconciliation histories already reside in the exact1700-file banked
# semantic package. Do not recursively copy their complete source/proof trees again.
inputs.extend([A/'integration/through291-root-disposition.json',A/'integration/through291-current-assessment/review.md',A/'integration/through291-current-assessment/assessment.json',A/'integration/through291-current-assessment/freeze.json'])
'''
new=new[:start]+archive+new[end:]
assert 'v9' not in new and 'C05-301-303' not in new and "'root-register-caller'" not in new
out=A/'close_c05_306_compact.py';assert not out.exists();compile(new,str(out),'exec');out.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='close_c05_303_compact.py',tofile=out.name));(B/'closure-method.diff.txt').write_text(diff);print(diff)
