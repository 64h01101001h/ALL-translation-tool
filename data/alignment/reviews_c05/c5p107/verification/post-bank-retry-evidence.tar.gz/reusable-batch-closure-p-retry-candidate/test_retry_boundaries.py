"""Focused synthetic registration tests and read-only actual caller checks; no generators."""
from pathlib import Path
import copy, json, tempfile, unittest
import closure as c
from prepare_p_config import plan
ROOT=Path(__file__).resolve().parent
BATCH=ROOT.parent/'C05-319-321'
OLD=json.loads((BATCH/'closure.config.json').read_bytes())

class Registration(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT); self.addCleanup(self.tmp.cleanup)
        self.w=Path(self.tmp.name); self.run=object.__new__(c.Closure)
        self.run.w=self.w; self.run.base='a'*40; self.run.retrospective=False; self.run.expected_work={}
        self.before={}; self.proof=dict(written_files=[],files=[],inputs=[])
        for path in ['tools/build_alignment_layer.py','data/alignment/pages_c05/index.html']:
            before=('OLD '+path).encode(); after=('NEW '+path).encode(); self.before[path]=before
            f=self.w/path; f.parent.mkdir(parents=True,exist_ok=True); f.write_bytes(after)
            self.proof['written_files'].append(path)
            self.proof['files'].append(dict(path=path,before_sha256=c.sha(before),after_sha256=c.sha(after)))
            self.proof['inputs'].append(dict(path=str(f),**c.pin(before)))
        extra=self.w/'unchanged.txt';extra.write_bytes(b'unchanged')
        self.proof['inputs'].append(dict(path=str(extra),**c.pin(extra.read_bytes())))
        def git(*args):
            self.assertEqual(args[0],'show'); commit,path=args[1].split(':',1)
            self.assertEqual(commit,'a'*40);return self.before[path]
        self.run.git=git
    def verify(self):self.run.verify_registration_inputs(self.proof)
    def rejected(self):
        with self.assertRaises(c.Invalid):self.verify()
    def test_valid_preimages_and_both_postimages_bound(self):
        self.verify();self.assertEqual(set(self.run.expected_work),set(self.proof['written_files']))
        for p in self.proof['written_files']:self.assertEqual(self.run.expected_work[p],c.pin((self.w/p).read_bytes()))
    def test_changed_base_blob(self):self.before[self.proof['written_files'][0]]=b'wrong BASE';self.rejected()
    def test_wrong_preimage_size(self):self.proof['inputs'][0]['bytes']+=1;self.rejected()
    def test_wrong_declared_before_hash(self):self.proof['files'][0]['before_sha256']='0'*64;self.rejected()
    def test_changed_builder(self):(self.w/self.proof['written_files'][0]).write_bytes(b'changed');self.rejected()
    def test_changed_index(self):(self.w/self.proof['written_files'][1]).write_bytes(b'changed');self.rejected()
    def test_wrong_declared_after_hash(self):self.proof['files'][1]['after_sha256']='0'*64;self.rejected()
    def test_duplicate_written_path(self):self.proof['written_files'][1]=self.proof['written_files'][0];self.rejected()
    def test_missing_written_path(self):self.proof['written_files'].pop();self.rejected()
    def test_invented_written_path(self):self.proof['written_files'][1]='docs/errata_register.json';self.rejected()
    def test_duplicate_output_path(self):self.proof['files'][1]=self.proof['files'][0];self.rejected()
    def test_missing_output_path(self):self.proof['files'].pop();self.rejected()
    def test_missing_preimage(self):self.proof['inputs'].pop(0);self.rejected()
    def test_duplicate_preimage(self):self.proof['inputs'].append(self.proof['inputs'][0]);self.rejected()
    def test_other_input_still_exact(self):(self.w/'unchanged.txt').write_bytes(b'changed');self.rejected()

class Callers(unittest.TestCase):
    def setUp(self):
        self.run=object.__new__(c.Closure);self.run.b=BATCH;self.run.w=Path(OLD['repository'])
        self.run.retrospective=False;self.run.expected_work={};self.run.checked={}
        self.run.c=copy.deepcopy(OLD);self.run.c['active_caller']='compact-closure-attempt02-caller'
        self.run.c['historical_failures']['compact-closure-caller']=dict(exit=1,reason='Actual preserved first closure precommit failure')
        self.run.c['callers']['compact-closure-caller']={n:c.pin((BATCH/'compact-closure-caller'/n).read_bytes()) for n in c.NATIVE}
    def rejected(self):
        with self.assertRaises(c.Invalid):self.run.verify_callers()
    def test_actual_completed_callers_and_three_failures(self):
        self.run.verify_callers();self.assertEqual(self.run.native['compact-closure-caller']['exit'],1)
        self.assertTrue(all(self.run.native[n]['exit']==0 for n in self.run.c['required_roles'].values()))
    def test_unknown_active_not_exempted(self):self.run.c['active_caller']='compact-closure-attempt03-caller';self.rejected()
    def test_missing_old_failure(self):del self.run.c['historical_failures']['compact-closure-caller'];self.rejected()
    def test_wrong_old_failure_exit(self):self.run.c['historical_failures']['compact-closure-caller']['exit']=2;self.rejected()
    def test_active_caller_cannot_be_bound(self):self.run.c['callers']['compact-closure-attempt02-caller']={};self.rejected()
    def test_old_caller_cannot_be_omitted(self):del self.run.c['callers']['compact-closure-caller'];self.rejected()
    def test_completed_original_cannot_be_active(self):
        self.run.c['active_caller']='compact-closure-caller';del self.run.c['callers']['compact-closure-caller'];del self.run.c['historical_failures']['compact-closure-caller'];self.rejected()
    def test_required_pass_cannot_be_failure(self):
        self.run.c['historical_failures'][self.run.c['required_roles']['tests']]=dict(exit=1,reason='invalid');self.rejected()
    def test_plan_explicit_retry_accounts_for_old_failure(self):
        p=plan(BATCH,OLD['reproduction'],active_caller='compact-closure-attempt02-caller')
        self.assertIn('compact-closure-caller',p['callers']);self.assertNotIn(p['active_caller'],p['callers'])
        self.assertEqual(p['historical_failures']['compact-closure-caller']['exit'],1)
    def test_plan_rejects_unknown_retry(self):
        with self.assertRaises(ValueError):plan(BATCH,OLD['reproduction'],active_caller='compact-closure-attempt03-caller')

if __name__=='__main__':unittest.main(verbosity=2)
