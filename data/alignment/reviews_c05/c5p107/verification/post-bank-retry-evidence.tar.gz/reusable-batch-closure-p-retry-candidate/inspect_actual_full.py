"""Read-only full verification; deliberately no approval(), staged(), or execute()."""
from pathlib import Path
import copy,json,traceback
from closure import NATIVE,pin,save
from p_profile import PClosure
from prepare_p_config import plan
ROOT=Path(__file__).resolve().parent;B=ROOT.parent/'C05-319-321'
c=copy.deepcopy(json.loads((B/'closure.config.json').read_bytes()))
p=plan(B,c['reproduction'],active_caller='compact-closure-attempt02-caller')
c['active_caller']=p['active_caller'];c['historical_failures']=p['historical_failures']
c['callers']['compact-closure-caller']={n:pin((B/'compact-closure-caller'/n).read_bytes()) for n in NATIVE}
c['artifacts']['profile_method']=dict(path=str(ROOT/'p_profile.py'),**pin((ROOT/'p_profile.py').read_bytes()))
config=ROOT/'actual-readonly.config.json';save(config,c)
run=PClosure(config,ROOT/'actual-full-inspection')
try:
    facts=run.verify()
    result=dict(status='PASS_READ_ONLY_FULL_VERIFIER_NOT_ROOT_EXECUTION',facts=facts,expected_work=run.expected_work,
        config=pin(config.read_bytes()),method=pin((ROOT/'closure.py').read_bytes()),profile=pin((ROOT/'p_profile.py').read_bytes()),
        scope='Actual full verify() only. No root approval, staging, commit, generator, production/test/reproduction rerun, or source write.')
    save(run.o/'proof.json',result);print(json.dumps({k:v for k,v in result.items() if k!='expected_work'},indent=2))
except BaseException as exc:
    save(run.o/'failure.json',dict(status='FAIL_READ_ONLY_INSPECTION',error=str(exc),traceback=traceback.format_exc()));raise
