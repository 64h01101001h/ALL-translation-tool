"""Reviewer rerun of scoped retry tests; fixtures stay in this review directory."""
from pathlib import Path
import hashlib,importlib.util,json,sys,unittest
ROOT=Path(__file__).resolve().parent;C=ROOT.parent/'reusable-batch-closure-p-retry-candidate'
sys.path.insert(0,str(C))
spec=importlib.util.spec_from_file_location('retry_tests',C/'test_retry_boundaries.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=ROOT
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(m.Registration),
                          unittest.defaultTestLoader.loadTestsFromTestCase(m.Callers)])
assert suite.countTestCases()==25
result=unittest.TextTestRunner(verbosity=2).run(suite)
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
proof={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,
       'failures':len(result.failures),'errors':len(result.errors),
       'methods':{n:pin((C/n).read_bytes()) for n in ('closure.py','prepare_p_config.py','p_profile.py','test_retry_boundaries.py')},
       'scope':'Independent rerun of author targeted tests after full code/test review; synthetic local registration fixtures and read-only existing caller records, no production/test/generation commands.'}
with (ROOT/'targeted-test-proof.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
sys.exit(0 if result.wasSuccessful() else 1)
