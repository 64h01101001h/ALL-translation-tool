"""Root source/range intake. Immutable original review supplies typed query records.

No generator or semantic judgment is delegated to this identity verification.
Current scoped semantic acceptance is checked separately after its final freeze.
"""
from pathlib import Path
from collections import defaultdict, Counter
import datetime, gzip, hashlib, json, re, sqlite3, subprocess, sys, types
B = Path(__file__).resolve().parent
W = B.parents[1] / 'campaign-worktree'
Q = B / 'reconciled'
S = B / 'semantic-review-history/v1'
O = B / 'root-reconciliation-inputs'
assert not O.exists()
def read(p): return json.loads(p.read_bytes())
def pin(raw): return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def expected(x): return {k: x[k] for k in ('bytes', 'sha256')}
def git(*args): return subprocess.check_output(['git', *args], cwd=W)
freezes = [
    ('tibetan', 'freeze.json', '9f02303cfaa0b6948e72be4953177989a9e023d4eff644aaf80d51cb2f255ace'),
    ('english', 'freeze.json', '2a4f6a9f684ed5dcb76c23591c13d8520c004ae9047aa8f47b0706103d61eac1'),
    ('reconciled', 'freeze.json', 'bd0d058547e2c6265e1e5b9326191130897bb906484d5960a5ee73ccfa2ea140'),
    ('reconciliation-history/v1', 'freeze.json', '6beabe2726cbdd404577bfa91a22442cf100ee01ee9ed49920cb7d37bec2bf8c'),
    ('semantic-review-history/v1', 'freeze.json', '0ffb996a488d9e86396b89173f6f1ce12fad0ff7600d15f7b11c6104b3cb0f97'),
]
frozen = {}
for directory, name, sha in freezes:
    root = B / directory
    raw = (root / name).read_bytes()
    assert pin(raw)['sha256'] == sha
    files = json.loads(raw)['files']
    assert isinstance(files, dict)
    for rel, record in files.items():
        p = root / rel
        assert p.resolve().is_relative_to(root.resolve())
        assert pin(p.read_bytes()) == expected(record), str(p)
    frozen[directory] = {'files': len(files), 'sha256': sha}
origin, baseline = read(B / 'proposal-baseline.json'), read(B / 'baseline.json')
assert origin['commit'] == '49b66f3af9cbb47599bb40286637fc9e683b7cdf'
assert baseline['commit'] == git('rev-parse', 'HEAD').decode().strip() == '91d2c245ddd410894f12653cf3acf0302d488520'
assert baseline['course_boundary'] == 318
assert not git('status', '--porcelain', '--untracked-files=no')
for record in origin['source_pins'].values():
    assert pin(Path(record['path']).read_bytes()) == expected(record)
for rel, record in origin['governing_git_pins'].items():
    assert pin(git('show', origin['commit'] + ':' + rel)) == expected(record)
for rel, sha in baseline['sha256'].items():
    assert pin((W / rel).read_bytes())['sha256'] == sha
    if not rel.endswith('.json.gz'):
        assert pin(git('show', baseline['commit'] + ':' + rel))['sha256'] == sha
for name, rel in [('hgm_tools', 'engines/hgm_tools.py'), ('build_alignment_layer', 'tools/build_alignment_layer.py'), ('gen_alignment_page', 'tools/gen_alignment_page.py')]:
    raw = git('show', origin['commit'] + ':' + rel)
    assert raw == (Q / 'evidence/pinned' / rel).read_bytes()
    module = types.ModuleType(name)
    module.__file__ = str(W / rel)
    sys.modules[name] = module
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
G = sys.modules['gen_alignment_page']
db = sqlite3.connect(Path(origin['source_pins']['spine']['path']).as_uri() + '?mode=ro', uri=True)
db.row_factory = sqlite3.Row
db.execute('PRAGMA query_only=ON')
source = [dict(r) for r in db.execute('select * from corpus_segments where course=? and seq between ? and ? order by seq', ('C05', 313, 327))]
assert source == read(S / 'evidence/independent-complete-source-context.json')
byseq = {r['seq']: r for r in source}
for name in ['source.json', 'context.json']:
    for r in read(B / name):
        assert all(byseq[r['seq']][k] == v for k, v in r.items())
keys = ['seq', 'id', 'd', 'tib', 'eng', 'tib_range', 'eng_range']
resolved = {}
for angle in ['tibetan', 'english', 'final']:
    for seq in [319, 320, 321]:
        root = Q / str(seq) if angle == 'final' else B / angle / str(seq)
        spec = read(root / 'spec.json')
        assert spec['course'] == 'C05' and len(spec['segments']) == 1
        seg = spec['segments'][0]
        assert seg['seq'] == seq
        spans = seg['spans']; byid = {r['id']: r for r in spans}
        assert len(byid) == len(spans)
        tr = G.resolve(byseq[seq]['wylie'], spans, 'tib', seq)
        er = G.resolve(byseq[seq]['english'], G.with_members(spans, [byid[i] for i in seg['eng_order']], byseq[seq]['english']), 'eng', seq)
        rows = [dict(seq=seq, id=r['id'], d=r['d'], tib=r['tib'], eng=r['eng'], tib_range=list(tr[r['id']]), eng_range=list(er[r['id']]) if r['eng'] is not None else None) for r in spans]
        resolved[(angle, seq)] = rows
        decisions = read(root / ('final-decisions.json' if angle == 'final' else 'decisions.json'))
        assert [{k: r[k] for k in keys} for r in decisions['spans']] == rows
        if angle == 'final':
            assert read(root / 'final-ordered-tuples.json')['source_order'] == rows
            assert read(root / 'errata.json') == []
            oldspec = read(B / 'reconciliation-history/v1' / str(seq) / 'spec.json')
            if seq == 319:
                oldspan = next(r for r in oldspec['segments'][0]['spans'] if r['id'] == 'w15')
                assert oldspan['d'] == 3
                oldspan['d'] = 5
            assert oldspec == spec
            if seq != 319:
                for p in root.iterdir():
                    assert p.read_bytes() == (B / 'reconciliation-history/v1' / str(seq) / p.name).read_bytes()
dispositions = Counter(); changes = []; omissions = []
for seq in [319, 320, 321]:
    current = {r['id']: r for r in resolved[('final', seq)]}
    d = read(Q / str(seq) / 'original-dispositions.json'); seen = set()
    for r in d['spans']:
        a, oid = r['angle'], r['original']['id']
        assert (a, oid) not in seen; seen.add((a, oid))
        original = next(x for x in resolved[(a, seq)] if x['id'] == oid)
        assert r['original'] == original
        for fid in r['final_ids']: assert fid in current
        if r['decision'] == 'RETAIN':
            assert len(r['final_ids']) == 1
            assert all(original[k] == current[r['final_ids'][0]][k] for k in keys if k != 'id')
        else:
            assert r['decision'] == 'RECAST'
            changes.append(r)
        dispositions[r['decision']] += 1
    assert len(seen) == sum(len(resolved[(a, seq)]) for a in ['tibetan', 'english'])
    omissions.extend(d['original_omissions'])
master = json.load(gzip.open(origin['source_pins']['master']['path'], 'rt'))
corpus = json.load(gzip.open(origin['source_pins']['corpus']['path'], 'rt'))
collections = {k: list(master[k].values()) if isinstance(master[k], dict) else master[k] for k in ['unified_entries', 'curated_entries', 'glossary_entries']}
index = defaultdict(list)
for collection, entries in collections.items():
    for i, entry in enumerate(entries):
        for term in [entry.get('wylie')]:
            if term: index[term].append(dict(collection=collection, index=i, entry=entry))
lexical_count = 0
for rel in ['tibetan/evidence/full-lexical-evidence.json', 'tibetan/evidence/supplemental-full-lexical-evidence.json', 'english/evidence/lexical-evidence.json', 'english/evidence/supplemental-lexical-evidence.json']:
    for q in read(B / rel):
        assert q['master_records'] == index[q['term']]
        assert q['count'] == len(q['master_records'])
        actual = [dict(r) for r in db.execute('select * from entries where wylie=?', (q['term'],))]
        assert actual == q['spine_entries']
        lexical_count += 1
master_objects = read(S / 'evidence/master-complete-objects.json')
for r in master_objects.values(): assert collections[r['collection']][r['index']] == r['entry']
sql_count = 0
for rel in ['tibetan/evidence/corpus-queries.json', 'tibetan/evidence/partial-parallel-queries.json', 'english/evidence/corpus-queries.json']:
    for q in read(B / rel):
        actual = [dict(r) for r in db.execute(q['sql'], q['params'])]
        assert actual == q['rows'] and len(actual) == q['count']
        sql_count += 1
corpus_objects = read(S / 'evidence/corpus-complete-objects.json')
for r in corpus_objects.values():
    actual = dict(db.execute('select * from corpus_segments where id=?', (r['spine']['id'],)).fetchone())
    assert actual == r['spine']
    assert corpus[r['external_corpus_index']] == r['external_corpus_record'] == json.loads(actual['raw'])
physical = Path(origin['source_pins']['physical']['path']).read_bytes()
folded = ' '.join(physical.decode('latin1').split())
for r in read(S / 'evidence/independent-physical-proof.json'):
    raw = physical[slice(*r['acip_complete_physical_byte_range'])]
    assert raw.decode('latin1') == r['acip_original_extent']
    assert ' '.join(raw.decode('latin1').split()) == byseq[r['seq']]['acip']
    assert folded[slice(*r['english_range_in_linefolded_latin1'])] == byseq[r['seq']]['english']
screens = read(S / 'errata-audit.json')
assert len(screens) == 30
for r in screens:
    g = r['five_refutation_grounds']; row = byseq[r['seq']]
    assert r['refuted'] and not g['d']['correction_established']
    for k, positions in g['a']['actual_occurrences'].items():
        assert [m.start() for m in re.finditer('(?=' + re.escape(r['found']) + ')', row[k])] == positions
    assert g['e']['field_lengths'] == {k:len(row[k]) for k in ['acip','wylie','english']}
    original = resolved[(r['angle'],r['seq'])]
    assert g['e']['original_span_counts'] == dict(spans=len(original),nulls=sum(x['eng'] is None for x in original),nonnull_d5=sum(x['d']==5 and x['eng'] is not None for x in original),d5_total=sum(x['d']==5 for x in original),d7=sum(x['d']==7 for x in original))
db.close()
final = sum((resolved[('final', n)] for n in [319, 320, 321]), [])
assert len(final) == 85 and sum(r['d'] == 5 and r['eng'] is not None for r in final) == 56
assert sum(r['d'] == 7 for r in final) == 14 and not any(r['eng'] is None for r in final)
assert dispositions == {'RETAIN': 151, 'RECAST': 12}
assert lexical_count == 134 and sql_count == 36 and len(master_objects) == 141 and len(corpus_objects) == 63
O.mkdir()
for name, obj in [('resolved-spans.json', final), ('changed-original-dispositions.json', changes)]:
    (O / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
proof = dict(status='PASS_ROOT_INPUTS', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), actual_baseline=baseline['commit'], source_origin=origin['commit'], freezes=frozen, canonical_original_spans=163, canonical_final_spans=85, dispositions=dict(dispositions), original_omissions=len(omissions), lexical_queries=lexical_count, sql_queries=sql_count, complete_master_objects=141, complete_corpus_objects=63, root_generator_runs=0, limits=['This is structural/source verification; root linguistic judgment is separate.', 'Historical semantic review v1 supplies immutable query evidence; current scoped semantic approval is required separately.'])
(O / 'proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
