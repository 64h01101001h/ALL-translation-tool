"""Relocate six more completed campaign proof files with exact byte verification.

Leave containing folders and their existing symbolic links unchanged. Preserve
the original file paths as links to verified external copies. No source edit.
"""
from pathlib import Path
import datetime,hashlib,json,os,shutil,stat
A=Path(__file__).resolve().parent;I=A/'integration'
E=Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398')
O=A/'storage-file-relocation-through318-extra';O.mkdir(exist_ok=False)
D=E/'relocated-completed-files-through318-extra';D.mkdir(exist_ok=False)
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest(),mode=stat.S_IMODE(p.stat().st_mode))
records=[]
for rel in ['through276-checkpoint-execution/packages-run/original-base-review-package.diff','through276-checkpoint-execution-v2/packages-run/current-review-package.diff','through276-checkpoint-execution-v2/packages-run/original-base-review-package.diff.gz','through273-checkpoint-execution-01/runs/attempt01/current-review-package.diff','through273-checkpoint-execution-01/runs/attempt01/original-base-review-package.diff.gz','through273-checkpoint-execution-01/runs/attempt01/current-review-package.diff.gz']:
 src=I/rel;dst=D/rel
 assert src.is_file() and not src.is_symlink() and not dst.exists()
 assert src.stat().st_mtime<datetime.datetime(2026,9,14,19,0,tzinfo=datetime.timezone.utc).timestamp()
 original=pin(src);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 with dst.open('rb') as f:os.fsync(f.fileno())
 assert pin(dst)==original==pin(src)
 link=src.with_name(src.name+'.verified-external-link');assert not link.exists()
 link.symlink_to(dst);assert pin(link)==original
 os.replace(link,src)
 assert src.is_symlink() and pin(src)==original
 records.append(dict(original_path=str(src),external_path=str(dst),**original))
 (O/'verified-files.json').write_text(json.dumps(records,indent=2)+'\n')
proof=dict(status='PASS_BYTE_VERIFIED_COMPLETED_FILE_RELOCATION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,relocated_bytes=sum(r['bytes'] for r in records),available_internal_bytes=os.statvfs(A).f_bavail*os.statvfs(A).f_frsize,limits='External drive required; original paths remain readable with exact bytes and target file modes. Containing directories and all preexisting symlinks unchanged. Current source, master, worktree and active batch evidence unchanged. Additional storage was necessary after the earlier three-file byte-exact relocation; only these six completed historical proof files were relocated.')
(O/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
