# Current-bank preparation candidate for C05:319–321

`prepare_current_bank.py` is a candidate adapted from C05:316–318's preparation helper. It has not been executed. It neither depends on approval of a commit-closure method nor stages, commits, writes the worktree, runs generators or runs tests.

Root must first create `bank-preparation-root-review.json` after reviewing this exact method. Its required shape is:

```json
{
  "verdict": "APPROVE_ROOT_CURRENT_BANK_PREPARATION",
  "methods": {
    "prepare_current_bank.py": {"bytes": 0, "sha256": "actual method SHA256"}
  },
  "method_note": {"bytes": 0, "sha256": "actual bank-preparation-method.md SHA256"},
  "reference_diff": {"bytes": 0, "sha256": "actual bank-preparation-method.diff.txt SHA256"}
}
```

The zero byte values above are schema examples, not executable approval. Root supplies the measured identities. The helper rejects missing approval, mismatched identities, existing preparation outputs, incomplete records or any failed gate before creating its output directories.

The method verifies actual baseline `91d2c245ddd410894f12653cf3acf0302d488520` through318 while keeping source origin `49b66f3af9cbb47599bb40286637fc9e683b7cdf` through312 and v1's absent later receipt distinct. It binds the current 546-file semantic freeze and 392-file reconciliation freeze, 987 copy mappings, root input/intake/semantic judgments, current native streams, versioned acceptance before/after landing and successful v7 registration. The current319 directory is explicitly `reviewed-final-v2/319`;320/321 retain their reviewed-final directories.

Production, retention, course CSV and the actual17 named fidelity tests must pass. The external reproduction must exist at `/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through321`, report PASS, have exactly the seven expected whole outputs, match current production hashes and the actual incoming CSV seed, and record one layer and one view invocation. Its methods must equal the previously approved unchanged methods. Missing or running reproduction cannot yield an invented passing record or fabricated ledger totals. The helper reads these proofs; it does not repeat their executions.

The prepared evidence directory is `landing/root-current-method`. It contains current helpers, root judgments and the bounded root query/range proofs, plus both actual failed root caller captures, their preserved method versions and real attempt02 passes. The failed variant-inclusive query and failed full-record comparison of the changed319 native locator are preserved distinctly. Reconciliation preparation and semantic-review failures remain in the already banked frozen semantic review, with explicit v1/v2 lineage references; full historical review trees are not copied again.

The versioned-interface package includes the exact candidate/original method snapshots, exact diffs, root approval, independent review, test results, test method and original proof freeze. Its1777-file fixture tree remains referenced by that freeze and is not recursively copied. The six additional completed historical file relocations include their small proof, inventory, actual caller and helper. Packaging checks the existing symlinks, target sizes, modes and readability; it does not recopy or rehash the1,489,096,878 bytes of historical files. Existing through309 MAIN assessment is referenced once. Every file selected for copying must be a regular nonsymlink file at most4 MiB.

Successful preparation also writes `compact-reproduction-review/method-review.json` and `landing/root-ledger-entry-template.md`. The template derives final totals, timings, source/range/query counts, copies, retention and reproduction facts from the verified current records. Its only substitution tokens are exactly `@BASE@`, `@DATA@` and `@UTC@`. It states verified coverage321 while keeping staged source audit, exact Git modes/blobs/tree, append-only three-ledger verification and commit closure separate. It preserves MAIN-unapplied, phone-FAILED_UNACCEPTED and inherited runtime/editorial limits.

`landing/root-current-method/preparation-proof.json` records the exact prerequisite input pins, copied-method manifest, ledger identity and actual totals, explicitly recording no staging, closure or worktree write. All gates and the full copy inventory are checked before creating outputs; later I/O failures leave their partial preparation intact rather than deleting evidence or permitting an overwrite. Root can approve and run this helper once after every gate passes. No bespoke commit-closure implementation is supplied.
