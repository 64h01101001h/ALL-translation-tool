"""Bind the completed root reading to the exact separately approved v2 inputs."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess
B = Path(__file__).resolve().parent
S, Q, W = B/'semantic-review', B/'reconciled', B.parents[1]/'campaign-worktree'
def read(p): return json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes(); return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,obj):
    assert not p.exists(),p
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
proof=read(B/'root-reconciliation-inputs/proof.json')
assert proof['status']=='PASS_ROOT_INPUTS'
assert proof['canonical_original_spans']==163 and proof['canonical_final_spans']==85
assert pin(S/'freeze.json')['sha256']=='617775c5b7a27cc382a701b6a74100707fde89cef7bcedf99444520e09a85988'
assert pin(Q/'freeze.json')['sha256']=='bd0d058547e2c6265e1e5b9326191130897bb906484d5960a5ee73ccfa2ea140'
f,m=read(S/'freeze.json'),read(S/'review.json')
assert f['verdict']==f['spec_verdict']==f['quality_verdict']==m['verdict']==m['spec_verdict']==m['quality_verdict']=='APPROVE'
assert f['open_findings']==m['open_findings']==[] and f['file_count']==len(f['files'])==546
for rel,r in f['files'].items():
    p=S/rel;assert p.resolve().is_relative_to(S.resolve()) and pin(p)==r,p
rs=read(B/'root-reconciliation-inputs/resolved-spans.json')
assert rs==read(S/'resolved-spans.json')
reviewed=read(S/'span-review.json')
assert len(reviewed)==85 and all(x['verdict']=='SOUND' for x in reviewed)
assert [{k:x[k] for k in rs[0]} for x in reviewed]==rs
old=read(B/'semantic-review-history/v1/span-review.json')
assert len(old)==len(reviewed)
for a,b in zip(old,reviewed):
    if a['seq']==319:
        assert a['canonical_native_resolver']=='native/final-319-resolver-v1'
        assert b['canonical_native_resolver']=='native/scoped-final-319-resolver-v2'
        a=dict(a,canonical_native_resolver=b['canonical_native_resolver'])
    if (a['seq'],a['id'])!=(319,'w15'):assert a==b
    else:assert a['d']==3 and b['d']==5 and all(a[k]==b[k] for k in rs[0] if k!='d')
assert m['total_spans']==85 and m['total_nulls']==0 and m['total_word_pairs']==56 and m['total_d7']==14
dispositions=read(S/'original-decision-review.json');assert len(dispositions)==163
expected=sum((read(Q/str(n)/'original-dispositions.json')['spans'] for n in [319,320,321]),[])
assert [(r['angle'],r['original'],r['decision'],r['final_ids']) for r in expected]==[(r['angle'],r['original'],r['reconciler_disposition'],r['final_ids']) for r in dispositions]
assert len(read(S/'original-omission-review.json'))==22 and len(read(S/'errata-audit.json'))==30
assert read(S/'bank-ready-errata.json')==[] and read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
assert read(S/'scoped-v2/semantic-change-review.json')['status']=='SOUND'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert head==proof['actual_baseline']==f['later_supplied_acceptance_baseline']==m['later_supplied_acceptance_baseline']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W)
receipt=read(S/'scoped-v2/actual-baseline-receipt.json')
assert receipt['baseline_identity']==pin(B/'baseline.json') and receipt['actual_git_head']==head
assert receipt['received_for_review_version']==2 and receipt['initial_review_v1_baseline_receipt'] is None
assert (S/'scoped-v2/actual-through318-baseline.json').read_bytes()==(B/'baseline.json').read_bytes()
native=[]
for row in m['segments']:
    seq=row['seq'];directory=S/row['fresh_native_directory']
    assert directory.resolve().is_relative_to(S.resolve())
    e=read(directory/'execution.json')
    assert e['exit']==0 and (directory/'exit.txt').read_bytes()==b'0\n' and not (directory/'stderr.bin').read_bytes()
    assert e['cwd']==str(S) and e['environment_override']['PYTHONDONTWRITEBYTECODE']=='1'
    assert e['argv'][1:]==['-B',str(S/'helpers/canonical.py.txt'),'generate']
    for stream,p in e['streams'].items():assert pin(directory/(stream+'.bin'))==p
    assert (directory/'stdin.bin').read_bytes()==(Q/str(seq)/'spec.json').read_bytes()
    assert (directory/'stdout.bin').read_bytes()==(Q/str(seq)/'body.html').read_bytes()
    selected=S/row['reviewed_input_directory']
    assert selected.resolve().is_relative_to(S.resolve())
    for name in ['spec.json','body.html']:assert (selected/name).read_bytes()==(Q/str(seq)/name).read_bytes()
    resolver=S/row['fresh_native_directory'].replace('-generator-','-resolver-')
    re=read(resolver/'execution.json')
    assert re['exit']==0 and (resolver/'exit.txt').read_bytes()==b'0\n' and not (resolver/'stderr.bin').read_bytes()
    assert re['argv'][1:]==['-B',str(S/'helpers/canonical.py.txt'),'resolve']
    for stream,rp in re['streams'].items():assert pin(resolver/(stream+'.bin'))==rp
    assert (resolver/'stdin.bin').read_bytes()==(Q/str(seq)/'spec.json').read_bytes()
    actual=[{k:r[k] for k in rs[0]} for r in read(resolver/'stdout.bin')]
    assert actual==[r for r in rs if r['seq']==seq]
    native.append(dict(seq=seq,execution=e,resolver_execution=re,root_generator_runs=0))
compat=B/'root-reconciliation-verification';compat.mkdir(exist_ok=False)
shutil.copy2(B/'root-reconciliation-inputs/resolved-spans.json',compat/'resolved-spans.json')
reading=dict(completed='Root read all163 original rationales,22 original omissions,85 final spans/ranges/rationales and13 final omissions; all12 recasts and151 retained identities; complete source313–327; all85 fresh v1 reasons and scoped v2 changes/report; all30 five-ground screens. Read39 critical complete master objects including all HGM/comparative/provenance fields, plus the complete chos bzod corpus witnesses in C05,GIE,SVN.',critical_full_master_objects_read=39,scope='Repeated evidence metadata is bound by exact identity. Truncated portions of judgment output were reread in bounded projections. No repeated linguistic reading of identical duplicate source text is claimed.',conclusions='319 preserves two color compounds with members and four distinct causal pas occurrences, the substantival afflicted things, narrow desire, and source-supported gives forth. rang gi/its is now correctly d5 without changing strings or ranges. 320 preserves shared negative scope, separate result/causative roles and source heading apparatus. 321 preserves the technical mastery-of-phenomena reading against explicitly disclosed conflicting mined metadata, the second path compound rendered elliptically as uninterrupted, and the final Free of desire compound with crossed contained members.',nulls='Zero nulls: distributed, implicit or uncertain exponents remain unbanked with reasons. No supplied predicate or article is invented.',errata='All30 source-category screens refuted; no new register record or allowance. Digital matches do not establish independent publication witnesses.',correction='Full reconciliationv1 and semanticNEEDS_CORRECTION archives retained byte-exact; twelve changed reconciliation paths mapped. Only319/w15 depth changed, and current files carry their actual v2 baseline receipt.')
save(B/'root-reconciliation-reading.json',reading)
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=head,source_origin=proof['source_origin'],prior_root_checks=pin(B/'root-reconciliation-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(Q/'freeze.json'),reading=reading,current_native_evidence=native,limits=['One root intake failure used variant-inclusive matching for declared exact-wylie queries. Failed method/streams preserved; corrected exact-scope intake passed. No source/spec/generator change resulted. First current intake also expected all84 other full review records identical, but the42 source319 records necessarily point to the new scoped native resolver; only that exact versioned locator is now allowed and its actual streams/ranges are verified.','Exact987 original-copy mappings are checked by the version-aware acceptance gate before and after landing.']))
out=dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),page='c5p107',segments=[319,320,321],counts=dict(spans=85,nulls=0,nonnull_d5=56,total_d5=56,d7=14),source_origin=proof['source_origin'],actual_baseline=head,review=pin(S/'review.md'),review_json=pin(S/'review.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(Q/'freeze.json'),read_evidence=reading,semantic_decision=reading['conclusions'],null_decisions=reading['nulls'],errata=reading['errata'],allowances=read(S/'span-head-allow-needed.json'),execution_reuse='All248 original/final ranges independently resolved. Original generations and unchanged320321 validations reused by exact identity; changed319 fresh generator/resolver ran once. Root repeats no individual generator. Aggregate production and fidelity checks follow.',limits='Provisional machine acceptance only. No hgm_gloss promotion, human editorial acceptance, MAIN application, merged runtime or device acceptance.')
save(B/'root-semantic-disposition.json',out)
print(json.dumps({k:out[k] for k in ['verdict','page','counts','review_freeze']},indent=2))
