# Independent review of versioned reviewed-input adapters

**APPROVE. No findings in the scoped change.** The two candidate source files, their preserved snapshots, original source hashes and exact unified diffs were verified byte-for-byte. Reversing only each added selection block makes the entire candidate AST identical to its original, confirming that source, range, count, freeze, hash, original-copy, mode and gate logic is unchanged.

The adapters permit exactly `reviewed-final/{seq}` and, only when `type(review_version) is int` and its value is at least2, `reviewed-final-v{review_version}/{seq}`. Omitted selection retains legacy behavior. The literal allowlist rejects traversal, absolute paths, other sequence/version directories, leading-zero versions, unknown roots and noncanonical separators. Boolean, float, string, null and invalid integer versions cannot authorize a versioned directory. Invalid nonstring path values also fail closed.

**58 isolated cases passed:29 per adapter, including52 expected rejections.** The exact candidate AST loops were compiled and executed against real fixture files and hashes; the registration loop used its actual `unique_object`, `decode`, `pin`, `capture` and `reviewed` functions. The positive current-package test selects corrected319 from `reviewed-final-v2/319` while320/321 retain `reviewed-final/{seq}`. Legacy defaults and an explicit future integer version also work. Selecting stale v1 data for319 fails.

Acceptance rejects mismatched current spec/body hashes and mismatched selected spec/body copies. Registration rejects mismatched current or selected spec bytes, incorrect per-row or frozen spec hashes, and mismatched banked copies. Registration's direct checks remain spec-focused; body validation continues to be performed by its required preceding acceptance stage. This change does not introduce a new registration body read, and this review does not claim one.

No full registration or acceptance entry point ran. All candidate source files and the frozen semantic review remained unchanged; test writes were confined to this independent-review directory. The tests deliberately cover the changed interface and surrounding byte checks rather than performing a production landing or re-testing unrelated registration mutations.

Candidate identities:

- `verify_semantic_acceptance_v2.py`: SHA256 `b1aa955c6b44e214ef94ae106c2209817927e0696d300879b11d7605553fe964`.
- `register_reviewed_page_v7.py`: SHA256 `a5bf59d90af1697680088092e87373cdd3dd8a1939f517d15fc12fa9dba56610`.

Actual evidence: `input-proof.json`, `test-results.json`, `test-summary.json`, and reproducible `run_isolated_tests.py.txt`, with isolated fixtures retained. The reviewed semantic input was freeze `617775c5b7a27cc382a701b6a74100707fde89cef7bcedf99444520e09a85988`.
