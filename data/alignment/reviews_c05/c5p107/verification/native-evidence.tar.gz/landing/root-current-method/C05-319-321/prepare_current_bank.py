"""Prepare current evidence and a proof-derived ledger template; never commit.

Run once only after root approves this exact method and every current production,
fidelity, retention and external reproduction record has passed. All prerequisite
checks precede output creation. No generators, tests, source/worktree writes,
staging or commit closure are performed. Historical fixture trees and relocated
large files remain referenced rather than recopied.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess

B = Path(__file__).resolve().parent
A = B.parent
W = A.parent / 'campaign-worktree'
R = Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through321')
BASE = '91d2c245ddd410894f12653cf3acf0302d488520'
ORIGIN = '49b66f3af9cbb47599bb40286637fc9e683b7cdf'
FREEZE = '617775c5b7a27cc382a701b6a74100707fde89cef7bcedf99444520e09a85988'
RECON = 'bd0d058547e2c6265e1e5b9326191130897bb906484d5960a5ee73ccfa2ea140'
SEQUENCES = [319, 320, 321]
OUTPUTS = {'data/alignment/alignment_full_v1.json', 'data/alignment/alignment_evidence_v1.json'} | {
    'docs/geshe_michael_roach_dictionary' + suffix
    for suffix in ('.html', '.csv', '_reverse.csv', '_by_course.csv', '_changes.csv')}
captured = {}


def pin(path):
    assert path.is_file(), path
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    result = dict(bytes=path.stat().st_size, sha256=digest.hexdigest())
    if path in captured:
        assert captured[path] == result, ('Input changed during preparation', path)
    captured[path] = result
    return result


def read(path):
    pin(path)
    return json.loads(path.read_bytes())


def save(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def caller(directory, expected_exit):
    execution = read(directory / 'execution.json')
    command = read(directory / 'command.json')
    assert execution['exit'] == expected_exit
    assert all(execution[key] == value for key, value in command.items())
    assert (directory / 'exit.txt').read_bytes() == f'{expected_exit}\n'.encode()
    assert execution['recorder_sha256'] == pin(A / 'record_external_step.py')['sha256']
    assert execution['stdin_bytes'] == 0 and (directory / 'stdin.bin').read_bytes() == b''
    for stream in ('stdout', 'stderr'):
        assert pin(directory / f'{stream}.bin') == dict(
            bytes=execution[f'{stream}_bytes'], sha256=execution[f'{stream}_sha256'])
    pin(directory / 'exit.txt')
    pin(directory / 'stdin.bin')
    return execution


def bounded_files(directory):
    assert directory.is_dir() and not directory.is_symlink(), directory
    return sorted(path for path in directory.rglob('*') if path.is_file())


def main():
    # This is a preparation approval, not approval of any commit-closure method.
    approval = read(B / 'bank-preparation-root-review.json')
    assert approval['verdict'] == 'APPROVE_ROOT_CURRENT_BANK_PREPARATION'
    assert approval['methods'] == {'prepare_current_bank.py': pin(B / 'prepare_current_bank.py')}
    assert approval['method_note'] == pin(B / 'bank-preparation-method.md')
    assert approval['reference_diff'] == pin(B / 'bank-preparation-method.diff.txt')
    baseline = read(B / 'baseline.json')
    assert baseline['commit'] == BASE and baseline['course_boundary'] == 318
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == BASE
    frozen = read(B / 'semantic-review/freeze.json')
    meta = read(B / 'semantic-review/review.json')
    reconciled = read(B / 'reconciled/freeze.json')
    assert pin(B / 'semantic-review/freeze.json')['sha256'] == FREEZE
    assert pin(B / 'reconciled/freeze.json')['sha256'] == RECON
    assert frozen['file_count'] == len(frozen['files']) == 546 and len(reconciled['files']) == 392
    assert frozen['verdict'] == frozen['spec_verdict'] == frozen['quality_verdict'] == meta['verdict'] == 'APPROVE'
    assert frozen['open_findings'] == meta['open_findings'] == []
    assert frozen['later_supplied_acceptance_baseline'] == meta['later_supplied_acceptance_baseline'] == BASE
    assert frozen['later_baseline_accepted_through'] == meta['later_baseline_accepted_through'] == 318
    assert frozen['source_origin_git_commit'] == meta['source_origin_git_commit'] == ORIGIN
    assert frozen['initial_review_v1_baseline_receipt'] is None and meta['initial_review_v1_baseline_receipt'] is None
    assert [meta[key] for key in ('total_spans', 'total_nulls', 'total_word_pairs', 'total_d7')] == [85, 0, 56, 14]
    assert [(row['seq'], row['span_count'], row['null_count'], row['word_pair_count'])
            for row in meta['segments']] == [(319, 42, 0, 27), (320, 11, 0, 7), (321, 32, 0, 22)]
    assert [row['reviewed_input_directory'] for row in meta['segments']] == [
        'reviewed-final-v2/319', 'reviewed-final/320', 'reviewed-final/321']
    assert read(B / 'semantic-review/bank-ready-errata.json') == []
    assert read(B / 'semantic-review/span-head-allow-needed.json') == {'pages_c05': {}}
    mappings = read(B / 'semantic-review/original-to-copy-manifest.json')
    assert len(mappings) == 987
    root = read(B / 'root-reconciliation-inputs/proof.json')
    intake = read(B / 'root-reconciliation-intake.json')
    decision = read(B / 'root-semantic-disposition.json')
    assert root['status'] == 'PASS_ROOT_INPUTS' and root['actual_baseline'] == BASE
    assert intake['status'] == 'PASS_ROOT_CURRENT_INTAKE' and intake['baseline'] == BASE
    assert decision['verdict'] == 'APPROVE_ROOT_SEMANTIC_ACCEPTANCE' and decision['actual_baseline'] == BASE
    assert root['source_origin'] == intake['source_origin'] == decision['source_origin'] == ORIGIN
    assert decision['review_freeze'] == pin(B / 'semantic-review/freeze.json')
    assert decision['review_json'] == pin(B / 'semantic-review/review.json')
    assert decision['review'] == pin(B / 'semantic-review/review.md')
    assert decision['reconciliation_freeze'] == pin(B / 'reconciled/freeze.json')
    assert (root['canonical_original_spans'], root['canonical_final_spans'], root['original_omissions']) == (163, 85, 22)
    assert root['root_generator_runs'] == 0 and root['dispositions'] == {'RECAST': 12, 'RETAIN': 151}
    for folder, expected in [('reconciliation-history/v1', (355, '6beabe2726cbdd404577bfa91a22442cf100ee01ee9ed49920cb7d37bec2bf8c')),
                             ('semantic-review-history/v1', (457, '0ffb996a488d9e86396b89173f6f1ce12fad0ff7600d15f7b11c6104b3cb0f97'))]:
        assert len(read(B / folder / 'freeze.json')['files']) == expected[0]
        assert pin(B / folder / 'freeze.json')['sha256'] == expected[1]
        assert root['freezes'][folder] == dict(files=expected[0], sha256=expected[1])
    # Consume the actual successful native records; do not generate anything.
    assert [row['seq'] for row in intake['current_native_evidence']] == SEQUENCES
    for row, proof in zip(meta['segments'], intake['current_native_evidence']):
        directories = [row['fresh_native_directory'],
                       'native/scoped-final-319-resolver-v2' if row['seq'] == 319 else f"native/final-{row['seq']}-resolver-v1"]
        assert proof['root_generator_runs'] == 0
        for name, directory in zip(('execution', 'resolver_execution'), directories):
            path = B / 'semantic-review' / directory
            execution = read(path / 'execution.json')
            assert execution == proof[name] and execution['exit'] == 0
            assert (path / 'exit.txt').read_bytes() == b'0\n'
            for stream in ('stdin', 'stdout', 'stderr'):
                assert pin(path / f'{stream}.bin') == execution['streams'][stream]
            assert execution['streams']['stdin'] == dict(bytes=row['spec_bytes'], sha256=row['spec_sha256'])
        assert proof['execution']['streams']['stdout'] == dict(bytes=row['body_bytes'], sha256=row['body_sha256'])
    acceptance = [read(B / 'landing' / name) for name in
                  ('root-semantic-acceptance-proof.json', 'root-frozen-input-copy-check.json')]
    for proof in acceptance:
        assert proof['head'] == BASE and proof['page'] == 107 and proof['segments'] == SEQUENCES
        assert proof['exact_final_hashes_counts_and_ranges'] is True and proof['original_review_bytes_identical'] is True
        assert proof['manifest_records'] == len(mappings) and proof['manifest'] == mappings
        assert proof['review_sha256'] == decision['review']['sha256']
        assert proof['review_json_sha256'] == decision['review_json']['sha256']
    assert acceptance[0]['landed_bytes_checked'] is False and acceptance[1]['landed_bytes_checked'] is True
    copies = read(B / 'landing/review-copy-and-register-proof.json')
    assert copies['baseline_commit'] == BASE and copies['semantic_files_copied_exactly'] == len(frozen['files']) + 1
    assert copies['added_errata'] == [] and copies['only_reviewed_allowances_added'] == {'pages_c05': {}}
    assert copies['prior_errata_retained'] == 194 and copies['reconciliation_reports_copied_exactly'] == 3
    registration = read(B / 'landing/registration/proof.json')
    assert registration['status'] == 'PASS' and registration['baseline_commit'] == BASE
    assert registration['page'] == 107 and registration['segments'] == SEQUENCES
    assert registration['method'] == pin(A / 'register_reviewed_page_v7.py')
    assert registration['head_allowances'] == {'pages_c05': {}}
    assert set(registration['written_files']) == {'tools/build_alignment_layer.py', 'data/alignment/pages_c05/index.html'}

    # Missing or RUNNING retention/reproduction records fail before any write.
    ret = read(B / 'landing/retention-source-check.json')
    course = read(B / 'landing/course-csv-check.json')
    build = read(B / 'landing/canonical-builds-once.json')
    repro = read(R / 'proof.json')
    assert build['status'] == repro['status'] == 'PASS'
    assert ret['baseline_commit'] == course['baseline_commit'] == build['baseline_commit'] == repro['baseline_commit'] == BASE
    assert ret['segments'] == repro['segments'] == SEQUENCES and ret['page'] == 'c5p107'
    assert build['page'] == 107 and build['first_segment'] == 319
    assert ret['reviewed_analyst_spans'] == meta['total_spans'] and ret['added_links'] == meta['total_spans'] + 3 == 88
    assert ret['added_by_segment'] == {str(row['seq']): row['span_count'] + 1 for row in meta['segments']}
    assert ret['prior_links_retained'] == baseline['full_links'] and ret['full_links'] == ret['prior_links_retained'] + ret['added_links']
    for key in ('review_tuples_and_source_ranges_match', 'source_hashes_unchanged',
                'prior_notes_trees_evidence_and_acip_retained', 'prior_csv_content_and_references_retained', 'navigation_targets_exist'):
        assert ret[key] is True, key
    assert course['all_depths_counts_and_metadata_match_main_csv_refs'] is True
    assert course['course_csv_sha256'] == pin(W / 'docs/geshe_michael_roach_dictionary_by_course.csv')['sha256']
    assert {row['path'] for row in repro['outputs']} == OUTPUTS and len(repro['outputs']) == 7
    assert repro['all_original_inputs_unchanged'] is True and repro['layer_invocations'] == repro['view_invocations'] == 1
    assert len(build['runs']) == len(repro['runs']) == 2 and all(row['exit'] == 0 for row in build['runs'] + repro['runs'])
    for row in repro['outputs']:
        assert row['complete_bytes_equal'] is True
        assert pin(W / row['path']) == {key: row[key] for key in ('bytes', 'sha256')}
        assert row['sha256'] == build['output_sha256'][row['path']]
    for path in ('data/hgm_dictionary_v27_2.json.gz', 'data/full_parallel_corpus_v32.json.gz'):
        assert pin(W / path)['sha256'] == baseline['sha256'][path] == build['output_sha256'][path]
    assert pin(B / 'landing/previous-main-csv-seed.bin') == pin(R / 'seed/previous-main-csv-seed.bin') == repro['seed']
    assert repro['seed']['sha256'] == baseline['sha256']['docs/geshe_michael_roach_dictionary.csv']
    assert all(build['previous_main_csv_seed'][key] == value for key, value in repro['seed'].items())
    assert pin(R / 'evidence/canonical-builds-once.json') == pin(B / 'landing/canonical-builds-once.json')
    assert pin(R / 'evidence/retention-source-check.json') == pin(B / 'landing/retention-source-check.json')
    registered = read(R / 'registered-pages.json')
    assert len(registered) == repro['registered_pages']
    assert sorted(seq for row in registered if row['course'] == 'C05' for seq in row['sequences']) == list(range(1, 322))
    prior_reuse = read(A / 'C05-316-318/compact-reproduction-review/method-review.json')
    assert prior_reuse['verdict'] == 'APPROVE_REUSE_UNCHANGED_REPRODUCTION_METHOD'
    for name in ('reproduce_generated_outputs.py', 'run_reproduction_readonly.py'):
        assert pin(A / name) == prior_reuse['methods'][name] == pin(R / 'method' / (name + '.txt'))

    expected_tests = {'constitution', 'gen_alignment_page', 'alignment_gate_coverage', 'alignment_builder',
                      'dictionary_exports', 'no_broken_words', 'no_split_syllables', 'no_phonetics_in_layer',
                      'no_degenerate_members', 'no_supplied_span_head', 'layer_matches_spine', 'evidence_matches_spine',
                      'errata_quotes_hold', 'view_matches_layer', 'generated_docs_in_sync', 'builder_sees_every_span', 'errata_name_their_witnesses'}
    tests = caller(B / 'ctest-17-caller', 0)
    stdout = (B / 'ctest-17-caller/stdout.bin').read_bytes()
    passed = re.findall(rb'^\s*(\d+)/17 Test\s+#\d+:\s+(\w+)\s+\.{2,}\s+Passed\s+[\d.]+\s+sec\s*$', stdout, re.M)
    assert len(passed) == len(re.findall(rb'^\s*\d+/\d+ Test\s+#', stdout, re.M)) == 17
    assert sorted(int(index) for index, _ in passed) == list(range(1, 18))
    assert {name.decode() for _, name in passed} == expected_tests
    assert any(line in stdout.splitlines() for line in (b'100% tests passed out of 17', b'100% tests passed, 0 tests failed out of 17'))
    timing = re.findall(rb'Total Test time \(real\) =\s*([0-9.]+) sec', stdout)
    assert len(timing) == 1
    for name, run in zip(('build-layer', 'build-view'), build['runs']):
        assert (B / 'landing' / (name + '.exit')).read_bytes() == b'0\n'
        for stream in ('stdout', 'stderr'):
            assert pin(B / 'landing' / (name + '.' + stream)) == dict(bytes=run[stream + '_bytes'], sha256=run[stream + '_sha256'])
    failures = [('root-inputs-caller', 'root-inputs-attempt02-caller', 'failure-disposition.json', 'verify_root_inputs.v1.py.txt'),
                ('root-semantic-intake-caller', 'root-semantic-intake-attempt02-caller', 'semantic-intake-failure-disposition.json', 'accept_root_semantics.v1.py.txt')]
    failure_bindings = []
    for failed, retry, disposition, method in failures:
        old = caller(B / failed, 1)
        current = caller(B / retry, 0)
        record = read(B / 'root-intake-history' / disposition)
        assert record['failed_caller'] == failed and record['retry'] == retry
        failure_bindings.append(dict(failed_caller=failed, retry=retry, failed_execution=old, passing_execution=current,
                                     disposition=record, preserved_method=dict(path=str(B / 'root-intake-history' / method), **pin(B / 'root-intake-history' / method))))
    for name in ('semantic-acceptance-caller', 'land-caller', 'landed-acceptance-caller', 'register-caller',
                 'copy-register-check-caller', 'builders-caller', 'retention-caller', 'course-csv-caller'):
        caller(B / name, 0)

    interface = A / 'versioned-review-interface'
    adapter_approval = read(interface / 'root-approval.json')
    independent = read(interface / 'independent-review/review.json')
    independent_summary = read(interface / 'independent-review/test-summary.json')
    independent_freeze = read(interface / 'independent-review/freeze.json')
    assert adapter_approval['verdict'] == 'APPROVE_ROOT_VERSIONED_INPUT_ADAPTERS'
    assert independent['verdict'] == 'APPROVE' and independent['open_findings'] == []
    assert independent_summary['status'] == 'PASS' and independent_summary['test_count'] == adapter_approval['tests'] == 58
    assert independent_summary['rejections_verified'] == adapter_approval['expected_rejections'] == 52
    assert pin(interface / 'independent-review/freeze.json')['sha256'] == adapter_approval['independent_review_freeze_sha256']
    assert len(independent_freeze['files']) == adapter_approval['independent_frozen_files'] == 1777
    for name, value in adapter_approval['methods'].items():
        assert pin(A / name) == value and independent['candidate_hashes'][name] == value['sha256']
    storage_root = A / 'storage-file-relocation-through318-extra'
    storage = read(storage_root / 'proof.json')
    assert storage['status'] == 'PASS_BYTE_VERIFIED_COMPLETED_FILE_RELOCATION'
    assert storage['records'] == read(storage_root / 'verified-files.json') and len(storage['records']) == 6
    assert storage['relocated_bytes'] == sum(row['bytes'] for row in storage['records'])
    for row in storage['records']:
        original, external = Path(row['original_path']), Path(row['external_path'])
        assert original.is_symlink() and original.resolve() == external.resolve() and external.is_file()
        assert external.stat().st_size == row['bytes'] and stat.S_IMODE(external.stat().st_mode) == row['mode']
        assert os.access(external, os.R_OK)
    storage_caller = caller(A / 'storage-file-relocation-through318-extra-caller', 0)
    assert Path(storage_caller['argv'][2]).name == 'relocate_completed_evidence_318_extra.py'

    # Inventory only bounded current files. Frozen review and old proof trees are already retained.
    names = ('prepare_current_bank.py', 'bank-preparation-method.md', 'bank-preparation-method.diff.txt',
             'bank-preparation-root-review.json', 'verify_root_inputs.py', 'accept_root_semantics.py', 'baseline.json',
             'proposal-baseline.json', 'source.json', 'context.json', 'root-reconciliation-intake.json',
             'root-semantic-disposition.json', 'root-reconciliation-reading.json', 'root-preparation-proof.json',
             'root-preparation-original-rows.json', 'root-lexical-preparation.json', 'root-parallel-preparation.json')
    files = [B / name for name in names]
    files += [A / name for name in ('record_external_step.py', 'verify_semantic_acceptance_v2.py', 'register_reviewed_page_v7.py',
                                   'land_reviewed_page_v2.py', 'verify_review_copy_and_register.py', 'run_reviewed_builders_once.py',
                                   'run_tool_readonly_sqlite.py', 'verify_landed_batch.py', 'verify_course_csv.py',
                                   'reproduce_generated_outputs.py', 'run_reproduction_readonly.py', 'bank_compact_verification.py',
                                   'prepare_review_whitespace_pins_v4.py', 'audit_staged_source_whitespace_v12.py',
                                   'relocate_completed_evidence_318_extra.py')]
    files += [A / 'C05-313-315/whitespace-latin1-independent-review.json']
    for folder in ('root-reconciliation-inputs', 'root-reconciliation-verification', 'root-intake-history',
                   'root-inputs-caller', 'root-inputs-attempt02-caller', 'root-semantic-intake-caller', 'root-semantic-intake-attempt02-caller'):
        files += bounded_files(B / folder)
    files += bounded_files(storage_root) + bounded_files(A / 'storage-file-relocation-through318-extra-caller')
    for name in ('candidate.json', 'root-approval.json', 'verify_semantic_acceptance.py.txt', 'verify_semantic_acceptance_v2.py.txt',
                 'verify_semantic_acceptance_v2.py.diff', 'register_reviewed_page_v6.py.txt', 'register_reviewed_page_v7.py.txt',
                 'register_reviewed_page_v7.py.diff'):
        files.append(interface / name)
    independent_names = ('freeze.json', 'review.md', 'review.json', 'input-proof.json', 'test-results.json', 'test-summary.json', 'run_isolated_tests.py.txt')
    for name in independent_names:
        path = interface / 'independent-review' / name
        if name != 'freeze.json':
            assert pin(path) == independent_freeze['files'][name]
        files.append(path)
    for path in files:
        assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 4 * 1024 * 1024, path
        pin(path)
    white = read(A / 'C05-313-315/whitespace-latin1-independent-review.json')
    assert white['verdict'] == white['pin_preparation_v4']['verdict'] == 'APPROVE'
    assert white['method_sha256'] == pin(A / 'audit_staged_source_whitespace_v12.py')['sha256']
    assert white['pin_preparation_v4']['method_sha256'] == pin(A / 'prepare_review_whitespace_pins_v4.py')['sha256']
    integration = [A / 'integration/through309-root-disposition.json'] + [A / 'integration/through309-current-assessment' / name
                  for name in ('freeze.json', 'review.md', 'assessment.json', 'future-reuse-method.md')]
    integration_refs = [dict(path=str(path), **pin(path)) for path in integration]
    lineage_paths = [B / folder / 'freeze.json' for folder in ('reconciliation-history/v1', 'semantic-review-history/v1')]
    lineage_paths += [B / 'semantic-review' / name for name in ('evidence-version-map.json', 'scoped-v2/reconciliation-reference-supersession.json',
                      'scoped-v2/historical-manifest-rebase-proof.json', 'scoped-v2/review-v1-archive-proof.json')]
    lineage_refs = [dict(path=str(path), **pin(path)) for path in lineage_paths]
    elapsed = (datetime.datetime.fromisoformat(build['finished_at']) - datetime.datetime.fromisoformat(build['started_at'])).total_seconds()
    assert elapsed >= 0
    date = datetime.datetime.fromisoformat(build['finished_at']).date().isoformat()
    per_segment = '; '.join(f"{row['seq']}: {row['span_count']}/{row['null_count']}/{row['word_pair_count']}" for row in meta['segments'])
    entry = f'''

### {date} — independently reviewed C05:319–321; verified coverage321/511

- Accepted {meta['total_spans']} provisional spans, {meta['total_nulls']} nulls, {meta['total_word_pairs']} nonnull depth-5 pairs and {meta['total_d7']} depth-7 members, plus3 source anchors: {ret['added_links']} new links. Per segment {per_segment} (spans/nulls/nonnull d5). {511 - SEQUENCES[-1]} C05 segments remain322–511; C06 waits for complete C05 and C13 stays blocked upstream.
- Immutable source/proposal origin {ORIGIN} through312 remains distinct from actual acceptance @BASE@ through318. Original Tibetan/English freezes contain {root['freezes']['tibetan']['files']}/{root['freezes']['english']['files']} files; current reconciliation392 SHA{RECON}; semantic546 SHA{FREEZE}. Fresh SPEC/QUALITY APPROVE has zero open findings. All {len(mappings)} current original-copy mappings were checked before/after landing; {root['canonical_original_spans']} original dispositions, {root['canonical_final_spans']} final decisions, {root['original_omissions']} original omissions and13 final omissions remain readable. No erratum, supplied-head allowance or hgm_gloss promotion is added.
- Root independently verified {root['canonical_original_spans'] + root['canonical_final_spans']} original/final ranges, {root['sql_queries']} SQL queries, {root['lexical_queries']} lexical queries, {root['complete_master_objects']} complete master objects and {root['complete_corpus_objects']} complete corpus objects. Root's source-specific reading covered {decision['read_evidence']['critical_full_master_objects_read']} critical complete master objects plus the complete source context and semantic decisions. Identity verification does not imply repeated linguistic reading of duplicate metadata.
- {decision['semantic_decision']} {decision['null_decisions']} {decision['errata']}
- Only319/w15 rang gi→its changed from d3 to d5. Full reconciliationv1 (355 frozen files plus freeze) and semantic NEEDS_CORRECTION v1 (457 plus freeze) remain byte-exact with explicit old/current bindings. The current319 input is reviewed-final-v2/319; unchanged320/321 use their retained reviewed-final directories. Six original generations and unchanged320/321 validations are reused by exact code/input/native identity; changed319 fresh generator/resolver each ran once. Root repeated no individual generator. Reconciliation preparation attempt01 and all semantic attempts remain in the frozen review. Two actual root intake failures are preserved with their method versions and real attempt02 passes: exact-wylie queries were first over-expanded to variants, and then unchanged-record equality first rejected the necessary319 native-resolver locator update.
- Versioned acceptancev2/registrationv7 are root-approved at their exact method hashes. The independent interface review passed58 isolated cases with52 expected rejections. Its exact methods, diffs, root approval, review and test results are retained once in a bounded current-method package; the1777-file original proof remains referenced without recopying its fixture tree. Registration body validation remains in the required preceding acceptance gate.
- Aggregate production passed once in {elapsed:.6f}s; all17 named fidelity tests passed in {timing[0].decode()}s. All {ret['prior_links_retained']} prior links and {ret['prior_csv_rows_retained']} prior main-CSV rows, notes, trees, evidence, ACIP and references are retained. Current {ret['full_links']} links, {ret['null_exponents']} nulls, {ret['evidence_headwords']} heads, {ret['evidence_pairs']} evidence pairs, {ret['current_csv_rows']} main-CSV rows and {course['current_course_depth_groups']} course-depth groups come from actual passing records. Seven whole outputs reproduce exactly once from {repro['registered_pages']} registered pages and the actual {repro['seed']['bytes']}-byte incoming CSV seed SHA{repro['seed']['sha256']}. External proof: {R / 'proof.json'}. Source/master/corpus bytes remain unchanged.
- Private DATA @DATA@ is based on @BASE@; the separately validated closure supplies its completion time @UTC@. Exact staged mode/blob/tree, source-whitespace audit, Git parent/tree and identical append-only three-ledger checks remain separate required closure gates. This prepared template neither stages nor commits and does not preclaim those gate results. Production/fidelity/retention/reproduction establish verified coverage321; commit closure is separate.
- Six additional completed historical proof files ({storage['relocated_bytes']} bytes) were relocated to the external evidence drive. Their original paths remain readable symlinks with the recorded target sizes and modes; the original relocation proof supplies the completed byte verification. The exact small passing proof, six-record inventory, helper and actual caller streams are retained. Packaging does not recopy or rehash those large files. The earlier three-file relocation is historical evidence already banked at318. Current source, master, worktree and active evidence remain unchanged; the external drive remains required.
- Isolated desktop-consumable outputs are verified through321. Existing through309 MAIN applicability evidence is referenced once; no new321 MAIN applicability or runtime claim is made. MAIN remains unapplied. Phone remains FAILED_UNACCEPTED for four inherited C01 mappings; no installation, and historical installed through171 is unchanged. Rendering/QSettings/runtime,42 depth shortfalls and28 trim calls remain open. No paid generation, release or external-account action occurred.
'''
    assert set(re.findall(r'@[A-Z0-9_]+@', entry)) == {'@BASE@', '@DATA@', '@UTC@'}
    destination = B / 'landing/root-current-method'
    reproduction_review = B / 'compact-reproduction-review'
    ledger = B / 'landing/root-ledger-entry-template.md'
    assert not destination.exists() and not reproduction_review.exists() and not ledger.exists()
    # All actual prerequisite records and output hashes have passed before writing.
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == BASE
    for path, identity in list(captured.items()):
        assert pin(path) == identity, path
    prerequisite_pins = dict(captured)
    destination.mkdir()
    records = []
    for path in sorted(set(files)):
        target = destination / path.relative_to(A)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        assert pin(target) == pin(path)
        records.append(dict(original=str(path), copy=str(target.relative_to(destination)), **pin(path)))
    save(destination / 'manifest.json', records)
    save(destination / 'root-intake-failure-bindings.json', failure_bindings)
    save(destination / 'versioned-review-interface-reference.json', dict(
        root_approval=pin(interface / 'root-approval.json'), original_review=str(interface / 'independent-review'),
        original_freeze=pin(interface / 'independent-review/freeze.json'), original_frozen_files=1777,
        retained_current_proof_files=list(independent_names), tests=58, expected_rejections=52,
        scope='Exact bounded methods/diffs/approval/test proofs copied once. Repeated fixture trees are referenced by the original verified freeze and are not recopied.'))
    save(destination / 'storage-relocation-reference.json', dict(
        proof=pin(storage_root / 'proof.json'), records=storage['records'], limits=storage['limits'],
        scope='Only the six-file extra relocation small proof/inventory/method/caller is copied. Large targets are stat/readability checked and bound to prior completed byte verification, not recopied or rehashed.'))
    save(destination / 'version-lineage-reference.json', dict(references=lineage_refs, source_origin=ORIGIN,
        actual_baseline=BASE, initial_v1_baseline_receipt=None,
        scope='Existing frozen semantic review already preserves all original, corrective and failed-attempt evidence. Both complete v1 archives remain referenced; no historical proof tree is recopied.'))
    save(destination / 'integration-reference.json', dict(references=integration_refs,
        scope='Existing through309 MAIN assessment only; no current MAIN application, runtime or device assessment.'))
    reproduction_review.mkdir()
    save(reproduction_review / 'method-review.json', dict(
        verdict='APPROVE_REUSE_UNCHANGED_REPRODUCTION_METHOD', root_preparation_approval=pin(B / 'bank-preparation-root-review.json'),
        methods={name: pin(A / name) for name in ('reproduce_generated_outputs.py', 'run_reproduction_readonly.py')},
        prior_method_review=str(A / 'C05-316-318/compact-reproduction-review/method-review.json'), current_proof=str(R / 'proof.json'),
        judgment='Actual passing current retention/reproduction, unchanged approved methods, seven whole-output equality, actual incoming seed, completed native runs and unchanged inputs were checked. No successful native work was repeated for packaging.',
        limits='Production/source fidelity only; no MAIN runtime or device acceptance.'))
    ledger.write_text(entry)
    save(destination / 'preparation-proof.json', dict(
        status='PREPARED_CURRENT_BANK_INPUTS', baseline_commit=BASE, source_origin=ORIGIN, segments=SEQUENCES,
        method=pin(B / 'prepare_current_bank.py'), root_approval=pin(B / 'bank-preparation-root-review.json'),
        ledger=pin(ledger), method_files=len(records), retained_semantic_copies=len(mappings),
        actual_totals={key: ret[key] for key in ('full_links', 'null_exponents', 'evidence_headwords', 'evidence_pairs', 'current_csv_rows')},
        input_pins=[dict(path=str(path), **identity) for path, identity in sorted(prerequisite_pins.items())],
        production_reproduction_proof=dict(path=str(R / 'proof.json'), **pin(R / 'proof.json')),
        staging_performed=False, closure_performed=False, worktree_writes=False,
        limits='Preparation output only; later staging, audit and commit closure are neither executed nor claimed.'))
    print(json.dumps(dict(status='PREPARED',method_files=len(records), ledger_bytes=ledger.stat().st_size)))


if __name__ == '__main__':
    main()
