"""Write an explicit unapproved P-profile plan, or bind it after every input exists."""
from pathlib import Path
import argparse
import json
from bind_config import bind
from closure import SCHEMA, save

PROFILE_FILES = {
 'profile_original_generations':'semantic-review/original-generator-identity-reuse.json',
 'profile_version_map':'semantic-review/evidence-version-map.json',
 'profile_prior_review_freeze':'semantic-review-history/v1/freeze.json',
 'profile_prior_reconciliation_freeze':'reconciliation-history/v1/freeze.json',
 'profile_manifest_rebase':'semantic-review/scoped-v2/historical-manifest-rebase-proof.json',
 'profile_actual_baseline_receipt':'semantic-review/scoped-v2/actual-baseline-receipt.json',
 'profile_supersession_map':'reconciled/correction-v2/supersession-map.json',
 'profile_correction_proof':'reconciled/correction-v2/proof.json',
 'profile_fresh319_validation':'semantic-review/scoped-v2/fresh319-validation-proof.json'}
BASE_FILES = {
 'baseline':'baseline.json','proposal_baseline':'proposal-baseline.json','semantic_freeze':'semantic-review/freeze.json',
 'reconciliation_freeze':'reconciled/freeze.json','review':'semantic-review/review.json',
 'original_copies':'semantic-review/original-to-copy-manifest.json','root_inputs':'root-reconciliation-inputs/proof.json',
 'root_intake':'root-reconciliation-intake.json','root_disposition':'root-semantic-disposition.json',
 'errata':'semantic-review/bank-ready-errata.json','head_allowances':'semantic-review/span-head-allow-needed.json'}
ROLES = dict(root_inputs='root-inputs-attempt02-caller',semantic_acceptance='semantic-acceptance-caller',
 root_intake='root-semantic-intake-attempt02-caller',landing='land-caller',landed_semantic_acceptance='landed-acceptance-caller',
 registration='register-caller',registered_copy='copy-register-check-caller',builders='builders-caller',tests='ctest-17-caller',
 retention='retention-caller',course_csv='course-csv-caller',reproduction='reproduction-caller',bank='compact-bank-caller',
 stage='stage-data-caller',whitespace='whitespace-audit-caller')
FAILURES={
 'root-inputs-caller':dict(exit=1,reason='Actual original root input failure used variant-inclusive matching for a declared exact-wylie query; unchanged-source attempt02 passed.'),
 'root-semantic-intake-caller':dict(exit=1,reason='Actual initial intake assumed all other review records identical; the42 unchanged source319 records require the explicitly versioned resolver locator. Attempt02 passed after exact typed correction.')}


def plan(batch,reproduction,profile_only=False):
    b=Path(batch).resolve();a=b.parent;w=a.parent/'campaign-worktree';r=Path(reproduction).resolve()
    review=json.loads((b/'semantic-review/review.json').read_bytes());page=review['segments'][-1]['seq']//3
    v=w/f'data/alignment/reviews_c05/c5p{page}/verification'
    paths={k:str(b/p) for k,p in dict(BASE_FILES,**PROFILE_FILES).items()}
    paths['profile_method']=str(Path(__file__).with_name('p_profile.py'))
    paths['recorder']=str(a/'record_external_step.py')
    if not profile_only:
        paths.update({k:str(b/p) for k,p in {
         'build':'landing/canonical-builds-once.json','retention':'landing/retention-source-check.json',
         'course_csv':'landing/course-csv-check.json','registration':'landing/registration/proof.json',
         'whitespace':'landing/source-whitespace-proof.json','whitespace_stdout':'landing/staged-diff-check.stdout',
         'whitespace_stderr':'landing/staged-diff-check.stderr','whitespace_exit':'landing/staged-diff-check.exit',
         'whitespace_preparation':'landing/whitespace-pin-preparation.json','whitespace_pins':'landing/review-whitespace-exact-pins.json',
         'ledger_template':'landing/root-ledger-entry-template.md'}.items()})
        paths.update({k:str(v/p) for k,p in {'bank_summary':'summary.json','bank_archive':'native-evidence.tar.gz',
         'bank_manifest':'archive-manifest.json','post_bank_archive':'post-bank-evidence.tar.gz','post_bank_manifest':'post-bank-manifest.json'}.items()})
        paths.update({k:str(a/p) for k,p in {'registration_method':'register_reviewed_page_v7.py',
         'whitespace_method':'audit_staged_source_whitespace_v12.py','whitespace_pin_method':'prepare_review_whitespace_pins_v4.py',
         'whitespace_method_review':'C05-313-315/whitespace-latin1-independent-review.json'}.items()})
        paths['reproduction_proof']=str(r/'proof.json');paths['reproduction_inputs']=str(r/'input-manifest.json')
    callers={p.name:str(p) for p in sorted(b.glob('*-caller')) if p.name!='compact-closure-caller'}
    return dict(schema=SCHEMA,repository=str(w),batch=str(b),reproduction=str(r),artifacts=paths,callers=callers,
         required_roles=ROLES,historical_failures=FAILURES,active_caller='compact-closure-caller',post_freeze=[],retrospective=None)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--batch',required=True);p.add_argument('--reproduction',required=True)
    p.add_argument('--output',required=True);p.add_argument('--bind',action='store_true');p.add_argument('--profile-only',action='store_true')
    a=p.parse_args();d=plan(a.batch,a.reproduction,a.profile_only)
    save(a.output,bind(d) if a.bind else d)
