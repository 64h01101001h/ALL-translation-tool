"""CANDIDATE_NOT_ADOPTED: explicit C05 scoped review-v2 profile over closure v2.

Consumes original evidence schemas without adding aliases or changing any proof.
The generic closure's production/caller/archive/index/ledger gates remain intact.
"""
from pathlib import Path
import argparse
import copy
import json
from closure import Closure, Invalid, exact, need, pin, read, relpath, save, selected, sha, under


class PClosure(Closure):
    def reviewed_spec_path(self, row):
        directory = relpath(row['reviewed_input_directory'])
        version=self.doc('review')['review_version']
        need(type(version) is int and version == 2, 'P explicit integer review version')
        need(directory in {f"reviewed-final/{row['seq']}",f"reviewed-final-v{version}/{row['seq']}"},
             'Approved reviewed-input directory contract')
        return under(self.b/'semantic-review', directory+'/spec.json')

    def reconciliation_total(self, reconciliation, count_name, legacy_field):
        need(reconciliation['version'] == 2, 'Explicit reconciliation version2 required')
        return reconciliation['counts'][{'spans':'spans','nulls':'nulls','nonnull_d5':'nonnull_d5','d7':'d7'}[count_name]]

    def verify_root_inputs(self, root, proposal, sequences):
        need(root['status'] == 'PASS_ROOT_INPUTS' and root['actual_baseline'] == self.base
             and root['source_origin'] == proposal['commit'], 'P exact root input/source baseline')
        need(root['root_generator_runs'] == 0 and root['canonical_final_spans'] == self.totals['spans'], 'P root final ranges')
        originals = self.doc('profile_original_generations')
        need(len(originals) == 2*len(sequences) and
             {(r['angle'],r['seq']) for r in originals} == {(a,s) for a in ('tibetan','english') for s in sequences}, 'P exact six original generations')
        original_spans = 0
        checked_sources = set()
        for row in originals:
            native = Path(row['native_directory'])
            need(native.is_relative_to(self.b/row['angle']), 'Original native directory scope')
            execution = row['execution']; self.native_execution(native, execution)
            helper = Path(execution['argv'][-1]); exact(helper, row['helper_identity'])
            stdin = (native/'stdin.bin').read_bytes()
            spec = json.loads(stdin); need(spec['course'] == 'C05' and len(spec['segments']) == 1
                and spec['segments'][0]['seq'] == row['seq'], 'Original native spec identity')
            original_spans += len(spec['segments'][0]['spans'])
            for dep in row['canonical_dependencies']:
                raw = exact(under(self.b/row['angle'], dep['path']), dep)
                need(dep['git_object'].startswith(proposal['commit']+':'), 'Native dependency source origin')
                need(self.git('show', dep['git_object']) == raw, 'Native dependency Git identity')
            for source in row['sources']:
                key = (source['path'],source['bytes'],source['sha256'])
                if key not in checked_sources:
                    exact(source['path'],source); checked_sources.add(key)
        need(original_spans == root['canonical_original_spans'], 'P exact original range/spec count')

    def native_execution(self, directory, execution):
        need(set(p.name for p in directory.iterdir()) == {'execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt'}, 'P actual five-file native inventory')
        need(read(directory/'execution.json') == execution and execution['exit'] == 0, 'P actual native PASS')
        need((directory/'exit.txt').read_bytes() == b'0\n', 'P native exit bytes')
        for stream in ('stdin','stdout','stderr'):
            exact(directory/(stream+'.bin'),execution['streams'][stream])

    def profile_gate(self, root, intake, decision, frozen, review, reconciliation):
        need(frozen['review_version'] == review['review_version'] == 2, 'P review-version identity')
        need(self.c['post_freeze'] == [] and 'exclusions' not in frozen, 'No invented P completion-log exclusion')
        version = self.doc('profile_version_map')
        need(version['review_version'] == 2 and
             version['current_final_inputs'] == {str(r['seq']):r['reviewed_input_directory'] for r in review['segments']}, 'P versioned final input map')
        need(reconciliation['counts']['d5_total'] == self.totals['total_d5'], 'P total depth5 count')
        need(reconciliation['later_acceptance_baseline_consumed'] == self.base and
             reconciliation['original_v1_later_acceptance_baseline_consumed'] is None, 'P current/original baseline distinction')
        receipt = self.doc('profile_actual_baseline_receipt')
        need(receipt['status'] == 'VERIFIED' and receipt['actual_git_head'] == self.base
             and receipt['baseline_identity'] == self.checked['baseline'] and receipt['received_for_review_version'] == 2
             and receipt['initial_review_v1_baseline_receipt'] is None, 'P actual review-v2 baseline receipt')
        need(review['actual_through318_baseline_receipt'] == 'scoped-v2/actual-baseline-receipt.json', 'P explicit baseline receipt locator')
        need(receipt['source_origin_git_commit'] == decision['source_origin'] and receipt['accepted_through'] == self.seqs[0]-1, 'P origin/acceptance receipts')
        history = Path(version['historical_review_archive']); old_rec_root=Path(version['historical_reconciliation_archive'])
        need(history == self.b/'semantic-review-history/v1' and old_rec_root == self.b/'reconciliation-history/v1', 'P history scope')
        old_review = self.frozen('profile_prior_review_freeze', history)
        old_rec = self.frozen('profile_prior_reconciliation_freeze', old_rec_root)
        need(old_review['verdict'] == 'NEEDS_CORRECTION', 'P preserves prior unapproved review')
        need(frozen['previous_review_freeze_sha256'] == review['previous_review_freeze_sha256'] == self.checked['profile_prior_review_freeze']['sha256'], 'P review freeze lineage')
        supersedes = reconciliation['supersedes']; mapping = self.doc('profile_supersession_map')
        need(supersedes['freeze_sha256'] == mapping['prior_freeze_sha256'] == self.checked['profile_prior_reconciliation_freeze']['sha256'], 'P reconciliation freeze lineage')
        need(root['freezes']['reconciled'] == {'files':len(reconciliation['files']),'sha256':self.checked['reconciliation_freeze']['sha256']}, 'P root current reconciliation binding')
        for name, old, key in [('reconciliation-history/v1',old_rec,'profile_prior_reconciliation_freeze'),
                               ('semantic-review-history/v1',old_review,'profile_prior_review_freeze')]:
            need(root['freezes'][name] == {'files':len(old['files']),'sha256':self.checked[key]['sha256']}, 'P root history binding')
        prior_names=set(old_rec['files'])|{'freeze.json'}
        actual_changed=set()
        for relative in prior_names:
            before=(old_rec_root/relative).read_bytes(); after=(self.b/'reconciled'/relative).read_bytes()
            if before != after: actual_changed.add(relative)
        need(actual_changed == {r['relative_path'] for r in mapping['changed_original_paths']}, 'P complete changed-path map')
        for row in mapping['changed_original_paths']:
            exact(row['archived_path'],row['old_identity'])
            if row['relative_path'] == 'freeze.json':
                need(row['current_identity'] == 'See the v2 freeze hash returned separately; embedding its own hash would be recursive.', 'P freeze self-reference contract')
            else:
                exact(row['old_path'],row['current_identity'])
        need(set(mapping['unchanged_original_paths']) == prior_names-actual_changed, 'P complete unchanged-path map')
        # The historical manifests remain byte-exact; only verified-original
        # references in a separate proof map resolve changed reconciliation paths.
        for group in self.doc('profile_manifest_rebase'):
            manifest = json.loads(exact(group['manifest'],group['identity']))
            need(len(manifest) == len(group['records']), 'P historical manifest coverage')
            for i,(original,binding) in enumerate(zip(manifest,group['records'])):
                need(binding['record_index'] == i and binding['historical_original'] == original['original']
                     and binding['copy'] == original['copy'] and binding['identity'] == selected(original), 'P historical manifest binding')
                if 'original_git_commit' in original:
                    raw=self.git('show',original['original_git_commit']+':'+relpath(original['repository_relative_path']))
                    need(pin(raw)==binding['identity'], 'P immutable historical original')
                else:
                    raw=exact(binding['verified_original'],binding['identity'])
                need(raw == exact(under(history,original['copy']),original), 'P historical copy identity')
        correction=self.doc('profile_correction_proof')
        need(correction['status'] == 'PASS' and correction['later_acceptance_baseline_consumed'] == self.base, 'P correction PASS')
        need(correction['current_counts'] == reconciliation['counts'], 'P correction counts')
        need(correction['all_other_spec_values_identical'] is True and correction['unchanged320321_all_segment_files_and_final_native_proofs'] is True, 'P bounded correction scope')
        change=correction['changed_alignment']; need(len(change)==1, 'P one scoped correction')
        changed=change[0]; need(changed['old_d']==3 and changed['new_d']==5, 'P supported depth correction')
        old_spec=read(old_rec_root/f"{changed['seq']}/spec.json")
        new_spec=read(self.b/f"reconciled/{changed['seq']}/spec.json")
        expected=copy.deepcopy(old_spec)
        spans=[s for g in expected['segments'] for s in g['spans'] if s['id']==changed['id']]
        need(len(spans)==1 and spans[0]['d']==changed['old_d'] and spans[0]['tib']==changed['tib'] and spans[0]['eng']==changed['eng'], 'P original corrected span')
        spans[0]['d']=changed['new_d']; need(expected==new_spec, 'P only specified depth changes')
        need(len(intake['current_native_evidence']) == len(self.seqs) and [r['seq'] for r in intake['current_native_evidence']] == self.seqs, 'P three actual current native records')
        for row,native in zip(review['segments'],intake['current_native_evidence']):
            need(native['root_generator_runs']==0, 'P root generation reuse')
            generator=relpath(row['fresh_native_directory']); need(generator.count('-generator-')==1, 'P explicit generator locator')
            resolver=generator.replace('-generator-','-resolver-')
            self.native_execution(under(self.b/'semantic-review',generator),native['execution'])
            self.native_execution(under(self.b/'semantic-review',resolver),native['resolver_execution'])
            need(native['execution']['streams']['stdin'] == {'bytes':row['spec_bytes'],'sha256':row['spec_sha256']}
                 and native['execution']['streams']['stdout'] == {'bytes':row['body_bytes'],'sha256':row['body_sha256']}, 'P current native/spec/body identity')
            need(native['resolver_execution']['streams']['stdin'] == native['execution']['streams']['stdin'], 'P resolver exact current spec')
        fresh=self.doc('profile_fresh319_validation')
        need(fresh['status']=='PASS' and fresh['fresh_generator_runs']==fresh['fresh_resolver_runs']==1
             and fresh['no_original_or320321_generator_or_resolver_repeated'] is True, 'P scoped fresh native PASS')

    def approval(self, receipt):
        d=read(receipt)
        need(d['profile_method'] == pin(Path(__file__).read_bytes()), 'P exact profile method approval required')
        super().approval(receipt)
        (self.o/'executed-profile.py.txt').write_bytes(Path(__file__).read_bytes())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('staged','execute'))
    p.add_argument('--config',required=True);p.add_argument('--root-review',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();run=PClosure(a.config,a.output,retrospective=False)
    try:
        run.approval(a.root_review)
        if a.mode=='execute': result=run.execute()
        else: result=dict(run.verify(),status='PASS_P_LIVE_STAGED_VERIFICATION',tree=run.staged())
        save(run.o/'proof.json',result);print(json.dumps(result,indent=2))
    except (Invalid,KeyError,OSError,ValueError) as exc:
        save(run.o/'failure.json',{'status':'FAIL_CLOSED','error':str(exc),'mode':a.mode});raise


if __name__=='__main__':main()
