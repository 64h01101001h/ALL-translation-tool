# Independent successor review

**PASS for the six-line R1–R3 method correction and bounded mutation lane. P319–321 remains unsupported by this method's current proof profile; no real P config or closure is approved here.** Frozen v1 and its NEEDS_CORRECTION verdict remain unchanged.

Reviewed successor freeze: `d872bf80f23a627fd170a6161d43e59dc177a160941c582bcd80371931a92ce4`. All1488 frozen files and the five external reference pins were independently checked. `closure.py` is39,102 bytes, SHA256 `b59405f1801f49ad4d6c785df37f01b9bd713baba45d040440841219d706a1c7`. The exact diff contains six added lines and zero removed lines. The prior complete static review remains applicable to unchanged code; this review read the complete delta, targeted regressions, actual-Git harness, successor README and recorded outcomes.

## R1–R3 are closed

- **R1 closed:** reproduction requires exactly two native records before entering the named layer/view loop. The passing two-run control remains;0,1 and3 records are rejected.
- **R2 closed:** every explicitly pinned artifact addressed inside the worktree also enters `work_identity`. The final staged gate rejects changed archive/summary bytes even when they match a newly staged blob. This does not change the explicit external source contract.
- **R3 closed:** unknown placeholder names are rejected before DATA commit or ledger append. Uppercase, lowercase and numbered names are covered; required DATA/BASE/UTC placeholders and existing whitespace checks remain.

The author bank contains23 actual passing unit tests:18 inherited tests and five targeted regression tests. The independent reviewer reran those five targeted tests with all temporary fixtures under this review directory; they passed with actual native streams. That is five reviewer reruns, not five newly authored tests or a new campaign CTest pass. The test dependency on the prior reviewer's exact fixture function is pinned and its AST selection was inspected.

## Actual synthetic Git acceptance and recovery

The author ran the real `execute`, `staged` and `git` methods in four tiny repositories under the candidate directory. The full verifier was explicitly stubbed as `SYNTHETIC_EVIDENCE_NOT_PRODUCTION`, and no approval receipt was fabricated. The four cases establish successful DATA/DOCS commits, unknown-placeholder refusal before DATA, changed-artifact refusal before DATA, and an actual DOCS pre-commit-hook failure after DATA followed by explicit manual recovery without rerunning closure.

The reviewer read the full harness, byte-verified every recorded native command/stdin/stdout/stderr/exit, and independently inspected the resulting repositories using read-only Git commands. The checks confirm actual DATA parent/tree against the accepted index, unchanged preexisting ledger content, three identical appended entries, DOCS parent/scope, clean tracked state, and the untracked fixture's path and bytes. Both refused cases retain only their baseline commit and unchanged ledger preimages. The recorded failure checkpoint binds the already-created DATA commit, exact ledger entry and staged ledger paths; the recovered DOCS commit has the correct parent and content. Full source/semantic/production verification was not newly exercised by these mutation tests.

Two actual preparation failures remain honestly preserved. The first synthetic harness attempt stopped before DATA on its own trailing whitespace; only the harness was corrected and rerun. The successor's attempted historical318 verification stopped at the unchanged current-worktree CSV check after root advanced P. That refusal is neither a historical PASS nor a campaign fidelity failure; no gate was relaxed or worktree reset to manufacture a pass. The earlier v1 historical PASS applies to its recorded earlier checkout state. A reviewer read-only lookup initially used nonexistent `live-probes-attempt02/proof.json`; it was corrected to the documented `summary.json` and is not represented as a method/test failure.

## Adoption boundary and minimum next work

The three-fix successor can replace bespoke closure mechanics for its supported, strictly validated interface after root approves the exact code, actual final config and complete ledger draft. Each real run must still execute every current source, root/fresh semantic, native,17-test, seven-output, seed/retention, bank/archive, whitespace, stage/tree and final ledger/state gate. This review supplies method acceptance only. It does not provide a root approval receipt or a semantic, integration, release or live-closure approval.

Current P is an explicit different interface: versioned319 selection, nested reconciliation counts, root `actual_baseline`/`freezes` fields, current native records and archived-v1 lineage. The current generic code still rejects those shapes. [P-profile-requirements.md](P-profile-requirements.md) gives the minimum concrete adaptation; it must be separately reviewed, derive counts from current files and preserve the already root-approved acceptance/registration selector contract. Then construct and review a real P config and ledger draft bound to actual through318 baseline. Do not rename old proof fields, fabricate native-count aliases, default to historical319 or relax the existing schema checks.
