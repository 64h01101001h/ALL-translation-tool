"""Root checks existing frozen captures; no query, generation or resolution."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys
B=Path('/Users/adamderickandrade/Documents/ChatGPT/Geshe Michael Roach Tib _ Eng Alignment/campaign-artifacts/C05-364-366')
W=B.parent.parent/'campaign-worktree'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base,origin=read(B/'baseline.json'),read(B/'proposal-baseline.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()==base['commit']=='1be02f91d0c7546f4997d25cafd19c976ba4db3e'
assert base['course_boundary']==363 and origin['course_boundary']==357
inventories={}
for angle in ('tibetan','english','reconciled'):
    f=B/angle/'freeze.json';rows=read(f)['files']
    for rel,expected in rows.items():assert pin(f.parent/rel)==expected,rel
    inventories[angle]=dict(freeze=pin(f),files=len(rows))
assert len(sys.argv)==2 and inventories['reconciled']['freeze']['sha256']==sys.argv[1]
for item in origin['source_pins'].values():
    assert pin(Path(item['path']))=={k:item[k] for k in ('bytes','sha256')}
source={r['seq']:r for r in read(B/'source.json')}
captures=[];resolved=[];original_spans=0
for angle in ('tibetan','english','reconciled'):
    for seq in range(364,367):
        folder=B/angle/str(seq);spans=read(folder/'spec.json')['segments'][0]['spans']
        if angle!='reconciled':original_spans+=len(spans)
        for mode in ('generator','resolver'):
            native=B/angle/'native'/f'{seq}-{mode}-v1'
            ex=read(native/'execution.json')
            assert ex['exit']==0 and (native/'exit.txt').read_text().strip()=='0'
            assert (native/'stderr.bin').read_bytes()==b''
            for stream in ('stdin','stdout','stderr'):
                e=ex['streams'][stream] if 'streams'in ex else ex[stream]
                assert pin(native/(stream+'.bin'))=={k:e[k]for k in('bytes','sha256')}
            assert (native/'stdin.bin').read_bytes()==(folder/'spec.json').read_bytes()
            if mode=='generator':assert (native/'stdout.bin').read_bytes()==(folder/'body.html').read_bytes()
            else:
                rows=read(native/'stdout.bin');assert len(rows)==len(spans)
                for sp,row in zip(spans,rows):
                    assert all(sp[k]==row[k]for k in('id','d','tib','eng'))and row['seq']==seq
                    for field,lang in(('tib','wylie'),('eng','english')):
                        extent=row[field+'_range']
                        if row[field]is None:assert extent is None
                        else:assert source[seq][lang][extent[0]:extent[1]]==row[field]
                    if angle=='reconciled':resolved.append({k:row[k]for k in('seq','id','d','tib','eng','tib_range','eng_range')})
                if angle=='reconciled':assert rows==read(folder/'resolved-ranges.json')
            captures.append(dict(angle=angle,seq=seq,mode=mode,path=str(native),execution=pin(native/'execution.json')))
assert original_spans==135 and len(resolved)==70
for mode in('generator','resolver'):
    assert len({x['execution']['sha256']for x in captures if x['mode']==mode})==8
    a=B/'english/native'/f'365-{mode}-v1';b=B/'reconciled/native'/f'365-{mode}-v1'
    for name in('execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt'):
        assert (a/name).read_bytes()==(b/name).read_bytes()
assert (B/'english/365/spec.json').read_bytes()==(B/'reconciled/365/spec.json').read_bytes()
assert sum(inventories[a]['files'] for a in ('english','tibetan'))==243
choices=read(B/'root-reconciliation-decisions.json')
assert pin(B/'root-reconciliation-decisions.json')==dict(bytes=34675,sha256='4724e72c779e0711059107a0bcfe29c416ccd9442247c75bd8719733521d8bd4')
assert choices['source_origin']==origin['commit'] and choices['actual_baseline']==base['commit']
expected=[]
for item in choices['selected_original_items']:
    seq=item['seq'];angle=item['original_angle'];sid=item['original_id'];selected_id=item['selected_id']
    originals=read(B/angle/str(seq)/'spec.json')['segments'][0]['spans']
    matches=[sp for sp in originals if sp['id']==sid];assert len(matches)==1
    sp=dict(matches[0]);sp['id']=selected_id;assert sp==item['span']
    expected.append(dict(seq=seq,**{k:sp[k]for k in('id','d','tib','eng')},tib_range=item['tib_range'],eng_range=item['eng_range']))
assert resolved==expected
questions=[dict(angle='english',path='english/364/errata-review.json',field='source_questions',index=0,original=read(B/'english/364/errata-review.json')['source_questions'][0])]
assert len(read(B/'english/364/errata-review.json')['source_questions'])==1
save(B/'root-reconciliation-verification/resolved-spans.json',resolved)
proof=dict(status='PASS_ROOT_INPUTS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 baseline=base['commit'],source_origin=origin['commit'],root_generator_runs=0,root_resolver_runs=0,
 verified_native_generations=8,verified_native_resolvers=8,
 unique_original_generations=6,unique_original_resolvers=6,reconciler_generations=2,reconciler_resolvers=2,reused_english_pairs=1,
 count_scope='Nine selected capture views per kind contain eight unique executions: six originals plus changed364/366 pairs; unchanged English365 pair is copied byte-for-byte, not rerun.',
 historical_successful_native_captures=[],inventories=inventories,native_captures=captures,
 original_spans=135,final_spans=70,original_frozen_members=243,original_source_questions=questions,root_choices=pin(B/'root-reconciliation-decisions.json'),method=pin(Path(__file__)),
 limits='Exact existing native/source identities only; no semantic acceptance or native rerun.')
save(B/'root-current-inputs/proof.json',proof)
print(json.dumps(dict(status=proof['status'],selected_views_per_kind=9,unique_executions_per_kind=8,original_spans=135,final_spans=70)))
