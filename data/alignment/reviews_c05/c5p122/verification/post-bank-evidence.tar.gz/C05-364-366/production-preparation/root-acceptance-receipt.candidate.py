"""Prepare root acceptance from the future exact independent review; not run by author.

Usage (root only, after actual reading): root-acceptance-receipt.py REVIEW_FREEZE_SHA256
Existing receipt adapted to exact K selected_id/root choices and empty-errata policy; root executes only after actual complete final reading.
"""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path('/Users/adamderickandrade/Documents/ChatGPT/Geshe Michael Roach Tib _ Eng Alignment/campaign-artifacts/C05-364-366');S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert (B/'root-final-review-reading.json').is_file() and (B/'root-assembled-reading.json').is_file()
assert pin(B/'root-reconciliation-decisions.json')==dict(bytes=34675,sha256='4724e72c779e0711059107a0bcfe29c416ccd9442247c75bd8719733521d8bd4')
choices=read(B/'root-reconciliation-decisions.json')
assert choices['expected']==dict(total_spans=70,segments={'364':31,'365':10,'366':29},total_nulls=1,total_word_pairs=42,total_d5=42,total_d7=9,proposed_errata=0)
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
    assert obj['source_origin_git_commit']=='e4da4c94f59f4af61de90fde63127890130c5902'
    assert obj['later_supplied_acceptance_baseline']=='1be02f91d0c7546f4997d25cafd19c976ba4db3e'
    assert obj['later_baseline_accepted_through']==363
    assert [obj[k] for k in ('total_spans','total_nulls','total_word_pairs','total_d7')]==[70,1,42,9]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert base==choices['actual_baseline']=='1be02f91d0c7546f4997d25cafd19c976ba4db3e'
assert origin==choices['source_origin']=='e4da4c94f59f4af61de90fde63127890130c5902'
inputs=read(B/'root-current-inputs/proof.json')
assert inputs['status']=='PASS_ROOT_INPUTS' and inputs['baseline']==base and inputs['source_origin']==origin
assert inputs['verified_native_generations']==8 and inputs['verified_native_resolvers']==8
assert inputs['original_spans']==135 and inputs['final_spans']==70 and inputs['original_frozen_members']==243 and len(inputs['original_source_questions'])==1
resolved=read(S/'resolved-spans.json');assert resolved==read(B/'root-reconciliation-verification/resolved-spans.json')
assert [sum(x['seq']==s for x in resolved)for s in (364,365,366)]==[31,10,29]
expected=[dict(seq=i['seq'],**{k:i['span'][k]for k in('id','d','tib','eng')},tib_range=i['tib_range'],eng_range=i['eng_range'])for i in choices['selected_original_items']]
assert all(i['selected_id']==i['span']['id']for i in choices['selected_original_items']) and resolved==expected
counts=dict(spans=len(resolved),nulls=sum(x['eng']is None for x in resolved),nonnull_d5=sum(x['d']==5 and x['eng']is not None for x in resolved),total_d5=sum(x['d']==5 for x in resolved),d7=sum(x['d']==7 for x in resolved))
assert counts==dict(spans=70,nulls=1,nonnull_d5=42,total_d5=42,d7=9)
assembled=read(B/'root-assembled-reading.json');final=read(B/'root-final-review-reading.json')
assert assembled['status']=='ROOT_ASSEMBLED_READING_BOUND_TO_IMMUTABLE_RECONCILIATION'
assert assembled['reconciliation_freeze']==pin(B/'reconciled/freeze.json')
for rel,p in assembled['files'].items():assert pin(B/rel)==p,rel
assert all(f'reconciled/{s}/{n}'in assembled['files']for s in (364,365,366)for n in ('spec.json','final-rationales.json','omissions.json'))
assert final['status']=='ROOT_PERSONAL_FINAL_REVIEW_READING_COMPLETE'
assert final['review_freeze']==pin(S/'freeze.json') and final['review']==pin(S/'review.json')
assert assembled['reading'].strip() and final['reading'].strip()
reading='Root assembled reading: '+assembled['reading']+' Final independent-review reading: '+final['reading']+' These are actual root-authored receipts; no material-object reading count is inferred from hash checks or the independent reviewer inventory.'
assert read(S/'bank-ready-errata.json')==[]
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
for seq in (364,365,366):assert read(S/f'reviewed-final/{seq}/errata.json')==[]
utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 reading=reading,semantic_files_verified=len(freeze['files']),limits='Exact immutable identity plus separately completed root reading; production checks still follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,source_origin=origin,page='c5p122',segments=[364,365,366],counts=counts,
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading.json'),final_independent_reading=pin(B/'root-final-review-reading.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision='Approve the70 provisional spans31/10/29 selected by the exact root decisions and subsequently independently reviewed. All root rulings, adopted rationale corrections and retained omissions remain in their immutable records.',
 root_rulings=choices['rulings'],errata_decision='No new errata or head allowance. Preserve the English364 unresolved edition-relationship question and the original Tibetan registered-class claim as provenance. Adopted reasons retain physical/source-role inference without asserting an identical registered defect; C16 continuation differences do not establish a source correction. Ordinary empty-errata production must retain all204 register entries shared by proposal origin and actual baseline.',errata=[],allowances={'pages_c05':{}},
 native_history='Eight unique generator/resolver pairs: six originals plus two changed364/366 reconciliation pairs, with nine selected views including one byte-exact English365 copied pair. Root/reviewer no native reruns. Preserve all original evidence, recorder captures and actual preparation/reading/assembly history; no historical failure substitutes for required passing production roles.',
 limits='Provisional only; no source/master correction, hgm_gloss promotion, MAIN application or phone acceptance. This receipt does not execute production or closure.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[364,365,366],semantic_files=len(freeze['files']))))
