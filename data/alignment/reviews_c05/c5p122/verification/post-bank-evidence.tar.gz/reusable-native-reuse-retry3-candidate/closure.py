"""CANDIDATE_NOT_ADOPTED: strict C05 compact closure profile, Python stdlib only.

No generator/test runner, shell evaluation, source normalization or proof-tree copy.
A hash-bound explicit root review is required for every live operation.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile

SCHEMA = 'c05-compact-closure-config-v1'
OUTPUTS = {'data/alignment/alignment_full_v1.json', 'data/alignment/alignment_evidence_v1.json'} | {
    'docs/geshe_michael_roach_dictionary' + s for s in
    ('.html', '.csv', '_reverse.csv', '_by_course.csv', '_changes.csv')}
SOURCES = ('data/hgm_dictionary_v27_2.json.gz', 'data/full_parallel_corpus_v32.json.gz')
UNCHANGED = ('docs/errata_register.json', 'data/alignment/span_head_allow.json')
LEDGERS = ('data/alignment/C05_CAMPAIGN.md', 'docs/handoff/HANDOFF_LOG.md',
           'docs/superpowers/plans/2026-09-12-aci-alignment-campaign.md')
ROLES = {'root_inputs', 'semantic_acceptance', 'root_intake', 'landing',
         'landed_semantic_acceptance', 'registration', 'registered_copy', 'builders',
         'tests', 'retention', 'course_csv', 'reproduction', 'bank', 'stage', 'whitespace'}
TESTS = {'constitution', 'gen_alignment_page', 'alignment_gate_coverage', 'alignment_builder',
         'dictionary_exports', 'no_broken_words', 'no_split_syllables', 'no_phonetics_in_layer',
         'no_degenerate_members', 'no_supplied_span_head', 'layer_matches_spine', 'evidence_matches_spine',
         'errata_quotes_hold', 'view_matches_layer', 'generated_docs_in_sync', 'builder_sees_every_span',
         'errata_name_their_witnesses'}
NATIVE = {'command.json', 'execution.json', 'exit.txt', 'stdin.bin', 'stdout.bin', 'stderr.bin'}


class Invalid(Exception):
    pass


def need(condition, message):
    if not condition:
        raise Invalid(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def selected(row):
    return {k: row[k] for k in ('bytes', 'sha256')}


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, data):
    with Path(path).open('x', encoding='utf-8') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def relpath(value):
    p = PurePosixPath(value)
    need(isinstance(value, str) and not p.is_absolute() and value == p.as_posix()
         and '..' not in p.parts and value not in ('', '.'), f'Unsafe relative path: {value}')
    return value


def under(root, relative):
    p = root / relpath(relative)
    need(p.resolve().is_relative_to(root.resolve()), f'Escaped path: {p}')
    return p


def exact(path, expected):
    raw = Path(path).read_bytes()
    need(pin(raw) == selected(expected), f'Byte identity failed: {path}')
    return raw


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def check_indexed_bytes(path, raw, mode, oid):
    need(mode == ('100755' if path == 'tools/build_alignment_layer.py' else '100644')
         and oid == blob(raw), 'Indexed mode/blob mismatch: ' + path)


def names(raw):
    return [x.decode() for x in raw.split(b'\0') if x]


def check_ctest(raw):
    passed = re.findall(rb'^\s*(\d+)/17 Test\s+#\d+:\s+(\w+)\s+\.{2,}\s+Passed\s+[\d.]+\s+sec\s*$', raw, re.M)
    need(len(passed) == len(re.findall(rb'^\s*\d+/\d+ Test\s+#', raw, re.M)) == 17, 'Missing actual passing test')
    need(sorted(int(i) for i, _ in passed) == list(range(1, 18)), 'Test indices')
    need({n.decode() for _, n in passed} == TESTS, 'Wrong fidelity test bank')
    need(any(x in raw.splitlines() for x in (b'100% tests passed out of 17',
         b'100% tests passed, 0 tests failed out of 17')), 'Missing passing test summary')


def check_native(directory, expected_exit, recorder_hash):
    ex, cmd = read(directory / 'execution.json'), read(directory / 'command.json')
    need(all(k in ex and ex[k] == v for k, v in cmd.items()), f'Native command mismatch: {directory}')
    need(ex['recorder_sha256'] == recorder_hash, 'Recorder identity')
    need(type(expected_exit) is int and ex['exit'] == expected_exit, f'Unexpected native exit: {directory}')
    need((directory / 'exit.txt').read_bytes() == f'{expected_exit}\n'.encode(), 'Native exit bytes')
    need(ex['stdin_bytes'] == 0 and (directory / 'stdin.bin').read_bytes() == b'', 'Native stdin')
    for stream in ('stdout', 'stderr'):
        exact(directory / (stream + '.bin'), {'bytes': ex[stream + '_bytes'], 'sha256': ex[stream + '_sha256']})
    return ex


def check_scope(paths, page):
    root = f'data/alignment/reviews_c05/c5p{page}/'
    fixed = OUTPUTS | {f'data/alignment/pages_c05/c5p{page-1}.html',
                      f'data/alignment/pages_c05/c5p{page}.html', 'data/alignment/pages_c05/index.html',
                      f'data/alignment/specs_c05/c5p{page}.json', 'tools/build_alignment_layer.py'}
    need(fixed <= set(paths), 'Missing required staged paths')
    need(all(relpath(p) in fixed or p.startswith(root) for p in paths), 'Unexpected staged path')


class Closure:
    def __init__(self, config_path, output, retrospective=False):
        self.config_path = Path(config_path).resolve()
        self.c = read(self.config_path)
        need(self.c['schema'] == SCHEMA, 'Unsupported config schema')
        need(set(self.c) == {'schema', 'repository', 'batch', 'reproduction', 'artifacts', 'callers',
             'required_roles', 'historical_failures', 'active_caller', 'post_freeze', 'retrospective'}, 'Unknown/missing config key')
        self.w = Path(self.c['repository']).resolve()
        self.b = Path(self.c['batch']).resolve()
        self.r = Path(self.c['reproduction']).resolve()
        self.o = Path(output).resolve()
        need(not self.o.is_relative_to(self.w), 'Verification output must be outside repository')
        self.o.mkdir(parents=True, exist_ok=False)
        self.retrospective = retrospective
        self.git_count = 0
        self.checked = {}
        self.expected_work = {}
        self.config_pin = pin(self.config_path.read_bytes())

    def git(self, *args, allowed=(0,)):
        # Capture native command/streams/exit for metadata and actions; never a shell.
        d = self.o / f'git-{self.git_count:03d}'
        self.git_count += 1
        d.mkdir()
        cmd = {'argv': ['git', *args], 'cwd': str(self.w),
               'environment_overrides': {'GIT_OPTIONAL_LOCKS': '0', 'PYTHONDONTWRITEBYTECODE': '1'}}
        save(d / 'command.json', cmd)
        (d / 'stdin.bin').write_bytes(b'')
        result = subprocess.run(cmd['argv'], cwd=self.w, input=b'', capture_output=True,
                                env=dict(os.environ, **cmd['environment_overrides']))
        for name, raw in [('stdout.bin', result.stdout), ('stderr.bin', result.stderr),
                          ('exit.txt', f'{result.returncode}\n'.encode())]:
            (d / name).write_bytes(raw)
        save(d / 'execution.json', dict(cmd, exit=result.returncode,
                                       stdout=pin(result.stdout), stderr=pin(result.stderr)))
        need(result.returncode in allowed, f'Git failed: {args}')
        return result.stdout

    def artifact(self, key):
        row = self.c['artifacts'][key]
        need(set(row) == {'path', 'bytes', 'sha256'}, f'Invalid artifact binding: {key}')
        raw = exact(row['path'], row)
        self.checked[key] = selected(row)
        path = Path(row['path'])
        if path.is_relative_to(self.w):
            self.work_identity(str(path.relative_to(self.w)), raw)
        return raw

    def doc(self, key):
        return json.loads(self.artifact(key))

    def approval(self, receipt):
        d = read(receipt)
        need(d['verdict'] == 'APPROVE_ROOT_REUSABLE_C05_CLOSURE', 'Explicit root method review required')
        need(d['config'] == self.config_pin and d['method'] == pin(Path(__file__).read_bytes()), 'Stale method/config approval')
        need(d['root_review']['reviewer_role'] == 'root' and bool(d['root_review']['judgment'].strip())
             and bool(d['root_review']['utc']), 'Missing actual root review')
        need(d['reviewed_scope'] == 'C05 three-segment private closure; no semantic or integration approval inferred', 'Approval scope')
        need(self.c['retrospective'] is None, 'Retrospective config cannot execute a live closure')
        self.review_pin = pin(Path(receipt).read_bytes())
        # Small method/config/approval bytes only, never an old proof tree.
        (self.o / 'reviewed-config.json').write_bytes(self.config_path.read_bytes())
        (self.o / 'root-method-review.json').write_bytes(Path(receipt).read_bytes())
        (self.o / 'executed-method.py.txt').write_bytes(Path(__file__).read_bytes())

    def work_identity(self, path, raw):
        """Retrospective checks immutable DATA objects, without copying old trees."""
        relpath(path)
        self.expected_work[path] = pin(raw)
        if self.retrospective:
            row = self.tree[path]
            need(row[1] == blob(raw), f'Committed blob mismatch: {path}')
        else:
            need(under(self.w, path).read_bytes() == raw, f'Current bytes differ: {path}')

    def frozen(self, key, root, landed=None):
        f = self.doc(key)
        for relative, row in f['files'].items():
            raw = exact(under(root, relative), row)
            if landed:
                self.work_identity(landed + '/' + relpath(relative), raw)
        if 'file_count' in f:
            need(f['file_count'] == len(f['files']), 'Frozen count differs from manifest')
        return f

    def reviewed_spec_path(self, row):
        return self.b / f"semantic-review/reviewed-final/{row['seq']}/spec.json"

    def reconciliation_total(self, reconciliation, count_name, legacy_field):
        return reconciliation[legacy_field]

    def verify_root_inputs(self, root, proposal, sequences):
        need(root['status'] == 'PASS_ROOT_INPUTS' and root['baseline'] == self.base and root['source_origin'] == proposal['commit'], 'Root source/input acceptance')
        need(root['root_generator_runs'] == 0 and root['verified_native_generations'] == len(sequences) * 3, 'Native reuse proof')

    def profile_gate(self, root, intake, decision, frozen, review, reconciliation):
        return None

    def verify_review_metadata(self, d, proposal, baseline):
        need(all(d[k] == 'APPROVE' for k in ('verdict', 'spec_verdict', 'quality_verdict'))
             and d['open_findings'] == [], 'Fresh independent semantic approval required')
        need(d['source_origin_git_commit'] == proposal['commit'], 'Source origin conflated with acceptance baseline')
        need(d['later_supplied_acceptance_baseline'] == self.base
             and d['later_baseline_accepted_through'] == baseline['course_boundary'], 'Wrong acceptance baseline')

    def verify_reconciliation_metadata(self, rec, proposal, seqs):
        need(rec['source_origin_git_commit'] == proposal['commit'] and rec['segments'] == seqs, 'Reconciliation origin')

    def verify_policy_inputs(self):
        need(self.doc('errata') == [] and self.doc('head_allowances') == {'pages_c05': {}}, 'This profile requires unchanged registers')
        for path in UNCHANGED:
            raw = under(self.w, path).read_bytes()
            need(self.git('rev-parse', self.base + ':' + path).decode().strip() == blob(raw), 'Mutated register: ' + path)

    def verify_registration_scope(self, registration):
        need(registration['errata'] == [] and registration['head_allowances'] == {'pages_c05': {}}, 'Registration scope')

    def check_staged_scope(self, paths):
        check_scope(paths, self.page)

    def verify(self):
        # No alternate field names or blanket missing-field/failure exceptions.
        baseline, proposal = self.doc('baseline'), self.doc('proposal_baseline')
        self.base = baseline['commit']
        need(re.fullmatch('[0-9a-f]{40}', self.base) is not None, 'Baseline must be exact commit')
        if self.retrospective:
            cp = self.doc('checkpoint')
            need(cp['status'] == 'PASS_FIXED_PRIVATE_CHECKPOINT' and cp['incoming'] == self.base, 'Historical checkpoint baseline')
            need(self.c['retrospective'] == {'data': cp['data'], 'final': cp['final']}, 'Retrospective commits')
            self.data, self.final = cp['data'], cp['final']
            need(self.git('rev-parse', self.data + '^').decode().strip() == self.base, 'DATA parent')
            need(self.git('rev-parse', self.final + '^').decode().strip() == self.data, 'DOCS parent')
            self.tree = {}
            requested = {r['path'] for r in self.doc('accepted_index')['files']}
            requested.update(str(Path(r['original']).relative_to(self.w)) for r in self.doc('reproduction_inputs')
                             if Path(r['original']).is_relative_to(self.w))
            for row in self.git('ls-tree', '-r', '-z', self.data, '--', *sorted(requested)).split(b'\0'):
                if row:
                    meta, path = row.split(b'\t'); mode, kind, oid = meta.decode().split()
                    need(kind == 'blob', 'Unexpected tree member')
                    self.tree[path.decode()] = (mode, oid)
        else:
            need(self.git('rev-parse', 'HEAD').decode().strip() == self.base, 'Wrong live acceptance baseline')
        f = self.doc('semantic_freeze')
        need(f['schema'] == 'c05-independent-semantic-review-freeze-v1', 'Unsupported semantic schema')
        review = self.doc('review')
        for d in (f, review):
            self.verify_review_metadata(d, proposal, baseline)
        seqs = [row['seq'] for row in review['segments']]
        need(seqs == list(range(baseline['course_boundary'] + 1, baseline['course_boundary'] + 4)), 'Nonconsecutive three-segment batch')
        need(seqs == proposal['proposal_segments'] and seqs[-1] % 3 == 0, 'Proposal/page mismatch')
        self.page, self.seqs = seqs[-1] // 3, seqs
        self.review_root = f'data/alignment/reviews_c05/c5p{self.page}'
        self.v = self.w / self.review_root / 'verification'
        f = self.frozen('semantic_freeze', self.b / 'semantic-review', self.review_root)
        rec = self.frozen('reconciliation_freeze', self.b / 'reconciled')
        need(rec['schema'] == 'c05-independent-reconciliation-freeze-v1', 'Unsupported reconciliation schema')
        need(f['reconciliation_freeze_sha256'] == self.c['artifacts']['reconciliation_freeze']['sha256'], 'Reconciliation binding')
        self.verify_reconciliation_metadata(rec, proposal, seqs)
        self.work_identity(self.review_root + '/freeze.json', self.artifact('semantic_freeze'))
        totals = dict(spans=0, nulls=0, nonnull_d5=0, total_d5=0, d7=0)
        for row in review['segments']:
            seq = row['seq']; spec = self.reviewed_spec_path(row)
            raw = exact(spec, {'bytes': row['spec_bytes'], 'sha256': row['spec_sha256']})
            d = json.loads(raw)
            need(d['course'] == 'C05' and len(d['segments']) == 1 and d['segments'][0]['seq'] == seq, 'Spec segment identity')
            spans = d['segments'][0]['spans']
            counts = {'spans': len(spans), 'nulls': sum(s['eng'] is None for s in spans),
                      'nonnull_d5': sum(s['d'] == 5 and s['eng'] is not None for s in spans),
                      'total_d5': sum(s['d'] == 5 for s in spans), 'd7': sum(s['d'] == 7 for s in spans)}
            need((row['span_count'], row['null_count'], row['word_pair_count']) ==
                 (counts['spans'], counts['nulls'], counts['nonnull_d5']), 'Review counts differ from frozen specs')
            need(row['generator_exit'] == row['resolver_exit'] == 0, 'Missing actual native PASS')
            for k in totals:
                totals[k] += counts[k]
        for k, field in [('spans', 'total_spans'), ('nulls', 'total_nulls'), ('nonnull_d5', 'total_word_pairs'), ('d7', 'total_d7')]:
            need(totals[k] == f[field] == self.reconciliation_total(rec, k, field) == review[field], 'Frozen aggregate mismatch')
        self.totals = totals
        copies = self.doc('original_copies')
        for row in copies:
            if 'original_git_commit' in row:
                raw = self.git('show', row['original_git_commit'] + ':' + relpath(row['repository_relative_path']))
                need(pin(raw) == selected(row), 'Historical original identity')
            else:
                raw = exact(row['original'], row)
            need(exact(under(self.b / 'semantic-review', row['copy']), row) == raw, 'Copy identity')
            self.work_identity(self.review_root + '/' + relpath(row['copy']), raw)
        self.copies = copies
        root, intake, decision = self.doc('root_inputs'), self.doc('root_intake'), self.doc('root_disposition')
        self.verify_root_inputs(root, proposal, seqs)
        need(intake['status'] == 'PASS_ROOT_CURRENT_INTAKE' and intake['baseline'] == self.base, 'Current root intake')
        need(intake['prior_root_checks'] == self.checked['root_inputs'], 'Root intake provenance')
        need(decision['verdict'] == 'APPROVE_ROOT_SEMANTIC_ACCEPTANCE' and decision['actual_baseline'] == self.base, 'Root semantic acceptance')
        need(decision['source_origin'] == proposal['commit'] and decision['segments'] == seqs
             and decision['page'] == f'c5p{self.page}' and decision['counts'] == totals, 'Root semantic identity')
        need(intake['review_freeze'] == decision['review_freeze'] == self.checked['semantic_freeze'], 'Root/fresh freeze binding')
        need(decision['read_evidence']['completed'].strip() and decision['semantic_decision'].strip(), 'Root reading evidence absent')
        self.profile_gate(root, intake, decision, f, review, rec)
        self.verify_policy_inputs()
        for path in SOURCES:
            # Archive sources are intentionally external/ignored in this checkout;
            # their exact baseline and original source pins, not Git blobs, govern.
            raw = (self.w / path).read_bytes()
            need(sha(raw) == baseline['sha256'][path], 'Mutated source baseline pin: ' + path)
        self.source_pins = {str(Path(row['path'])): row for row in proposal['source_pins'].values()}
        for row in self.source_pins.values():
            exact(row['path'], row)
        registration = self.doc('registration')
        need(registration['status'] == 'PASS' and registration['baseline_commit'] == self.base
             and registration['page'] == self.page and registration['segments'] == self.seqs, 'Registration PASS')
        self.verify_registration_scope(registration)
        need(registration['method'] == pin(self.artifact('registration_method')), 'Registration method identity')
        self.verify_registration_inputs(registration)
        self.verify_callers()
        self.verify_production(baseline, review)
        self.verify_archives(f)
        # Every explicitly bound auxiliary artifact is checked, including code and history.
        for key in self.c['artifacts']:
            self.artifact(key)
        return {'segments': seqs, 'page': self.page, 'counts': totals,
                'semantic_files': len(f['files']), 'reconciliation_files': len(rec['files']),
                'original_copy_records': len(copies), 'acceptance_baseline': self.base,
                'source_origin': proposal['commit']}

    def verify_registration_inputs(self, registration):
        # v7 records preimages for precisely the two files it then publishes.
        written = registration['written_files']
        allowed = {'tools/build_alignment_layer.py', 'data/alignment/pages_c05/index.html'}
        need(type(written) is list and len(written) == 2 and set(written) == allowed,
             'Registration written-file scope')
        rows = registration['files']
        need(len(rows) == 2 and {r['path'] for r in rows} == allowed,
             'Registration output inventory')
        outputs = {r['path']: r for r in rows}
        seen = set()
        for row in registration['inputs']:
            path = Path(row['path'])
            relative = str(path.relative_to(self.w)) if path.is_relative_to(self.w) else None
            if relative in outputs:
                need(relative not in seen, 'Duplicate registration preimage')
                seen.add(relative)
                before = self.git('show', self.base + ':' + relative)
                need(pin(before) == selected(row) and sha(before) == outputs[relative]['before_sha256'],
                     'Registration BASE preimage mismatch: ' + relative)
                after = (self.git('show', self.data + ':' + relative) if self.retrospective
                         else under(self.w, relative).read_bytes())
                need(sha(after) == outputs[relative]['after_sha256'],
                     'Registration postimage mismatch: ' + relative)
                self.work_identity(relative, after)
            # Other inputs retain the existing exact-current/retrospective contract.
            elif not (self.retrospective and path.is_relative_to(self.w)):
                exact(path, row)
        need(seen == allowed, 'Missing registration preimage')

    def verify_callers(self):
        roles, failures, callers = self.c['required_roles'], self.c['historical_failures'], self.c['callers']
        need(set(roles) == ROLES and len(set(roles.values())) == len(ROLES), 'Missing/duplicate actual passing gate role')
        need(not set(roles.values()) & set(failures), 'Failure bypass targets a required passing gate')
        need(set(roles.values()) | set(failures) <= set(callers), 'Unbound required caller')
        active = self.c['active_caller']
        need(active in ('compact-closure-caller', 'compact-closure-attempt02-caller', 'compact-closure-attempt03-caller')
             and active not in callers, 'Invalid active caller exemption')
        if active in ('compact-closure-attempt02-caller', 'compact-closure-attempt03-caller'):
            need('compact-closure-caller' in failures and failures['compact-closure-caller']['exit'] == 1,
                 'Retry requires explicit actual first-closure failure')
        if active == 'compact-closure-attempt03-caller':
            need('compact-closure-attempt02-caller' in failures and failures['compact-closure-attempt02-caller']['exit'] == 1,
                 'Third attempt requires explicit actual second-closure failure')
        actual = {p.name for p in self.b.glob('*-caller') if p.is_dir()}
        need(actual - {active} == set(callers), 'Unexpected or missing caller directory')
        if active in actual and not self.retrospective:
            need(not (self.b / active / 'execution.json').exists(), 'Active caller already completed')
        recorder = sha(self.artifact('recorder'))
        self.native = {}
        for name, record in callers.items():
            need(relpath(name) == Path(name).name and set(record) == NATIVE, 'Caller inventory')
            d = self.b / name
            need({p.name for p in d.iterdir()} == NATIVE, 'Unexpected caller member')
            for n, expected in record.items():
                exact(d / n, expected)
            exit_code = 0
            if name in failures:
                failure = failures[name]
                need(set(failure) == {'exit', 'reason'} and type(failure['exit']) is int and failure['exit'] != 0
                     and failure['reason'].strip(), 'Unreviewable failure bypass')
                exit_code = failure['exit']
            self.native[name] = check_native(d, exit_code, recorder)
        check_ctest((self.b / roles['tests'] / 'stdout.bin').read_bytes())

    def verify_production(self, baseline, review):
        build, repro = self.doc('build'), self.doc('reproduction_proof')
        ret, course, summary = self.doc('retention'), self.doc('course_csv'), self.doc('bank_summary')
        for d in (build, repro):
            need(d['status'] == 'PASS' and d['baseline_commit'] == self.base, 'Missing actual production PASS')
        need(ret['baseline_commit'] == course['baseline_commit'] == self.base, 'Retention baseline')
        need(ret['segments'] == repro['segments'] == self.seqs and ret['page'] == f'c5p{self.page}', 'Production segments')
        need(ret['reviewed_analyst_spans'] == self.totals['spans'] and
             ret['added_links'] == self.totals['spans'] + len(self.seqs), 'Retention span/source-anchor counts')
        need(ret['full_links'] == ret['prior_links_retained'] + ret['added_links']
             and ret['prior_links_retained'] == baseline['full_links'], 'Prior links retained')
        for k in ('review_tuples_and_source_ranges_match', 'source_hashes_unchanged',
                  'prior_notes_trees_evidence_and_acip_retained', 'prior_csv_content_and_references_retained'):
            need(ret[k] is True, 'Retention gate: ' + k)
        need(course['all_depths_counts_and_metadata_match_main_csv_refs'] is True, 'Course CSV gate')
        need(len(build['runs']) == 2 and all(r['exit'] == 0 for r in build['runs']), 'Actual build runs')
        for label, execution in zip(('layer', 'view'), build['runs']):
            for stream in ('stdout', 'stderr'):
                exact(self.b / f'landing/build-{label}.{stream}',
                      {'bytes': execution[stream + '_bytes'], 'sha256': execution[stream + '_sha256']})
        need(repro['all_original_inputs_unchanged'] is True and repro['layer_invocations'] == repro['view_invocations'] == 1, 'Reproduction invocation/source gate')
        need(len(repro['outputs']) == 7 and {r['path'] for r in repro['outputs']} == OUTPUTS, 'Seven whole outputs required')
        for row in repro['outputs']:
            need(row['complete_bytes_equal'] is True, 'Partial output comparison forbidden')
            raw = exact(under(self.r / 'workspace', row['path']), row)
            need(raw == exact(under(self.r / 'expected', row['path']), row), 'Whole reproduction bytes')
            self.work_identity(row['path'], raw)
            need(build['output_sha256'][row['path']] == row['sha256'], 'Build/output mismatch')
            if row['path'].endswith('_by_course.csv'):
                need(course['course_csv_sha256'] == row['sha256'], 'Course output pin')
        for path in SOURCES:
            need(build['output_sha256'][path] == baseline['sha256'][path], 'Production source mutation')
        seed = exact(self.b / 'landing/previous-main-csv-seed.bin', repro['seed'])
        need(seed == exact(self.r / 'seed/previous-main-csv-seed.bin', repro['seed']), 'Actual seed mismatch')
        need(self.git('rev-parse', self.base + ':docs/geshe_michael_roach_dictionary.csv').decode().strip() == blob(seed), 'Seed is not actual acceptance baseline')
        need(selected(build['previous_main_csv_seed']) == repro['seed'], 'Build seed binding')
        # Reproduction input manifest binds all copied code/source/input bytes. For a
        # retrospective run, current registered code may have legitimately advanced.
        for row in self.doc('reproduction_inputs'):
            copied = exact(under(self.r, row['copy']), row)
            original = Path(row['original'])
            if str(original) in self.source_pins:
                need(selected(row) == selected(self.source_pins[str(original)]), 'Reproduction source pin mismatch')
                need(copied == exact(original, row), 'Reproduction external source mutated')
            elif self.retrospective and original.is_relative_to(self.w):
                self.work_identity(str(original.relative_to(self.w)), copied)
            else:
                need(copied == exact(original, row), 'Reproduction input mutated')
        need(len(repro['runs']) == 2, 'Exactly two actual reproduction native executions required')
        for label, run in zip(('layer', 'view'), repro['runs']):
            d = self.r / 'executions' / label
            need(read(d / 'execution.json') == run and run['exit'] == 0, 'Reproduction native execution')
            need(all(k in run and run[k] == v for k, v in read(d / 'command.json').items()), 'Reproduction native command')
            need((d / 'exit.txt').read_bytes() == b'0\n' and (d / 'stdin.bin').read_bytes() == b''
                 and run['stdin_bytes'] == 0, 'Reproduction native exit/stdin')
            for stream in ('stdout', 'stderr'):
                exact(d / (stream + '.bin'), run[stream])
        need(summary['status'] == 'PASS' and summary['page'] == self.page and summary['segments'] == self.seqs, 'Current bank PASS')
        need(summary['fidelity_tests']['passed'] == 17 and summary['fidelity_tests']['failed'] == 0, '17-test bank proof')
        need(summary['fidelity_tests']['execution'] == self.native[self.c['required_roles']['tests']], 'Bank actual test execution')
        need(summary['retention'] == ret and summary['course_csv'] == course and
             summary['reproduction_outputs'] == repro['outputs'] and summary['semantic_review'] == review, 'Bank current evidence identity')
        need(selected(summary['archive']) == selected(self.c['artifacts']['bank_archive']), 'Bank archive pin')
        self.wh = self.doc('whitespace')
        need(self.wh['all_warnings_accounted_for'] is True and self.wh['baseline_head'] == self.base
             and self.wh['review_freeze_sha256'] == self.checked['semantic_freeze']['sha256'], 'Whitespace gate')
        need(self.wh['git_diff_check_exit'] in (0, 2), 'Unexpected diff-check status')
        need(pin(self.artifact('whitespace_stdout')) == {'bytes': self.wh['raw_log_bytes'], 'sha256': self.wh['raw_log_sha256']}, 'Native whitespace diagnostic pin')
        need(self.artifact('whitespace_stderr') == b'' and self.artifact('whitespace_exit') == f"{self.wh['git_diff_check_exit']}\n".encode(), 'Whitespace native exit')
        for path, row in self.wh['files'].items():
            raw = exact(self.w / path, row)
            self.work_identity(path, raw)
        wr = self.doc('whitespace_method_review')
        need(wr['verdict'] == wr['pin_preparation_v4']['verdict'] == 'APPROVE', 'Independent whitespace method review')
        need(wr['method_sha256'] == sha(self.artifact('whitespace_method')) and
             wr['pin_preparation_v4']['method_sha256'] == sha(self.artifact('whitespace_pin_method')), 'Unapproved whitespace method change')
        prepared = self.doc('whitespace_preparation')
        need(prepared['status'] == 'EXACT_V12_PINS_PREPARED' and prepared['freeze'] == self.checked['semantic_freeze']
             and prepared['pins'] == self.doc('whitespace_pins'), 'Whitespace preparation')

    def verify_archive(self, archive_key, rows, expected_mode=None):
        need(len({r['member'] for r in rows}) == len(rows), 'Duplicate archive member')
        with tarfile.open(fileobj=io.BytesIO(self.artifact(archive_key)), mode='r:gz') as tf:
            need(tf.getnames() == [r['member'] for r in rows], 'Archive inventory')
            for row in rows:
                member = tf.getmember(relpath(row['member']))
                need(member.isfile(), 'Archive symlink/nonregular member')
                if expected_mode is not None:
                    need(member.mode == expected_mode, 'Archive mode mismatch')
                raw = tf.extractfile(member).read()
                need(pin(raw) == selected(row) and raw == exact(row['original'], row), 'Archive full bytes/original identity')

    def verify_archives(self, frozen):
        self.verify_archive('bank_archive', self.doc('bank_manifest'))
        post = self.doc('post_bank_manifest')
        need(post['archive'] == selected(self.c['artifacts']['post_bank_archive'])
             and post['all_members_byte_equal'] is True, 'Post-bank archive binding')
        self.verify_archive('post_bank_archive', post['members'])
        for item in self.c['post_freeze']:
            need(set(item) == {'archive', 'manifest', 'source_relative', 'exclusion'}, 'Post-freeze contract keys')
            source_relative = relpath(item['source_relative'])
            need(frozen['exclusions']['active_capture_directory'] == item['exclusion']
                 and item['exclusion'] == source_relative + ' (completes after freeze)', 'Explicit freeze exclusion required')
            need(not any(p == source_relative or p.startswith(source_relative + '/') for p in frozen['files']), 'Cannot archive/omit frozen semantic member')
            need(not any(r['copy'] == source_relative or r['copy'].startswith(source_relative + '/') for r in self.copies), 'Cannot omit copy target')
            manifest = self.doc(item['manifest'])
            need(manifest['status'] == 'PASS_EXACT_POST_FREEZE_CALLER_ARCHIVE'
                 and manifest['semantic_freeze'] == self.checked['semantic_freeze'], 'Post-freeze archive binding')
            need(manifest['archive'] == selected(self.c['artifacts'][item['archive']]), 'Post-freeze archive hash')
            rows = manifest['members']
            need([r['member'] for r in rows] == [source_relative + '/' + n for n in sorted(NATIVE)], 'Complete post-freeze native bytes required')
            source = under(self.b / 'semantic-review', source_relative)
            need({p.name for p in source.iterdir()} == NATIVE, 'Post-freeze source members')
            for row in rows:
                need(row['original'] == str(source / Path(row['member']).name), 'Post-freeze source binding')
            check_native(source, 0, sha(self.artifact('recorder')))
            self.verify_archive(item['archive'], rows, expected_mode=0o644)
            path = self.review_root + '/' + source_relative
            need(not self.git('ls-tree', '-z', self.base, '--', path), 'Late caller exists at acceptance baseline')
            if self.retrospective:
                need(not any(p.startswith(path + '/') for p in self.tree), 'Unfrozen duplicate unexpectedly committed')
            else:
                need(not (self.w / path).exists(), 'Late caller must be separately archived before staging')

    def staged(self):
        need(not self.retrospective, 'Historical proof cannot stand in for live index')
        need(self.git('rev-parse', 'HEAD').decode().strip() == self.base, 'Acceptance baseline moved')
        need(not self.git('diff', '--name-only', '-z'), 'Unstaged tracked change')
        paths = names(self.git('diff', '--cached', '--name-only', '-z'))
        self.check_staged_scope(paths)
        index = {}
        for row in self.git('ls-files', '--stage', '-z').split(b'\0'):
            if row:
                meta, path = row.split(b'\t'); mode, oid, stage = meta.decode().split()
                need(stage == '0' and path.decode() not in index, 'Unmerged/duplicate index')
                index[path.decode()] = (mode, oid)
        records = []
        for path in paths:
            p = under(self.w, path)
            need(not p.is_symlink(), 'Staged symlink')
            raw = p.read_bytes(); mode, oid = index[path]
            if path in self.expected_work:
                need(pin(raw) == self.expected_work[path], 'Verified file changed before staging: ' + path)
            check_indexed_bytes(path, raw, mode, oid)
            records.append(dict(path=path, git_mode=mode, git_blob=oid, **pin(raw)))
        diag = self.git('diff', '--cached', '--check', allowed=(self.wh['git_diff_check_exit'],))
        need(diag == self.artifact('whitespace_stdout'), 'Final whitespace differs from passed audit')
        tree = self.git('write-tree').decode().strip()
        save(self.o / 'accepted-index.json', {'status': 'PASS', 'baseline': self.base, 'tree': tree, 'files': records})
        return tree

    def retrospective_checkpoint(self):
        accepted = self.doc('accepted_index'); cp = self.doc('checkpoint')
        need(accepted['status'] == 'PASS' and accepted['baseline'] == self.base, 'Historical accepted index')
        need(self.git('rev-parse', self.data + '^{tree}').decode().strip() == accepted['tree'] == cp['accepted_index_tree'], 'Historical tree mismatch')
        paths = names(self.git('diff', '--name-only', '-z', self.base, self.data))
        self.check_staged_scope(paths)
        need(set(paths) == {r['path'] for r in accepted['files']}, 'Historical path inventory')
        for row in accepted['files']:
            need(self.tree[row['path']] == (row['git_mode'], row['git_blob']), 'Historical indexed identity')
        entry = self.artifact('completed_ledger_entry')
        need(set(names(self.git('diff', '--name-only', '-z', self.data, self.final))) == set(LEDGERS), 'Historical ledger scope')
        for row in cp['ledgers']:
            need(row['path'] in LEDGERS, 'Unexpected ledger')
            before = self.git('show', self.data + ':' + row['path'])
            after = self.git('show', self.final + ':' + row['path'])
            need(after == before + entry and pin(before) == row['before'] and pin(after) == row['after'], 'Historical append-only identical ledger')
        need(len(cp['ledgers']) == 3 and cp['tracked_clean'] is True and cp['untracked_preserved'] is True, 'Historical state proof')
        return {'status': 'PASS_RETROSPECTIVE_ARTIFACT_VALIDATION', 'adoption': 'CANDIDATE_NOT_ADOPTED',
                'data': self.data, 'final': self.final,
                'limits': 'Historical artifact/commit validation only; no current staged or clean-state claim; no method approval.'}

    def execute(self):
        untracked = self.git('ls-files', '--others', '--exclude-standard', '-z')
        facts = self.verify()
        tree = self.staged()
        template = self.artifact('ledger_template').decode('utf-8')
        need(all(t in template for t in ('@DATA@', '@BASE@', '@UTC@')), 'Ledger identity placeholders required')
        need(set(re.findall(r'@[A-Za-z_][A-Za-z0-9_]*@', template)) <= {'@DATA@', '@BASE@', '@UTC@'},
             'Unresolved ledger placeholder')
        need(not any(line.endswith(' ') for line in template.splitlines()), 'Ledger trailing whitespace')
        # The complete root-reviewed narrative is immutable configuration data.
        # No automatic claim of semantic reading, MAIN or phone acceptance is authored.
        preimages = {p: self.git('show', self.base + ':' + p) for p in LEDGERS}
        for p, raw in preimages.items():
            need((self.w / p).read_bytes() == raw, 'Ledger preimage changed')
        need(pin(self.config_path.read_bytes()) == self.config_pin, 'Config changed during verification')
        self.git('commit', '-m', f'Bank reviewed provisional C05 alignments for segments {self.seqs[0]}–{self.seqs[-1]}')
        data = self.git('rev-parse', 'HEAD').decode().strip()
        need(self.git('rev-parse', data + '^').decode().strip() == self.base and
             self.git('rev-parse', data + '^{tree}').decode().strip() == tree, 'Committed DATA parent/tree')
        entry = template.replace('@DATA@', data).replace('@BASE@', self.base).replace('@UTC@', datetime.datetime.now(datetime.timezone.utc).isoformat()).encode()
        need(not re.search(rb'@[A-Z_]+@', entry), 'Unresolved ledger placeholder')
        for p, old in preimages.items():
            need((self.w / p).read_bytes() == old and entry not in old, 'Ledger changed/repeated')
            with (self.w / p).open('ab') as f:
                f.write(entry)
            need((self.w / p).read_bytes() == old + entry, 'Ledger append failed')
        (self.o / 'ledger-entry.md').write_bytes(entry)
        need(set(names(self.git('diff', '--name-only', '-z'))) == set(LEDGERS), 'Unexpected ledger-stage change')
        self.git('add', '--', *LEDGERS)
        need(set(names(self.git('diff', '--cached', '--name-only', '-z'))) == set(LEDGERS), 'Unexpected staged ledger path')
        need(not self.git('diff', '--cached', '--check'), 'Ledger whitespace')
        self.git('commit', '-m', f'Record verified C05 coverage through segment {self.seqs[-1]} and integration limits')
        final = self.git('rev-parse', 'HEAD').decode().strip()
        need(self.git('rev-parse', final + '^').decode().strip() == data, 'DOCS parent')
        need(set(names(self.git('diff', '--name-only', '-z', data, final))) == set(LEDGERS), 'DOCS path scope')
        for p, old in preimages.items():
            need(self.git('show', final + ':' + p) == old + entry == (self.w / p).read_bytes(), 'Final ledger identity')
        need(not self.git('status', '--porcelain', '--untracked-files=no'), 'Final tracked state dirty')
        need(self.git('ls-files', '--others', '--exclude-standard', '-z') == untracked, 'Untracked path list changed')
        return dict(facts, status='PASS_REUSABLE_PRIVATE_CHECKPOINT', data=data, final=final,
                    tree=tree, config=self.config_pin, method_review=self.review_pin,
                    tracked_clean=True, untracked_preserved=True,
                    limits='Provisional private alignment closure only; no MAIN/device/hgm_gloss approval.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('retrospective', 'staged', 'execute'))
    parser.add_argument('--config', required=True)
    parser.add_argument('--output', required=True, help='New directory outside repository')
    parser.add_argument('--root-review')
    args = parser.parse_args()
    run = Closure(args.config, args.output, args.mode == 'retrospective')
    try:
        if args.mode == 'retrospective':
            need(run.c['retrospective'] is not None, 'Historical commits required')
            facts = run.verify()
            result = dict(facts, **run.retrospective_checkpoint())
        else:
            need(args.root_review is not None, '--root-review required')
            run.approval(args.root_review)
            if args.mode == 'execute':
                result = run.execute()
            else:
                facts = run.verify()
                result = dict(facts, status='PASS_LIVE_STAGED_VERIFICATION', tree=run.staged())
        save(run.o / 'proof.json', result)
        print(json.dumps(result, indent=2))
    except (Invalid, KeyError, OSError, ValueError, tarfile.TarError) as exc:
        save(run.o / 'failure.json', {'status': 'FAIL_CLOSED', 'error': str(exc), 'mode': args.mode})
        raise


if __name__ == '__main__':
    main()
