"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root personally read all118 original span tuples/rationales,25 omissions,six singular notes,30 error-category judgments and both original source-specific five-ground assessments;40 complete master objects and5 complete corpus wrappers, plus source/context/six physical extents, are separately pinned. Full final63 tuple/rationales and final omission/disposition reasons were checked by exact original identity plus changed source-specific root rulings. Root read independent preliminary assessment before final choices, then all63 independent final judgments, complete final omission judgments and both GTHU proposal dispositions before acceptance. Worker152-master/31-corpus reading is not claimed as root reading. Exact native/source identity checks are distinct from semantic reading.'
decision='Approve63 provisional spans31/7/25,44nonnullD5,6D7,0nulls.346 adds the independently proposed first BYAS/engaged; KHO NA/only is d6; the tighter MA/not is d6 with YIN/does unbanked. Keep explicit PHA ROL PO/other side, NA/Suppose, first PHYIR/Because by causal-clause scope, second PAR/in and tighter LDAN PA/possess.347 first root-count BZHI stays unbanked in the expanded outline; following-heading Four is apparatus and not an alternative body exponent.348 keeps BSAMS BZHIN/Purposely, flat MA/without plus NOR/mistake and BDAG GIR/possession plus BYED/take. Whole BGROD MIN/improper phrase preserves negative meaning; contextual GRO BA/Engaging remains distinct from the curated living-being noun. Desire/sex and wrong-impression recasts remain unbanked without false absence nulls.'
errata='No new errata or head allowances. Raw GTHU/force remains provisional with exact glossary attestation and warning preserved. English LOW/UNCERTAIN and Tibetan LOW/PROBABLE originals and all GATHU/MTHU/source counterevidence remain complete; root accepts the independent LOW/UNCERTAIN deferred/unfiled disposition. TCS02 GATHU is not a corrected MTHU witness; neither duplicate publication-family readings nor potentially same-source glossary establish independent correctness. Existing202 records must remain unchanged in production. No source/master correction, normalized pairing or hgm_gloss promotion.'
assert read(S/'bank-ready-errata.json')==[]
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p116',segments=[346,347,348],counts=dict(spans=63,nulls=0,nonnull_d5=44,total_d5=44,d7=6),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading-addendum.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Seven actual unique native pairs:6original and1changed346reconciler; unchanged347348reuseexactEnglishspec/body/ranges/native. Nine selected capture views include2duplicates; root/reviewer0newnative runs. Root exact346spec and old/new singularnote and all original histories are preserved; no superseded candidate generation or production rerun.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[346,347,348],semantic_files=len(freeze['files']))))
