"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert (B/'root-final-review-reading.json').is_file() and (B/'root-assembled-reading.json').is_file()
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root personally read all130 original span/range/rationale records,22 original omissions,six notes,30 error-category judgments and source-specific five-ground assessments;46 complete master objects (44new,2exact same-root reuse),4 complete nonlocal corpus objects and1 current register object, plus source/context/six physical extents, are separately pinned. Final66 tuples and rationale/25 omission records were read using exact personally read originals plus all changed root rulings and five changed/three additional omission reasons. Independent preliminary assessment preceded root choices. root-final-review-reading.json binds actual final independent reading before this acceptance; reviewer170master/22corpus inventory is separate. Identity checks do not substitute for semantic reading.'
decision='Approve66 provisional spans40/11/15,41nonnullD5,noD7/nulls.352 uses tightGZHAN/else,whole parental-lineage/count phrase atd3,two distinctRANG self references,negativecopulaMIN/is not,and separateYIN/is plusYANG/even if. NYE DU/closely related is uncertain and unbanked; preserve BREL BA/related and MO/female. Tight whole exposure/in the open,nursing phrase,local list coordinators,DRUNG DU/full locative,and GNAS PA/observing remain.353 exact eleven English tuples reused with wrong-impression/given and following apparatus unbanked.354 local secondGYIS/by selected,shared KYI/of andfirstby unbanked; GANGDE/Thatd3 retained; BSHAD/Represents omitted because local YIN TE shares classification. Sensory words preserve exact fourfoldorder.'
errata='Retain two exact English-original LOW/PROBABLE352 editorial questions, for inherited SRID MO and awkward number/list/each wording, with full five grounds and counterevidence. No confirmed repair or independently corrected witness is claimed. Leave SRID MO/sister unbanked; do not replace source or fill hgm_gloss. No other newerrata or headallowance. Register additions follow only approved canonical nonempty-errata production with202priorrecords preserved.'
assert read(S/'bank-ready-errata.json')==read(B/'english/352/errata.json')
assert len(read(S/'bank-ready-errata.json'))==2
assert all(x['seq']==352 and x['severity']=='LOW' and x['confidence']=='PROBABLE' for x in read(S/'bank-ready-errata.json'))
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p118',segments=[352,353,354],counts=dict(spans=66,nulls=0,nonnull_d5=41,total_d5=41,d7=0),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading.json'),final_independent_reading=pin(B/'root-final-review-reading.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Eight unique actual native pairs:6originals+2changed352354; unchanged353 reuses exact English spec/body/ranges/native. Nine captureviews include1copy. Root/reviewer no newnative queries/generation. Original sourcequestions and histories preserved; sourceorigin348 differs from actual351baseline supplied after historical rootselection null; no futurecommit invented.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[352,353,354],semantic_files=len(freeze['files']))))
