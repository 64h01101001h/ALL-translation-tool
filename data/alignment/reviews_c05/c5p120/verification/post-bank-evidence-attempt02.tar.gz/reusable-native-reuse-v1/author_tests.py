"""Focused read-only actual I/H compatibility and in-memory rejection tests."""
from pathlib import Path
from unittest.mock import patch
import copy,json,sys,ast
import native_reuse_profile as P
from closure import Closure,Invalid,pin
D=Path(__file__).resolve().parent;A=D.parent
REAL_READ=Path.read_bytes

def encode(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def load(p):return json.loads(REAL_READ(p))

class Case:
    def __init__(self,batch='C05-358-360'):
        self.b=A/batch;self.c=load(self.b/'closure-config.json');self.root=load(Path(self.c['artifacts']['root_inputs']['path']));self.proposal=load(self.b/'proposal-baseline.json');self.seqs=self.proposal['proposal_segments'];self.overlay={}
        self.c['artifacts']['native_reuse_selection']={'path':str(self.b/'reconciled/native-selection.json'),**pin(REAL_READ(self.b/'reconciled/native-selection.json'))}
        self.c['artifacts']['native_reuse_profile']={'path':str(D/'native_reuse_profile.py'),**pin(REAL_READ(D/'native_reuse_profile.py'))}
    def raw(self,p):
        p=Path(p)
        if p in self.overlay:
            if self.overlay[p]is None:raise FileNotFoundError('in-memory missing capture: '+str(p))
            return self.overlay[p]
        return REAL_READ(p)
    def json(self,p):return json.loads(self.raw(p))
    def artifact(self,key,doc):
        p=Path(self.c['artifacts'][key]['path']);raw=encode(doc);self.overlay[p]=raw;self.c['artifacts'][key].update(pin(raw))
    def setfile(self,angle,relative,raw):
        p=self.b/angle/relative;self.overlay[p]=raw
        fp=self.b/angle/'freeze.json';f=self.json(fp);f['files'][relative]=pin(raw);fr=encode(f);self.overlay[fp]=fr
        if angle in P.ANGLES:
            self.root['inventories'][angle]['freeze']=pin(fr)
            if angle=='reconciled':self.c['artifacts']['reconciliation_freeze'].update(pin(fr))
        else:self.c['artifacts']['semantic_freeze'].update(pin(fr))
        if angle=='reconciled'and relative=='native-selection.json':self.c['artifacts']['native_reuse_selection'].update(pin(raw))
        if relative.endswith('/execution.json'):
            for row in self.root['native_captures']:
                if row['path']==str(p.parent):row['execution']=pin(raw)
    def selection(self,change):
        p=self.b/'reconciled/native-selection.json';x=self.json(p);change(x);self.setfile('reconciled','native-selection.json',encode(x))
    def execution(self,change,seq=358,mode='resolver',angle='reconciled'):
        rel=f'native/{seq}-{mode}-v1/execution.json';x=self.json(self.b/angle/rel);change(x);self.setfile(angle,rel,encode(x))
    def run(self):
        run=P.NativeReuseClosure.__new__(P.NativeReuseClosure);run.b=self.b;run.c=self.c;run.base=self.root['baseline'];run.checked={};run.w=Path(self.c['repository']);run.expected_work={};run.retrospective=False
        def read_overlay(path):return self.raw(path)
        with patch.object(Path,'read_bytes',read_overlay):run.verify_root_inputs(self.root,self.proposal,self.seqs)
        return run.native_reuse_proof

results=[]
def positive(name,c,unique,reused):
    x=c.run();assert x['selected_views']==18 and x['unique_executions']=={'generator':unique,'resolver':unique}and x['reused_english_sequences']==reused
    results.append({'case':name,'outcome':'PASS','derived':x})
def reject(name,mutate,expected):
    c=Case();mutate(c)
    try:c.run()
    except (Invalid,KeyError,OSError,ValueError)as e:
        assert expected in str(e),(name,'wrong rejecting guard',str(e),expected)
        results.append({'case':name,'outcome':'REJECT_AS_EXPECTED','guard':str(e),'files_modified_on_disk':0})
    else:raise AssertionError('Accepted invalid case: '+name)

positive('actual I: eight unique complete pairs, nine views',Case(),8,[358])
positive('actual H: historical nine unique complete pairs, nine views',Case('C05-355-357'),9,[])
c=Case('C05-355-357');run=Closure.__new__(Closure);run.base=c.root['baseline'];Closure.verify_root_inputs(run,c.root,c.proposal,c.seqs);results.append({'case':'unchanged adopted core accepts historical nine count','outcome':'PASS'})
c=Case();run=Closure.__new__(Closure);run.base=c.root['baseline']
try:Closure.verify_root_inputs(run,c.root,c.proposal,c.seqs)
except Invalid as e:assert str(e)=='Native reuse proof';results.append({'case':'unchanged adopted core still rejects actual I eight count','outcome':'REJECT_AS_EXPECTED','guard':str(e)})
else:raise AssertionError('Adopted core changed')
for key,value in [('verified_native_generations',9),('verified_native_resolvers',9),('unique_original_generations',5),('unique_original_resolvers',5),('reconciler_generations',3),('reconciler_resolvers',3),('reused_english_pairs',0),('root_generator_runs',1),('root_resolver_runs',1),('root_generator_runs',False)]:
    reject('wrong/bool root count '+key+'='+repr(value),lambda c,k=key,v=value:c.root.__setitem__(k,v),'Native count differs: '+key)
reject('missing resolver view',lambda c:c.root['native_captures'].pop(),'Complete18')
reject('duplicated view replaces another',lambda c:c.root['native_captures'].__setitem__(1,copy.deepcopy(c.root['native_captures'][0])),'Complete18')
reject('extra19th view',lambda c:c.root['native_captures'].append(copy.deepcopy(c.root['native_captures'][0])),'Complete18')
reject('wrong canonical view path',lambda c:c.root['native_captures'][0].__setitem__('path',str(c.b/'english/native/358-generator-v1')),'Canonical native view path')
reject('missing native stdin file',lambda c:c.overlay.__setitem__(c.b/'english/native/358-generator-v1/stdin.bin',None),'in-memory missing capture')
reject('changed execution without matching root pin',lambda c:c.root['native_captures'][0]['execution'].__setitem__('sha256','0'*64),'Root selected execution pin')
reject('wrong original freeze pin',lambda c:c.root['inventories']['english']['freeze'].__setitem__('sha256','0'*64),'Byte identity failed')
reject('no explicit selected-native artifact',lambda c:c.c['artifacts'].pop('native_reuse_selection'),'native_reuse_selection')
reject('wrong explicit selection path',lambda c:c.c['artifacts']['native_reuse_selection'].__setitem__('path',str(c.b/'english/native-selection.json')),'Explicit frozen native-selection path')
reject('wrong origin',lambda c:c.root.__setitem__('source_origin','0'*40),'Root source/input acceptance')
def wrongbaseline(c):c.root['baseline']='0'*40;c.proposal['commit']='1'*40
reject('wrong source/baseline identity',wrongbaseline,'Root source/input acceptance')
# Rebind the affected freeze and root/config pins; these reach the actual
# byte-relation checks rather than merely failing an old hash.
def changespec(c):
    p=c.b/'reconciled/358/spec.json';x=c.json(p);x['segments'][0]['note']+=' changed';c.setfile('reconciled','358/spec.json',encode(x))
reject('reused spec/note changed with fresh frozen pins',changespec,'Native stdin equals complete spec')
reject('reused body changed with fresh frozen pins',lambda c:c.setfile('reconciled','358/body.html',c.raw(c.b/'reconciled/358/body.html')+b'changed'),'Native output equals frozen body.html')
reject('reused resolved ranges changed with fresh frozen pins',lambda c:c.setfile('reconciled','358/resolved-ranges.json',b'[]\n'),'Native output equals frozen resolved-ranges.json')
reject('recorded stream hash wrong with fresh execution/root/freeze pins',lambda c:c.execution(lambda e:e['streams']['stdin'].__setitem__('sha256','0'*64)),'Recorded native stream identity: stdin')
def exitone(c):
    c.execution(lambda e:e.__setitem__('exit',1));c.setfile('reconciled','native/358-resolver-v1/exit.txt',b'1\n')
reject('nonzero native exit with fresh pins',exitone,'Native count differs: exit')
def stderr(c):
    c.execution(lambda e:e['streams'].__setitem__('stderr',pin(b'warning')));c.setfile('reconciled','native/358-resolver-v1/stderr.bin',b'warning')
reject('nonempty stderr with matching recorded pin',stderr,'Native success/empty stderr bytes')
reject('one-sided reuse: only resolver execution becomes distinct',lambda c:c.execution(lambda e:e.__setitem__('utc','2026-09-15T06:00:00.000001+00:00')),'Generator/resolver reuse must be paired')
reject('claimed copied source is a different sequence',lambda c:c.selection(lambda x:x['selected'][0]['selected']['resolver'].__setitem__('original_path',str(c.b/'english/native/359-resolver-v1'))),'Exact original five-file paired reuse')
reject('claimed copied source mixes original angles',lambda c:c.selection(lambda x:x['selected'][0]['selected']['resolver'].__setitem__('original_path',str(c.b/'tibetan/native/358-resolver-v1'))),'Exact original five-file paired reuse')
reject('false new-execution label for actual pair reuse',lambda c:c.selection(lambda x:x['selected'][0].__setitem__('mode','NEW_EXECUTION')),'Selected reuse mode')
reject('wrong full selected capture pin',lambda c:c.selection(lambda x:x['selected'][0]['selected']['generator']['files']['stdin.bin'].__setitem__('bytes',0)),'Selected full native pins')
reject('unsupported selected capture version',lambda c:c.selection(lambda x:x.__setitem__('selected_capture_version',2)),'Native count differs: selected_capture_version')
reject('wrong selection unique count with fresh pins',lambda c:c.selection(lambda x:x.__setitem__('total_actual_unique_pairs',9)),'Native count differs: total_actual_unique_pairs')
def rec_count(c):
    fp=c.b/'reconciled/freeze.json';x=c.json(fp);x['new_generator_runs']=3;raw=encode(x);c.overlay[fp]=raw;c.root['inventories']['reconciled']['freeze']=pin(raw);c.c['artifacts']['reconciliation_freeze'].update(pin(raw))
reject('wrong frozen reconciliation unique/new count',rec_count,'Native count differs: new_generator_runs')
def review_count(c):
    x=c.json(Path(c.c['artifacts']['review']['path']));x['native_history']['actual_unique_pairs']=9;c.artifact('review',x)
reject('wrong independent review native count',review_count,'Native count differs: actual_unique_pairs')
def review_path(c):
    x=c.json(Path(c.c['artifacts']['review']['path']));x['segments'][0]['native_evidence']['resolver']['stdin']='native/reconciled/359-resolver-v1/stdin.bin';c.artifact('review',x)
reject('review native view points at another segment',review_path,'Reviewed selected native capture pin/copy')
reject('semantic copied capture bytes differ despite fresh semantic pin',lambda c:c.setfile('semantic-review','native/reconciled/358-generator-v1/stdout.bin',b'changed'),'Reviewed selected native capture pin/copy')
reject('semantic reviewed body differs despite fresh semantic pin',lambda c:c.setfile('semantic-review','reviewed-final/358/body.html',b'changed'),'Reviewed complete native input/body')
def original_duplicate(c):
    for n in ['spec.json','body.html','resolved-ranges.json']:c.setfile('english','358/'+n,c.raw(c.b/'tibetan/358'/n))
    for m in P.MODES:
        for n in P.CAPTURE:
            rel=f'native/358-{m}-v1/{n}';c.setfile('english',rel,c.raw(c.b/'tibetan'/rel))
reject('two original views share complete native identity',original_duplicate,'Six distinct original executions per mode')
# Verify the extension cannot quietly replace unrelated closure gates.
assert pin(REAL_READ(D/'closure.py'))==P.CORE_PIN
assert REAL_READ(D/'closure.py')==REAL_READ(A/'reusable-errata-v1/closure.py')
cls=next(n for n in ast.parse(REAL_READ(D/'native_reuse_profile.py')).body if isinstance(n,ast.ClassDef))
assert {n.name for n in cls.body if isinstance(n,ast.FunctionDef)}=={'verify_root_inputs','approval'}
for name in ['verify','verify_policy_inputs','verify_callers','verify_production','verify_archives','staged','execute']:
    assert getattr(P.NativeReuseClosure,name)is getattr(Closure,name)
results.append({'case':'adopted core byte-identical and every later gate inherited unchanged','outcome':'PASS'})
print(json.dumps({'status':'PASS_FOCUSED_NATIVE_REUSE_TESTS','cases':len(results),'results':results,'candidate':pin(REAL_READ(D/'native_reuse_profile.py')),'core':pin(REAL_READ(D/'closure.py')),'limits':'Only verify_root_inputs called on actual frozen I/H files and in-memory mutation overlays. No live closure, constructor, Git command, native engine, W write, source query, old proof-tree copy or production check rerun.'},indent=2))
