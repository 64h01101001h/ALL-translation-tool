"""Plan bounded current late evidence; every file is explicit and byte-pinned."""
from pathlib import Path
import argparse
from closure import NATIVE,exact,need,pin,read,save

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--batch',required=True);p.add_argument('--bank-manifest',required=True)
p.add_argument('--extra',action='append',default=[]);p.add_argument('--output',required=True)
a=p.parse_args();b=Path(a.batch).resolve();artifacts=b.parent
manifest=Path(a.bank_manifest).resolve();bank=read(manifest)
archived={r['original'] for r in bank}
files={b/'landing'/name for name in ('source-whitespace-proof.json','review-whitespace-exact-pins.json',
       'whitespace-pin-preparation.json','staged-diff-check.stdout','staged-diff-check.stderr',
       'staged-diff-check.exit','root-ledger-entry-template.md')}
for directory in sorted(b.glob('*-caller')):
    if directory.name=='compact-closure-caller':continue
    need({x.name for x in directory.iterdir()}==NATIVE,'Only completed exact native callers can enter post-bank plan')
    files.update(directory/name for name in NATIVE if str(directory/name) not in archived)
files.update(Path(x).resolve() for x in a.extra)
rows=[]
for path in sorted(files):
    need(path.is_file() and not path.is_symlink() and path.is_relative_to(artifacts),'Explicit regular current artifact required')
    rows.append(dict(original=str(path),member=str(path.relative_to(artifacts)),**pin(path.read_bytes())))
save(a.output,dict(schema='c05-current-post-bank-plan-v1',status='UNAPPROVED_PLAN',batch=str(b),
     earlier_bank_manifest=dict(path=str(manifest),**pin(manifest.read_bytes())),members=rows,
     scope='Current late whitespace/ledger/completed caller files plus explicitly supplied methods; no recursive proof-tree copy.'))
