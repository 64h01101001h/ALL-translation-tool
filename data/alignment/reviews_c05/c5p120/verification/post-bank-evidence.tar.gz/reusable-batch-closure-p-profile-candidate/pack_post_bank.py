"""Pack a reviewed explicit post-bank plan once; no directory discovery or mutation.

Usage: pack_post_bank.py PLAN NEW_ARCHIVE NEW_MANIFEST
Only the two new output files are written. All source and caller bytes survive.
"""
from pathlib import Path
import argparse
import gzip
import io
import tarfile
from closure import exact,need,pin,read,relpath,save


def pack(plan_path,archive_path,manifest_path):
    plan_path=Path(plan_path);archive_path=Path(archive_path);manifest_path=Path(manifest_path)
    plan_raw=plan_path.read_bytes();plan=read(plan_path)
    need(plan['schema']=='c05-current-post-bank-plan-v1','Post-bank plan schema')
    exact(plan['earlier_bank_manifest']['path'],plan['earlier_bank_manifest'])
    rows=plan['members'];need(rows and len({r['member'] for r in rows})==len(rows),'Duplicate/empty post-bank members')
    need(not archive_path.exists() and not manifest_path.exists(),'Post-bank outputs must be new')
    for row in rows:
        relpath(row['member']);exact(row['original'],row)
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tf:
                for row in rows:
                    data=exact(row['original'],row);info=tarfile.TarInfo(row['member'])
                    info.size=len(data);info.mode=0o644
                    tf.addfile(info,io.BytesIO(data))
    with tarfile.open(archive_path,'r:gz') as tf:
        need(tf.getnames()==[r['member'] for r in rows],'Exact post-bank archive inventory')
        for row in rows:
            member=tf.getmember(row['member']);need(member.isfile() and member.mode==0o644,'Post-bank member mode')
            need(tf.extractfile(member).read()==exact(row['original'],row),'Post-bank complete original bytes')
    need(plan_path.read_bytes()==plan_raw,'Plan changed during packing')
    save(manifest_path,dict(archive=pin(archive_path.read_bytes()),members=rows,all_members_byte_equal=True,
         plan=dict(path=str(plan_path.resolve()),**pin(plan_raw)),
         scope=plan['scope']+' The packer caller completes afterward and remains a separately pinned final-config input; no incomplete-caller exemption.'))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan');p.add_argument('archive');p.add_argument('manifest')
    a=p.parse_args();pack(a.plan,a.archive,a.manifest)
