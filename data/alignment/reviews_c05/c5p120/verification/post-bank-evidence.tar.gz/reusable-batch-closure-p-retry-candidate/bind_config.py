"""Bind an explicit batch plan without approving it or running its methods.

A plan has the closure config shape. Replace artifacts values by absolute paths,
and callers values by absolute caller directory paths. Historical failures and
required passing roles must be supplied explicitly by the root; none are inferred.
"""
from pathlib import Path
import argparse
import json
from closure import NATIVE, ROLES, SCHEMA, need, pin, save


def bind(plan):
    need(plan['schema'] == SCHEMA, 'Unsupported plan schema')
    need(set(plan['required_roles']) == ROLES, 'Every actual passing role is required')
    need(not set(plan['required_roles'].values()) & set(plan['historical_failures']), 'Cannot bypass a required passing role')
    result = dict(plan)
    result['artifacts'] = {k: dict(path=str(Path(p).resolve()), **pin(Path(p).read_bytes()))
                           for k, p in plan['artifacts'].items()}
    result['callers'] = {}
    for name, directory in plan['callers'].items():
        d = Path(directory)
        need(d.name == name and {p.name for p in d.iterdir()} == NATIVE, 'Caller must have exactly six native files')
        ex = json.loads((d / 'execution.json').read_bytes())
        expected = plan['historical_failures'][name]['exit'] if name in plan['historical_failures'] else 0
        need(ex['exit'] == expected, 'Actual failure needs an explicit reviewed failure record; PASS cannot be fabricated')
        result['callers'][name] = {n: pin((d / n).read_bytes()) for n in sorted(NATIVE)}
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan'); p.add_argument('output')
    args = p.parse_args()
    save(args.output, bind(json.loads(Path(args.plan).read_bytes())))
