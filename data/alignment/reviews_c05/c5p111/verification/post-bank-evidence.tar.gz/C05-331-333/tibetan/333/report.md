C05:333 — Codex TIBETAN-FIRST, PROVISIONAL proposal; source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324.
The three numerals, two roots and two come/from pairs were checked against their complete local clauses.
One med scopes over all three roots and is banked once at first no; later English negations are repeated exponents, not positive roots.
dang bcas pa owns with in the virtue-stage construction; it cannot borrow later possessing. rnams remains distributed and omitted.
All original decisions and uncertain omissions: original-decisions.json; exact source gaps: unwrapped-source-intervals.json.
Five-ground screens found no supported source correction; errata.json is empty. No hgm_gloss or source change.
Complete original evidence and reading scope: ../evidence/original-to-copy-manifest.json, ../evidence/reused-lexical-preparation.json and ../reading-receipt.json.
Measured: 31 spans; 0 nulls; 22 nonnull d5 word pairs; 22 total d5; 1 d7.
Generator EXIT=0; stderr empty; body 5127 bytes; SHA256 3ba949d4b7fb9b550b0fa8f75a42d8f8d2dd568c60825c0cf7a3207b1b680f96.
Resolver EXIT=0; stderr empty; actual ranges equal ../intended-ranges.json. Native directories preserve argv/stdin/stdout/stderr/exit.
Spec 5144 bytes; SHA256 564c56abf0d70bb0ca1149ac48218d3c0d20eeb6c2e2493bc108ee19784febd1. Native stdout equals body exactly; both source columns reconstruct verbatim.
