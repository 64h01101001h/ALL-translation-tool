C05:331 — Codex TIBETAN-FIRST, PROVISIONAL proposal; source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324.
The sole source sbyor ba owns the first technical label; later English labels and stealing repetitions remain unwrapped.
Both value spans and all three motive from spans use their own clauses; the additional from your enemy is excluded.
Raw skyes ba is retained. The final lta bu/exemplified and bshad/description citation recasts are the first review targets.
All original decisions and uncertain omissions: original-decisions.json; exact source gaps: unwrapped-source-intervals.json.
Five-ground screens found no supported source correction; errata.json is empty. No hgm_gloss or source change.
Complete original evidence and reading scope: ../evidence/original-to-copy-manifest.json, ../evidence/reused-lexical-preparation.json and ../reading-receipt.json.
Measured: 27 spans; 0 nulls; 21 nonnull d5 word pairs; 21 total d5; 0 d7.
Generator EXIT=0; stderr empty; body 4783 bytes; SHA256 ccf200c7382a014089ebbc3a60b3dff27d6d3dde75ccfdff1714a81c33296213.
Resolver EXIT=0; stderr empty; actual ranges equal ../intended-ranges.json. Native directories preserve argv/stdin/stdout/stderr/exit.
Spec 4650 bytes; SHA256 28711413e1e3623263d1c5c6b2e428e53b2957011b9ea2ff781a55f9dd7619f8. Native stdout equals body exactly; both source columns reconstruct verbatim.
