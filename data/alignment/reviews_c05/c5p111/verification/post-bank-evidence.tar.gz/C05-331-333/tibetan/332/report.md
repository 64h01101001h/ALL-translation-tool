C05:332 — Codex TIBETAN-FIRST, PROVISIONAL proposal; source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324.
Challenge the complete reputation and banquet recasts first; the predicate enjoyed belongs to bsten par bya'o, not the earlier preparation modifier.
chu dogs and third skyes pa/do remain omitted with explicit uncertainty; no null or unproved spelling correction is supplied.
Only the first shared like and initial Sexual misconduct are banked; public, river, earth and repeated subjects remain unwrapped.
All original decisions and uncertain omissions: original-decisions.json; exact source gaps: unwrapped-source-intervals.json.
Five-ground screens found no supported source correction; errata.json is empty. No hgm_gloss or source change.
Complete original evidence and reading scope: ../evidence/original-to-copy-manifest.json, ../evidence/reused-lexical-preparation.json and ../reading-receipt.json.
Measured: 29 spans; 0 nulls; 19 nonnull d5 word pairs; 19 total d5; 0 d7.
Generator EXIT=0; stderr empty; body 5351 bytes; SHA256 4627a764d303b7b27e6bbb09c327da8e651e551bf097fd1dae7c94231ad76e78.
Resolver EXIT=0; stderr empty; actual ranges equal ../intended-ranges.json. Native directories preserve argv/stdin/stdout/stderr/exit.
Spec 5203 bytes; SHA256 7c43f3381f9e95db9ddd98b6210135110c528904dee5c364924468b33b54e5d0. Native stdout equals body exactly; both source columns reconstruct verbatim.
