"""Explicit current-batch configuration data for the reviewed shared closure."""
from pathlib import Path
import json,sys
B=Path(__file__).resolve().parent;A=B.parent;W=A.parent/'campaign-worktree'
sys.path.insert(0,str(A/'reusable-errata-v1'))
from closure import SCHEMA
R=Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through333')
V=W/'data/alignment/reviews_c05/c5p111/verification'
paths={k:str(B/p) for k,p in {
 'baseline':'baseline.json','proposal_baseline':'proposal-baseline.json','semantic_freeze':'semantic-review/freeze.json',
 'reconciliation_freeze':'reconciled/freeze.json','review':'semantic-review/review.json',
 'original_copies':'semantic-review/original-to-copy-manifest.json','root_inputs':'root-current-inputs/proof.json',
 'root_intake':'root-reconciliation-intake.json','root_disposition':'root-semantic-disposition.json',
 'errata':'semantic-review/bank-ready-errata.json','head_allowances':'semantic-review/span-head-allow-needed.json',
 'build':'landing/canonical-builds-once.json','retention':'landing/retention-source-check.json',
 'course_csv':'landing/course-csv-check.json','registration':'landing/registration/proof.json',
 'whitespace':'landing/source-whitespace-proof.json','whitespace_stdout':'landing/staged-diff-check.stdout',
 'whitespace_stderr':'landing/staged-diff-check.stderr','whitespace_exit':'landing/staged-diff-check.exit',
 'whitespace_preparation':'landing/whitespace-pin-preparation.json','whitespace_pins':'landing/review-whitespace-exact-pins.json',
 'ledger_template':'landing/root-ledger-entry-template.md',
 'root_input_method':'root-input-receipt.py',
 'root_acceptance_method':'root-acceptance-receipt.py',
 'current_reproduction_method_review':'compact-reproduction-review/method-review.json'}.items()}
paths.update({k:str(A/p) for k,p in {
 'recorder':'record_external_step.py',
 'closure_method':'reusable-errata-v1/closure.py','method_review':'reusable-errata-v1/root-method-review.json',
 'candidate_freeze':'reusable-errata-v1/candidate-freeze.json',
 'registration_method':'register_reviewed_page_v7.py',
 'whitespace_method':'audit_staged_source_whitespace_v12.py','whitespace_pin_method':'prepare_review_whitespace_pins_v5.py',
 'failed_whitespace_pin_method':'prepare_review_whitespace_pins_v4.py',
 'whitespace_method_review':'whitespace-v5-independent-review/review.json',
 'whitespace_method_review_freeze':'whitespace-v5-independent-review/freeze.json',
 'whitespace_method_tests':'whitespace-v5-independent-review/test-results.json',
 'prior_whitespace_method_review':'C05-313-315/whitespace-latin1-independent-review.json',
 'semantic_acceptance_method':'verify_semantic_acceptance_v2.py',
 'post_bank_plan_method':'reusable-batch-closure-p-profile-candidate/post_bank_plan.py',
 'post_bank_pack_method':'reusable-batch-closure-p-profile-candidate/pack_post_bank.py',
 'binder_method':'reusable-batch-closure-p-retry-candidate/bind_config.py'}.items()})
paths.update({k:str(V/p) for k,p in {'bank_summary':'summary.json','bank_archive':'native-evidence.tar.gz',
 'bank_manifest':'archive-manifest.json','post_bank_archive':'post-bank-evidence.tar.gz','post_bank_manifest':'post-bank-manifest.json'}.items()})
paths.update(reproduction_proof=str(R/'proof.json'),reproduction_inputs=str(R/'input-manifest.json'))
roles=dict(root_inputs='root-inputs-caller',semantic_acceptance='semantic-acceptance-caller',
 root_intake='root-semantic-intake-caller',landing='land-caller',landed_semantic_acceptance='landed-acceptance-caller',
 registration='register-caller',registered_copy='copy-register-check-caller',builders='builders-caller',tests='ctest-17-caller',
 retention='retention-caller',course_csv='course-csv-caller',reproduction='reproduction-caller',bank='compact-bank-caller',
 stage='stage-data-caller',whitespace='whitespace-audit-caller')
failures={'whitespace-pins-caller': {'exit': 1, 'reason': 'Original v4 preparation stopped before outputs because Y contains no complete physical ReadingASCII.txt manifest original. No frozen semantic member contains CRLF; corrected reviewed preparation handles the empty witness inventory without adding exceptions. Actual failed caller remains preserved.'}}
names={p.name for p in B.glob('*-caller') if p.is_dir() and p.name!='compact-closure-caller'}
names|={'post-bank-pack-caller','post-bank-stage-caller'}
plan=dict(schema=SCHEMA,repository=str(W),batch=str(B),reproduction=str(R),artifacts=paths,
 callers={n:str(B/n) for n in sorted(names)},required_roles=roles,historical_failures=failures,
 active_caller='compact-closure-caller',post_freeze=[],retrospective=None)
with (B/'closure-plan.json').open('x') as f:f.write(json.dumps(plan,indent=2)+'\n')
print('Wrote explicit unapproved closure plan; no validation or acceptance inferred.')
