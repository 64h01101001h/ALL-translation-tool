C05:331 — Codex independent English-first; PROVISIONAL proposal only.
Challenge sgo nas / out of at d6 first: its grammatical means/motive function controls depth. The desire/dislike value and steal occurrences have distinct measured ranges.
Counts: 26 spans; 21 non-null d5 pairs; 21 total d5; 0 d7; 0 nulls; 0 errata.
Source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324; no acceptance through330 baseline consumed.
Complete source/context325–339 was checked once against SQLite URI mode=ro. Original query results are reused for packaging without query repetition.
Source/context SHA256 fcd658f6d87396c52f42b9ecfc368f4d54e519eed2f4be5795e958a85be4c43d.
Complete master objects and corpus objects occur once in ../evidence/lexical.json, supplemental-lexical.json and corpus.json; exact paths/hashes are in ../evidence/material-manifest.json.
All three complete source fields match C16:856; textual identity does not prove publication independence or ingestion history. Physical six-field extents are independently byte-verified.
decisions.json records every measured occurrence, semantic rationale and omission. errata-review.json applies the five grounds to all five categories.
Actual canonical generator EXIT=0; stdout/body=4373 bytes; stderr=0 bytes; body SHA256 386d52c14d81b5c540ba082e28ef374632485468b553eeeed3efbb1e577df2a6.
Actual canonical resolver EXIT=0; stderr=0; all intended ranges agree. Native streams: ../native/331-generator-v1 and ../native/331-resolver-v1.
Spec SHA256 66652e3acbd0aab503ed49f8fb0f59e43db201af5e4dc879cc6c14e36be4ea05; source exact after markup removal. One resolver/generator run per unchanged spec.
The preliminary physical one-line assumption failure is preserved under ../failures/evidence-v1; successful source queries were reused and physical byte extents fixed the check.
No source/master edits, hgm_gloss promotion or semantic acceptance is claimed.
