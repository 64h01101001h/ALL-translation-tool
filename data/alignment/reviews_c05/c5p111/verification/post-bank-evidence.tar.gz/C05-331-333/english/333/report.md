C05:333 — Codex independent English-first; PROVISIONAL proposal only.
Challenge the shared med omission first: one source negative scopes desire, dislike and ignorance, while three English no tokens repeat it. The positive lexical stems remain separate.
Counts: 28 spans; 20 non-null d5 pairs; 20 total d5; 0 d7; 0 nulls; 0 errata.
Source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324; no acceptance through330 baseline consumed.
Complete source/context325–339 was checked once against SQLite URI mode=ro. Original query results are reused for packaging without query repetition.
Source/context SHA256 fcd658f6d87396c52f42b9ecfc368f4d54e519eed2f4be5795e958a85be4c43d.
Complete master objects and corpus objects occur once in ../evidence/lexical.json, supplemental-lexical.json and corpus.json; exact paths/hashes are in ../evidence/material-manifest.json.
All three complete source fields match C16:858; textual identity does not prove publication independence or ingestion history. Physical six-field extents are independently byte-verified.
decisions.json records every measured occurrence, semantic rationale and omission. errata-review.json applies the five grounds to all five categories.
Actual canonical generator EXIT=0; stdout/body=4615 bytes; stderr=0 bytes; body SHA256 14553cf0a674e9b7ec6a210db7ced0ce0f81e6bd8a29c3c3f60a9d535ae43131.
Actual canonical resolver EXIT=0; stderr=0; all intended ranges agree. Native streams: ../native/333-generator-v1 and ../native/333-resolver-v1.
Spec SHA256 5c5181e4c02b5ae600937a6ea2dd9c6b4d560cf877d41bec0c75b781e5297ad1; source exact after markup removal. One resolver/generator run per unchanged spec.
The preliminary physical one-line assumption failure is preserved under ../failures/evidence-v1; successful source queries were reused and physical byte extents fixed the check.
No source/master edits, hgm_gloss promotion or semantic acceptance is claimed.
