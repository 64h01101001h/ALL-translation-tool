import json
from pathlib import Path
A=Path(__file__).resolve().parents[1];rows={r['seq']:r for r in json.loads((A/'evidence/source-context.json').read_text())}
def put(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def build(seq,title,items,note,omissions):
 r=rows[seq];sp=[];dec=[];cur=0;parent=None
 for i,(tib,eng,d,anchor,why)in enumerate(items,1):
  sid=('m'if d==7 else'p'if d==6 else'f'if d<5 else'w')+str(i);at=r['wylie'].find(tib,parent[0]if d==7 else cur,parent[1]if d==7 else len(r['wylie']));assert at>=0,(seq,tib);tr=[at,at+len(tib)]
  if d!=7:cur=tr[1]
  if d==5:parent=tr
  ea=r['english'].index(eng,r['english'].index(anchor));er=[ea,ea+len(eng)];s={'id':sid,'d':d,'tib':tib,'eng':eng};sp.append(s);dec.append({**s,'seq':seq,'tib_range':tr,'eng_range':er,'complete_local_clause_anchor':anchor,'rationale':why})
 order=[x['id']for x in sorted([x for x in dec if x['d']!=7],key=lambda x:x['eng_range'][0])]
 put(A/str(seq)/'spec.json',{'course':'C05','segments':[{'seq':seq,'title':title,'spans':sp,'eng_order':order,'note':note}]});put(A/str(seq)/'decisions.json',{'producer':'Codex independent English-first','status':'PROVISIONAL','source_row':r,'spans':dec,'omissions':omissions});put(A/str(seq)/'errata.json',[]);print(seq,'spans',len(sp),'d5',sum(x['d']==5 for x in sp))

build(331,'motivations for stealing',[
 ('ma byin par len pa','stealing',5,"Next let's consider the act of stealing",'First full stealing compound names the act; the later English stealing in the ignorance introduction is an added repetition.'),
 ('sbyor ba','"undertaking" stage',5,'An example of the "undertaking" stage','Only explicit sbyor ba is paired to the first stage name, not the later implicit repeated undertaking stage.'),
 ("'dod chags",'desire',5,'this act coming from desire','First root: desire.'),
 ('las','from',6,'this act coming from desire','First ablative is the first coming-from clause.'),
 ('skyes ba','coming',5,'this act coming from desire','Exact BA form has an HGM coming attestation; no correction to PA.'),
 ('nor','value',5,'you steal something of value out of a longing','First wealth object is explicated as something of value; only value is claimed.'),
 ('la','for',6,'a longing for it','The wealth-object relation reappears in English as longing for it; for this act is not the selected occurrence.'),
 ('chags pa','longing',5,'a longing for it','Attachment to wealth becomes longing; it is distinct from the earlier desire root.'),
 ('sgo nas','out of',6,'out of a longing for it','Grammatical means/motive postposition, d6 by its Tibetan function.'),
 ('ma byin par len pa','steal',5,'you steal something of value out of a longing','Second full stealing compound is the first English steal, inside the desire example.'),
 ('lta bu','example',5,'An example of the "undertaking" stage','First source example expression belongs to desire; it does not claim the later for example or the final exemplified.'),
 ('zhe sdang','dislike',5,'A case where this stage comes from dislike','Second root: dislike.'),
 ('las','from',6,'A case where this stage comes from dislike','Second root ablative; do not attach to the later from your enemy.'),
 ('skyes pa','comes',5,'A case where this stage comes from dislike','The singular comes belongs to the dislike-stage example.'),
 ('dgra bo','enemy',5,'from your enemy','Enemy is the owner of the stolen valuables; the genitive is retained outside this atom.'),
 ('nor','value',5,'you steal something of value from your enemy','Second wealth object belongs to the enemy clause.'),
 ('rku ba','steal',5,'you steal something of value from your enemy','First rku ba is the second English steal, not the quoted steals.'),
 ('lta bu','for example',5,'would be, for example, where you steal','Second source exemplar has the explicit for example in the dislike clause; A case stays outside.'),
 ('gti mug','ignorance',5,'stealing coming from ignorance','Third root: ignorance.'),
 ('las','from',6,'stealing coming from ignorance','Third root ablative, after the enemy clause.'),
 ('skyes pa','coming',5,'stealing coming from ignorance','Second English coming belongs to the ignorance example; distinct from exact BA coming earlier.'),
 ('bram ze','Brahmin',5,'when a Brahmin steals','The quoted agent; the article is supplied.'),
 ('rku ba','steals',5,'when a Brahmin steals','Second rku ba is the finite quoted steals.'),
 ('chos','religion',5,"It's religion when a Brahmin steals",'Dharma/religion meaning in the quotation; HGM glossary explicitly attests religion.'),
 ('bshad','description',5,'by the description that','Teaching/describing predicate is recast into description outside the quotation.'),
 ("lta bu'o",'exemplified',5,'is exemplified by the description','Final exemplar expression belongs to the ignorance quotation; extra An example framing remains outside.')
],
 'PROVISIONAL machine alignment by Codex, independent English-first proposal. Only one explicit sbyor ba is linked; later undertaking/stage and stealing repetitions supplied in English remain unwrapped. The two wealth/value and two steal occurrences belong to desire and dislike respectively; the final rku ba owns quoted steals. Exact skyes ba is HGM-attested as coming. The first la belongs to longing for it. sgo nas is grammatical at d6. Example expressions are paired once per local motivation clause. Articles, supplied participants, and clause framing are unclaimed. No source correction or hgm_gloss promotion.',
 [{'tib':"ni; 'i; su; ces pa",'reason':'Unclaimed topic, bound relational and quotation material; no false absence is asserted.'},{'english':'later "undertaking" stage; for stealing; A case; final An example','reason':'English repeats stages/acts or illustrative framing beyond the explicit Tibetan tokens; each Tibetan occurrence is banked once.'},{'english':'Next let\'s consider the act of; something of; your; it; would be where you','reason':'Supplied framing and participants remain unwrapped.'}])

build(332,'motivations for sexual misconduct',[
 ("'dod pas log par g-yem pa",'Sexual misconduct',5,'Sexual misconduct that comes from desire','Established whole technical term, anchored to first English occurrence; later repeated subject names are implicit.'),
 ("'dod chags",'desire',5,'Sexual misconduct that comes from desire','First root: desire.'),
 ('las','from',6,'Sexual misconduct that comes from desire','First motivation-source ablative.'),
 ('skyes pa','comes',5,'Sexual misconduct that comes from desire','First arising predicate.'),
 ('chags pa','lustful feelings',5,'because of lustful feelings','HGM expressly attests the complete lustful feelings equivalent; supplied sexual activity is not pulled under it.'),
 ('sgo nas','because of',6,'because of lustful feelings','Grammatical means/motive postposition; d6 reflects Tibetan function.'),
 ('log par','wrong',5,'some wrong kind of sexual activity','The adverbial wrongness is recast as an English adjective; kind of sexual activity is not claimed.'),
 ("'jug pa",'engages',5,'one engages in some wrong kind','This engagement verb is the first engages, not later engaging.'),
 ('lta bu','for example',5,'a case where, for example','First exemplar belongs to desire; a case stays outside.'),
 ('zhe sdang','dislike',5,'Sexual misconduct born from dislike','Second root: dislike.'),
 ('las','from',6,'Sexual misconduct born from dislike','Second source ablative belongs to born from dislike.'),
 ('skyes pa','born',5,'Sexual misconduct born from dislike','Second arising predicate is born, distinct from comes and the later active do recast.'),
 ('gzhan sma dbab pa',"harm someone else's reputation",3,"in order to harm someone else's reputation",'Complete reputational-harm phrase, including gzhan as its participant; do not assign sma dbab pa only reputation. TCS17:562–563 corroborate the disgrace sense, not this full sentence.'),
 ('phyir du','in order to',6,"in order to harm someone else's reputation",'Purpose construction attached to reputational harm.'),
 ("'khrig pa",'sexual intercourse',5,'engaging in sexual intercourse','HGM-attested intercourse compound; repeated Sexual misconduct is not this occurrence.'),
 ('spyod pa','engaging',5,'engaging in sexual intercourse','Conduct/performance verb in the dislike example; in is unclaimed.'),
 ('lta bu','represented by',5,'would be represented by engaging','Second exemplar construction; the conditional auxiliary would be stays outside.'),
 ('gti mug','ignorance',5,'that you do from ignorance','Third root: ignorance.'),
 ('las','from',6,'that you do from ignorance','Third motivation-source relation; the active do recast is left unclaimed.'),
 ('me tog','flowers',5,'like the flowers and the fruits','First item of the quoted common-use analogy.'),
 ('dang','and',6,'flowers and the fruits','Coordination of flowers and fruits, not one of the supplied repeated likes.'),
 ("'bras bu",'fruits',5,'flowers and the fruits','Concrete fruit sense; of the earth is supplied.'),
 ('zas g-yos legs par grub pa','banquet ready',3,'like a banquet ready for the feast','Prepared-food phrase retained at d3; for the feast is explanatory expansion. Do not relocate the master legs par grub pa gloss enjoyed into this earlier food clause.'),
 ('lam','road',5,'like a public road','Last analogy item; public is supplied.'),
 ('thams cad','everyone',5,'by everyone together','All participants in the quoted recommendation; together is not separately licensed.'),
 ('kyis','by',6,'by everyone together','Agentive marks the participants who would make use of the object.'),
 ("bsten par bya'o",'should be enjoyed',3,'Sex should be enjoyed by everyone','Complete modal use/enjoy predicate; source has no explicit quoted Sex token here.'),
 ("zhes pa lta bu'o",'is typified in the statement that',3,'is typified in the statement that','Complete quotation-and-example construction; no d5 claim is made for this expanded framing.')
],
 'PROVISIONAL machine alignment by Codex, independent English-first proposal. The initial sexual-misconduct term is linked once; later English subject repetitions are implicit. comes and born have distinct source predicates; the third skyes pa is omitted because the active do recast has no secure separate atom. Reputational harm and the prepared-food wording are retained only as d3 phrases. The master\'s reputation-only sma dbab pa and enjoyed for legs par grub pa are not blindly mapped across clauses. chu dogs is omitted because its pool correspondence and spelling are not sufficiently resolved by the available lexical evidence; no correction is proposed. Shared comparison dang \'dra bas is omitted rather than assigned arbitrarily to one of four likes. The modal predicate and closing quotation formula are d3. Source words, English and HGM master remain unchanged.',
 [{'tib':'third skyes pa','reason':'The English act that you do from ignorance recasts an arising predicate; do is not a secure standalone equivalent. Omit, not null.'},{'tib':'chu dogs','reason':'Exact phrase has no master entry; corpus pool in the river matches only these C05/C16 copies. dogs alone has unrelated HGM readings, no independently corrected witness or defensible local split. Omit without declaring a typo.'},{'tib':"dang 'dra bas",'reason':'One shared similarity construction covers the full flowers/fruits/food/water/road list, while English repeats like four times; no unique local atom is assigned.'},{'english':'subject repetitions; of the earth; for the feast; public; together; Sex','reason':'Expanded participants and qualifications remain outside lexical atoms.'}])

build(333,'mental deeds and virtuous roots',[
 ('brnab sems','Coveting',5,'Coveting and the rest','Established mental-misdeed compound.'),
 ('sogs','and the rest',6,'Coveting and the rest','Enumerative closing gesture only; three misdeeds is not captured.'),
 ('yid','thought',5,'three misdeeds of thought','Mental domain; the explanatory misdeeds remains unwrapped.'),
 ('kyi','of',6,'misdeeds of thought','Genitive relation for the mental-domain grouping.'),
 ('gsum','three',5,'three misdeeds of thought','First numeral counts mental misdeeds, not the roots.'),
 ('rtsa ba','roots',5,'these three roots of non-virtue','First roots phrase; the later root phrase is the referent restated after them.'),
 ('gsum','three',5,'these three roots of non-virtue','Second numeral counts the roots that generate mental misdeeds.'),
 ('las','from',6,'thought come from these three roots','First source ablative belongs to the mental misdeeds.'),
 ('skyes','come',5,'thought come from these three roots','First come predicates the three mental misdeeds.'),
 ('rtsa ba','roots',5,'them--to these three roots','Second source roots maps the second English roots in the explanatory restatement.'),
 ('gsum','three',5,'them--to these three roots','Third source/English numeral occurrence belongs to the restated root referent.'),
 ("de'i",'them',5,'subsequent to them--to these','Demonstrative referring to those three roots; retained whole with its genitive ending.'),
 ('mjug thogs','just subsequent',5,'occur just subsequent to them','Established immediately-subsequent expression; just marks immediacy, not an English participant.'),
 ('byung ba','occur',5,'because they occur just subsequent','Occurrence of the three mental misdeeds immediately after their roots.'),
 ('phyir','because',6,'because they occur just subsequent','Reason particle; does not claim supplied they.'),
 ('dge ba','virtues',5,'The ten virtues','Virtuous deeds, read in karma-prose register; HGM glossary supports virtues while curated goodness is retained as counterevidence.'),
 ('bcu','ten',5,'The ten virtues','Counts the virtues, not stages.'),
 ('sbyor ba','undertaking',5,'stages (undertaking and conclusion','First named stage.'),
 ('dang','and',6,'undertaking and conclusion','Connects undertaking and conclusion; not earlier and here we consider.'),
 ('mjug','conclusion',5,'undertaking and conclusion','Conclusion stage; not the earlier mjug thogs compound.'),
 ('dang','as well as',6,'as well as actual commission','Second stage-list coordinator.'),
 ('dngos gzhi','actual commission',5,'as well as actual commission','Established technical main-stage compound; no speculative gzhi/commission member.'),
 ('dang bcas pa','with',6,'consider them with all their various stages','Comitative construction scopes the whole stages list; it does not own possessing in the later root clause.'),
 ('chags','desire',5,'no desire for something','Positive lexical stem under the single shared med; English no and for something stay outside.'),
 ('sdang','dislike',5,'no dislike for a thing','Second positive lexical stem under shared negation; no dislike is not treated as a standalone Tibetan negative compound.'),
 ('gti mug','ignorance',5,'no ignorance of things','Third positive lexical stem under shared negation; gti mug med is not isolated from the prior two terms.'),
 ('las','from',6,'commission), come from the states','Final source ablative belongs to the ten virtues arising from the three non-afflicted roots.'),
 ('skyes pa','come',5,'commission), come from the states','Second English come predicates the virtues, not the earlier mental misdeeds.')
],
 'PROVISIONAL machine alignment by Codex, independent English-first proposal. The three gsum occurrences count mental misdeeds, their roots, and the restated root referent respectively. The first and second roots/come pairs have distinct clauses. mjug thogs owns just subsequent; the later mjug owns conclusion. dang bcas pa is comitative at d6 and owns with the stages, never possessing in the later root description. One med negates all three chags/sdang/gti mug terms; English repeats no three times. med is omitted as distributed, not nulled or assigned only to ignorance, while the three positive lexical stems remain aligned. rnams and supplied explanations of states, participants and stages remain unclaimed. No source correction or hgm_gloss promotion.',
 [{'tib':'med','reason':'Single shared negation spans chags, sdang and gti mug; English no is repeated three times. No one occurrence exhausts the source scope; omit rather than falsely null or attach only to the last root.'},{'tib':'rnams','reason':'Plurality/scope is distributed over the ten virtues and the expanded all their various stages wording; no single English exponent is asserted.'},{'tib':"ni; te; po; middle las; yin no",'reason':'Topic, connective, nominal, temporal and closing grammar omitted without absence claims.'},{'english':'misdeeds; of non-virtue; they; here we consider them; all their various stages; states of possessing; for something; for a thing; of things','reason':'Supplied or distributed domain explanations, participants and qualifications remain unwrapped.'}])
