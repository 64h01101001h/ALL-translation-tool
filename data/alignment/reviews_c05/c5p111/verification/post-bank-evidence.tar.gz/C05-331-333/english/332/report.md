C05:332 — Codex independent English-first; PROVISIONAL proposal only.
Challenge the d3 zas g-yos legs par grub pa / banquet ready first: it preserves a contextual prepared-food phrase without claiming a lexical banquet entry or the supplied for the feast.
Counts: 28 spans; 17 non-null d5 pairs; 17 total d5; 0 d7; 0 nulls; 0 errata.
Source origin daad5db6ea6207085dc820101b3a2e9aaf942417 through324; no acceptance through330 baseline consumed.
Complete source/context325–339 was checked once against SQLite URI mode=ro. Original query results are reused for packaging without query repetition.
Source/context SHA256 fcd658f6d87396c52f42b9ecfc368f4d54e519eed2f4be5795e958a85be4c43d.
Complete master objects and corpus objects occur once in ../evidence/lexical.json, supplemental-lexical.json and corpus.json; exact paths/hashes are in ../evidence/material-manifest.json.
All three complete source fields match C16:857; textual identity does not prove publication independence or ingestion history. Physical six-field extents are independently byte-verified.
decisions.json records every measured occurrence, semantic rationale and omission. errata-review.json applies the five grounds to all five categories.
Actual canonical generator EXIT=0; stdout/body=5050 bytes; stderr=0 bytes; body SHA256 a9f8b9969716249b2e91ba78df100ee305df7c1edd83efb0ed597e75d7b499c0.
Actual canonical resolver EXIT=0; stderr=0; all intended ranges agree. Native streams: ../native/332-generator-v1 and ../native/332-resolver-v1.
Spec SHA256 0fd6ef452b6184e70239c0b737d3b4cf450532a23b14c46b4002639dc055aa11; source exact after markup removal. One resolver/generator run per unchanged spec.
The preliminary physical one-line assumption failure is preserved under ../failures/evidence-v1; successful source queries were reused and physical byte extents fixed the check.
No source/master edits, hgm_gloss promotion or semantic acceptance is claimed.
