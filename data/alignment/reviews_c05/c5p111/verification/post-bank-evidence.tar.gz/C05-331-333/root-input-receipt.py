"""Verify existing frozen source/native identities; never invoke a generator."""
from pathlib import Path
import datetime, hashlib, json, subprocess
B=Path(__file__).resolve().parent
W=B.parent.parent/'campaign-worktree'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base,origin=read(B/'baseline.json'),read(B/'proposal-baseline.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()==base['commit']=='9e6e7a5e278a109b7cf7d171410073cb8a0051d2'
assert base['course_boundary']==330 and origin['course_boundary']==324
inventories={}
for angle in ('tibetan','english','reconciled'):
    f=B/angle/'freeze.json';rows=read(f)['files']
    assert isinstance(rows,dict)
    for rel,expected in rows.items(): assert pin(f.parent/rel)==expected,rel
    inventories[angle]=dict(freeze=pin(f),files=len(rows))
assert inventories['reconciled']['freeze']['sha256']=='1a96bca03438486638fa7c0dc5fe4210d09e807644477e1acc2009643e27ba80'
for item in origin['source_pins'].values():
    assert pin(Path(item['path']))=={k:item[k] for k in ('bytes','sha256')}
source={r['seq']:r for r in read(B/'source.json')}
captures=[];resolved=[];original_spans=0
for angle in ('tibetan','english','reconciled'):
    for seq in range(331,334):
        folder=B/angle/str(seq);spec=read(folder/'spec.json')
        spans=spec['segments'][0]['spans']
        if angle!='reconciled':original_spans+=len(spans)
        version=1
        for mode in ('generator','resolver'):
            native=folder/('native-'+mode) if angle=='tibetan' else B/angle/'native'/f'{seq}-{mode}-v{version}'
            ex=read(native/'execution.json')
            assert ex['exit']==0 and (native/'exit.txt').read_text().strip()=='0'
            assert (native/'stderr.bin').read_bytes()==b''
            for stream in ('stdin','stdout','stderr'):
                e=ex['streams'][stream] if 'streams' in ex else {k:ex[stream][k] for k in ('bytes','sha256')}
                assert pin(native/(stream+'.bin'))==e
            assert (native/'stdin.bin').read_bytes()==(folder/'spec.json').read_bytes()
            if mode=='generator':assert (native/'stdout.bin').read_bytes()==(folder/'body.html').read_bytes()
            else:
                rows=read(native/'stdout.bin')
                assert len(rows)==len(spans)
                for sp,row in zip(spans,rows):
                    assert {k:row[k] for k in ('id','d','tib','eng')}=={k:sp[k] for k in ('id','d','tib','eng')}
                    assert row['seq']==seq
                    for field,lang in (('tib','wylie'),('eng','english')):
                        extent=row[field+'_range']
                        if row[field] is None:assert extent is None
                        else:assert source[seq][lang][extent[0]:extent[1]]==row[field]
                    if angle=='reconciled':resolved.append({k:row[k] for k in ('seq','id','d','tib','eng','tib_range','eng_range')})
                if angle=='reconciled':assert rows==read(folder/'resolved-ranges.json')
            captures.append(dict(angle=angle,seq=seq,mode=mode,path=str(native),execution=pin(native/'execution.json')))
assert original_spans==169 and len(resolved)==87
save(B/'root-reconciliation-verification/resolved-spans.json',resolved)
proof=dict(status='PASS_ROOT_INPUTS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 baseline=base['commit'],source_origin=origin['commit'],root_generator_runs=0,root_resolver_runs=0,
 verified_native_generations=9,verified_native_resolvers=9,
 count_scope='Six final original proposals plus three reconciled finals. Packaging failures remain inside frozen histories; they are not generator failures.',
 historical_successful_native_captures=[],inventories=inventories,native_captures=captures,
 original_spans=169,final_spans=87,method=pin(Path(__file__)),
 limits='Exact existing source, native streams, selected spec/body and source ranges verified. No generator/resolver rerun; no semantic acceptance inferred.')
save(B/'root-current-inputs/proof.json',proof)
print(json.dumps(dict(status=proof['status'],selected_generators=9,selected_resolvers=9,historical_generators=0,historical_resolvers=0,original_spans=169,final_spans=87)))
