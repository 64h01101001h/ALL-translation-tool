"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read complete source331–333, context325–339, six physical excerpts, all169 original span rationales and omissions, all87 final reconciled rationales and16 omission records, and the material exact disposition changes and spelling-screen reasons. Full material master and corpus readings are recorded in root-original-reading-progress.json, root-material-reading-addendum.json and root-final-reading-progress.json; the new complete dngos entries and complete TCS17:562/563 comparators were read. Root read the complete independent review, all87 independent final-span judgments, all16 independent omission judgments, errata verdicts and resolved findings. The reviewer separately read107 full master objects; root does not claim that whole inventory as its own reading. Frozen inventory and native identity checks are separate from these semantic readings. No root generator or resolver rerun.'
decision='Approve87 provisional spans. In331 retain raw skyes ba/coming on exact attestation and whole sgonas/out of and ces pa/that at d3; repeated explanatory labels stay unbanked. In332 whole log par/wrong preserves the local recast, complete gzhan smad dbab pa/harm someone else’s reputation retains its predicate, and lta bu/represented by has complete HGM support. The banquet construction remains omitted because raw g-yos is unresolved and later enjoyed cannot be borrowed; chu dogs/pool is uncertain with no corrected witness. Whole kyis/by is permitted, and the one shared ’dra bas represents the first like without inventing repeated Tibetan words. In333 each repeated root, numeral, from and come has its own occurrence; mjug thogs/just subsequent retains immediacy, dang bcas pa/with is whole d3, and dngos/actual is the one transparent d7 member. Shared med represents first no across all three roots; rnams remains uncertain and unbanked because its English realization is distributed. No null is invented.'
errata='No new errata or head allowances. Raw skyes ba is attested; unresolved g-yos and chu dogs do not establish a corrected source. All199 prior registered items remain unchanged.'
utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p111',segments=[331,332,333],counts=dict(spans=87,nulls=0,nonnull_d5=61,total_d5=61,d7=1),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-final-reading-progress.json'),material_addendum=pin(B/'root-material-reading-addendum.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Six original and three reconciled generator/resolver results verified without rerunning them. No root input generator/resolver run.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[331,332,333],semantic_files=len(freeze['files']))))
