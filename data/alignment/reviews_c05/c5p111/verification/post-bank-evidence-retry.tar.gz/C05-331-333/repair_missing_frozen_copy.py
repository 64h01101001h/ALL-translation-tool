from pathlib import Path
import hashlib,json,subprocess,datetime
B=Path(__file__).resolve().parent;W=B.parent.parent/'campaign-worktree';S=B/'semantic-review';D=W/'data/alignment/reviews_c05/c5p111'
pin=lambda raw:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
base=json.loads((B/'baseline.json').read_bytes())['commit'];assert git('rev-parse','HEAD').decode().strip()==base
f=json.loads((S/'freeze.json').read_bytes());missing=[]
for rel,row in f['files'].items():
 p=S/rel;q=D/rel;assert p.resolve().is_relative_to(S.resolve()) and q.resolve().is_relative_to(D.resolve())
 raw=p.read_bytes();assert pin(raw)==row
 if not q.exists():missing.append(rel)
 else:assert q.read_bytes()==raw,rel
rel='governing/source-origin-to-through330.diff';assert missing==[rel],missing
raw=(S/rel).read_bytes();target=D/rel;target.parent.mkdir(parents=True,exist_ok=True)
with target.open('xb') as out:out.write(raw)
for name,row in f['files'].items():assert pin((D/name).read_bytes())==row and (D/name).read_bytes()==(S/name).read_bytes(),name
subprocess.run(['git','add','--',str(target.relative_to(W))],cwd=W,check=True)
assert git('show',':'+str(target.relative_to(W)))==raw
assert git('rev-parse','HEAD').decode().strip()==base
report=dict(status='PASS_EXACT_MISSING_FROZEN_COPY_REPAIRED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=base,freeze=pin((S/'freeze.json').read_bytes()),repaired=dict(source=str(S/rel),target=str(target),**pin(raw)),all_frozen_copy_identities_verified=len(f['files']),only_staged_path=str(target.relative_to(W)),production_reruns=0,semantic_reruns=0,limits='Exact frozen evidence transport repair only. No semantic change, source change, register change, production generation or commit.',prevention='Before future batch staging, compare every path in the complete final semantic freeze to its landed copy, regardless of extension; reject any missing or changed file before closure. Do not infer completeness from a landing extension filter.')
p=B/'landing/missing-frozen-copy-repair.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
