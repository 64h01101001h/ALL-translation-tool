# Reviewed nonempty errata registration — proposed helper for ROOT review

Status: code preparation and fixture verification only. No live campaign-worktree registration, source/master edit, semantic approval, account operation, release, or paid API was performed by this preparation. Synthetic APPROVE records in fixtures are test inputs, not acceptance of C05:298 or any linguistic decision. ROOT must finish reading and accepting the actual independent semantic review before use.

Final candidate: `register_reviewed_page_with_errata.py`, **33,574 bytes**, SHA-256 **`9aa0682f996325b435cc1d8126315c5744b2aff796cebc6263440cb99a0c3886`**.

## Intended invocation and required provenance

Keep the helper at `campaign-artifacts/registration-with-errata-preparation/register_reviewed_page_with_errata.py`. It derives the sibling `campaign-worktree` and batch paths from that location, as the prior helper did from its own location.

After ROOT code review and fresh semantic acceptance, invoke the exact reviewed helper with page, first sequence, and two **literal SHA-256 values obtained from the accepted files**:

```text
python3 -B campaign-artifacts/registration-with-errata-preparation/register_reviewed_page_with_errata.py 100 298 --reviewed-errata-sha256 ACCEPTED_ERRATA_SHA256 --review-freeze-sha256 ACCEPTED_REVIEW_FREEZE_SHA256
```

The placeholders are deliberately not filled from the ongoing semantic review. These arguments bind the actual accepted `bank-ready-errata.json` and `review-freeze.json`; the existing root acceptance proof format otherwise pins only `review.md` and `review.json` directly. Re-freezing changed errata after acceptance cannot satisfy the old explicit pins. The helper must run without `-O`; it rejects an optimized interpreter before reading or writing task inputs.

The existing `baseline.json`, `proposal-baseline.json`, root semantic acceptance proof, root landed-copy proof, frozen semantic review, reconciled specs, landed spec/page/review copies, and unchanged baseline registry/index/allowance/errata files must be present. The proposal baseline must always contain `source_pins.spine.path`, `bytes`, and `sha256`, even when the governing origin equals the current HEAD. The path must name this worktree's source spine exactly; the size/hash must match the original database before any registration artifacts are created.

## Code rationale

### Preserve the accepted registration contract

The helper is a separate adaptation of the read and copied `register_reviewed_page_v3.py`. The existing helper remains untouched and still rejects nonempty errata.

The current acceptance baseline must equal Git HEAD and precede the page's three sequences. Both root proof files must name that HEAD, page, and sequence list, and retain the exact review hashes and landed-copy assertions. The semantic review and freeze must say APPROVE with no open findings. Frozen file paths remain confined to the semantic-review directory; duplicate JSON keys and duplicate frozen paths fail. This helper additionally checks every frozen file against its recorded size/hash and its banked byte-identical copy, including provenance evidence that registration does not otherwise consume.

Historical source origins retain their original meaning. A governing/source-origin commit different from current HEAD must equal the proposal baseline's commit and be an actual Git ancestor. It is never silently replaced by the current acceptance HEAD. Both commits are recorded in the proof. The proposal's spine identity is checked independently of that branch, so current-HEAD reviews cannot bypass original-source binding.

Each segment's reviewed spec remains byte-bound to the review metadata, reconciled copy, and banked copy; the landed combined spec must equal exactly those three accepted segments. The landed generator exit/spec hash/page presence checks remain. This code supplies no new semantic correspondence judgment and does not rerun the alignment generator or build the alignment layer.

Allowance normalization preserves v3's dictionary and two list forms. Only current C05 spans at depths 5 or 7 with English and a nonempty reviewed licensor may be added. Existing keys cannot be replaced. The insertion preserves the previous allowance bytes and is inverse-checked. Registry/index modifications use the existing exact unique anchors, inverse-byte checks, and Python AST parse. The registry, index, allowance, sidecar, and prose must all equal their actual HEAD preimages before preparation. Existing registered course entries, old coverage entries, and old allowance explanations cannot be silently changed.

### Validate the entire errata delta before native application

The accepted errata must be a nonempty list. Empty lists remain the v3 use case. Each entry must have exactly `seq`, `kind`, `found`, `expected`, `evidence`, `severity`, and `confidence`. Unknown fields, including a hypothetical `hgm_gloss`, fail instead of being silently dropped. Sequence values must be integers on this approved page; strings and booleans fail. All six content fields must be nonempty strings and kind/severity/confidence must belong to the existing supported sets. This path supports source document/ingest findings, not layer artefact, dismissed, or unverifiable class records.

The canonical merge strips leading/trailing whitespace in `found`. This wrapper refuses a frozen quote that would be changed by that normalization. It also refuses empty quotations, missing/ambiguous source rows, and quotations absent from all three original source columns. These stricter checks prevent the canonical tool's permissive cases from discarding or altering reviewed content.

`expected_errata` computes an assertion target only. It does not write a register or generate prose. Stable IDs must already be unique valid `E-NNN` values; the next IDs follow the original maximum, including gaps. Both existing and incoming duplicate signatures are checked with the canonical `(segment, found[:60])` rule. Thus distinct full quotations with the same canonical prefix cannot bypass duplicate handling, and a duplicate old record cannot be counted as a new addition. This closes the canonical tool's omission of an incoming-to-incoming duplicate check.

The source is opened using SQLite `mode=ro` and `PRAGMA query_only=ON`. Its complete file identity is checked against the proposal pin before/after quotation queries. Nonempty WAL/journal files fail rather than pretending a standalone byte copy is a complete snapshot. Full original rows and matching column names are recorded as quotation evidence. The English spelling proposal is only a register record; source bytes and HGM equivalents are never edited or promoted.

### Execute the actual canonical tools in isolation

The merge, prose generator, two errata gates, `hgm_tools.py`, and existing read-only SQLite wrapper are pinned to exact source hashes. Each repository dependency must also equal its current Git HEAD bytes. The current baseline `build_alignment_layer.py` is copied byte-identically for the merge tool's import; it is not executed as a builder. No canonical engine or gate is rewritten.

The helper creates a new staging workspace under the batch's new `landing/registration` directory, copying those exact dependencies, original sidecar/prose, accepted errata bytes, and original source database. The database is created exclusively and its device/inode ownership captured before copying; its copied bytes are verified and made read-only.

Seven native commands run through the exact existing SQLite read-only wrapper: baseline prose generation, merge dry run, merge apply, new prose generation, quotation gate, witness gate, and prose reproduction. Each actual command preserves argv, cwd, explicit environment adjustments, stdin, stdout, stderr, and numeric exit. Process launch failures and timeouts are named separately; timeout output is retained without inventing a numeric exit. No command output is reconstructed from expected results.

Baseline prose must already reproduce exactly from the old sidecar. The dry-run and apply summaries must each say that every input is added with zero duplicates/refusals. After apply, the entire decoded sidecar must equal the full original list followed by the exact expected new records, including stable IDs and the native note. Every original record byte is preserved up to the unavoidable old list-closing delimiter. This deliberately requires the original sidecar's existing canonical indentation format instead of accepting unrelated formatting churn.

The native prose output must reproduce byte-for-byte and both unmodified errata suites must pass. The original database, staged database, incoming bytes, wrapper, and copied dependencies are checked again. Exit zero by itself is insufficient: the fixture that makes the actual canonical merge add one record and refuse another returns zero, leaves a partial staged sidecar, and is rejected before any worktree write.

### Remove only the successful owned database copy

After all candidate/native verification succeeds, the helper checks the staging DB's exact expected resolved path, non-symlink regular-file status, original creation device/inode, size, complete hash, and distinctness from the original source. It records this identity and a hash inventory of all retained staged and native evidence in `staging-spine-cleanup.json`, rechecks ownership immediately before unlinking, removes that one file, and verifies the original source and every retained file again. The cleanup proof then states `REMOVED_VERIFIED_OWNED_COPY`.

This prevents the compact-banking copier from recursively archiving a redundant 249 MB source database per successful errata batch. Canonical failures keep their staging copies for inspection. Fixtures replacing the staging DB with byte-identical bytes at a different inode, or with a symlink to the original source, fail before cleanup and publication; neither original database is removed.

### Publish and recover the narrow five-file result

Before the first worktree write, the helper saves the complete candidate/preimage files, exact diff, method source, hashes, file modes, and PREPARED proof. All five target paths are guarded even when no allowance addition is needed. Every captured input and the original database are rechecked; then **all five** current target preimages/modes are checked before the first publication write. Each target is checked again immediately before its own write, with path/symlink/mode guards. Writes retain existing modes and unchanged candidates are skipped.

The proof tracks attempted writes separately from completed writes. On failure, recognized complete candidate bytes are restored to their exact preimages in reverse order, and already-original bytes are recorded as such. An unknown/truncated/concurrently altered value, symlink, changed mode, or failed restoration is retained and marked for manual recovery from the saved preimage. The helper never claims an incomplete rollback succeeded. Full proof files remain on disk; successful stdout contains a compact status/count/path summary.

## Actual verification evidence

`fixture-results-root-revision.json` records **61/61 PASS** on the exact final helper hash. `canonical-gate-fixture-results-root-revision.json` records **3/3 PASS** on that same hash. The synthetic fixture factory uses real temporary Git repositories, real SQLite databases, and copied byte-identical canonical modules. It does not substitute a fake Git response or rewritten merge/prose implementation.

The final cases cover seven successful registrations (multiple records, no allowances, all allowance forms, current/historical origin and source-origin alias), exact original-byte/mode preservation and stable IDs across gaps; 47 failures before registration artifacts; four native/prepublication fault cases; and three publication/concurrent-change recovery cases. The supplemental three cases execute the unmodified native quotation/witness gates to real exit 1, and detect committed baseline prose that does not reproduce from the sidecar. Each remains confined to staging.

Specific final evidence is in:

- `fixtures-root-revision/control/`: successful native commands, candidates, compact stdout, complete proof, and verified staging DB cleanup.
- `fixtures-root-revision/native_partial_apply/`: real native merge exit 0, stdout reporting one refused record, retained partial sidecar, retained stage DB, and zero worktree changes.
- `fixtures-root-revision/altered_spine_quote_retained/`: a changed unrelated source row leaves the proposed quote present but fails the reviewed proposal spine hash before artifacts/writes.
- `fixtures-root-revision/stage_db_replaced/` and `stage_db_symlink/`: refusal to delete a staging file whose ownership/path no longer matches.
- `fixtures-root-revision/second_write_failure/`: exact rollback of the first completed publication write.
- `fixtures-root-revision/truncated_second_write/`: original first target restored, truncated second target preserved and explicitly named for recovery.
- `fixtures-root-revision/late_target_drift/`: a changed final target detected before any publication write.
- `fixtures-root-revision/refrozen_errata_after_acceptance/`: explicit accepted SHA pins reject a replacement erratum even when its freeze is refreshed.
- `fixtures-canonical-gates-root-revision/`: actual quotation gate, witness gate, and canonical prose baseline failures.

Native stdout/stderr/exit/stdin/command records remain beside each fixture. Top-level `test-root-revision.*` and `test-gates-root-revision.*` are the actual test runner output. Earlier 52-case and 56-case results, their respective helper copies inside the fixtures, and their native evidence are retained under `fixtures/`, `fixtures-final/`, and the earlier result/output filenames; they are historical evidence for earlier helper hashes and are not represented as tests of the final candidate.

## Integration limits and boundaries

The canonical prose template still says that C03 is in progress and C04–C18 are unread at that depth. That inherited coverage sentence is recorded explicitly in the helper proof as a stale integration limit; this preparation does not alter canonical prose behavior or claim that the sentence is current campaign coverage.

This helper performs no semantic acceptance, source correction, layer/dictionary generation, CSV export, commit, staging in Git, bank-copy integration, or fixed-index/closure update. Future ordinary landing work must include the exact two errata files in the approved change/closure scope, bank the successful native/proof evidence, and run its existing downstream verification, including `verify_review_copy_and_register.py`. The full original errata prefix and exact allowed records must remain visible in that proof. The current live register's 192 entries are not hard-coded as a future global constant; a real run proves its actual current baseline prefix and count.

Publication is intentionally not claimed to be an atomic multi-file transaction. Recognized writes can be restored, and unrecognized partial/concurrent values are surfaced for controlled recovery. Existing Git HEAD/baseline and source hash checks prevent silent advancement, but the caller should retain the campaign's existing single-writer landing discipline. No actual H298 approval or production use is implied by these engineering fixtures.
