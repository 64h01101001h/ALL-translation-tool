"""Preserve unexecuted closure preparation and bind actual second whitespace pass."""
from pathlib import Path
import datetime,difflib,hashlib,json,shutil
B=Path(__file__).resolve().parent;A=B.parent;O=B/'frozen-helper-whitespace'
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
P=A/'close_c05_309_compact.py';old=P.read_text()
assert not (B/'compact-closure').exists()
shutil.copy2(P,O/'closure-before-audit-classification.py.txt');shutil.copy2(B/'closure-method-review.json',O/'closure-review-before.json')
new=old.replace("'root-whitespace-audit-caller'","'root-whitespace-audit-attempt02-caller'")
needle="assert read(B/'landing/registration/proof.json')['status']=='PASS'"
new=new.replace(needle,"assert read(B/'root-whitespace-audit-caller/execution.json')['exit']==1\nassert read(B/'frozen-helper-whitespace/root-review.json')['verdict']=='APPROVE'\nassert pin((A/'audit_staged_source_whitespace_v10.py').read_bytes())==read(B/'frozen-helper-whitespace/root-review.json')['method']\n"+needle)
needle="inputs=sorted(set(inputs)); members=[]"
new=new.replace(needle,"inputs.extend([A/'audit_staged_source_whitespace_v10.py',B/'prepare_frozen_helper_audit.py',B/'update_closure_for_recorded_audit.py'])\ninputs.extend(p for p in (B/'frozen-helper-whitespace').rglob('*') if p.is_file())\ninputs.extend(p for p in (B/'root-whitespace-audit-caller').rglob('*') if p.is_file())\n"+needle)
compile(new,str(P),'exec');P.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='prepared309closure',tofile='recorded309closure'));(O/'closure-update.diff.txt').write_text(diff)
review=json.loads((B/'closure-method-review.json').read_bytes());review.update(method=pin(P.read_bytes()),previous_unexecuted_preparation=pin(old.encode()),scope=review['scope']+' Addendum: root reviewed recorded first audit failure and exact four frozen helper space exception; closure now verifies actual successful attempt02, pins v10 to root review, and banks both complete diagnostics plus bounded method evidence. Other accepted-tree checks unchanged.',updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(B/'closure-method-review.json').write_text(json.dumps(review,indent=2)+'\n');print(diff);print(json.dumps(review['method']))
