"""Preserve four historical helper warnings without modifying frozen evidence."""
from pathlib import Path
import datetime,difflib,hashlib,json,shutil
B=Path(__file__).resolve().parent;A=B.parent;S=B/'semantic-review';L=B/'landing'
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
O=B/'frozen-helper-whitespace';O.mkdir(exist_ok=False)
prior=O/'first-audit';prior.mkdir()
for name in ('staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit','review-whitespace-exact-pins.json'):
 shutil.copy2(L/name,prior/name)
old=(A/'audit_staged_source_whitespace_v8.py').read_text()
new=old.replace('import datetime\n','import datetime\nimport io, tokenize\n',1)
needle="        elif pin['kind'] == 'blank_eof':"
addition='''        elif pin['kind'] == 'frozen_python_trailing_space':
            assert set(grouped) == {'trailing whitespace.'}
            assert grouped['trailing whitespace.'] == pin['lines'] == [53]
            assert (len(raw),digest) in {(17224,'3e641bb4697b2a42d41f091fa7768a812ca4a1d25f7ed1995d57c57b6e600f7c'),(17222,'298238a1407862abd26eadd8a2678e48f2e271fb4009732aed2a126d59b64201')}
            assert lines[52] == b'screen(309,\\'mental-movement expression and G-YO\\',\\'acip\\',"BLO\\'I G-YO BA SNGON DU BTANG NAS", '
            matching=[m for m in manifest if m['sha256']==digest and m['bytes']==len(raw) and m['original'].endswith('/finish_package.py')]
            assert matching and all(Path(m['original']).read_bytes()==raw for m in matching)
            cleaned=raw.split(b'\\n');cleaned[52]=cleaned[52][:-1];cleaned=b'\\n'.join(cleaned)
            tokens=lambda data:[(t.type,t.string) for t in tokenize.tokenize(io.BytesIO(data).readline)]
            assert tokens(raw)==tokens(cleaned)
            compile(raw,'frozen-original-helper','exec');compile(cleaned,'comparison-only-helper','exec')
'''
assert old.count(needle)==1;new=new.replace(needle,addition+needle)
new=new.replace("reason = 'Exact independently frozen evidence:","reason = 'Exact independently frozen evidence (including the two pinned historical Python files with token-identical outside-token trailing space):",1)
# Keep A-relative resolution: the executable helper resides beside v8.
target=A/'audit_staged_source_whitespace_v10.py';assert not target.exists();compile(new,str(target),'exec');target.write_text(new)
(O/'method.diff.txt').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='v8',tofile='v10')))
assert new.replace('import io, tokenize\n','').replace(addition,'').replace('Exact independently frozen evidence (including the two pinned historical Python files with token-identical outside-token trailing space):','Exact independently frozen evidence:')==old
pins=json.loads((L/'review-whitespace-exact-pins.json').read_bytes());f=json.loads((S/'review-freeze.json').read_bytes());added=[]
for r in f['files']:
 if r['sha256'] not in ('3e641bb4697b2a42d41f091fa7768a812ca4a1d25f7ed1995d57c57b6e600f7c','298238a1407862abd26eadd8a2678e48f2e271fb4009732aed2a126d59b64201'):continue
 raw=(S/r['path']).read_bytes();assert pin(raw)=={k:r[k] for k in ('bytes','sha256')}
 assert r['path'] not in pins;pins[r['path']]=dict(kind='frozen_python_trailing_space',lines=[53],**pin(raw));added.append(r['path'])
assert len(added)==4
(L/'review-whitespace-exact-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
proof=dict(status='EXACT_FROZEN_HELPER_PINS_PREPARED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),method=pin(target.read_bytes()),unchanged_v8_recovered_exactly=True,added=added,prior_diagnostic=pin((prior/'staged-diff-check.stdout').read_bytes()),scope='Only four frozen copies of two exact historical Python helper versions, one trailing space at known line53. Full source and review remain unchanged. Actual audit additionally verifies original-file identity and token stream equivalence after comparison-only removal. No canonical/source/fidelity gate change.')
(O/'preparation.json').write_text(json.dumps(proof,indent=2)+'\n');print((O/'method.diff.txt').read_text());print(json.dumps(proof,indent=2))
