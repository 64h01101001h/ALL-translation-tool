"""Adapt verified306 closure to actual309 fields without weakening tree checks."""
from pathlib import Path
import difflib
B=Path(__file__).resolve().parent;A=B.parent
old=(A/'close_c05_306_compact.py').read_text();new=old
changes={
 "B = A / 'C05-304-306'":"B = A / 'C05-307-309'",
 "BASE = 'f1651c64b0ad9b0c7ea85f9961332ac1a3787e83'":"BASE = '51d73c889a3f175b90e4c466f3dc4b1f7af3bca5'",
 'compact-reproduction-through306':'compact-reproduction-through309',
 "B/'semantic-review/freeze.json'":"B/'semantic-review/review-freeze.json'",
 "type(frozen['open_findings']) is int and frozen['open_findings']==0":"frozen['open_findings']==[]",
 "(frozen['total_spans'],frozen['total_nulls'],frozen['total_word_pairs'])==(75,12,43)":"(frozen['counts']['spans'],frozen['counts']['nulls'],frozen['counts']['nonnull_d5_word_pairs'])==(129,4,75)",
 "reviewroot/'freeze.json'":"reviewroot/'review-freeze.json'",
 '(304,305,306)':'(307,308,309)',
 "'root-register-attempt02-caller'":"'root-register-caller'",
 "assert read(B/'root-register-caller/execution.json')['exit']==1\n":"",
 'segments 304–306':'segments 307–309',
 'through segment 306':'through segment 309',
 'coverage=306,remaining=205':'coverage=309,remaining=202',
}
for before,after in changes.items():
 assert before in new,before;new=new.replace(before,after)
new=new.replace('c5p102','__CURRENT_PAGE__').replace('c5p101','c5p102').replace('__CURRENT_PAGE__','c5p103')
start=new.index("inputs.extend([Path(__file__).resolve(),B/'prepare_compact_closure.py'")
end=new.index("inputs.extend([A/'integration/through291-root-disposition.json'",start)
new=new[:start]+'''inputs.extend([Path(__file__).resolve(),B/'prepare_compact_closure.py',B/'closure-method-review.json',B/'closure-method.diff.txt',B/'root-semantic-disposition.json',B/'root-reconciliation-intake.json',B/'verify_root_current_intake.py',B/'accept_root_semantics.py'])
inputs.extend([A/'audit_staged_source_whitespace_v6.py',A/'audit_staged_source_whitespace_v7.py',A/'audit_staged_source_whitespace_v8.py',A/'C05-286-288/compact-reproduction-review/whitespace-v7-review.json',A/'C05-292-294/whitespace-v8-root-review.json'])
inputs.extend([A/'register_reviewed_page_v4.py',A/'prepare_review_whitespace_pins_v2.py',A/'C05-304-306/registration-v4-root-review.json',A/'C05-304-306/whitespace-pin-v2-root-review.json'])
# Whole original/reconciliation and prior semantic boundaries are already in the
# current1249-file semantic package. Their exact pins were root verified.
''' +new[end:]
out=A/'close_c05_309_compact.py';assert not out.exists();compile(new,str(out),'exec');out.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='close_c05_306_compact.py',tofile=out.name));(B/'closure-method.diff.txt').write_text(diff);print(diff)
