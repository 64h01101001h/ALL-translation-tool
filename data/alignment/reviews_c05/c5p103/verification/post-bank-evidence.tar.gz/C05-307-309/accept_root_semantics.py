"""Record root judgment after complete semantic reading and exact current intake."""
from pathlib import Path
import datetime,hashlib,json,subprocess
B=Path(__file__).resolve().parent;S=B/'semantic-review';W=B.parents[1]/'campaign-worktree'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
i=read(B/'root-reconciliation-intake.json');assert i['status']=='PASS_ROOT_CURRENT_INTAKE'
f=read(S/'review-freeze.json');m=read(S/'review.json')
assert f['verdict']==f['spec_verdict']==f['quality_verdict']==m['verdict']=='APPROVE'
assert f['open_findings']==m['open_findings']==[]
assert pin(S/'review-freeze.json')==i['review_freeze'] and pin(S/'review.md')==i['semantic_report']
assert (m['total_spans'],m['total_nulls'],m['total_word_pairs'])==(129,4,75)
assert read(S/'bank-ready-errata.json')==[]
assert set(read(S/'span-head-allow-needed.json')['pages_c05'])=={'c5p103/s308w23','c5p103/s309w8','c5p103/s309w11'}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert head==i['baseline']==read(B/'baseline.json')['commit']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W)
out=dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),page='c5p103',segments=[307,308,309],counts=dict(spans=129,nulls=4,nonnull_d5=75,total_d5=76,d7=30),source_origin=i['source_origin'],actual_baseline=head,review=pin(S/'review.md'),review_json=pin(S/'review.json'),review_freeze=pin(S/'review-freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),read_evidence=i['reading'],semantic_decision='Accept the occurrence-specific schools/existence and appearance correspondences after full original-to-final review. Distinguish the second visual-consciousness predicate in307 from burning-steel appears in308. The corrected three308 rationales now address actual W200:205/E349:356, preserving original snang ba to snang tightening. Accept mental intention as whole blo g-yo idiom in309; do not invent a separate g-yo mental intention word equivalent. Preserve repeated created/maker occurrences and supported contiguous compound members. All uncertain/distributed meanings remain unbanked with reasons.',null_decisions='307 gnyis is fused into the two-school enumeration, not later both referring to object/perception.307 zhig has no separate indefinite exponent in actual pus and blood.308 gyis and yis are fused into active subjects three types of beings and Who made. These four have explicit source-function grounds; uncertainty is not represented as null.',errata='Nine complete five-ground screens reviewed; no bankable new errata. Internal corpus parallels confirm only the stated shared fields/phrases, without publication independence. Retain registered historical/source discrepancies without altering GMR wording.',execution_reuse='Root independently resolved all366 original/final spans and verified six original plus three fresh final native execution inputs/outputs/errors/exits. No duplicate root generator execution for rationale-only correction. Aggregate production generation and normal fidelity/reproduction checks remain required after landing.',limits='The review freeze truthfully predates capture of actual306 baseline. Root binds current exact original-source identity and the actual51d73 baseline here; no retrospective reviewer consumption claim. Provisional machine acceptance only; no hgm_gloss promotion, human editorial signoff, MAIN application or device acceptance inferred.')
p=B/'root-semantic-disposition.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
