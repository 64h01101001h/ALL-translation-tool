"""Bind root's completed semantic reading to actual source and execution bytes.

The six original and three independent final generator executions are reused,
not rerun. Canonical occurrence resolution is independently called by root.
"""
from pathlib import Path
from collections import Counter
import datetime, gzip, hashlib, importlib.util, json, sqlite3, subprocess, sys
B=Path(__file__).resolve().parent; A=B.parent; W=A.parent/'campaign-worktree'; S=B/'semantic-review'
def read(p): return json.loads(p.read_bytes())
def pin(raw): return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,d):
    assert not p.exists(),p
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def verify_freeze(base,name,expected):
    assert pin((base/name).read_bytes())['sha256']==expected
    f=read(base/name); rows=f['files']; rows=rows.items() if isinstance(rows,dict) else ((r['path'],r) for r in rows)
    n=0
    for rel,r in rows:
        assert (base/rel).resolve().is_relative_to(base.resolve())
        assert pin((base/rel).read_bytes())=={k:r[k] for k in ('bytes','sha256')},rel
        n+=1
    return n
counts={}
for label,base,name,h in [
 ('tibetan',B/'tibetan','freeze-final-v1.json','63204cb888eb18983948cdd7c208c557cc33481c38433f7a523d412b906d3c60'),
 ('english',B/'english','freeze.json','b16de542d7780bfa0334123c8132b3826cdef3815f32ac0218618d8213ce27f8'),
 ('reconciled',B/'reconciled','freeze.json','0ebc1b362a42c3382549cc14ce7c5bdcb5a63794fbc9c42953ae6cb7d608e2d0'),
 ('semantic',S,'review-freeze.json','8d4ada44323d8df7100624fdc1975faee95af0f24ee9a40df0f049135ff1b68f'),
 ('prior-reconciliation',B/'reconciled/history/F1-before','freeze.json','13cdeba610f4eb8dcc5ececd95722411660de9835ef750a0118a6947da1118a9'),
 ('prior-semantic',S/'history/NEEDS_CORRECTION-F1','review-freeze.json','ce740d16169172187470e3c8ff60871d73d50b74adb7bab08214d279577fbb08')]:
    counts[label]=verify_freeze(base,name,h)
history=read(B/'reconciled/correction-F1/original-to-history-byte-map.json')['records']
for r in history: assert pin((B/'reconciled'/r['history']).read_bytes())=={k:r[k] for k in ('bytes','sha256')}
origin=read(B/'proposal-baseline.json'); baseline=read(B/'baseline.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert head==baseline['commit']=='51d73c889a3f175b90e4c466f3dc4b1f7af3bca5'
assert baseline['course_boundary']==306
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W)
for r in origin['source_pins'].values(): assert pin(Path(r['path']).read_bytes())=={k:r[k] for k in ('bytes','sha256')}
assert pin((W/'tools/gen_alignment_page.py').read_bytes())=={k:origin['governing_git_pins']['tools/gen_alignment_page.py'][k] for k in ('bytes','sha256')}
sys.path.insert(0,str(W/'tools'))
definition=importlib.util.spec_from_file_location('root_canonical_generator',W/'tools/gen_alignment_page.py')
g=importlib.util.module_from_spec(definition);definition.loader.exec_module(g)
db=sqlite3.connect((W/'build/hgm_spine_v27_2.db').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
sources={r['seq']:dict(r) for r in db.execute('SELECT * FROM corpus_segments WHERE course=? AND seq BETWEEN ? AND ? ORDER BY seq',('C05',307,309))}
for r in read(B/'source.json'): assert all(sources[r['seq']][k]==v for k,v in r.items())
resolved=[]; reports=[]; executions=[]; originals={}
for angle in ('tibetan','english','final'):
    for seq in (307,308,309):
        directory=B/'reconciled'/str(seq) if angle=='final' else B/angle/str(seq)
        native=S/'commands'/f'final-native-{seq}' if angle=='final' else B/'reconciled/native-original-replays'/angle/str(seq)
        raw=(directory/'spec.json').read_bytes(); body=(directory/'body.html').read_bytes(); spec=json.loads(raw)['segments'][0]
        assert (native/'stdin.bin').read_bytes()==raw and (native/'stdout.bin').read_bytes()==body
        assert (native/'stderr.bin').read_bytes()==b'' and (native/'exit.txt').read_bytes()==b'0\n'
        command=read(native/'command.json'); assert command['env_override']['PYTHONDONTWRITEBYTECODE']=='1'
        if angle!='final': assert command['stdin_source']==str(directory/'spec.json') and command['saved_body']==str(directory/'body.html')
        spans=spec['spans']; byid={s['id']:s for s in spans}; src=sources[seq]
        tr=g.resolve(src['wylie'],spans,'tib',seq)
        er=g.resolve(src['english'],g.with_members(spans,[byid[i] for i in spec['eng_order']],src['english']),'eng',seq)
        rows=[dict(seq=seq,id=s['id'],d=s['d'],tib=s['tib'],eng=s['eng'],tib_range=list(tr[s['id']]),eng_range=list(er[s['id']]) if s['eng'] is not None else None) for s in spans]
        observed={r['side']:r['ranges'] for r in read(native/'observed-ranges.json')['resolutions']}
        for r in rows: assert r['tib_range']==observed['tib'][r['id']] and r['eng_range']==observed['eng'].get(r['id'])
        executions.append(dict(angle=angle,seq=seq,directory=str(native),spec=pin(raw),body=pin(body),exit=0,stderr_bytes=0,action='REUSE actual independent native execution; root called canonical resolver only'))
        if angle=='final':
            tuples=read(directory/'final-ordered-tuples.json')['tuples']
            assert rows==[dict(seq=seq,**{k:r['span'][k] for k in ('id','d','tib','eng')},tib_range=r['tib_range'],eng_range=r['eng_range']) for r in tuples]
            resolved+=rows
            reports.append(dict(seq=seq,spans=len(spans),depths=dict(Counter(s['d'] for s in spans)),nulls=sum(s['eng'] is None for s in spans),nonnull_d5=sum(s['d']==5 and s['eng'] is not None for s in spans),errata_candidates=len(read(directory/'errata.json')),generator_exit=0,body_bytes=len(body),exact_saved_body=True,body_sha256=pin(body)['sha256'],spec_sha256=pin(raw)['sha256'],execution_reused=str(native)))
        else: originals[(angle,seq)]={r['id']:r for r in rows}
assert resolved==read(S/'resolved-spans.json') and len(resolved)==129
dispositions=0
for seq in (307,308,309):
    for d in read(B/f'reconciled/{seq}/original-span-dispositions.json')['decisions']:
        o=originals[(d['angle'],seq)][d['original_span']['id']]
        assert all(o[k]==d['original_span'][k] for k in ('id','d','tib','eng'))
        assert o['tib_range']==d['actual_original_tib_range'] and o['eng_range']==d['actual_original_eng_range']
        dispositions+=1
assert dispositions==237
master=json.load(gzip.open(W/'data/hgm_dictionary_v27_2.json.gz','rt')); corpus=json.load(gzip.open(W/'data/full_parallel_corpus_v32.json.gz','rt'))
full_master=set(); full_corpus=set()
def verify_records(x):
    if isinstance(x,list):
        for v in x: verify_records(v)
    elif isinstance(x,dict):
        if {'collection','index','record'}<=x.keys():
            assert master[x['collection']][x['index']]==x['record'];full_master.add((x['collection'],x['index']))
        if {'id','course','acip','wylie','english','raw'}<=x.keys():
            assert json.loads(x['raw'])==corpus[x['id']-1]
            assert all(corpus[x['id']-1][k]==x[k] for k in ('course','acip','wylie','english')); full_corpus.add(x['id'])
        for v in x.values(): verify_records(v)
for p in [S/'independent/master-full-records.json',S/'independent/remaining-cited-records.json',S/'independent/source-context-full-rows.json',S/'independent/all-query-results.json']+[B/f'reconciled/{q}/errata-five-grounds.json' for q in (307,308,309)]: verify_records(read(p))
db.close()
out=B/'root-reconciliation-verification';out.mkdir(exist_ok=False)
save(out/'resolved-spans.json',resolved); save(out/'report.json',reports);save(out/'execution-reuse.json',executions)
proof=dict(status='PASS_ROOT_CURRENT_INTAKE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=head,source_origin=origin['commit'],frozen_file_counts=counts,history_files=len(history),original_dispositions=dispositions,original_native_replays_reused=6,independent_final_native_executions_reused=3,root_generator_executions=0,root_canonical_resolution_spans=sum(len(v) for v in originals.values())+len(resolved),exact_full_master_objects=len(full_master),exact_full_corpus_objects=len(full_corpus),reading='Root read all three complete source texts, six original specs/reports, all237 original dispositions and all129 final reasons/ranges/annotations,17 material omissions and32 original omission dispositions, all9 full five-ground judgment texts and entire old fresh report plus complete current diff including recovered truncated paragraph. Fifteen complete critical master objects and four full contextual corpus witnesses were separately read and matched earlier. Large repeated evidence objects were omitted only from reading projections; actual object identity is checked here. No semantic judgment is inferred solely from this mechanical check.',semantic_report=pin((S/'review.md').read_bytes()),reconciliation_freeze=pin((B/'reconciled/freeze.json').read_bytes()),review_freeze=pin((S/'review-freeze.json').read_bytes()))
save(B/'root-reconciliation-intake.json',proof);print(json.dumps(proof,indent=2))
