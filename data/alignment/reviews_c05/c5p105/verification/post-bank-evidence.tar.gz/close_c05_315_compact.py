"""Bind existing passing evidence to the exact staged tree, then checkpoint privately.

No generators, tests, source edits, integration, or prior proof trees are repeated.
Every Git command has a native record. Refuses a second invocation's output path.
"""
from pathlib import Path
import datetime, hashlib, io, json, os, subprocess, tarfile

A = Path(__file__).resolve().parent
R = A.parent
W = R / 'campaign-worktree'
B = A / 'C05-313-315'
O = B / 'compact-closure'
BASE = '49b66f3af9cbb47599bb40286637fc9e683b7cdf'
V = W / 'data/alignment/reviews_c05/c5p105/verification'
REPRO = Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through315')
O.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(b): return dict(bytes=len(b), sha256=sha(b))
def read(p): return json.loads(p.read_bytes())
def save(p, d): p.write_text(json.dumps(d, indent=2, ensure_ascii=False)+'\n')
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(label, *args, allowed=(0,)):
    d=O/label; d.mkdir()
    argv=['git', *args]; started=utc()
    save(d/'command.json',dict(argv=argv,cwd=str(W),started_at=started,environment_overrides={'GIT_OPTIONAL_LOCKS':'0'}))
    (d/'stdin.bin').write_bytes(b'')
    result=subprocess.run(argv,cwd=W,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),input=b'',capture_output=True)
    for n,b in [('stdout.bin',result.stdout),('stderr.bin',result.stderr),('exit.txt',f'{result.returncode}\n'.encode())]: (d/n).write_bytes(b)
    save(d/'execution.json',dict(argv=argv,cwd=str(W),started_at=started,finished_at=utc(),exit=result.returncode,stdout=pin(result.stdout),stderr=pin(result.stderr)))
    assert result.returncode in allowed,(label,result.returncode)
    return result.stdout
def names(b): return [x.decode() for x in b.split(b'\0') if x]

assert git('incoming','rev-parse','HEAD').decode().strip()==BASE
assert not git('unstaged-entry','diff','--name-only','-z')
frozen=read(B/'semantic-review/freeze.json')
assert frozen['verdict']=='APPROVE' and frozen['open_findings']==[]
assert (frozen['total_spans'],frozen['total_nulls'],frozen['total_word_pairs'])==(95,1,67)
reviewroot=W/'data/alignment/reviews_c05/c5p105'
for relative, value in frozen['files'].items():
    row=dict(path=relative,**value)
    original=(B/'semantic-review'/row['path']).read_bytes()
    assert pin(original)=={k:row[k] for k in ('bytes','sha256')}
    assert (reviewroot/row['path']).read_bytes()==original
assert (reviewroot/'freeze.json').read_bytes()==(B/'semantic-review/freeze.json').read_bytes()
for seq in (313,314,315):
    assert (reviewroot/f'{seq}-reconciliation.md').read_bytes()==(B/f'reconciled/{seq}/report.md').read_bytes()
for caller in ('semantic-acceptance-caller','root-semantic-intake-caller','landing-caller','landed-semantic-acceptance-caller','registration-caller','registered-copy-check-caller','canonical-builders-caller','ctest-17-caller','retention-caller','course-csv-caller','compact-reproduction-caller','compact-bank-caller','stage-data-caller','whitespace-audit-attempt03-caller'):
    d=B/caller; ex=read(d/'execution.json')
    assert ex['exit']==0 and (d/'exit.txt').read_bytes()==b'0\n'
    for stream in ('stdout','stderr'):
        raw=(d/f'{stream}.bin').read_bytes()
        assert len(raw)==ex[f'{stream}_bytes'] and sha(raw)==ex[f'{stream}_sha256']
build=read(B/'landing/canonical-builds-once.json')
assert build['status']=='PASS' and build['baseline_commit']==BASE
for path,h in build['output_sha256'].items(): assert sha((W/path).read_bytes())==h,path
repro=read(REPRO/'proof.json')
assert repro['status']=='PASS' and repro['baseline_commit']==BASE and len(repro['outputs'])==7
for row in repro['outputs']: assert pin((W/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
wh=read(B/'landing/source-whitespace-proof.json')
assert wh['all_warnings_accounted_for'] and wh['baseline_head']==BASE
assert sha((A/'audit_staged_source_whitespace_v7.py').read_bytes())==read(A/'C05-286-288/compact-reproduction-review/whitespace-v7-review.json')['v7_sha256']
assert read(A/'C05-286-288/compact-reproduction-review/whitespace-v7-review.json')['verdict']=='APPROVE'
assert sha((A/'audit_staged_source_whitespace_v8.py').read_bytes())==read(A/'C05-292-294/whitespace-v8-root-review.json')['v8_sha256']
assert read(A/'C05-292-294/whitespace-v8-root-review.json')['verdict']=='APPROVE'
assert read(B/'format-adapters/review.json')['verdict']=='APPROVE'
adapter=read(B/'format-adapters/review.json')['changes']
assert len(adapter)==2
for row in adapter:
    assert sha((A/row['old']).read_bytes())==row['old_sha256']
    assert sha((A/row['new']).read_bytes())==row['new_sha256']
for failed in ('root-reconciliation-inputs-caller','root-reconciliation-inputs-attempt02-caller','root-reconciliation-inputs-attempt03-caller','root-reconciliation-inputs-attempt04-caller','root-reconciliation-inputs-attempt05-caller'):
    assert read(B/failed/'execution.json')['exit']==1
assert read(B/'root-reconciliation-inputs-attempt06-caller/execution.json')['exit']==0
assert read(B/'registration-format-adaptation.json')['verdict']=='APPROVE'
assert read(B/'bank-preparation-caller/execution.json')['exit']==0
assert read(B/'whitespace-audit-caller/execution.json')['exit']==1
assert read(B/'whitespace-audit-attempt02-caller/execution.json')['exit']==1
assert read(B/'whitespace-latin1-independent-review.json')['verdict']=='APPROVE'
assert read(B/'whitespace-latin1-independent-review.json')['method_sha256']==sha((A/'audit_staged_source_whitespace_v12.py').read_bytes())

assert read(B/'root-semantic-disposition.json')['verdict']=='APPROVE_ROOT_SEMANTIC_ACCEPTANCE'
assert read(B/'root-reconciliation-intake.json')['review_freeze']==pin((B/'semantic-review/freeze.json').read_bytes())
assert read(B/'landing/registration/proof.json')['status']=='PASS'
assert sha((B/'landing/staged-diff-check.stdout').read_bytes())==wh['raw_log_sha256']
for path,row in wh['files'].items(): assert pin((W/path).read_bytes())=={k:row[k] for k in ('bytes','sha256')}

# Archive only late evidence and bounded current method/history bindings.
inputs=[B/'landing'/n for n in ('source-whitespace-proof.json','review-whitespace-exact-pins.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit','root-ledger-entry-template.md')]
for caller in ('whitespace-audit-attempt03-caller','compact-bank-caller','stage-data-caller','retention-caller','compact-reproduction-caller'):
    inputs.extend(sorted(p for p in (B/caller).rglob('*') if p.is_file()))
inputs.extend([Path(__file__).resolve(),B/'prepare_compact_closure.py',B/'closure-method-review.json',B/'closure-method.diff.txt',B/'root-semantic-disposition.json',B/'root-reconciliation-intake.json',B/'verify_root_reconciliation_inputs.py',B/'accept_root_semantics.py'])
inputs.extend([A/'audit_staged_source_whitespace_v6.py',A/'audit_staged_source_whitespace_v7.py',A/'audit_staged_source_whitespace_v8.py',A/'audit_staged_source_whitespace_v11.py',A/'C05-286-288/compact-reproduction-review/whitespace-v7-review.json',A/'C05-292-294/whitespace-v8-root-review.json'])
inputs.extend([A/'register_reviewed_page_v5.py',A/'register_reviewed_page_v6.py',A/'prepare_review_whitespace_pins_v3.py',B/'registration-format-adaptation.json',B/'registration-format-adaptation.diff'])
# All408 fresh frozen files remain readable in the banked review. Complete
# historical through309 integration native evidence remains once at its source.
inputs.extend([A/'integration/through309-root-disposition.json',A/'integration/through309-current-assessment/review.md',A/'integration/through309-current-assessment/assessment.json',A/'integration/through309-current-assessment/freeze.json'])
for folder in ('format-adapters','root-intake-schema-correction','bank-preparation-caller','root-reconciliation-inputs-caller','root-reconciliation-inputs-attempt02-caller','root-reconciliation-inputs-attempt03-caller','root-reconciliation-inputs-attempt04-caller','root-reconciliation-inputs-attempt05-caller','root-reconciliation-inputs-attempt06-caller'):
    inputs.extend(p for p in (B/folder).rglob('*') if p.is_file())
inputs.extend([A/'audit_staged_source_whitespace_v12.py',B/'pin_native_eof.py',B/'prepare_latin1_whitespace.py',B/'whitespace-latin1-independent-review.json'])
for folder in ('whitespace-history','whitespace-latin1-history','whitespace-latin1-history-attempt02','whitespace-audit-caller','whitespace-audit-attempt02-caller','whitespace-eof-pin-caller','latin1-whitespace-preparation-caller','latin1-whitespace-preparation-attempt02-caller','closure-preparation-history','closure-preparation-caller'):
    inputs.extend(p for p in (B/folder).rglob('*') if p.is_file())
inputs.extend([A/'prepare_review_whitespace_pins_v4.py',B/'whitespace-pin-v4.diff.txt'])
for folder in ('whitespace-pin-v4-preflight','whitespace-pin-v4-preflight-caller'):
    inputs.extend(p for p in (B/folder).rglob('*') if p.is_file())
inputs=sorted(set(inputs)); members=[]
archive=V/'post-bank-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'x:gz') as tf:
    for p in inputs:
        raw=p.read_bytes(); name=str(p.relative_to(A)); info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644
        tf.addfile(info,io.BytesIO(raw)); members.append(dict(original=str(p),member=name,**pin(raw)))
with tarfile.open(archive,'r:gz') as tf:
    assert tf.getnames()==[m['member'] for m in members]
    for m in members: assert tf.extractfile(m['member']).read()==Path(m['original']).read_bytes()
save(V/'post-bank-manifest.json',dict(archive=pin(archive.read_bytes()),members=members,all_members_byte_equal=True,scope='Actual late whitespace, bank/stage callers and bounded method evidence. Earlier native-evidence archive unchanged.'))
git('stage-post-bank','add','--',str(archive.relative_to(W)),str((V/'post-bank-manifest.json').relative_to(W)))
paths=names(git('staged-paths','diff','--cached','--name-only','-z'))
fixed=set(build['output_sha256'])-{'data/hgm_dictionary_v27_2.json.gz','data/full_parallel_corpus_v32.json.gz'}
fixed.update(['data/alignment/pages_c05/c5p104.html','data/alignment/pages_c05/c5p105.html','data/alignment/pages_c05/index.html','data/alignment/specs_c05/c5p105.json','tools/build_alignment_layer.py','data/alignment/span_head_allow.json'])
assert fixed.issubset(paths)
assert all(p in fixed or p.startswith('data/alignment/reviews_c05/c5p105/') for p in paths)
records=[]
index={}
for row in git('accepted-index-entries','ls-files','--stage','-z').split(b'\0'):
    if not row: continue
    meta,path=row.split(b'\t',1);mode,oid,stage=meta.split()
    assert stage==b'0' and path.decode() not in index
    index[path.decode()]=(mode.decode(),oid.decode())
for i,path in enumerate(paths):
    raw=(W/path).read_bytes()
    # Git's blob hash verifies the exact staged bytes, without copying each blob again.
    mode,oid=index[path]
    assert mode==('100755' if path=='tools/build_alignment_layer.py' else '100644'),path
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid,path
    records.append(dict(path=path,git_blob=oid,**pin(raw)))
assert not git('unstaged-final','diff','--name-only','-z')
diag=git('final-whitespace','diff','--cached','--check',allowed=(2,))
assert diag==(B/'landing/staged-diff-check.stdout').read_bytes()
tree=git('accepted-index-tree','write-tree').decode().strip()
save(O/'accepted-index.json',dict(status='PASS',baseline=BASE,tree=tree,files=records,semantic_frozen_files=len(frozen['files']),seven_outputs_match_reproduction=True,whitespace_diagnostic_unchanged=pin(diag),source_archives_unchanged=True))
git('commit-data','commit','-m','Bank reviewed provisional C05 alignments for segments 313–315')
data=git('data-head','rev-parse','HEAD').decode().strip()
assert git('data-parent','rev-parse',data+'^').decode().strip()==BASE
assert git('data-tree','rev-parse',data+'^{tree}').decode().strip()==tree

entry=(B/'landing/root-ledger-entry-template.md').read_text().replace('@DATA@',data).replace('@BASE@',BASE).replace('@UTC@',utc())
assert '@DATA@' not in entry and '@BASE@' not in entry and '@UTC@' not in entry
assert not any(line.endswith(' ') for line in entry.splitlines())
rawentry=entry.encode(); (O/'ledger-entry.md').write_bytes(rawentry)
ledgers=['data/alignment/C05_CAMPAIGN.md','docs/handoff/HANDOFF_LOG.md','docs/superpowers/plans/2026-09-12-aci-alignment-campaign.md']
ledger_records=[]
for i,path in enumerate(ledgers):
    old=git(f'ledger-before-{i}','show',data+':'+path)
    assert (W/path).read_bytes()==old and rawentry not in old
    with (W/path).open('ab') as f: f.write(rawentry)
    assert (W/path).read_bytes()==old+rawentry
    ledger_records.append(dict(path=path,before=pin(old),after=pin(old+rawentry)))
assert set(names(git('ledger-changes','diff','--name-only','-z')))==set(ledgers)
git('stage-ledgers','add','--',*ledgers)
assert set(names(git('staged-ledger-paths','diff','--cached','--name-only','-z')))==set(ledgers)
assert not git('ledger-whitespace','diff','--cached','--check')
git('commit-docs','commit','-m','Record verified C05 coverage through segment 315 and integration limits')
final=git('final-head','rev-parse','HEAD').decode().strip()
assert git('docs-parent','rev-parse',final+'^').decode().strip()==data
assert set(names(git('docs-changes','diff','--name-only','-z',data,final)))==set(ledgers)
for i,row in enumerate(ledger_records):
    after=git(f'ledger-final-{i}','show',final+':'+row['path'])
    old=(O/f'ledger-before-{i}/stdout.bin').read_bytes()
    assert after==old+rawentry==(W/row['path']).read_bytes()
assert not git('final-tracked-state','status','--porcelain','--untracked-files=no')
untracked=names(git('untracked','ls-files','--others','--exclude-standard','-z'))
assert untracked==['data/teaching/dcc_captions'],untracked
proof=dict(status='PASS_FIXED_PRIVATE_CHECKPOINT',utc=utc(),incoming=BASE,data=data,final=final,coverage=315,remaining=196,accepted_index_tree=tree,data_tree_equals_accepted_index=True,ledgers=ledger_records,all_prior_ledger_bytes_preserved=True,tracked_clean=True,untracked=untracked,main='OPEN_NO_APPLICATION',phone='FAILED_UNACCEPTED; no installation; installed through171 unchanged')
save(O/'proof.json',proof)
print(json.dumps(proof,indent=2))
