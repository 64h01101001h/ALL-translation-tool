"""Bind one frozen native stdout to the audit's existing blank_eof class."""
from pathlib import Path
import hashlib,json,shutil,datetime
B=Path(__file__).resolve().parent;S=B/'semantic-review';L=B/'landing'
H=B/'whitespace-history';H.mkdir(exist_ok=False)
for name in ['review-whitespace-exact-pins.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit']:
    shutil.copy2(L/name,H/name)
rel='native/evidence-rechecks-v2/stdout.bin';raw=(S/rel).read_bytes()
assert len(raw)==565 and hashlib.sha256(raw).hexdigest()=='63bf1b23388c180034fb45bbd1260086da74ac3f5ea0d7c3e23b4096320f68f2'
record=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert json.loads((S/'freeze.json').read_bytes())['files'][rel]==record
assert (B.parents[1]/'campaign-worktree/data/alignment/reviews_c05/c5p105'/rel).read_bytes()==raw
assert raw.endswith(b'}\n\n') and not b''.join(raw.split(b'\n')[17:]).strip()
data=json.loads(raw);assert data==json.loads((S/'evidence/independent-evidence-proof.json').read_bytes())
pins=json.loads((L/'review-whitespace-exact-pins.json').read_bytes());assert rel not in pins
pins[rel]=dict(kind='blank_eof',**record)
(L/'review-whitespace-exact-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'review.json').write_text(json.dumps(dict(verdict='APPROVE_EXISTING_BLANK_EOF_PIN',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),path=rel,identity=record,judgment='The actual frozen successful native summary ends in a verified empty line after JSON. The unchanged v11 audit already supports blank_eof. Pin this exact file; no new class, no source or review byte normalization.',actual_failed_caller='whitespace-audit-caller'),indent=2)+'\n')
print(json.dumps(dict(status='PINNED',path=rel,identity=record)))
