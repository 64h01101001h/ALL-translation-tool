"""Adapt the verified312 closure to the exact315 evidence; preserve every gate."""
from pathlib import Path
import difflib
B=Path(__file__).resolve().parent;A=B.parent
old=(A/'close_c05_312_compact.py').read_text();new=old
changes={
"B = A / 'C05-310-312'":"B = A / 'C05-313-315'",
"BASE = '8575edf1e0de695677194c1fde60f1d9e2c2f204'":"BASE = '49b66f3af9cbb47599bb40286637fc9e683b7cdf'",
'compact-reproduction-through312-attempt02':'compact-reproduction-through315',
'==(110,1,73)':'==(95,1,67)',
'(310,311,312)':'(313,314,315)',
'segments 310–312':'segments 313–315',
'through segment 312':'through segment 315',
'coverage=312,remaining=199':'coverage=315,remaining=196',
}
for before,after in changes.items():
    assert before in new,before;new=new.replace(before,after)
new=new.replace('c5p104','__CURRENT_PAGE__').replace('c5p103','c5p104').replace('__CURRENT_PAGE__','c5p105')
start=new.index("assert read(B/'root-register-caller/execution.json')['exit']==1")
end=new.index("assert read(B/'root-semantic-disposition.json')",start)
new=new[:start]+'''for failed in ('root-reconciliation-inputs-caller','root-reconciliation-inputs-attempt02-caller','root-reconciliation-inputs-attempt03-caller','root-reconciliation-inputs-attempt04-caller','root-reconciliation-inputs-attempt05-caller'):
    assert read(B/failed/'execution.json')['exit']==1
assert read(B/'root-reconciliation-inputs-attempt06-caller/execution.json')['exit']==0
assert read(B/'registration-format-adaptation.json')['verdict']=='APPROVE'
assert read(B/'bank-preparation-caller/execution.json')['exit']==0
''' +new[end:]
names={
'root-semantic-acceptance-caller':'semantic-acceptance-caller',
'root-semantic-decision-caller':'root-semantic-intake-caller',
'root-materialize-caller':'landing-caller',
'root-landed-copy-caller':'landed-semantic-acceptance-caller',
'root-register-attempt02-caller':'registration-caller',
'root-register-copy-check-caller':'registered-copy-check-caller',
'root-canonical-builders-caller':'canonical-builders-caller',
'root-retention-caller':'retention-caller',
'root-course-csv-caller':'course-csv-caller',
'root-compact-reproduction-attempt02-caller':'compact-reproduction-caller',
'root-compact-bank-caller':'compact-bank-caller',
'root-stage-data-caller':'stage-data-caller',
'root-whitespace-audit-caller':'whitespace-audit-caller',
}
for before,after in names.items():assert before in new;new=new.replace(before,after)
start=new.index("inputs.extend([A/'register_reviewed_page_v4.py'")
end=new.index('inputs=sorted(set(inputs)); members=[]',start)
new=new[:start]+'''inputs.extend([A/'register_reviewed_page_v5.py',A/'register_reviewed_page_v6.py',A/'prepare_review_whitespace_pins_v3.py',B/'registration-format-adaptation.json',B/'registration-format-adaptation.diff'])
# All408 fresh frozen files remain readable in the banked review. Complete
# historical through309 integration native evidence remains once at its source.
inputs.extend([A/'integration/through309-root-disposition.json',A/'integration/through309-current-assessment/review.md',A/'integration/through309-current-assessment/assessment.json',A/'integration/through309-current-assessment/freeze.json'])
for folder in ('format-adapters','root-intake-schema-correction','bank-preparation-caller','root-reconciliation-inputs-caller','root-reconciliation-inputs-attempt02-caller','root-reconciliation-inputs-attempt03-caller','root-reconciliation-inputs-attempt04-caller','root-reconciliation-inputs-attempt05-caller','root-reconciliation-inputs-attempt06-caller'):
    inputs.extend(p for p in (B/folder).rglob('*') if p.is_file())
''' +new[end:]
needle="'data/alignment/specs_c05/c5p105.json','tools/build_alignment_layer.py'"
assert needle in new;new=new.replace(needle,needle+",'data/alignment/span_head_allow.json'")
out=A/'close_c05_315_compact.py';assert not out.exists();compile(new,str(out),'exec');out.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='close_c05_312_compact.py',tofile=out.name))
(B/'closure-method.diff.txt').write_text(diff)
print(diff)
