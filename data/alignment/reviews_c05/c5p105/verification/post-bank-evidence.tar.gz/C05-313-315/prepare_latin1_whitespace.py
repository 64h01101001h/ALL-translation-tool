"""Preserve the failed audit and pin an exactly reversible source display."""
from pathlib import Path
import datetime,difflib,hashlib,json,shutil
B=Path(__file__).resolve().parent;A=B.parent;S=B/'semantic-review';L=B/'landing'
H=B/'whitespace-latin1-history-attempt02';H.mkdir(exist_ok=False)
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
for n in ['review-whitespace-exact-pins.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit']:
    shutil.copy2(L/n,H/n)
rel='proposal-inputs/evidence/72cdac1ded02daf6b0a98a932f38be5c624ee3f52ffa4091b40405810fb80f1d.txt'
raw=(S/rel).read_bytes();f=json.loads((S/'freeze.json').read_bytes())['files'];assert f[rel]==pin(raw)
witness=Path(json.loads((B/'proposal-baseline.json').read_bytes())['source_pins']['physical']['path']);source=witness.read_bytes()
assert pin(source)=={k:json.loads((B/'proposal-baseline.json').read_bytes())['source_pins']['physical'][k] for k in ['bytes','sha256']}
assert source.decode('latin1').encode('utf8')==raw and raw.decode('utf8').encode('latin1')==source
pins=json.loads((L/'review-whitespace-exact-pins.json').read_bytes());assert rel not in pins
pins[rel]=dict(kind='reversible_latin1_utf8_view',**pin(raw),witness=dict(path=str(witness),**pin(source)))
old=(A/'audit_staged_source_whitespace_v11.py').read_text()
needle="        elif pin['kind'] == 'physical_source_lines':"
replacement="""        elif pin['kind'] == 'reversible_latin1_utf8_view':
            assert set(grouped) == {'trailing whitespace.'}
            witness = Path(pin['witness']['path'])
            witness_raw = witness.read_bytes()
            assert len(witness_raw) == pin['witness']['bytes']
            assert hashlib.sha256(witness_raw).hexdigest() == pin['witness']['sha256']
            assert (len(witness_raw), hashlib.sha256(witness_raw).hexdigest()) in physical
            assert witness_raw.decode('latin1').encode('utf8') == raw
            assert raw.decode('utf8').encode('latin1') == witness_raw
            assert raw.count(b'\\n') == witness_raw.count(b'\\n')
            source_lines = witness_raw.split(b'\\n')
            for n in grouped['trailing whitespace.']:
                assert lines[n-1].endswith(b'\\r') and source_lines[n-1].endswith(b'\\r')
                assert lines[n-1].decode('utf8').encode('latin1') == source_lines[n-1]
"""+needle
assert old.count(needle)==2;new=old.replace(needle,replacement,1)
new=new.replace("if pin['kind'] in ('physical_bytes', 'physical_chunk_stdout'):","if pin['kind'] in ('physical_bytes', 'physical_chunk_stdout', 'reversible_latin1_utf8_view'):")
p=A/'audit_staged_source_whitespace_v12.py';assert not p.exists();compile(new,str(p),'exec');p.write_text(new)
(H/'method.diff.txt').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='audit_staged_source_whitespace_v11.py',tofile=p.name)))
(L/'review-whitespace-exact-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(H/'binding.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),view=rel,view_pin=pin(raw),witness=dict(path=str(witness),**pin(source)),bidirectionally_exact=True,prior_method=pin(old.encode()),new_method=pin(new.encode()),scope='Additional explicitly pinned reversible display class. Every original byte, view byte and reported CRLF warning is proven; no source/view mutation or blanket waiver.'),indent=2)+'\n')
print((H/'method.diff.txt').read_text())
