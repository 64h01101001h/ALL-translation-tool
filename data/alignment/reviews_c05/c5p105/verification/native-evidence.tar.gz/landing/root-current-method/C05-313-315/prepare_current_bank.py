"""Bank current evidence and append-only ledger facts without historical recopy."""
from pathlib import Path
import datetime,hashlib,json,shutil
B=Path(__file__).resolve().parent;A=B.parent
def read(p):return json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
R=Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through315')
assert read(R/'proof.json')['status']=='PASS'
assert read(B/'ctest-17-caller/execution.json')['exit']==0
adapt=B/'format-adapters';adapt.mkdir(exist_ok=False)
shutil.copy2(A/'C05-310-312/format-adapters/review.json',adapt/'review.json')
for row in read(adapt/'review.json')['changes']:
    for label in ['old','new']:assert pin(A/row[label])['sha256']==row[label+'_sha256']
save(B/'registration-format-adaptation.json',dict(verdict='APPROVE',old=pin(A/'register_reviewed_page_v5.py'),new=pin(A/'register_reviewed_page_v6.py'),diff=pin(B/'registration-format-adaptation.diff'),judgment='Explicit allowlisted reconciliation freeze filename replaces an assumed name. Identical exact freeze SHA, source/baseline, span/licensor, copy and preimage checks remain. No frozen file is renamed or rewritten.'))
dest=B/'landing/root-current-method';dest.mkdir(exist_ok=False)
files=[Path(__file__).resolve()]+[B/n for n in ['accept_root_semantics.py','verify_root_reconciliation_inputs.py','root-reconciliation-intake.json','root-semantic-disposition.json','root-reconciliation-reading.json','root-original-reading-addendum.json','registration-format-adaptation.json','registration-format-adaptation.diff']]+[A/n for n in ['register_reviewed_page_v5.py','register_reviewed_page_v6.py','prepare_review_whitespace_pins_v3.py','audit_staged_source_whitespace_v11.py']]
for folder in ['root-reconciliation-inputs','root-intake-schema-correction','format-adapters']:
    files.extend(p for p in (B/folder).rglob('*') if p.is_file())
I=A/'integration';files.extend([I/'through309-root-disposition.json']+[I/'through309-current-assessment'/n for n in ['freeze.json','review.md','assessment.json','future-reuse-method.md']])
records=[]
for p in sorted(set(files)):
    rel=p.relative_to(A);t=dest/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);assert t.read_bytes()==p.read_bytes()
    records.append(dict(original=str(p),copy=str(t.relative_to(dest)),**pin(p)))
save(dest/'manifest.json',records)
review=B/'compact-reproduction-review';review.mkdir(exist_ok=False)
save(review/'method-review.json',dict(verdict='APPROVE_REUSE_UNCHANGED_REPRODUCTION_METHOD',methods={n:pin(A/n) for n in ['reproduce_generated_outputs.py','run_reproduction_readonly.py']},prior_passing_proof=str(A/'C05-310-312/compact-closure/proof.json'),current_proof=str(R/'proof.json'),judgment='Exact unchanged source-copy, incoming CSV seed, source guards, seven whole-output equality and unchanged-input checks. Current reproduction starts only after passing retention. No successful native work repeated for packaging.',limits='Production/source fidelity only; no MAIN runtime or device acceptance.'))
entry='''

### 2026-09-14 — independently reviewed C05:313–315; private coverage315/511

- Accepted95 provisional spans,1 null,67 nonnull depth-5 pairs (68 total d5),11 depth-7 members and3 source anchors:98 new links. Per313:32/0/24;314:54/0/39;315:9/1/4 (spans/nulls/nonnull d5).196 C05 segments remain316–511; C06 waits for full C05, C13 stays blocked upstream.
- Source/proposal/reconciliation origin8575edf1e0de695677194c1fde60f1d9e2c2f204 through309 is distinct from actual acceptance @BASE@ through312. Originals139/127 files; reconciliation730; fresh semantic408. Fresh SPEC/QUALITY APPROVE, zero open findings, freeze7a237aa7df978736cda8aa8851d9e6af98720d4d5a5fd7fcce2151febe1b1bf6. All1045 original-copy records checked before/after landing. All183 original dispositions,95 final decisions,17 material omissions and15 five-ground screens retained. Two exact314 la sogs pa head licences registered; no new erratum,194 register entries unchanged.
- Root independently resolved278 original/final spans, reran31 SQL queries, checked162 complete master and99 complete corpus objects and6 physical fields. Complete source-specific decisions were read, with37 full critical master objects and full C05:28/146 witnesses separately read. English external evidence has19 field queries plus3 complete-tuple comparisons; the historical shorthand22 queries is not22 homogeneous SQL executions. Original Tibetan five-ground file is tibetan/evidence/five-ground-errata-review.json. Broad identity checks do not claim fresh linguistic scrutiny of every metadata string.
- Preserve complete313 necessity/negation and tshad grub pa with members, one causal because,314 enumeration/shape/steel compounds and own occurrences,315 whole author epithet and work title. Sole315 rtsa ba null records absent separate root-text wording; mdzod owns Abhidharmakosha. Isolated yod pa/occupy, extra mountain repetition and distributed authorship/relations stay unbanked. Original apparatus remains verbatim; nothing enters hgm_gloss.
- Fresh reviewer generated each final once, exact with empty stderr; six original and three reconciled generator proofs reused after byte checks. Aggregate production builders passed once in14.399356s. All17 fidelity tests passed12.13s. All46571 prior links and22902 prior main-CSV rows, notes, trees, evidence, ACIP and references retained. Current46669 links,11976 nulls,7144 heads,15778 evidence pairs,22928 main-CSV rows and24558 course-depth groups. Seven full outputs reproduce exactly once from559 registered pages and the actual16509904-byte incoming CSV seed SHA8d696e062ac18a46b8cd458cc3f69e9b246aa163299e38dcf5d2e82917fb9a01. External proof: compact-reproduction-through315/proof.json under the campaign evidence drive.
- Five actual root intake failures arose from representation assumptions: optional source-copy path, null metadata beyond canonical ranges, query/comparison mix, record references versus embedded objects, and a register wrapper. Failed native streams and each method version are preserved; attempt06 passed. No source, spec or individual generator changed. Registration v6 explicitly binds the actual reconciliation freeze filename; whitespace preparation v3/audit v11 are unchanged byte-preserving methods. No new warning exception or source normalization.
- Fixed private DATA @DATA@ follows @BASE@. Exact staged-tree/source/review/output bindings precede commit; this identical append-only entry is committed to all three ledgers. Completion @UTC@. Actual Git streams, parent/tree and clean tracked state remain in compact-closure/proof.json.
- Isolated desktop-consumable outputs are verified through315. Existing complete through309 MAIN applicability assessment remains referenced once:314 native whole-file partitions/38782 paths/3502 evidence files. No new315 MAIN applicability or runtime claim; MAIN remains unapplied. Phone remains FAILED_UNACCEPTED for four inherited C01 mappings; no install, historical through171 unchanged. Rendering/QSettings/runtime,42 depth shortfalls and28 trim calls remain open. Preserve other work and external evidence.
- Workflow now overlaps root acceptance,316–318 fresh review and319–321 independent originals. Removed unused preliminary lexical scan; standard freeze filename/dictionary formats and indexed full evidence are requested for new work. Acceptance stays sequential in three-segment batches. Existing one-minute automation remains active through2026-09-15 07:00 America/Denver, then pause. No paid generation, release or external-account action.
'''
p=B/'landing/root-ledger-entry-template.md';assert not p.exists();p.write_text(entry)
print(json.dumps(dict(status='PREPARED',method_files=len(records),ledger_bytes=p.stat().st_size)))
