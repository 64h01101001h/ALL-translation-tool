"""Bind root's completed independent reading to the unchanged frozen inputs.

Identity checks do not supply the semantic judgment recorded below. Reuse
successful canonical evidence without repeating the individual generators.
"""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess
B=Path(__file__).resolve().parent; S=B/'semantic-review'; Q=B/'reconciled'
W=B.parents[1]/'campaign-worktree'
def read(p): return json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes(); return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(p,obj):
    assert not p.exists(),p
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=W)
f=read(S/'freeze.json');m=read(S/'review.json');old=read(B/'root-reconciliation-inputs/proof.json')
assert pin(S/'freeze.json')['sha256']=='7a237aa7df978736cda8aa8851d9e6af98720d4d5a5fd7fcce2151febe1b1bf6'
assert f['verdict']==f['spec_verdict']==f['quality_verdict']==m['verdict']=='APPROVE'
assert f['open_findings']==m['open_findings']==[]
assert len(f['files'])==f['file_count']==408
for rel,expected in f['files'].items():
    p=S/rel; assert p.resolve().is_relative_to(S.resolve())
    assert pin(p)==expected,rel
for rel in f['exclusions']['unsupported_runtime_helpers_preserved_exactly_under_methods']:
    assert (S/rel).read_bytes()==(S/'methods'/(Path(rel).name+'.txt')).read_bytes()
assert old['status']=='PASS_ROOT_RECONCILIATION_INPUTS_PENDING_FRESH_SEMANTIC_ACCEPTANCE'
assert old['reconciliation_freeze']==pin(Q/'FINAL-FREEZE.manifest.json')
for folder,name in [('tibetan','FINAL-FREEZE.manifest.json'),('english','freeze-manifest.json'),('reconciled','FINAL-FREEZE.manifest.json')]:
    files=read(B/folder/name)['files']; assert len(files)==old['frozen_files'][folder]
    items=files.items() if isinstance(files,dict) else ((r['path'],r) for r in files)
    for rel,r in items: assert pin(B/folder/rel)=={k:r[k] for k in ['bytes','sha256']}
resolved=read(B/'root-reconciliation-inputs/resolved-spans.json')
assert resolved==read(S/'resolved-spans.json') and len(resolved)==95
decisions=read(S/'span-decisions.json')
assert [{k:r[k] for k in resolved[0]} for r in decisions]==resolved
originals=read(S/'original-disposition-review.json'); assert len(originals)==183
for seq in [313,314,315]:
    expected=read(Q/str(seq)/'original-dispositions.json')['spans']
    actual=[r for r in originals if r['seq']==seq]
    assert [(r['angle'],r['original']['id'],r['decision'],r['final_ids']) for r in expected]==[(r['angle'],r['original_id'],r['original_decision'],r['final_ids']) for r in actual]
assert len(read(S/'omission-decisions.json'))==17
assert len(read(S/'five-ground-refutations.json'))==15
assert read(S/'bank-ready-errata.json')==[]
assert set(read(S/'span-head-allow-needed.json')['pages_c05'])=={'c5p105/s314w2','c5p105/s314w22'}
assert (m['total_spans'],m['total_nulls'],m['total_word_pairs'],m['total_d7'])==(95,1,67,11)
native=[]
for seq in [313,314,315]:
    p=S/f'native/fresh-final-{seq}-v1';ex=read(p/'execution.json')
    assert ex['exit']==0 and (p/'exit.txt').read_bytes()==b'0\n' and (p/'stderr.bin').read_bytes()==b''
    assert ex['cwd']==str(S) and ex['environment_override']=={'PYTHONDONTWRITEBYTECODE':'1'}
    assert '-B' in ex['argv'] and ex['argv'][-1]==str(S/'helpers/canonical.py')
    for stream,expected in ex['streams'].items(): assert pin(p/(stream+'.bin'))==expected
    assert (p/'stdin.bin').read_bytes()==(Q/str(seq)/'spec.json').read_bytes()
    assert (p/'stdout.bin').read_bytes()==(Q/str(seq)/'body.html').read_bytes()
    native.append(dict(seq=seq,path=str(p),execution=pin(p/'execution.json'),streams=ex['streams']))
head=git('rev-parse','HEAD').decode().strip()
assert head==old['baseline']==read(B/'baseline.json')['commit']==f['later_supplied_acceptance_baseline']
assert not git('status','--porcelain','--untracked-files=no')
receipt=read(S/'evidence/later-acceptance-receipt.json')
assert receipt['baseline_sha256']==pin(B/'baseline.json')['sha256']
assert receipt['original_reconciler_consumed_later_baseline'] is False
compat=B/'root-reconciliation-verification';compat.mkdir(exist_ok=False)
shutil.copy2(B/'root-reconciliation-inputs/resolved-spans.json',compat/'resolved-spans.json')
reading=dict(completed='Root read the complete source arguments, six original specs/reports and all183 original decisions/dispositions, all95 final ranges/reasons/order and17 omissions, original and reconciled fifteen category judgments, fresh report and95 independent reasons plus17 omission and15 five-ground judgments. Repeated complete evidence objects are identity-bound, not claimed as fresh linguistic reading of every metadata string.',critical_full_master_objects_read=37,critical_corpus_rows_fully_read=['C05:28','C05:146'],source_specific_conclusions='313 full certainty/necessity negation and tshad grub pa compound retained; the one causal chain uses because once.314 complete enumerative formulas and shape/steel compounds retained with members and exact occurrences; isolated yod pa/occupy omitted as distributed.315 author identity including attested epithet and complete title with three members retained; rtsa ba alone has no separate root-text exponent. Authorship, extra mountain repetition, distributed relations and following headings remain unbanked.',display_limits='Oversized repetitive displays were truncated; omitted judgment portions were re-read in bounded projections. No full-stream or fresh inspection of all duplicated embedded metadata is claimed.',original_reading_receipt=pin(B/'root-original-reading-addendum.json'),five_ground_path_correction='Original Tibetan screens are tibetan/evidence/five-ground-errata-review.json, not per-segment files.',external_query_terminology='English corpus-queries.json has22 evidence records:19 field queries and3 exact three-field tuple comparisons. All are checked; do not describe them as22 homogeneous SQL queries.')
put(B/'root-reconciliation-reading.json',reading)
intake=dict(status='PASS_ROOT_CURRENT_INTAKE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=head,source_origin=old['source_origin'],frozen_file_counts={**old['frozen_files'],'semantic':408},reading=reading,prior_root_checks=pin(B/'root-reconciliation-inputs/proof.json'),root_canonical_resolution_spans=278,root_generator_executions=0,independent_final_native_executions_reused=3,original_native_replays_reused=6,semantic_report=pin(S/'review.md'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(Q/'FINAL-FREEZE.manifest.json'),fresh_native_identity=native,limits=['Original-to-copy manifest checked by standard acceptance gate before landing.','Five failed root metadata/representation assumptions preserved with exact native errors and superseded helper bytes; sources and generators unchanged.','Digital parallels establish no publication or ingestion independence.'])
put(B/'root-reconciliation-intake.json',intake)
out=dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),page='c5p105',segments=[313,314,315],counts=dict(spans=95,nulls=1,nonnull_d5=67,total_d5=68,d7=11),source_origin=old['source_origin'],actual_baseline=head,review=pin(S/'review.md'),review_json=pin(S/'review.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(Q/'FINAL-FREEZE.manifest.json'),read_evidence=reading,semantic_decision=reading['source_specific_conclusions'],null_decisions='Only315 rtsa ba: root text has no separate exponent; mdzod already owns Abhidharmakosha. Uncertain/distributed items remain omissions, not nulls.',errata='Fifteen complete five-ground screens produce no new bankable erratum. BRTZOMS remains physically attested but does not establish a required emendation. Registered194 entries unchanged.',allowances=read(S/'span-head-allow-needed.json'),execution_reuse='278 canonical original/final resolutions independently checked. All six original and three reconciled successful native generator proofs reused exactly, with three fresh independent reviewer generations. Aggregate production and required fidelity checks follow.',limits='Provisional machine acceptance only; no hgm_gloss promotion, human editorial approval, MAIN application, merged runtime or device acceptance.')
put(B/'root-semantic-disposition.json',out)
print(json.dumps(dict(status=out['verdict'],page=out['page'],counts=out['counts'],review_freeze=out['review_freeze']),indent=2))
