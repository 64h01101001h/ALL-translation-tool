"""Root source/range/evidence intake, independent of the semantic verdict.

Reuse exact native generator proofs. Resolve every original/final span with
the unchanged canonical functions, and reopen full source evidence once.
"""
from pathlib import Path
from collections import Counter
import datetime,gzip,hashlib,importlib.util,json,os,re,sqlite3,subprocess,sys
B=Path(__file__).resolve().parent; Q=B/'reconciled'; W=B.parents[1]/'campaign-worktree'
O=B/'root-reconciliation-inputs'; assert not O.exists()
def read(p):return json.loads(p.read_bytes())
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def exp(r):return {k:r[k] for k in ('bytes','sha256')}
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
def occ(t,q):return [m.start() for m in re.finditer('(?='+re.escape(q)+')',t)]
frozen={}
for angle,name,sha in [('tibetan','FINAL-FREEZE.manifest.json','3dc43622702361a9c504165dcce0fd6335eb7d29aeb0e084a42013d711181e4e'),('english','freeze-manifest.json','250ecf94bf4056ec4046c3c73ac626dd3c6e63e7b4c6097bff0d627783baf609'),('reconciled','FINAL-FREEZE.manifest.json','9f833498613874c621c456101ae1604cf5430e66f77fc851f5e1a695e94ac76a')]:
    p=B/angle/name;assert pin(p.read_bytes())['sha256']==sha;f=read(p)['files']
    items=f.items() if isinstance(f,dict) else [(x['path'],x) for x in f]
    for rel,r in items:
        p=B/angle/rel;assert p.resolve().is_relative_to((B/angle).resolve());assert pin(p.read_bytes())==exp(r),p
    frozen[angle]=len(f)
origin=read(B/'proposal-baseline.json');base=read(B/'baseline.json')
assert origin['commit']=='8575edf1e0de695677194c1fde60f1d9e2c2f204'
assert base['commit']==git('rev-parse','HEAD').decode().strip()=='49b66f3af9cbb47599bb40286637fc9e683b7cdf'
assert base['course_boundary']==312 and not git('status','--porcelain','--untracked-files=no')
for r in origin['source_pins'].values():assert pin(Path(r['path']).read_bytes())==exp(r)
for rel,r in origin['governing_git_pins'].items():assert pin(git('show',origin['commit']+':'+rel))==exp(r)
for r in read(Q/'evidence/git-pins.json'):
    assert pin(git('show',r['git_object']))==exp(r)==pin((Q/r['path']).read_bytes())
copies=read(Q/'evidence/copy-identities.json')
for r in copies:
    raw=Path(r['original_path']).read_bytes();assert pin(raw)==exp(r)
    assert raw==(Q/r['object']).read_bytes()
    if 'logical_copy' in r:assert raw==(Q/r['logical_copy']).read_bytes()
    else:assert r['role'].startswith('source-')
for r in read(Q/'evidence/required-access.json'):assert os.access(r['path'],os.R_OK)
P=Q/'evidence/pinned';sys.path.insert(0,str(P/'engines'));sys.path.insert(0,str(P/'tools'))
for rel in ['tools/gen_alignment_page.py','tools/build_alignment_layer.py']:
    assert pin((P/rel).read_bytes())==exp(origin['governing_git_pins'][rel])
import gen_alignment_page as G
db=sqlite3.connect(Path(origin['source_pins']['spine']['path']).as_uri()+'?mode=ro',uri=True)
db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
sources={r['seq']:dict(r) for r in db.execute('SELECT * FROM corpus_segments WHERE course=? AND seq BETWEEN ? AND ? ORDER BY seq',('C05',313,315))}
for name in ['source.json','context.json']:
    for r in read(B/name):
        actual=dict(db.execute('SELECT * FROM corpus_segments WHERE course=? AND seq=?',(r['course'],r['seq'])).fetchone())
        assert all(actual[k]==v for k,v in r.items())
resolved={};native=[];reports=[]
keys=['seq','id','d','tib','eng','tib_range','eng_range']
for angle in ['tibetan','english','final']:
    for seq in [313,314,315]:
        p=Q/str(seq) if angle=='final' else B/angle/str(seq)
        raw=(p/'spec.json').read_bytes();spec=json.loads(raw);assert spec['course']=='C05' and len(spec['segments'])==1
        seg=spec['segments'][0];assert seg['seq']==seq;spans=seg['spans'];byid={r['id']:r for r in spans};assert len(byid)==len(spans)
        tr=G.resolve(sources[seq]['wylie'],spans,'tib',seq)
        er=G.resolve(sources[seq]['english'],G.with_members(spans,[byid[i] for i in seg['eng_order']],sources[seq]['english']),'eng',seq)
        rows=[dict(seq=seq,**{k:s[k] for k in ['id','d','tib','eng']},tib_range=list(tr[s['id']]),eng_range=list(er[s['id']]) if s['eng'] is not None else None) for s in spans]
        stem=f'final-{seq}' if angle=='final' else f'original-{angle}-{seq}'
        for mode in ['generator','resolver']:
            n=Q/'native'/f'{stem}-{mode}-v1';ex=read(n/'execution.json')
            assert ex['exit']==0 and (n/'exit.txt').read_bytes()==b'0\n' and (n/'stderr.bin').read_bytes()==b''
            assert (n/'stdin.bin').read_bytes()==raw and ex['environment_override']['PYTHONDONTWRITEBYTECODE']=='1'
            assert ex['cwd']==str(Q) and '-B' in ex['argv']
            for stream,r in ex['streams'].items():assert pin((n/(stream+'.bin')).read_bytes())==r
            if mode=='generator':assert (n/'stdout.bin').read_bytes()==(p/'body.html').read_bytes()
            else:
                observed=read(n/'stdout.bin');assert [{k:r[k] for k in keys} for r in observed]==rows
                for s,r in zip(spans,observed,strict=True):assert all(r[k]==v for k,v in s.items())
        resolved[(angle,seq)]=rows
        native.append(dict(angle=angle,seq=seq,stem=stem,spec=pin(raw),body=pin((p/'body.html').read_bytes()),generator_exit=0,root_generator_runs=0))
        if angle=='final':
            tuples=read(p/'final-ordered-tuples.json');assert [{k:(seq if k=='seq' else r[k]) for k in keys} for r in tuples['source_order']]==rows
            decisions=read(p/'final-decisions.json');assert [{k:r[k] for k in keys} for r in decisions['spans']]==rows
            assert decisions['eng_order']==seg['eng_order'] and read(p/'resolved-ranges.json')==observed
            assert read(p/'errata.json')==[]
            counts=dict(spans=len(rows),nulls=sum(r['eng'] is None for r in rows),nonnull_d5=sum(r['d']==5 and r['eng'] is not None for r in rows),d7=sum(r['d']==7 for r in rows))
            ver=read(p/'verification.json');assert all(ver['counts'][k]==v for k,v in counts.items())
            reports.append(dict(seq=seq,**counts))
dispositions=Counter();changed=[];omissions=0
for seq in [313,314,315]:
    d=read(Q/str(seq)/'original-dispositions.json');final={r['id']:r for r in resolved[('final',seq)]};rationales={r['id']:r['rationale'] for r in read(Q/str(seq)/'final-decisions.json')['spans']};seen=set()
    for r in d['spans']:
        angle=r['angle'];oid=r['original']['id'];key=(angle,oid);assert key not in seen;seen.add(key)
        orig=next(x for x in resolved[(angle,seq)] if x['id']==oid)
        original_spec=next(x for x in read(B/angle/str(seq)/'spec.json')['segments'][0]['spans'] if x['id']==oid)
        assert all((orig[k] if k in keys else original_spec[k])==v for k,v in r['original'].items())
        for fid in r['final_ids']:assert r['final_rationales'][fid]==rationales[fid]
        exact=any(all(orig[k]==final[fid][k] for k in ['d','tib','eng','tib_range','eng_range']) for fid in r['final_ids'])
        dispositions[r['decision']]+=1
        if not exact:changed.append(dict(seq=seq,**r))
    assert len(seen)==sum(len(resolved[(a,seq)]) for a in ['tibetan','english'])
    omissions+=len(read(Q/str(seq)/'final-decisions.json')['material_omissions'])
master=json.load(gzip.open(origin['source_pins']['master']['path'],'rt'));corpus=json.load(gzip.open(origin['source_pins']['corpus']['path'],'rt'))
collections={k:(list(master[k].values()) if isinstance(master[k],dict) else master[k]) for k in ['unified_entries','curated_entries','glossary_entries']}
master_ids=set();corpus_ids=set()
def records(term):
    return [dict(collection=c,index=i,entry=r) for c,rows in collections.items() for i,r in enumerate(rows) if isinstance(r,dict) and (r.get('wylie')==term or term in (r.get('wylie_variants') or []))]
lex=read(Q/'evidence/full-lexical-evidence.json')
for r in lex:
    assert r['master_records']==records(r['term']) and r['count']==len(r['master_records'])
    master_ids.update((v['collection'],v['index']) for v in r['master_records'])
for r in read(B/'english/evidence/lexical-evidence.json'):
    assert r['master_records']==records(r['term']) and r['count']==len(r['master_records'])
for filename in ['full-master-records.json','supplemental-full-master-records.json']:
    for r in read(B/'tibetan/evidence'/filename):
        q=r['query'];actual=[v for v in collections['unified_entries'] if v.get(q['field'])==q['equals']]
        assert r['records']==actual and len(actual)==r['count']
def check_corpus(r):
    assert json.loads(r['raw'])==corpus[r['id']-1]
    assert all(corpus[r['id']-1][k]==r[k] for k in ['course','acip','wylie','english'])
    corpus_ids.add(r['id'])
queries=read(Q/'evidence/original-query-rechecks.json')
for r in queries:
    actual=[dict(x) for x in db.execute(r['sql'],r['params'])]
    assert actual==r['complete_rows'] and len(actual)==r['original_count']==r['rechecked_count']
    for row in actual:check_corpus(row)
for r in sources.values():check_corpus(r)
external=read(B/'english/evidence/corpus-queries.json')
for r in external:
    if 'corpus_count' in r:
        rows=r['corpus_records'];assert r['corpus_count']==len(rows)==r['count']
    else:
        assert r['comparison']=='exact ACIP/Wylie/English tuple; course/id/seq not asserted identical'
        rows=r['records'];assert len(rows)==r['count']
        expected=[dict(corpus_index=i,record=v) for i,v in enumerate(corpus) if all(v[k]==sources[r['origin_seq']][k] for k in ['acip','wylie','english'])]
        assert rows==expected
    for row in rows:assert corpus[row['corpus_index']]==row['record']
physical_count=0
for r in read(Q/'evidence/physical-complete-row-proof.json'):
    raw=Path(r['original_physical_path']).read_bytes();assert pin(raw)['sha256']==r['sha256']
    assert raw[slice(*r['acip_exact_raw_byte_range'])].decode('ascii')==sources[r['seq']]['acip']
    folded=' '.join(raw.decode('latin1').split());assert folded[slice(*r['english_range_in_linefolded_latin1'])]==sources[r['seq']]['english'];physical_count+=2
register=read(P/'docs/errata_register.json');reg={r['item_id']:r for r in register};screens=0
for seq in [313,314,315]:
    for r in read(Q/str(seq)/'errata-audit.json')['all_original_source_suspicions']:
        screens+=1;assert r['refuted'] and not r['new_erratum'] and r['expected'] is None
        g=r['five_refutation_grounds'];a=g['a_quote']
        source_row=next(v for v in read(Q/str(seq)/a['source_full_row']) if v['seq']==seq)
        assert source_row==sources[seq]
        for field,positions in a['occurrences_in_each_source_field'].items():assert occ(sources[seq][field],r['found'])==positions
        assert not g['b_parallel']['independent_publication_or_ingestion_lineage_established']
        classes=read(Q/str(seq)/g['c_registered']['full_class_records'])
        assert classes['historical_register_origin']==origin['commit'] and classes['register_count']==194
        for v in classes['records']:assert reg[v['item_id']]==v
        assert g['e_counts']['register_count_rechecked']==len(register)==194
        assert g['e_counts']['field_lengths']=={k:len(sources[seq][k]) for k in ['acip','wylie','english']}
        for c in g['e_counts']['relevant_counts']:
            original=read(B/c['original_file'])[c['original_index']];assert c['claimed']==c['remeasured']==original['count']
db.close();assert screens==15 and sum(dispositions.values())==183
finals=sum((resolved[('final',seq)] for seq in [313,314,315]),[]);assert len(finals)==95 and sum(r['nonnull_d5'] for r in reports)==67
O.mkdir()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
save('resolved-spans.json',finals);save('original-resolved-spans.json',[dict(angle=a,seq=s,rows=v) for (a,s),v in resolved.items() if a!='final']);save('changed-original-dispositions.json',changed);save('execution-reuse.json',native);save('report.json',reports)
proof=dict(status='PASS_ROOT_RECONCILIATION_INPUTS_PENDING_FRESH_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=base['commit'],source_origin=origin['commit'],frozen_files=frozen,copy_records=len(copies),root_generator_runs=0,reused_original_generator_runs=6,reused_reconciled_generator_runs=3,root_canonical_resolved_spans=sum(len(v) for v in resolved.values()),dispositions=dict(dispositions),material_omissions=omissions,five_ground_screens=screens,actual_SQL_queries=len(queries),complete_master_objects=len(master_ids),complete_corpus_objects=len(corpus_ids),physical_extents=physical_count,reconciliation_freeze=pin((Q/'FINAL-FREEZE.manifest.json').read_bytes()),limits=['Fresh semantic verdict not consumed by this step.','Full external corpus records reopened by exact index; SQL query counts rederived independently in the original source spine.','No production acceptance or source/master write; historical metadata counts remain historical.'])
save('proof.json',proof);print(json.dumps(proof,indent=2))
