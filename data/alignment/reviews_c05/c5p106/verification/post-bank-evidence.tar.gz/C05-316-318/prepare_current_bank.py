"""Prepare current evidence and a proof-derived append-only ledger; do not commit.

Run once after the current production, fidelity, retention and reproduction pass.
No generators, tests, source changes or historical proof-tree copies occur here.
"""
from pathlib import Path
import datetime, hashlib, json, re, shutil, stat

B=Path(__file__).resolve().parent; A=B.parent; W=A.parent/'campaign-worktree'
R=Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through318')
BASE='af139c573f85aaf33278cd079719947ee9af8cdd'
FREEZE='81e6c82c71c035e51661aeed9056b502fecf5b2de8a5bdd01bc9c887a5098d21'
RECON='51aa8fc419bbd25ea20a21d0ea4524b1c964888891c7aa0c400b449c3f6ba314'
def read(p): return json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes(); return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

method_review=read(B/'closure-method-review.json')
assert method_review['verdict']=='APPROVE_ROOT_CURRENT_CLOSURE_METHOD'
for name,value in method_review['methods'].items(): assert pin(A/name)==value,name
assert pin(B/'closure-method.diff.txt')['sha256']==method_review['diff_sha256']
f=read(B/'semantic-review/freeze.json'); meta=read(B/'semantic-review/review.json')
assert pin(B/'semantic-review/freeze.json')['sha256']==FREEZE
assert pin(B/'reconciled/freeze.json')['sha256']==RECON
assert f['file_count']==len(f['files'])==494 and len(read(B/'reconciled/freeze.json')['files'])==356
assert f['verdict']==f['spec_verdict']==f['quality_verdict']=='APPROVE' and f['open_findings']==[]
assert f['later_supplied_acceptance_baseline']==BASE and f['later_baseline_accepted_through']==315
assert (f['total_spans'],f['total_nulls'],f['total_word_pairs'],f['total_d7'])==(79,3,54,9)
assert [(r['seq'],r['span_count'],r['null_count'],r['word_pair_count']) for r in meta['segments']]==[(316,22,1,15),(317,26,1,19),(318,31,1,20)]
assert read(B/'semantic-review/bank-ready-errata.json')==[]
assert read(B/'semantic-review/span-head-allow-needed.json')=={'pages_c05':{}}
root=read(B/'root-reconciliation-inputs/proof.json'); decision=read(B/'root-semantic-disposition.json')
assert root['status']=='PASS_ROOT_INPUTS' and root['baseline']==BASE
assert decision['verdict']=='APPROVE_ROOT_SEMANTIC_ACCEPTANCE' and decision['actual_baseline']==BASE
assert decision['review_freeze']==pin(B/'semantic-review/freeze.json')
ret=read(B/'landing/retention-source-check.json'); course=read(B/'landing/course-csv-check.json')
build=read(B/'landing/canonical-builds-once.json'); repro=read(R/'proof.json')
assert build['status']==repro['status']=='PASS'
assert ret['baseline_commit']==course['baseline_commit']==build['baseline_commit']==repro['baseline_commit']==BASE
assert ret['segments']==repro['segments']==[316,317,318] and ret['page']=='c5p106'
assert ret['reviewed_analyst_spans']==79 and ret['added_links']==82
for key in ('review_tuples_and_source_ranges_match','source_hashes_unchanged','prior_notes_trees_evidence_and_acip_retained','prior_csv_content_and_references_retained'):
    assert ret[key] is True,key
assert course['all_depths_counts_and_metadata_match_main_csv_refs'] is True
assert len(repro['outputs'])==7 and repro['all_original_inputs_unchanged'] is True
assert repro['layer_invocations']==repro['view_invocations']==1
for row in repro['outputs']:
    assert row['complete_bytes_equal'] is True
    assert pin(W/row['path'])=={k:row[k] for k in ('bytes','sha256')}
    assert row['sha256']==build['output_sha256'][row['path']]
assert pin(B/'landing/previous-main-csv-seed.bin')==pin(R/'seed/previous-main-csv-seed.bin')==repro['seed']
assert all(build['previous_main_csv_seed'][k]==v for k,v in repro['seed'].items())
tests=read(B/'ctest-17-caller/execution.json'); stdout=(B/'ctest-17-caller/stdout.bin').read_bytes()
assert tests['exit']==0 and len(stdout)==tests['stdout_bytes'] and hashlib.sha256(stdout).hexdigest()==tests['stdout_sha256']
assert b'100% tests passed, 0 tests failed out of 17' in stdout or b'100% tests passed out of 17' in stdout
timing=re.findall(rb'Total Test time \(real\) =\s*([0-9.]+) sec',stdout)
assert len(timing)==1
elapsed=(datetime.datetime.fromisoformat(build['finished_at'])-datetime.datetime.fromisoformat(build['started_at'])).total_seconds()
assert len(build['runs'])==2 and all(r['exit']==0 for r in build['runs'])
white_review=read(A/'C05-313-315/whitespace-latin1-independent-review.json')
assert white_review['verdict']=='APPROVE'
assert white_review['method_sha256']==pin(A/'audit_staged_source_whitespace_v12.py')['sha256']
assert white_review['pin_preparation_v4']['verdict']=='APPROVE'
assert white_review['pin_preparation_v4']['method_sha256']==pin(A/'prepare_review_whitespace_pins_v4.py')['sha256']
storage=read(A/'storage-file-relocation-through318/proof.json')
assert storage['status']=='PASS_BYTE_VERIFIED_COMPLETED_FILE_RELOCATION'
assert storage['records']==read(A/'storage-file-relocation-through318/verified-files.json')
assert len(storage['records'])==3 and storage['relocated_bytes']==sum(r['bytes'] for r in storage['records'])==2006986110
for row in storage['records']:
    old=Path(row['original_path']); target=Path(row['external_path'])
    assert old.is_symlink() and old.resolve()==target.resolve() and target.is_file()
    assert target.stat().st_size==row['bytes'] and stat.S_IMODE(target.stat().st_mode)==row['mode']
for name,exit_code in [('storage-relocation-through318-caller',1),('storage-file-relocation-through318-caller',0)]:
    d=A/name; execution=read(d/'execution.json')
    assert execution['exit']==exit_code and (d/'exit.txt').read_bytes()==f'{exit_code}\n'.encode()
    assert all(execution[k]==v for k,v in read(d/'command.json').items())
    assert execution['recorder_sha256']==pin(A/'record_external_step.py')['sha256']
    assert (d/'stdin.bin').read_bytes()==b'' and execution['stdin_bytes']==0
    for stream in ('stdout','stderr'):
        assert pin(d/f'{stream}.bin')==dict(bytes=execution[f'{stream}_bytes'],sha256=execution[f'{stream}_sha256'])

dest=B/'landing/root-current-method'; dest.mkdir(exist_ok=False)
files=[B/n for n in ('prepare_current_bank.py','verify_root_inputs.py','accept_root_semantics.py','closure-method-review.json','closure-method.diff.txt','baseline.json','proposal-baseline.json','source.json','context.json','root-reconciliation-intake.json','root-semantic-disposition.json','root-reconciliation-reading.json','root-original-freeze-verification.json','root-preparation-proof.json','root-preparation-original-rows.json','root-lexical-preparation.json','root-parallel-preparation.json')]
files += [A/n for n in ('close_c05_318_compact.py','register_reviewed_page_v6.py','prepare_review_whitespace_pins_v4.py','audit_staged_source_whitespace_v12.py','land_reviewed_page_v2.py','bank_compact_verification.py','C05-313-315/whitespace-latin1-independent-review.json','C05-313-315/registration-format-adaptation.json','C05-313-315/registration-format-adaptation.diff')]
files += [A/n for n in ('relocate_completed_evidence_318.py','relocate_completed_evidence_318_v2.py')]
storage_directories=[]
for folder in ('storage-relocation-through318','storage-file-relocation-through318','storage-relocation-through318-caller','storage-file-relocation-through318-caller'):
    directory=A/folder; assert directory.is_dir() and not directory.is_symlink()
    members=sorted(p for p in directory.rglob('*') if p.is_file())
    storage_directories.append(dict(path=str(directory),files=[str(p.relative_to(directory)) for p in members]))
    (dest/folder).mkdir()
    files.extend(members)
for folder in ('root-reconciliation-inputs','root-reconciliation-verification','root-intake-history'):
    assert (B/folder).is_dir()
    files.extend(p for p in (B/folder).rglob('*') if p.is_file())
records=[]
for p in sorted(set(files)):
    assert p.is_file() and not p.is_symlink(),p
    rel=p.relative_to(A); target=dest/rel; target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,target); assert target.read_bytes()==p.read_bytes()
    records.append(dict(original=str(p),copy=str(target.relative_to(dest)),**pin(p)))
save(dest/'manifest.json',records)
save(dest/'storage-relocation-reference.json',dict(proof=pin(A/'storage-file-relocation-through318/proof.json'),directories=storage_directories,limits=storage['limits'],scope='Exact small proof/caller/helper files only. The failed first proof directory is empty and recorded as empty; no proof is invented. Three large historical relocated files are referenced by the original passing proof and are not recopied or rehashed for packaging.'))
# Reference the existing through309 assessment once; do not copy its proof tree.
integration=[A/'integration/through309-root-disposition.json']+[A/'integration/through309-current-assessment'/n for n in ('freeze.json','review.md','assessment.json','future-reuse-method.md')]
save(dest/'integration-reference.json',dict(scope='Existing through309 assessment only; no current MAIN applicability or device assessment.',references=[dict(path=str(p),**pin(p)) for p in integration]))
review=B/'compact-reproduction-review'; review.mkdir(exist_ok=False)
save(review/'method-review.json',dict(verdict='APPROVE_REUSE_UNCHANGED_REPRODUCTION_METHOD',methods={n:pin(A/n) for n in ('reproduce_generated_outputs.py','run_reproduction_readonly.py')},prior_passing_proof=str(A/'C05-313-315/compact-closure/proof.json'),current_proof=str(R/'proof.json'),judgment='Unchanged exact source-copy, actual incoming CSV seed, source guards, seven whole-output equality and unchanged-input checks. Current proof follows passing retention. No successful native work is repeated for packaging.',limits='Production/source fidelity only; no MAIN runtime or device acceptance.'))

copies=len(read(B/'semantic-review/original-to-copy-manifest.json'))
entry=f'''

### 2026-09-14 — independently reviewed C05:316–318; private coverage318/511

- Accepted79 provisional spans,3 explicit topic nulls,54 nonnull depth-5 pairs and9 depth-7 members, plus3 source anchors: {ret['added_links']} new links. Per316:22/1/15;317:26/1/19;318:31/1/20 (spans/nulls/nonnull d5).193 C05 segments remain319–511; C06 waits for complete C05 and C13 stays blocked upstream.
- Source/proposal/reconciliation origin {root['source_origin']} through309 remains distinct from actual acceptance @BASE@ through315. Originals {root['frozen']['tibetan']['files']}/{root['frozen']['english']['files']} files; reconciliation356 SHA{RECON}; fresh semantic494 SHA{FREEZE}. Fresh SPEC/QUALITY APPROVE with zero open findings. All{copies} original-copy records remain byte-bound before/after landing;150 original dispositions,79 final decisions and21 material omissions remain readable. No erratum or supplied-head allowance is added; existing register and allowances retain their bytes.
- Root independently resolved{root['canonical_spans']} original/final spans, reexecuted{root['independent_sql_queries']} SQL queries and checked{root['complete_master_queries']} complete master queries/{root['unique_master_objects']} unique master objects,{root['complete_corpus_objects']} complete corpus objects and{root['physical_extents']} physical extents. Root's separate reading covers35 full critical master records and the complete source-specific decisions. Broad identity checks do not claim fresh linguistic reading of every repeated metadata string.
- {decision['semantic_decision']} {decision['null_decisions']} {decision['read_evidence']['count_label']} Original apparatus stays verbatim; nothing enters hgm_gloss.
- Three fresh final generations and six original native generations are reused after exact code/input/stream/exit checks; root repeated no generator. Two actual root intake adapter failures and their helper versions remain preserved; attempt03 passed. Frozen reviewer intake failures and the Tibetan318 note-only supersession remain preserved independently. Registrationv6 uses the actual reconciliation freeze.json. Unchanged independently approved whitespace preparationv4/auditv12 classify only exact frozen evidence; the actual staged audit remains a required closure gate.
- Aggregate production passed once in{elapsed:.6f}s; all17 fidelity tests passed in{timing[0].decode()}s. All{ret['prior_links_retained']} prior links and{ret['prior_csv_rows_retained']} prior main-CSV rows, notes, trees, evidence, ACIP and references are retained. Current{ret['full_links']} links,{ret['null_exponents']} nulls,{ret['evidence_headwords']} heads,{ret['evidence_pairs']} evidence pairs,{ret['current_csv_rows']} main-CSV rows and{course['current_course_depth_groups']} course-depth groups. Seven full outputs reproduce exactly once from{repro['registered_pages']} registered pages and the actual{repro['seed']['bytes']}-byte incoming CSV seed SHA{repro['seed']['sha256']}. External proof: {R/'proof.json'}.
- Fixed private DATA @DATA@ follows @BASE@. Exact staged mode/blob/tree, source/review/output bindings precede commit; all three ledgers receive this identical append-only entry. Completion @UTC@. Actual Git streams, parent/tree, source fidelity and clean tracked/untracked preservation remain in compact-closure/proof.json. Current DATA/DOCS close through318 with193 remaining; prepared319–321 material is not accepted by this checkpoint.
- Storage pressure required relocation of three completed historical proof files ({storage['relocated_bytes']} bytes) to the external evidence drive. The original paths remain readable symlinks to the byte-and-mode-verified files. An earlier directory attempt failed on an existing symlink before copying or relocating anything; both helpers, both actual caller streams, the empty failed proof-directory inventory and the passing small proof are preserved in root-current-method. Current source, master, worktree and active-batch evidence were unchanged; the external drive remains required. Large historic proof files are not recopied for this checkpoint.
- Isolated desktop-consumable outputs are verified through318. Existing through309 MAIN applicability evidence is referenced once by landing/root-current-method/integration-reference.json; no new318 applicability or runtime claim. MAIN remains unapplied. Phone remains FAILED_UNACCEPTED for four inherited C01 mappings; no installation, historical installed through171 unchanged. Rendering/QSettings/runtime,42 depth shortfalls and28 trim calls remain open. Other work and external evidence are preserved; no paid generation, release or external-account action.
'''
p=B/'landing/root-ledger-entry-template.md'; assert not p.exists(); p.write_text(entry)
print(json.dumps(dict(status='PREPARED',method_files=len(records),ledger_bytes=p.stat().st_size)))
