"""Preserve late freeze-caller bytes in an archive; remove only unlisted copies.

No whitespace is normalized and no source or frozen semantic file is changed.
"""
from pathlib import Path
import datetime,hashlib,io,json,shutil,subprocess,tarfile
B=Path(__file__).resolve().parent;S=B/'semantic-review';W=B.parents[1]/'campaign-worktree'
R=W/'data/alignment/reviews_c05/c5p106';V=R/'verification';src=S/'freeze-caller';dup=R/'freeze-caller'
def read(p):return json.loads(p.read_bytes())
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
f=read(S/'freeze.json');assert f['file_count']==494
assert pin((S/'freeze.json').read_bytes())['sha256']=='81e6c82c71c035e51661aeed9056b502fecf5b2de8a5bdd01bc9c887a5098d21'
names={'command.json','execution.json','exit.txt','stdin.bin','stdout.bin','stderr.bin'}
assert {p.name for p in src.iterdir()}=={p.name for p in dup.iterdir()}==names
assert not any(x.startswith('freeze-caller/') for x in f['files'])
assert not any(x['copy'].startswith('freeze-caller/') for x in read(S/'original-to-copy-manifest.json'))
e=read(src/'execution.json');assert e['exit']==0 and (src/'exit.txt').read_bytes()==b'0\n'
for k in ['stdout','stderr']:
 assert pin((src/(k+'.bin')).read_bytes())==dict(bytes=e[k+'_bytes'],sha256=e[k+'_sha256'])
assert read(src/'stdout.bin')['freeze_sha256']==pin((S/'freeze.json').read_bytes())['sha256']
argv=['git','ls-tree','-z','af139c573f85aaf33278cd079719947ee9af8cdd','--','data/alignment/reviews_c05/c5p106/freeze-caller']
c=subprocess.run(argv,cwd=W,capture_output=True);assert c.returncode==0 and c.stdout==c.stderr==b''
records=[];archive=V/'post-freeze-caller-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tf:
 for name in sorted(names):
  p=src/name;assert p.is_file() and not p.is_symlink()
  raw=p.read_bytes();assert raw==(dup/name).read_bytes()
  member='freeze-caller/'+name;info=tarfile.TarInfo(member);info.size=len(raw);info.mode=0o644
  tf.addfile(info,io.BytesIO(raw));records.append(dict(original=str(p),removed_duplicate=str(dup/name),member=member,**pin(raw)))
with tarfile.open(archive,'r:gz') as tf:
 assert tf.getnames()==[r['member'] for r in records]
 for r in records:assert tf.extractfile(r['member']).read()==Path(r['original']).read_bytes()==Path(r['removed_duplicate']).read_bytes()
manifest=dict(status='PASS_EXACT_POST_FREEZE_CALLER_ARCHIVE',archive=pin(archive.read_bytes()),members=records,semantic_freeze=pin((S/'freeze.json').read_bytes()),reason='This native caller completed after the semantic freeze and was explicitly excluded. Preserve exact native bytes in an archive rather than treating them as frozen reviewed prose. All494 frozen files and608 mapped original/copies remain unchanged.')
save(V/'post-freeze-caller-manifest.json',manifest)
shutil.rmtree(dup)
assert not dup.exists()
for rel,r in f['files'].items():assert pin((R/rel).read_bytes())=={k:r[k] for k in ['bytes','sha256']}
save(B/'post-freeze-caller-archive.json',dict(status=manifest['status'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive=str(archive),manifest=str(V/'post-freeze-caller-manifest.json'),members=len(records),original_native_exit=0,unfrozen_duplicate_removed=True,frozen_semantic_bytes_unchanged=True,source_or_generator_changes=False,baseline_path_absence=dict(argv=argv,cwd=str(W),exit=c.returncode,stdout_hex=c.stdout.hex(),stderr_hex=c.stderr.hex())))
history=B/'whitespace-history';history.mkdir(exist_ok=False)
for name in ['staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit']:
 shutil.move(str(B/'landing'/name),str(history/name))
print(json.dumps(dict(status=manifest['status'],members=len(records),source_or_generator_changes=False)))
