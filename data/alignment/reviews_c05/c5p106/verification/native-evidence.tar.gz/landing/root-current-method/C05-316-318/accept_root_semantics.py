"""Bind completed root linguistic reading to the independently checked inputs."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
B=Path(__file__).resolve().parent;S=B/'semantic-review';Q=B/'reconciled';W=B.parents[1]/'campaign-worktree'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
 assert not p.exists(),p
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
f=read(S/'freeze.json');m=read(S/'review.json');proof=read(B/'root-reconciliation-inputs/proof.json')
assert proof['status']=='PASS_ROOT_INPUTS' and proof['canonical_spans']==229
assert pin(S/'freeze.json')['sha256']==proof['frozen']['semantic-review']['manifest_sha256']=='81e6c82c71c035e51661aeed9056b502fecf5b2de8a5bdd01bc9c887a5098d21'
assert f['verdict']==f['spec_verdict']==f['quality_verdict']==m['verdict']=='APPROVE'
assert f['open_findings']==m['open_findings']==[]
for rel,r in f['files'].items():assert pin(S/rel)==r
for rel in f['exclusions']['unsupported_runtime_helpers_preserved_exactly_under_methods']:
 assert (S/rel).read_bytes()==(S/'methods'/(Path(rel).name+'.txt')).read_bytes()
rs=read(B/'root-reconciliation-inputs/resolved-spans.json');assert rs==read(S/'resolved-spans.json')
assert [{k:r[k] for k in rs[0]} for r in read(S/'independent-span-decisions.json')]==rs
originals=read(S/'independent-original-dispositions.json');assert len(originals)==150
expected=sum((read(Q/str(n)/'decisions.json')['original_dispositions'] for n in [316,317,318]),[])
assert [(r['angle'],r['original'],r['disposition'],r['final_ids']) for r in expected]==[(r['angle'],r['original'],r['original_disposition'],r['final_ids']) for r in originals]
assert len(read(S/'independent-omission-decisions.json'))==21 and len(read(S/'five-ground-errata-review.json'))==6
assert (m['total_spans'],m['total_nulls'],m['total_word_pairs'],m['total_d7'])==(79,3,54,9)
assert read(S/'bank-ready-errata.json')==[] and read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert head==proof['baseline']==f['later_supplied_acceptance_baseline']
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=W)
receipt=read(S/'later-baseline-receipt.json');assert receipt['baseline_file_sha256']==pin(B/'baseline.json')['sha256']
assert receipt['original_reconciler_consumed_later_baseline'] is False
for r in receipt['validation']:
 raw=subprocess.check_output(['git','show',head+':'+r['repository_relative_path']],cwd=W)
 assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
compat=B/'root-reconciliation-verification';compat.mkdir(exist_ok=False)
shutil.copy2(B/'root-reconciliation-inputs/resolved-spans.json',compat/'resolved-spans.json')
reading=dict(completed='Root read full selected source fields and surrounding argument, six original specs/reports and all150 original spans/reasons, all79 final spans/ranges/reasons/order, all17 changed original dispositions with remaining133 exact identities checked, all21 omissions, original Tibetan candidate and considerations, five English five-ground screens, six reconciled and fresh five-ground screens, fresh report and79 independent reasons. Full35 critical master objects were read, including complete HGM/provenance, and full C03:373/C16:437/EM:908/C05:320 corpus witnesses.',critical_full_master_objects_read=35,critical_corpus_rows_fully_read=['C03:373','C16:437','EM:908','C05:320'],scope='All unique source-specific judgment text was read. Repeated full metadata and duplicated source rows were checked by identity; no fresh linguistic reading of every repeated metadata string is claimed. Truncated judgment portions were reread in bounded projections.',conclusions='316 retains distinct virtue/Non-virtue, realm coordination, capital taken In/Respectively, whole compounds and independently supported de/it, zad/end, byed pa/brings. 317 preserves three distinct ripening roles and four black occurrences; Just is unresolved because competing HGM entries cannot establish ownership. 318 preserves distinct stream/with occurrences, whole negative-mixture compounds and members; first gcig/in question and su/by remain unresolved. BA/PA remains uncertain after the complete negative HGM ma dres ba headword with actual apostrophe supplies material counterevidence. No source correction is filed.',nulls='Exactly three ni topic markers: no separate English word, topic-predicate syntax carries their contribution; explicit copulas retain their actual predicates. Uncertain, redistributed and omitted phrases do not become nulls.',count_label='316 whitespace-start GNAG regex count0 is preserved as that literal method. Punctuation-aware lexical count is1 at Wylie[66,70);317 has4 under both methods. This is audit-label correction only; no frozen source/spec/native output changed.')
save(B/'root-reconciliation-reading.json',reading)
intake=dict(status='PASS_ROOT_CURRENT_INTAKE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=head,source_origin=proof['source_origin'],prior_root_checks=pin(B/'root-reconciliation-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(Q/'freeze.json'),root_canonical_resolution_spans=229,root_generator_executions=0,reading=reading,limits=['Two actual root intake adapter failures preserved: original master query collection scopes differ; SQL evidence includes dictionary rows as well as corpus rows. Exact third attempt passes.','A read-only diagnostic inspection also assumed a course key and failed before printing a row; no source/spec/native generator changed.','Full original-to-copy identities are checked by the standard acceptance gate immediately before and after landing.'])
save(B/'root-reconciliation-intake.json',intake)
out=dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),page='c5p106',segments=[316,317,318],counts=dict(spans=79,nulls=3,nonnull_d5=54,total_d5=54,d7=9),source_origin=proof['source_origin'],actual_baseline=head,review=pin(S/'review.md'),review_json=pin(S/'review.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(Q/'freeze.json'),read_evidence=reading,semantic_decision=reading['conclusions'],null_decisions=reading['nulls'],errata='No new errata from six reconciled/fresh source questions;194 existing register records unchanged. No supplied-head allowances.',allowances=read(S/'span-head-allow-needed.json'),execution_reuse='229 original/final canonical ranges independently resolved. Six original successful generations reused with exact code/input/stream/exit identity, and three fresh final generations reused. Aggregate production and fidelity checks follow.',limits='Provisional machine acceptance only. No hgm_gloss promotion, human editorial acceptance, MAIN application, merged runtime or device acceptance.')
save(B/'root-semantic-disposition.json',out)
print(json.dumps({k:out[k] for k in ['verdict','page','counts','review_freeze']},indent=2))
