"""Move sealed campaign-owned evidence to verified external storage.

Preserve the original readable paths with directory symlinks. Copy and verify
every file before releasing any original storage; never touch project data.
"""
from pathlib import Path
import datetime,hashlib,json,os,shutil,stat
A=Path(__file__).resolve().parent
E=Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398')
O=A/'storage-relocation-through318';O.mkdir(exist_ok=False)
D=E/'relocated-completed-evidence-through318';D.mkdir(exist_ok=False)
assert E.is_dir() and os.statvfs(E).f_bavail*os.statvfs(E).f_frsize>20*1024**3
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest(),mode=stat.S_IMODE(p.stat().st_mode))
def inventory(root):
 result={}
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():result[str(p.relative_to(root))]=pin(p)
  else:assert p.is_dir()
 return result
records=[]
for name in ['through273-checkpoint-execution-01','through276-checkpoint-execution-v2']:
 src=A/'integration'/name;dst=D/name
 assert src.is_dir() and not src.is_symlink() and not dst.exists()
 original=inventory(src);assert original
 # These are completed historic evidence folders, not current agent outputs.
 assert max(p.stat().st_mtime for p in src.rglob('*') if p.is_file()) < datetime.datetime(2026,9,14,19,0,tzinfo=datetime.timezone.utc).timestamp()
 shutil.copytree(src,dst,copy_function=shutil.copy2)
 assert inventory(dst)==original and inventory(src)==original
 (O/(name+'.manifest.json')).write_text(json.dumps(original,indent=2)+'\n')
 held=src.with_name(src.name+'.verified-relocation-holding');assert not held.exists()
 src.rename(held)
 try:src.symlink_to(dst,target_is_directory=True)
 except BaseException:held.rename(src);raise
 assert inventory(src)==original
 shutil.rmtree(held)
 records.append(dict(original_path=str(src),external_path=str(dst),files=len(original),bytes=sum(r['bytes'] for r in original.values()),every_file_hash_and_mode_equal=True,original_path_remains_readable=True))
 proof=dict(status='PASS_BYTE_VERIFIED_COMPLETED_EVIDENCE_RELOCATION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,available_internal_bytes=os.statvfs(A).f_bavail*os.statvfs(A).f_frsize,limits='External evidence drive required. Current source/master/worktree and active batch evidence unchanged. No frozen contents changed; completed original folder locations resolve to exact external copies.')
 (O/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
