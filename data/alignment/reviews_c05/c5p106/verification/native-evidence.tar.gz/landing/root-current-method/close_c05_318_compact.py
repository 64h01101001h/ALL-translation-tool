"""Bind existing passing evidence to the exact staged tree, then checkpoint privately.

No generators, tests, source edits, integration, or prior proof trees are repeated.
Every Git command has a native record. Refuses a second invocation's output path.
"""
from pathlib import Path
import datetime, hashlib, io, json, os, subprocess, tarfile

A = Path(__file__).resolve().parent
R = A.parent
W = R / 'campaign-worktree'
B = A / 'C05-316-318'
O = B / 'compact-closure'
BASE = 'af139c573f85aaf33278cd079719947ee9af8cdd'
V = W / 'data/alignment/reviews_c05/c5p106/verification'
REPRO = Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through318')
FREEZE = '81e6c82c71c035e51661aeed9056b502fecf5b2de8a5bdd01bc9c887a5098d21'
RECON = '51aa8fc419bbd25ea20a21d0ea4524b1c964888891c7aa0c400b449c3f6ba314'
O.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(b): return dict(bytes=len(b), sha256=sha(b))
def read(p): return json.loads(p.read_bytes())
def save(p, d): p.write_text(json.dumps(d, indent=2, ensure_ascii=False)+'\n')
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(label, *args, allowed=(0,)):
    d=O/label; d.mkdir()
    argv=['git', *args]; started=utc()
    save(d/'command.json',dict(argv=argv,cwd=str(W),started_at=started,environment_overrides={'GIT_OPTIONAL_LOCKS':'0'}))
    (d/'stdin.bin').write_bytes(b'')
    result=subprocess.run(argv,cwd=W,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),input=b'',capture_output=True)
    for n,b in [('stdout.bin',result.stdout),('stderr.bin',result.stderr),('exit.txt',f'{result.returncode}\n'.encode())]: (d/n).write_bytes(b)
    save(d/'execution.json',dict(argv=argv,cwd=str(W),started_at=started,finished_at=utc(),exit=result.returncode,stdout=pin(result.stdout),stderr=pin(result.stderr)))
    assert result.returncode in allowed,(label,result.returncode)
    return result.stdout
def names(b): return [x.decode() for x in b.split(b'\0') if x]

assert git('incoming','rev-parse','HEAD').decode().strip()==BASE
assert not git('unstaged-entry','diff','--name-only','-z')
entry_untracked=git('untracked-entry','ls-files','--others','--exclude-standard','-z')
assert names(entry_untracked)==['data/teaching/dcc_captions']
method_review=read(B/'closure-method-review.json')
assert method_review['verdict']=='APPROVE_ROOT_CURRENT_CLOSURE_METHOD'
for name,value in method_review['methods'].items():
    assert pin((A/name).read_bytes())==value,name
assert sha((B/'closure-method.diff.txt').read_bytes())==method_review['diff_sha256']
frozen=read(B/'semantic-review/freeze.json')
assert sha((B/'semantic-review/freeze.json').read_bytes())==FREEZE
assert frozen['verdict']==frozen['spec_verdict']==frozen['quality_verdict']=='APPROVE' and frozen['open_findings']==[]
assert frozen['file_count']==len(frozen['files'])==494
assert frozen['later_supplied_acceptance_baseline']==BASE and frozen['later_baseline_accepted_through']==315
assert (frozen['total_spans'],frozen['total_nulls'],frozen['total_word_pairs'],frozen['total_d7'])==(79,3,54,9)
reconciliation=read(B/'reconciled/freeze.json')
assert sha((B/'reconciled/freeze.json').read_bytes())==frozen['reconciliation_freeze_sha256']==RECON
assert len(reconciliation['files'])==356
reviewroot=W/'data/alignment/reviews_c05/c5p106'
for relative,row in frozen['files'].items():
    assert (B/'semantic-review'/relative).resolve().is_relative_to((B/'semantic-review').resolve())
    original=(B/'semantic-review'/relative).read_bytes()
    assert pin(original)=={k:row[k] for k in ('bytes','sha256')}
    assert (reviewroot/relative).read_bytes()==original
assert (reviewroot/'freeze.json').read_bytes()==(B/'semantic-review/freeze.json').read_bytes()
original_copy_records=read(B/'semantic-review/original-to-copy-manifest.json')
for i,row in enumerate(original_copy_records):
    if 'original_git_commit' in row:
        # These eleven governing originals are immutable historical Git blobs;
        # the current worktree may already contain accepted later changes.
        original=git(f'governing-original-{i}','show',row['original_git_commit']+':'+row['repository_relative_path'])
    else:
        original=Path(row['original']).read_bytes()
    assert pin(original)=={k:row[k] for k in ('bytes','sha256')}
    assert original==(B/'semantic-review'/row['copy']).read_bytes()==(reviewroot/row['copy']).read_bytes()
for relative,row in reconciliation['files'].items():
    assert pin((B/'reconciled'/relative).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
for seq in (316,317,318):
    assert (reviewroot/f'{seq}-reconciliation.md').read_bytes()==(B/f'reconciled/{seq}/report.md').read_bytes()
meta=read(B/'semantic-review/review.json')
assert [(r['seq'],r['span_count'],r['null_count'],r['word_pair_count']) for r in meta['segments']]==[(316,22,1,15),(317,26,1,19),(318,31,1,20)]
assert read(B/'semantic-review/bank-ready-errata.json')==[]
assert read(B/'semantic-review/span-head-allow-needed.json')=={'pages_c05':{}}
for i,path in enumerate(('docs/errata_register.json','data/alignment/span_head_allow.json')):
    assert (W/path).read_bytes()==git(f'unchanged-register-{i}','show',BASE+':'+path)

required_callers=('root-inputs-attempt03-caller','semantic-acceptance-caller','root-semantic-intake-caller','landing-caller','landed-semantic-acceptance-caller','registration-caller','registered-copy-check-caller','canonical-builders-caller','ctest-17-caller','retention-caller','course-csv-caller','compact-reproduction-caller','bank-preparation-caller','compact-bank-caller','stage-data-caller','whitespace-audit-caller')
failed_callers=('root-inputs-caller','root-inputs-attempt02-caller')
for caller in required_callers+failed_callers:
    assert (B/caller/'execution.json').is_file(),caller
caller_records=[]
for d in sorted(B.glob('*-caller')):
    # The recorder invoking this closure has no final execution record yet.
    if not (d/'execution.json').exists():
        assert d.name=='compact-closure-caller',('Unexpected incomplete caller',d)
        continue
    ex=read(d/'execution.json'); command=read(d/'command.json')
    assert all(ex[k]==v for k,v in command.items()),d
    assert ex['recorder_sha256']==sha((A/'record_external_step.py').read_bytes())
    assert ex['exit']==(1 if d.name in failed_callers else 0),(d,ex['exit'])
    assert (d/'exit.txt').read_bytes()==f"{ex['exit']}\n".encode()
    assert (d/'stdin.bin').read_bytes()==b'' and ex['stdin_bytes']==0
    for stream in ('stdout','stderr'):
        raw=(d/f'{stream}.bin').read_bytes()
        assert len(raw)==ex[f'{stream}_bytes'] and sha(raw)==ex[f'{stream}_sha256']
    caller_records.append(dict(caller=d.name,exit=ex['exit'],execution=pin((d/'execution.json').read_bytes())))
assert {p.name for p in (B/'root-intake-history').iterdir()}=={'verify_root_inputs.v1.py.txt','verify_root_inputs.v2.py.txt'}
root=read(B/'root-reconciliation-inputs/proof.json')
assert root['status']=='PASS_ROOT_INPUTS' and root['baseline']==BASE
assert root['canonical_spans']==229 and root['root_generator_runs']==0
assert root['frozen']['semantic-review']==dict(files=494,manifest_sha256=FREEZE)
assert root['frozen']['reconciled']==dict(files=356,manifest_sha256=RECON)
intake=read(B/'root-reconciliation-intake.json'); disposition=read(B/'root-semantic-disposition.json')
assert intake['status']=='PASS_ROOT_CURRENT_INTAKE' and intake['baseline']==BASE
assert intake['prior_root_checks']==pin((B/'root-reconciliation-inputs/proof.json').read_bytes())
assert intake['review_freeze']==pin((B/'semantic-review/freeze.json').read_bytes())
assert disposition['verdict']=='APPROVE_ROOT_SEMANTIC_ACCEPTANCE' and disposition['actual_baseline']==BASE
assert disposition['page']=='c5p106' and disposition['segments']==[316,317,318]
assert disposition['review_freeze']==intake['review_freeze']
registration=read(B/'landing/registration/proof.json')
assert registration['status']=='PASS' and registration['baseline_commit']==BASE
assert registration['errata']==[] and registration['head_allowances']=={'pages_c05':{}}
assert registration['method']==pin((A/'register_reviewed_page_v6.py').read_bytes())
assert read(A/'C05-313-315/registration-format-adaptation.json')['new']==registration['method']

build=read(B/'landing/canonical-builds-once.json')
assert build['status']=='PASS' and build['baseline_commit']==BASE and len(build['runs'])==2
assert all(r['exit']==0 for r in build['runs'])
for path,h in build['output_sha256'].items(): assert sha((W/path).read_bytes())==h,path
baseline=read(B/'baseline.json')
for path in ('data/hgm_dictionary_v27_2.json.gz','data/full_parallel_corpus_v32.json.gz'):
    assert build['output_sha256'][path]==baseline['sha256'][path]
repro=read(REPRO/'proof.json')
assert repro['status']=='PASS' and repro['baseline_commit']==BASE and repro['segments']==[316,317,318]
expected_outputs={'data/alignment/alignment_full_v1.json','data/alignment/alignment_evidence_v1.json'} | {'docs/geshe_michael_roach_dictionary'+suffix for suffix in ('.html','.csv','_reverse.csv','_by_course.csv','_changes.csv')}
assert len(repro['outputs'])==7 and {r['path'] for r in repro['outputs']}==expected_outputs
assert repro['all_original_inputs_unchanged'] is True and repro['layer_invocations']==repro['view_invocations']==1
for row in repro['outputs']:
    assert row['complete_bytes_equal'] is True
    assert pin((W/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
    assert build['output_sha256'][row['path']]==row['sha256']
seed=git('incoming-csv-seed','show',BASE+':docs/geshe_michael_roach_dictionary.csv')
assert seed==(B/'landing/previous-main-csv-seed.bin').read_bytes()==(REPRO/'seed/previous-main-csv-seed.bin').read_bytes()
assert pin(seed)==repro['seed']
assert all(build['previous_main_csv_seed'][k]==v for k,v in repro['seed'].items())
retention=read(B/'landing/retention-source-check.json'); course=read(B/'landing/course-csv-check.json')
assert retention['baseline_commit']==course['baseline_commit']==BASE
assert retention['page']=='c5p106' and retention['segments']==[316,317,318]
assert retention['reviewed_analyst_spans']==79 and retention['added_links']==82
for key in ('review_tuples_and_source_ranges_match','source_hashes_unchanged','prior_notes_trees_evidence_and_acip_retained','prior_csv_content_and_references_retained'):
    assert retention[key] is True,key
assert course['all_depths_counts_and_metadata_match_main_csv_refs'] is True
assert course['course_csv_sha256']==sha((W/'docs/geshe_michael_roach_dictionary_by_course.csv').read_bytes())
wh=read(B/'landing/source-whitespace-proof.json')
assert wh['all_warnings_accounted_for'] and wh['baseline_head']==BASE
assert wh['review_freeze_name']=='freeze.json' and wh['review_freeze_sha256']==FREEZE
assert wh['git_diff_check_exit'] in (0,2)
assert pin((B/'landing/staged-diff-check.stdout').read_bytes())==dict(bytes=wh['raw_log_bytes'],sha256=wh['raw_log_sha256'])
assert (B/'landing/staged-diff-check.stderr').read_bytes()==b''
assert (B/'landing/staged-diff-check.exit').read_bytes()==f"{wh['git_diff_check_exit']}\n".encode()
for path,row in wh['files'].items(): assert pin((W/path).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
white_review=read(A/'C05-313-315/whitespace-latin1-independent-review.json')
assert white_review['verdict']=='APPROVE'
assert white_review['method_sha256']==sha((A/'audit_staged_source_whitespace_v12.py').read_bytes())
assert white_review['pin_preparation_v4']['verdict']=='APPROVE'
assert white_review['pin_preparation_v4']['method_sha256']==sha((A/'prepare_review_whitespace_pins_v4.py').read_bytes())
prepared=read(B/'landing/whitespace-pin-preparation.json')
assert prepared['status']=='EXACT_V12_PINS_PREPARED' and prepared['freeze']==intake['review_freeze']
assert prepared['method']==pin((A/'prepare_review_whitespace_pins_v4.py').read_bytes())
assert prepared['pins']==read(B/'landing/review-whitespace-exact-pins.json')

# Re-read the already banked current evidence archive; never copy old proof trees.
summary=read(V/'summary.json'); archive_manifest=read(V/'archive-manifest.json')
assert summary['status']=='PASS' and summary['page']==106 and summary['segments']==[316,317,318]
assert summary['fidelity_tests']['passed']==17 and summary['fidelity_tests']['failed']==0
assert summary['retention']==retention and summary['course_csv']==course
assert summary['reproduction_outputs']==repro['outputs']
assert pin((V/'native-evidence.tar.gz').read_bytes())=={k:summary['archive'][k] for k in ('bytes','sha256')}
with tarfile.open(V/'native-evidence.tar.gz','r:gz') as tf:
    assert tf.getnames()==[row['member'] for row in archive_manifest]
    for row in archive_manifest:
        raw=tf.extractfile(row['member']).read()
        assert raw==Path(row['original']).read_bytes()
        assert pin(raw)=={k:row[k] for k in ('bytes','sha256')}
for row in read(B/'landing/root-current-method/manifest.json'):
    raw=Path(row['original']).read_bytes()
    assert pin(raw)=={k:row[k] for k in ('bytes','sha256')}
    assert raw==(B/'landing/root-current-method'/row['copy']).read_bytes()
storage=read(A/'storage-file-relocation-through318/proof.json')
assert storage['status']=='PASS_BYTE_VERIFIED_COMPLETED_FILE_RELOCATION'
assert len(storage['records'])==3 and storage['relocated_bytes']==2006986110
assert storage['records']==read(A/'storage-file-relocation-through318/verified-files.json')
for row in storage['records']:
    assert Path(row['original_path']).is_symlink()
    assert Path(row['original_path']).resolve()==Path(row['external_path']).resolve()
for name,exit_code in [('storage-relocation-through318-caller',1),('storage-file-relocation-through318-caller',0)]:
    d=A/name; ex=read(d/'execution.json')
    assert ex['exit']==exit_code and (d/'exit.txt').read_bytes()==f'{exit_code}\n'.encode()
    assert all(ex[k]==v for k,v in read(d/'command.json').items())
    assert ex['recorder_sha256']==sha((A/'record_external_step.py').read_bytes())
    assert (d/'stdin.bin').read_bytes()==b'' and ex['stdin_bytes']==0
    for stream in ('stdout','stderr'):
        assert pin((d/f'{stream}.bin').read_bytes())==dict(bytes=ex[f'{stream}_bytes'],sha256=ex[f'{stream}_sha256'])

# Archive only late current-batch evidence. Root source-specific methods/history
# and completed root callers are already exact members of native-evidence.tar.gz.
inputs=[B/'landing'/n for n in ('source-whitespace-proof.json','review-whitespace-exact-pins.json','whitespace-pin-preparation.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit','root-ledger-entry-template.md')]
for caller in ('bank-preparation-caller','whitespace-audit-caller','compact-bank-caller','stage-data-caller'):
    inputs.extend(sorted(p for p in (B/caller).rglob('*') if p.is_file()))
# Include any other completed current caller absent from the earlier archive.
archived_originals={row['original'] for row in archive_manifest}
for d in sorted(B.glob('*-caller')):
    if not (d/'execution.json').is_file(): continue
    inputs.extend(p for p in d.rglob('*') if p.is_file() and str(p) not in archived_originals)
inputs.extend([Path(__file__).resolve(),B/'prepare_current_bank.py',B/'closure-method-review.json',B/'closure-method.diff.txt'])
inputs=sorted(set(inputs)); members=[]
archive=V/'post-bank-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'x:gz') as tf:
    for p in inputs:
        raw=p.read_bytes(); name=str(p.relative_to(A)); info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644
        tf.addfile(info,io.BytesIO(raw)); members.append(dict(original=str(p),member=name,**pin(raw)))
with tarfile.open(archive,'r:gz') as tf:
    assert tf.getnames()==[m['member'] for m in members]
    for m in members: assert tf.extractfile(m['member']).read()==Path(m['original']).read_bytes()
save(V/'post-bank-manifest.json',dict(archive=pin(archive.read_bytes()),members=members,all_members_byte_equal=True,scope='Actual late whitespace, bank/stage callers and bounded method evidence. Earlier native-evidence archive unchanged.'))
git('stage-post-bank','add','--',str(archive.relative_to(W)),str((V/'post-bank-manifest.json').relative_to(W)))
paths=names(git('staged-paths','diff','--cached','--name-only','-z'))
fixed=set(expected_outputs)
fixed.update(['data/alignment/pages_c05/c5p105.html','data/alignment/pages_c05/c5p106.html','data/alignment/pages_c05/index.html','data/alignment/specs_c05/c5p106.json','tools/build_alignment_layer.py'])
assert fixed.issubset(paths)
assert all(p in fixed or p.startswith('data/alignment/reviews_c05/c5p106/') for p in paths)
records=[]
index={}
for row in git('accepted-index-entries','ls-files','--stage','-z').split(b'\0'):
    if not row: continue
    meta,path=row.split(b'\t',1);mode,oid,stage=meta.split()
    assert stage==b'0' and path.decode() not in index
    index[path.decode()]=(mode.decode(),oid.decode())
for i,path in enumerate(paths):
    raw=(W/path).read_bytes()
    # Git's blob hash verifies the exact staged bytes, without copying each blob again.
    mode,oid=index[path]
    assert mode==('100755' if path=='tools/build_alignment_layer.py' else '100644'),path
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid,path
    records.append(dict(path=path,git_mode=mode,git_blob=oid,**pin(raw)))
assert not git('unstaged-final','diff','--name-only','-z')
diag=git('final-whitespace','diff','--cached','--check',allowed=(wh['git_diff_check_exit'],))
assert diag==(B/'landing/staged-diff-check.stdout').read_bytes()
tree=git('accepted-index-tree','write-tree').decode().strip()
save(O/'accepted-index.json',dict(status='PASS',baseline=BASE,tree=tree,files=records,semantic_frozen_files=len(frozen['files']),seven_outputs_match_reproduction=True,whitespace_diagnostic_unchanged=pin(diag),source_archives_unchanged=True,original_copy_records_verified=len(original_copy_records),native_callers=caller_records))
git('commit-data','commit','-m','Bank reviewed provisional C05 alignments for segments 316–318')
data=git('data-head','rev-parse','HEAD').decode().strip()
assert git('data-parent','rev-parse',data+'^').decode().strip()==BASE
assert git('data-tree','rev-parse',data+'^{tree}').decode().strip()==tree

entry=(B/'landing/root-ledger-entry-template.md').read_text().replace('@DATA@',data).replace('@BASE@',BASE).replace('@UTC@',utc())
assert '@DATA@' not in entry and '@BASE@' not in entry and '@UTC@' not in entry
assert not any(line.endswith(' ') for line in entry.splitlines())
rawentry=entry.encode(); (O/'ledger-entry.md').write_bytes(rawentry)
ledgers=['data/alignment/C05_CAMPAIGN.md','docs/handoff/HANDOFF_LOG.md','docs/superpowers/plans/2026-09-12-aci-alignment-campaign.md']
ledger_records=[]
for i,path in enumerate(ledgers):
    old=git(f'ledger-before-{i}','show',data+':'+path)
    assert (W/path).read_bytes()==old and rawentry not in old
    with (W/path).open('ab') as f: f.write(rawentry)
    assert (W/path).read_bytes()==old+rawentry
    ledger_records.append(dict(path=path,before=pin(old),after=pin(old+rawentry)))
assert set(names(git('ledger-changes','diff','--name-only','-z')))==set(ledgers)
git('stage-ledgers','add','--',*ledgers)
assert set(names(git('staged-ledger-paths','diff','--cached','--name-only','-z')))==set(ledgers)
assert not git('ledger-whitespace','diff','--cached','--check')
git('commit-docs','commit','-m','Record verified C05 coverage through segment 318 and integration limits')
final=git('final-head','rev-parse','HEAD').decode().strip()
assert git('docs-parent','rev-parse',final+'^').decode().strip()==data
assert set(names(git('docs-changes','diff','--name-only','-z',data,final)))==set(ledgers)
for i,row in enumerate(ledger_records):
    after=git(f'ledger-final-{i}','show',final+':'+row['path'])
    old=(O/f'ledger-before-{i}/stdout.bin').read_bytes()
    assert after==old+rawentry==(W/row['path']).read_bytes()
assert not git('final-tracked-state','status','--porcelain','--untracked-files=no')
final_untracked=git('untracked','ls-files','--others','--exclude-standard','-z')
assert final_untracked==entry_untracked
untracked=names(final_untracked)
proof=dict(status='PASS_FIXED_PRIVATE_CHECKPOINT',utc=utc(),incoming=BASE,data=data,final=final,coverage=318,remaining=193,accepted_index_tree=tree,data_tree_equals_accepted_index=True,ledgers=ledger_records,all_prior_ledger_bytes_preserved=True,tracked_clean=True,untracked=untracked,untracked_preserved=True,source_fidelity=True,seven_outputs_match_reproduction=True,semantic_freeze_sha256=FREEZE,reconciliation_freeze_sha256=RECON,main='OPEN_NO_APPLICATION',phone='FAILED_UNACCEPTED; no installation; installed through171 unchanged')
save(O/'proof.json',proof)
print(json.dumps(proof,indent=2))
