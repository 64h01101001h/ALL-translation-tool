"""Independent root range/source intake, reusing frozen successful native runs.

Semantic reading is recorded separately; byte equality is not a linguistic verdict.
"""
from pathlib import Path
from collections import Counter,defaultdict
import datetime,gzip,hashlib,json,os,re,sqlite3,subprocess,sys,types
B=Path(__file__).resolve().parent;S=B/'semantic-review';Q=B/'reconciled';W=B.parents[1]/'campaign-worktree'
O=B/'root-reconciliation-inputs';assert not O.exists()
def read(p):return json.loads(p.read_bytes())
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def exp(r):return {k:r[k] for k in ('bytes','sha256')}
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
frozen={}
for angle,name,sha in [
 ('tibetan','frozen_manifest.json','43ec7de5a9a3d8faaa2fc9357864660b1001022a5663c6af2b091fe648883706'),
 ('english','freeze-manifest.json','e6b2c27396f5cea0171bb7fa97eb078aea16fdd357f597a003e66ffde35db2a3'),
 ('reconciled','freeze.json','51aa8fc419bbd25ea20a21d0ea4524b1c964888891c7aa0c400b449c3f6ba314'),
 ('semantic-review','freeze.json','81e6c82c71c035e51661aeed9056b502fecf5b2de8a5bdd01bc9c887a5098d21')]:
 p=B/angle/name;assert pin(p.read_bytes())['sha256']==sha
 f=read(p)['files'];items=f.items() if isinstance(f,dict) else ((x['path'],x) for x in f)
 for rel,r in items:
  p=B/angle/rel;assert p.resolve().is_relative_to((B/angle).resolve());assert pin(p.read_bytes())==exp(r),p
 frozen[angle]=dict(files=len(f),manifest_sha256=sha)
origin=read(B/'proposal-baseline.json');base=read(B/'baseline.json')
assert origin['commit']=='8575edf1e0de695677194c1fde60f1d9e2c2f204' and origin['course_boundary']==309
assert base['commit']==git('rev-parse','HEAD').decode().strip()=='af139c573f85aaf33278cd079719947ee9af8cdd'
assert base['course_boundary']==315 and not git('status','--porcelain','--untracked-files=no')
assert (B/'baseline.json').read_bytes()==(S/'later-acceptance-baseline.json').read_bytes()
for r in origin['source_pins'].values():assert pin(Path(r['path']).read_bytes())==exp(r)
for rel,r in origin['governing_git_pins'].items():assert pin(git('show',origin['commit']+':'+rel))==exp(r)
for name,rel in [('hgm_tools','engines/hgm_tools.py'),('build_alignment_layer','tools/build_alignment_layer.py'),('gen_alignment_page','tools/gen_alignment_page.py')]:
 raw=git('show',origin['commit']+':'+rel);assert raw==(S/'governing-originals'/(rel+'.txt')).read_bytes()
 m=types.ModuleType(name);m.__file__=str(W/rel);sys.modules[name]=m;exec(compile(raw,m.__file__,'exec'),m.__dict__)
G=sys.modules['gen_alignment_page']
db=sqlite3.connect(Path(origin['source_pins']['spine']['path']).as_uri()+'?mode=ro',uri=True)
db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
rows=[dict(x) for x in db.execute('select * from corpus_segments where course=? and seq between ? and ? order by seq',('C05',310,324))]
assert rows==read(S/'source-context-independent.json');sources={x['seq']:x for x in rows}
for name in ['source.json','context.json']:
 for r in read(B/name):assert all(sources[r['seq']][k]==v for k,v in r.items())
keys=['seq','id','d','tib','eng','tib_range','eng_range'];resolved={};native=[];specs={}
def check_fresh(n,raw):
 e=read(n/'execution.json');assert e['exit']==0 and (n/'exit.txt').read_bytes()==b'0\n' and (n/'stderr.bin').read_bytes()==b''
 assert e['cwd']==str(W) and e['environment']['PYTHONDONTWRITEBYTECODE']=='1'
 assert e['argv'][1:3]==['-B',str(S/'canonical_review.py')]
 assert (n/'stdin.bin').read_bytes()==raw
 for k,p in e['streams'].items():assert pin((n/(k+'.bin')).read_bytes())==p
 return (n/'stdout.bin').read_bytes()
assert (S/'canonical_review.py').read_bytes()==(S/'methods/canonical_review.py.txt').read_bytes()
for angle in ['tibetan','english','final']:
 for seq in [316,317,318]:
  p=Q/str(seq) if angle=='final' else B/angle/str(seq)
  raw=(p/'spec.json').read_bytes();spec=json.loads(raw);assert spec['course']=='C05' and len(spec['segments'])==1
  seg=spec['segments'][0];assert seg['seq']==seq;spans=seg['spans'];byid={x['id']:x for x in spans};assert len(byid)==len(spans)
  tr=G.resolve(sources[seq]['wylie'],spans,'tib',seq)
  er=G.resolve(sources[seq]['english'],G.with_members(spans,[byid[i] for i in seg['eng_order']],sources[seq]['english']),'eng',seq)
  rs=[dict(seq=seq,id=x['id'],d=x['d'],tib=x['tib'],eng=x['eng'],tib_range=list(tr[x['id']]),eng_range=list(er[x['id']]) if x['eng'] is not None else None) for x in spans]
  resolved[(angle,seq)]=rs;specs[(angle,seq)]=byid
  if angle=='final':
   assert check_fresh(S/'native/final'/str(seq)/'generator',raw)==(p/'body.html').read_bytes()
   assert json.loads(check_fresh(S/'native/final'/str(seq)/'resolver',raw))==rs
   assert rs==read(p/'resolved.json')['segments'][0]['resolved']
   assert [{k:x[k] for k in keys} for x in read(p/'decisions.json')['spans']]==rs
   assert read(p/'errata.json')==[]
  else:
   n=Q/'native/originals'/angle/str(seq)/'generate';i=read(n/'invocation.json');e=read(n/'execution.json')
   assert raw==(n/'stdin.json').read_bytes() and pin(raw)['sha256']==i['stdin_sha256']
   assert (n/'stdout').read_bytes()==(p/'body.html').read_bytes() and not (n/'stderr').read_bytes() and (n/'exit.txt').read_bytes()==b'0\n'
   assert e['exit_code']==0 and e['stdout_bytes']==(n/'stdout').stat().st_size and e['stderr_bytes']==0
   assert i['helper_sha256']==pin((Q/'canonical.py').read_bytes())['sha256'] and i['cwd']==str(W)
   assert i['argv'][1:]==['-B',str(Q/'canonical.py'),'generate'] and i['environment']['PYTHONDONTWRITEBYTECODE']=='1'
   assert json.loads(check_fresh(S/'native/original-resolvers'/angle/str(seq),raw))==rs
  native.append(dict(angle=angle,seq=seq,spec=pin(raw),body=pin((p/'body.html').read_bytes()),exit=0,root_generator_runs=0))
finals=sum((resolved[('final',n)] for n in [316,317,318]),[])
assert finals==read(S/'resolved-spans.json')
originals=[dict(angle=a,**r) for a in ['tibetan','english'] for n in [316,317,318] for r in resolved[(a,n)]]
assert originals==read(S/'original-resolved-spans.json')
dispositions=Counter();changes=[];omissions=[]
for seq in [316,317,318]:
 d=read(Q/str(seq)/'decisions.json');fin={x['id']:x for x in resolved[('final',seq)]};seen=set()
 for x in d['original_dispositions']:
  a=x['angle'];oid=x['original']['id'];assert (a,oid) not in seen;seen.add((a,oid))
  ori=next(r for r in resolved[(a,seq)] if r['id']==oid)
  assert x['original']==ori and x['original_spec_span']==specs[(a,seq)][oid]
  for r in x['final_tuples']:assert {k:r[k] for k in keys}==fin[r['id']]
  assert x['final_ids']==[r['id'] for r in x['final_tuples']]
  if x['disposition']=='retained_exact':assert len(x['final_ids'])==1 and all(ori[k]==fin[x['final_ids'][0]][k] for k in keys if k!='id')
  else:changes.append(x)
  dispositions[x['disposition']]+=1
 assert len(seen)==sum(len(resolved[(a,seq)]) for a in ['tibetan','english'])
 omissions += [dict(seq=seq,**x) for x in d['omissions']]
assert len(finals)==79 and len(originals)==150 and len(omissions)==21
master=json.load(gzip.open(origin['source_pins']['master']['path'],'rt'));corpus=json.load(gzip.open(origin['source_pins']['corpus']['path'],'rt'))
collections={k:(list(master[k].values()) if isinstance(master[k],dict) else master[k]) for k in ['unified_entries','curated_entries','glossary_entries']}
index=defaultdict(list)
for c,rr in collections.items():
 for i,r in enumerate(rr):
  if isinstance(r,dict):
   for t in set([r.get('wylie')]+(r.get('wylie_variants') or [])):
    if t:index[t].append(dict(collection=c,index=i,record=r))
mq=read(S/'independent-master-rechecks.json');mi=set()
for q in mq:
 expected=index[q['term']] if '/tibetan/' in q['original'] else [r for r in index[q['term']] if r['collection']=='unified_entries']
 assert q['records']==expected and q['count']==len(q['records'])
 mi.update((r['collection'],r['index']) for r in q['records'])
for r in read(S/'critical-complete-master-records-read.json'):assert collections[r['collection']][r['index']]==r['record']
bycourse=defaultdict(list)
for i,r in enumerate(corpus):bycourse[r['course']].append((i,r))
sq=read(S/'independent-sql-rechecks.json');ci=set()
for q in sq:
 actual=[dict(r) for r in db.execute(q['sql'],q['parameters'])];assert actual==q['rows'] and len(actual)==q['count']
 for r in actual:
  if 'course' in r and 'seq' in r:
   idx,record=bycourse[r['course']][r['seq']-1];assert json.loads(r['raw'])==record;ci.add(idx)
for r in read(S/'independent-full-corpus-rechecks.json')['original_records']:
 assert corpus[r['index']]==r['record'];ci.add(r['index'])
physical=Path(origin['source_pins']['physical']['path']).read_bytes()
for r in read(S/'physical-extents-independent.json'):
 assert r['count']==len(r['matches'])==1
 for m in r['matches']:
  raw=physical[slice(*m['byte_range'])];assert raw.decode('latin1')==m['latin1'] and pin(raw)['sha256']==m['sha256']
  assert ' '.join(raw.decode('latin1').split())==sources[r['seq']][r['field']]
screen=read(S/'five-ground-errata-review.json');assert len(screen)==6
for r in screen:
 assert r['refuted'] and not r['new_erratum'];g=r['independent_ground_checks']
 assert g['e_counts']['independently_remeasured']['source_chars']=={k:len(sources[r['seq']][k]) for k in ['acip','wylie','english']}
 for k,positions in g['a_quote']['exact_locations'].items():assert [m.start() for m in re.finditer('(?='+re.escape(r['found'])+')',sources[r['seq']][k])]==positions
assert len(re.findall(r'(?<![A-Za-z])gnag(?![A-Za-z])',sources[316]['wylie']))==1
assert len(re.findall(r'(?<![A-Za-z])gnag(?![A-Za-z])',sources[317]['wylie']))==4
assert read(S/'bank-ready-errata.json')==[] and read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
db.close();O.mkdir()
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save('resolved-spans.json',finals);save('original-resolved-spans.json',originals);save('changed-original-dispositions.json',changes);save('execution-reuse.json',native)
proof=dict(status='PASS_ROOT_INPUTS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=base['commit'],source_origin=origin['commit'],frozen=frozen,canonical_spans=229,final_spans=79,dispositions=dict(dispositions),material_omissions=21,root_generator_runs=0,verified_native_generations=9,independent_sql_queries=len(sq),complete_master_queries=len(mq),unique_master_objects=len(mi),complete_corpus_objects=len(ci),critical_complete_master_objects=35,physical_extents=6,semantic_five_ground_screens=6,errata=0,head_allowances=0,limits=['Linguistic approval is a separate root judgment.','No independent publication or ingestion lineage inferred from digital matches.','Original and reconciler source origin remains through309; only fresh reviewer received actual through315 baseline.'])
save('proof.json',proof);print(json.dumps(proof,indent=2))
