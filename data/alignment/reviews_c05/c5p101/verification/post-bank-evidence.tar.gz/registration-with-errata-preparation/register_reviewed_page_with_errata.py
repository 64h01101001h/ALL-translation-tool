"""Register one approved C05 page with its frozen, nonempty errata.

Usage: python3 -B register_reviewed_page_with_errata.py PAGE FIRST
       --reviewed-errata-sha256 SHA256 --review-freeze-sha256 SHA256
Keep this file in campaign-artifacts/registration-with-errata-preparation/.
Run only after ROOT code review, fresh semantic acceptance and landed-copy
verification. Exact canonical tools run in isolation before publication.
This binds reviewed bytes; it supplies no semantic judgment or HGM equivalents.
"""
from pathlib import Path
import ast
import argparse
import datetime
import difflib
import hashlib
import json
import os
import re
import shutil
import sqlite3
import stat
import subprocess
import sys
import traceback


CANONICAL = {
    'tools/merge_errata.py': '780387e0a83d26387f3658395af8476f1c41453a0c80408a93e02bee68d0f0e1',
    'tools/build_errata_register.py': '7e7c2dacf57426f2dc9e6bb13e137831b87f763f36b696d11b04d943c0ca39ac',
    'tools/test_errata_quotes_hold.py': 'e8d3862c460bb971055de60599fb9c3cc3e90e5e1d42f2ddba4806aa50e1dfd4',
    'tools/test_errata_name_their_witnesses.py': '4a2e74daa1733ede00433f75e2af74a950768a89e6bdb35473655891f7e546b6',
    'engines/hgm_tools.py': '11788e9fc3dc98e76ae9e1c3081e380696b3b75f65fbbeca148efaca274b77c6',
}
READONLY_PIN = 'c9c587ca1715dd333c98a743db2fa1c9d6e05eec597891ad42a7d3c17ab74801'
SIDECAR = 'docs/errata_register.json'
PROSE = 'docs/ERRATA_REGISTER.md'
SPINE = 'build/hgm_spine_v27_2.db'
FIELDS = ('kind', 'found', 'expected', 'evidence', 'severity', 'confidence')


def file_pin(path):
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            size += len(block)
            digest.update(block)
    return {'bytes': size, 'sha256': digest.hexdigest()}


def source_pin(path):
    resolved = path.resolve(strict=True)
    for suffix in ('-wal', '-journal'):
        journal = Path(str(resolved) + suffix)
        assert not journal.exists() or journal.stat().st_size == 0, ('Active SQLite journal', journal)
    return {'resolved_path': str(resolved), **file_pin(resolved)}


def expected_errata(incoming, old_raw, sequences, spine):
    """Assert the complete intended delta; never generate canonical output here."""
    assert isinstance(incoming, list) and incoming, 'Use v3 for empty errata'
    old = decode(old_raw)
    assert isinstance(old, list) and old, 'Expected an existing stable register'
    # Native merge reserializes. Require its existing format to preserve the
    # bytes of every prior entry, not merely decoded object equivalence.
    assert old_raw == json.dumps(old, ensure_ascii=False, indent=1).encode(), 'Noncanonical old register format'
    ids = []
    for record in old:
        item_id = record['item_id']
        assert isinstance(item_id, str) and re.fullmatch(r'E-[0-9]{3,}', item_id), item_id
        number = int(item_id[2:])
        assert item_id == f'E-{number:03d}' and number > 0
        ids.append(number)
    assert len(ids) == len(set(ids)), 'Duplicate prior stable ID'
    have = {(entry['segment'], entry.get('found', '')[:60]) for entry in old}
    seen, added, quotes = set(), [], []
    db = sqlite3.connect(spine.resolve().as_uri() + '?mode=ro', uri=True)
    try:
        db.execute('PRAGMA query_only=ON')
        assert db.execute('PRAGMA query_only').fetchone() == (1,)
        for number, entry in enumerate(incoming, max(ids) + 1):
            assert isinstance(entry, dict) and set(entry) == {'seq', *FIELDS}, 'Unexpected/missing erratum field'
            seq = entry['seq']
            assert type(seq) is int and seq in sequences, 'Erratum outside current approved page'
            assert all(isinstance(entry[field], str) and entry[field].strip() for field in FIELDS), 'Empty/non-string field'
            assert entry['kind'] in ('TIBETAN_SPELLING', 'ENGLISH_TYPO', 'ENGLISH_FACTUAL_ERROR', 'INGEST_ARTEFACT', 'FORMATTING')
            assert entry['severity'] in ('LOW', 'MEDIUM', 'HIGH')
            assert entry['confidence'] in ('UNCERTAIN', 'PROBABLE', 'CONFIRMED')
            found = entry['found']
            assert found == found.strip(), 'Native merge would change frozen found bytes'
            segment = f'C05:{seq}'
            signature = (segment, found[:60])
            assert signature not in have, ('Existing canonical duplicate signature', signature)
            assert signature not in seen, ('Duplicate incoming canonical signature', signature)
            seen.add(signature)
            rows = db.execute('SELECT wylie, english, acip FROM corpus_segments WHERE course=? AND seq=?', ('C05', seq)).fetchall()
            assert len(rows) == 1, ('Source row missing or ambiguous', segment)
            row = rows[0]
            columns = [column for column, value in zip(('wylie', 'english', 'acip'), row) if found in (value or '')]
            assert columns, ('Quote absent from original spine', segment, found)
            added.append({'item_id': f'E-{number:03d}', 'course': 'C05', 'segment': segment,
                          **{field: entry[field] for field in FIELDS},
                          'note': 'filed from the alignment batch, spine-verified on merge'})
            quotes.append({'segment': segment, 'found': found, 'matching_columns': columns,
                           'original_row': dict(zip(('wylie', 'english', 'acip'), row))})
    finally:
        db.close()
    return old, added, quotes


def native_run(destination, stage, label, script, *arguments):
    """Preserve native process evidence; no stdout reconstruction or shell."""
    evidence = destination / 'native' / label
    evidence.mkdir(parents=True, exist_ok=False)
    argv = [sys.executable, '-B', str(stage.parent / 'campaign-artifacts/run_tool_readonly_sqlite.py'), script, *map(str, arguments)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
    env.pop('PYTHONPATH', None)
    command = {'argv': argv, 'cwd': str(stage), 'stdin_bytes': 0,
               'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'PYTHONPATH': None},
               'utc_started': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (evidence / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    (evidence / 'stdin.bin').write_bytes(b'')
    try:
        result = subprocess.run(argv, cwd=stage, input=b'', capture_output=True, env=env, timeout=180)
    except subprocess.TimeoutExpired as exc:
        (evidence / 'stdout.bin').write_bytes(exc.stdout or b'')
        (evidence / 'stderr.bin').write_bytes(exc.stderr or b'')
        (evidence / 'timeout.json').write_text(json.dumps({'timeout_seconds': exc.timeout, 'exit': None}) + '\n')
        raise
    except BaseException:
        (evidence / 'launch-failure.txt').write_text(traceback.format_exc())
        raise
    (evidence / 'stdout.bin').write_bytes(result.stdout)
    (evidence / 'stderr.bin').write_bytes(result.stderr)
    (evidence / 'exit').write_text(str(result.returncode) + '\n')
    assert result.returncode == 0, ('Native tool failed', label, result.returncode)
    return result


def canonical_candidates(destination, dependencies, readonly, before, incoming_raw, expected, old, original_spine, spine_identity):
    stage = destination / 'canonical-stage/campaign-worktree'
    for relative, raw in {**dependencies, SIDECAR: before[SIDECAR], PROSE: before[PROSE]}.items():
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        assert target.read_bytes() == raw
    wrapper = stage.parent / 'campaign-artifacts/run_tool_readonly_sqlite.py'
    wrapper.parent.mkdir(parents=True)
    wrapper.write_bytes(readonly)
    incoming = stage.parent / 'frozen-errata.json'
    incoming.write_bytes(incoming_raw)
    spine = stage / SPINE
    spine.parent.mkdir(parents=True)
    # Exclusive creation and inode ownership make the later cleanup specific
    # to this staging copy. Never reuse or remove a source path.
    with original_spine.open('rb') as source, spine.open('xb') as target:
        created = os.fstat(target.fileno())
        shutil.copyfileobj(source, target, length=1024 * 1024)
    spine.chmod(0o444)
    assert file_pin(spine) == {key: spine_identity[key] for key in ('bytes', 'sha256')}
    assert source_pin(original_spine) == spine_identity, 'Original spine changed during copy'
    side, prose = stage / SIDECAR, stage / PROSE
    # Run the unmodified generator on the preimage too: stale prose must not
    # silently become part of this registration delta.
    native_run(destination, stage, 'baseline-prose', 'tools/build_errata_register.py')
    assert prose.read_bytes() == before[PROSE], 'Preexisting prose does not match canonical sidecar'
    count = len(expected)
    summary = f'incoming {count} | would add {count} | duplicate 0 | REFUSED 0'
    dry = native_run(destination, stage, 'merge-dry-run', 'tools/merge_errata.py', incoming, '--course', 'C05')
    assert dry.stdout.decode().splitlines()[0] == summary, 'Native dry-run delta differs'
    assert side.read_bytes() == before[SIDECAR] and prose.read_bytes() == before[PROSE], 'Dry run mutated candidates'
    applied = native_run(destination, stage, 'merge-apply', 'tools/merge_errata.py', incoming, '--course', 'C05', '--apply')
    assert applied.stdout.decode().splitlines()[0] == summary, 'Native apply refused/skipped records'
    result = side.read_bytes()
    assert decode(result) == old + expected, 'Native merge result is not the complete expected delta'
    assert result[:len(before[SIDECAR]) - 2] == before[SIDECAR][:-2], 'Prior register entry bytes changed'
    native_run(destination, stage, 'new-prose', 'tools/build_errata_register.py')
    generated = prose.read_bytes()
    native_run(destination, stage, 'quotes-hold', 'tools/test_errata_quotes_hold.py')
    native_run(destination, stage, 'witnesses-named', 'tools/test_errata_name_their_witnesses.py')
    # Prose identity is canonical reproduction, not our own table formatter.
    native_run(destination, stage, 'prose-reproduction', 'tools/build_errata_register.py')
    assert side.read_bytes() == result and prose.read_bytes() == generated
    assert file_pin(spine) == {key: spine_identity[key] for key in ('bytes', 'sha256')}
    assert source_pin(original_spine) == spine_identity
    assert incoming.read_bytes() == incoming_raw and wrapper.read_bytes() == readonly
    assert all((stage / path).read_bytes() == raw for path, raw in dependencies.items())
    # Successful candidates need only the source identity and native evidence
    # banked. A full source DB in landing would otherwise be archived per batch.
    expected_path = destination.resolve() / 'canonical-stage/campaign-worktree/build/hgm_spine_v27_2.db'
    assert spine.resolve() == expected_path and not spine.is_symlink()
    assert spine.resolve() != original_spine.resolve() and not spine.samefile(original_spine)
    owned = spine.stat()
    assert stat.S_ISREG(owned.st_mode) and (owned.st_dev, owned.st_ino) == (created.st_dev, created.st_ino)
    copied_pin = file_pin(spine)
    assert copied_pin == {key: spine_identity[key] for key in ('bytes', 'sha256')}
    retained = {str(path.relative_to(destination)): file_pin(path)
                for directory in (destination / 'canonical-stage', destination / 'native')
                for path in sorted(directory.rglob('*')) if path.is_file() and path != spine}
    cleanup = {'status': 'VERIFIED_OWNED_COPY', 'path': str(spine), 'device': owned.st_dev,
               'inode': owned.st_ino, **copied_pin, 'source_spine': spine_identity,
               'retained_files': retained, 'reason': 'Only successful helper-owned staging DB removed; native evidence and candidates retained.'}
    cleanup_path = destination / 'staging-spine-cleanup.json'
    cleanup_path.write_text(json.dumps(cleanup, indent=2) + '\n')
    current = spine.lstat()
    assert spine.resolve() == expected_path and stat.S_ISREG(current.st_mode)
    assert (current.st_dev, current.st_ino, current.st_size) == (owned.st_dev, owned.st_ino, copied_pin['bytes'])
    spine.unlink()
    assert not spine.exists() and not spine.is_symlink()
    assert source_pin(original_spine) == spine_identity
    assert all(file_pin(destination / path) == expected_pin for path, expected_pin in retained.items())
    cleanup['status'] = 'REMOVED_VERIFIED_OWNED_COPY'
    cleanup_path.write_text(json.dumps(cleanup, indent=2) + '\n')
    return {SIDECAR: result, PROSE: generated}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def normalize_allowances(value):
    # The two existing list forms are those accepted by the downstream verifier.
    if isinstance(value, list):
        result = {}
        for item in value:
            if 'key' in item:
                category, key = item['key'].split('/', 1)
            else:
                category, key = item['pages_directory'], item['allowlist_key']
            assert key not in result.setdefault(category, {}), ('duplicate allowance', key)
            result[category][key] = item['licensor']
        value = result
    assert isinstance(value, dict)
    assert not value or set(value) == {'pages_c05'}, 'Only the current C05 class may be extended'
    assert all(isinstance(entries, dict) for entries in value.values())
    return value


def main():
    if not __debug__:
        raise RuntimeError('Do not run this guard-based helper with Python optimization')
    artifacts = Path(__file__).resolve().parent.parent
    worktree = artifacts.parent / 'campaign-worktree'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('page', type=int)
    parser.add_argument('first', type=int)
    parser.add_argument('--reviewed-errata-sha256', required=True)
    parser.add_argument('--review-freeze-sha256', required=True)
    arguments = parser.parse_args()
    page, first = arguments.page, arguments.first
    for digest in (arguments.reviewed_errata_sha256, arguments.review_freeze_sha256):
        assert re.fullmatch(r'[0-9a-f]{64}', digest), 'Expected an explicit accepted SHA-256'
    sequences = list(range(first, first + 3))
    assert page * 3 == sequences[-1]
    batch = artifacts / f'C05-{first}-{first+2}'
    review = batch / 'semantic-review'
    landing = batch / 'landing'
    banked = worktree / f'data/alignment/reviews_c05/c5p{page}'
    captured = {}

    def capture(path):
        raw = path.read_bytes()
        if path in captured:
            assert captured[path] == raw, path
        captured[path] = raw
        return raw

    def read(path):
        return decode(capture(path))

    def git(*args):
        return subprocess.check_output(['git', *args], cwd=worktree)

    baseline = read(batch / 'baseline.json')
    head = git('rev-parse', 'HEAD').decode().strip()
    assert head == baseline['commit'] and baseline['course_boundary'] == first - 1
    proofs = [read(landing / name) for name in
              ('root-semantic-acceptance-proof.json', 'root-frozen-input-copy-check.json')]
    for checked in proofs:
        assert checked['head'] == head and checked['page'] == page and checked['segments'] == sequences
        assert checked['exact_final_hashes_counts_and_ranges'] and checked['original_review_bytes_identical']
        for name, field in [('review.md', 'review_sha256'), ('review.json', 'review_json_sha256')]:
            assert pin(capture(review / name))['sha256'] == checked[field]
    assert proofs[1]['landed_bytes_checked'] is True
    meta = read(review / 'review.json')
    assert meta['verdict'] == 'APPROVE' and meta['open_findings'] == []
    assert [item['seq'] for item in meta['segments']] == sequences
    freeze = read(review / 'review-freeze.json')
    assert pin(capture(review / 'review-freeze.json'))['sha256'] == arguments.review_freeze_sha256, 'Accepted review-freeze pin changed'
    assert freeze['verdict'] == 'APPROVE' and freeze['open_findings'] == []
    governing = freeze.get('governing_git_commit', freeze.get('source_origin_commit'))
    assert isinstance(governing, str) and re.fullmatch(r'(?:[0-9a-f]{40}|[0-9a-f]{64})', governing)
    proposal_baseline = read(batch / 'proposal-baseline.json')
    if governing != head:
        assert governing == proposal_baseline['commit'], 'Unrecognized historical governing origin'
    git('merge-base', '--is-ancestor', governing, head)
    assert capture(banked / 'review-freeze.json') == capture(review / 'review-freeze.json')
    frozen = {}
    for record in freeze['files']:
        path = Path(record['path'])
        relative = path.relative_to(review) if path.is_absolute() else path
        assert (review / relative).resolve().is_relative_to(review.resolve())
        assert str(relative) not in frozen
        frozen[str(relative)] = record

    def reviewed(relative):
        raw = capture(review / relative)
        assert pin(raw) == {key: frozen[relative][key] for key in ('bytes', 'sha256')}, relative
        assert capture(banked / relative) == raw, relative
        return decode(raw) if relative.endswith('.json') else raw

    reviewed('review.md')
    assert reviewed('review.json') == meta
    incoming = reviewed('bank-ready-errata.json')
    incoming_raw = capture(review / 'bank-ready-errata.json')
    assert pin(incoming_raw)['sha256'] == arguments.reviewed_errata_sha256, 'Accepted errata pin changed'
    # Verify every frozen file, including provenance, rather than only the
    # selected inputs consumed by registration.
    for relative, record in frozen.items():
        raw = capture(review / relative)
        assert pin(raw) == {key: record[key] for key in ('bytes', 'sha256')}, relative
        assert capture(banked / relative) == raw, relative
    requested = reviewed('span-head-allow-needed.json')
    wanted = normalize_allowances(requested)
    errata_before = {relative: capture(worktree / relative) for relative in (SIDECAR, PROSE)}
    for relative, raw in errata_before.items():
        assert raw == git('show', head + ':' + relative), ('Unexpected existing errata delta', relative)
    original_spine = worktree / SPINE
    spine_identity = source_pin(original_spine)
    reviewed_source_pin = proposal_baseline['source_pins']['spine']
    assert reviewed_source_pin['path'] == str(original_spine), 'Reviewed proposal spine path changed'
    assert {key: reviewed_source_pin[key] for key in ('bytes', 'sha256')} == {key: spine_identity[key] for key in ('bytes', 'sha256')}, 'Spine differs from reviewed proposal source'
    old_errata, expected_added, quote_bindings = expected_errata(incoming, errata_before[SIDECAR], sequences, original_spine)
    assert source_pin(original_spine) == spine_identity
    dependencies = {}
    for relative, expected_hash in CANONICAL.items():
        raw = capture(worktree / relative)
        assert pin(raw)['sha256'] == expected_hash, ('Canonical dependency changed; new code review required', relative)
        assert raw == git('show', head + ':' + relative), relative
        dependencies[relative] = raw
    readonly = capture(artifacts / 'run_tool_readonly_sqlite.py')
    assert pin(readonly)['sha256'] == READONLY_PIN, 'Read-only wrapper changed'
    allow_path = 'data/alignment/span_head_allow.json'
    old_allow_raw = capture(worktree / allow_path)
    assert old_allow_raw == git('show', head + ':' + allow_path), 'Unexpected existing allowance delta'
    old_allow = decode(old_allow_raw)
    assert isinstance(old_allow['pages_c05'], dict)

    spec_path = worktree / f'data/alignment/specs_c05/c5p{page}.json'
    spec = read(spec_path)
    landed = read(banked / 'landing.json')
    assert landed['course'] == 'C05' and landed['page'] == f'c5p{page}' and landed['segments'] == sequences
    assert landed['generator_exit'] == 0 and landed['spec_sha256'] == pin(capture(spec_path))['sha256']
    assert (worktree / f'data/alignment/pages_c05/c5p{page}.html').is_file()
    expected_segments = []
    spans = {}
    for row in meta['segments']:
        seq = row['seq']
        relative = f'reviewed-final/{seq}/spec.json'
        part = reviewed(relative)
        raw = capture(review / relative)
        assert pin(raw) == {'bytes': row['spec_bytes'], 'sha256': row['spec_sha256']}
        assert capture(batch / f'reconciled/{seq}/spec.json') == raw
        assert part['course'] == 'C05' and [s['seq'] for s in part['segments']] == [seq]
        segment = part['segments'][0]
        expected_segments.append(segment)
        for span in segment['spans']:
            assert re.fullmatch(r'[A-Za-z0-9_]+', span['id'])
            key = f'c5p{page}/s{seq}{span["id"]}'
            assert key not in spans, ('duplicate current span', key)
            spans[key] = dict(seq=seq, **span)
    assert spec == {'course': 'C05', 'segments': expected_segments}, 'Landed spec differs from approved current spans'
    bindings = []
    additions = wanted.get('pages_c05', {})
    for key, value in additions.items():
        assert key in spans, ('Allowance is not a span on the current approved page', key)
        assert key not in old_allow['pages_c05'], ('Existing allowance must not be replaced', key)
        assert isinstance(value, str) and value.strip(), ('Missing approved licensor', key)
        span = spans[key]
        assert span['d'] in (5, 7) and isinstance(span['eng'], str) and span['eng'], key
        bindings.append({'class': 'pages_c05', 'key': key, 'licensor': value, 'span': span})

    registry = 'tools/build_alignment_layer.py'
    index = 'data/alignment/pages_c05/index.html'
    before = {relative: capture(worktree / relative) for relative in (registry, index)}
    for relative, raw in before.items():
        assert raw == git('show', head + ':' + relative), ('Unexpected existing registration delta', relative)
    dependencies[registry] = before[registry]
    old_line = f'    "c5p{page-1}": {list(range(first-3, first))},\n'
    new_line = f'    "c5p{page}": {sequences},\n'
    source = before[registry].decode()
    assert source.count(old_line) == 1 and f'"c5p{page}"' not in source
    after = {registry: source.replace(old_line, old_line + new_line).encode()}
    ast.parse(after[registry])
    assert after[registry].replace(new_line.encode(), b'', 1) == before[registry]
    old_coverage = f'Reviewed campaign coverage: {first-1} of 511 source segments.'
    new_coverage = f'Reviewed campaign coverage: {first+2} of 511 source segments.'
    old_entry = f'<li><a href="c5p{page-1}.html">Page {page-1} · segments {first-3}–{first-1}</a></li>'
    new_entry = f'<li><a href="c5p{page}.html">Page {page} · segments {first}–{first+2}</a></li>'
    source = before[index].decode()
    assert source.count(old_coverage) == source.count(old_entry) == 1 and f'c5p{page}.html' not in source
    after[index] = source.replace(old_coverage, new_coverage).replace(old_entry, old_entry + '\n' + new_entry).encode()
    assert after[index].replace(new_coverage.encode(), old_coverage.encode(), 1).replace(('\n' + new_entry).encode(), b'', 1) == before[index]
    if additions:
        # Existing file format ends with pages_c05. Insert bytes only; never
        # reserialize existing explanations, classes, entries or their ordering.
        ending = b'\n  }\n}\n'
        assert old_allow_raw.endswith(ending) and old_allow_raw.count(b'  "pages_c05": {') == 1
        position = len(old_allow_raw) - len(ending)
        added_lines = ['    ' + json.dumps(key, ensure_ascii=False) + ': ' + json.dumps(value, ensure_ascii=False)
                       for key, value in additions.items()]
        insertion = ((',' if old_allow['pages_c05'] else '') + '\n' + ',\n'.join(added_lines)).encode()
        candidate = old_allow_raw[:position] + insertion + old_allow_raw[position:]
        expected_allow = decode(old_allow_raw)
        expected_allow['pages_c05'].update(additions)
        assert decode(candidate) == expected_allow
        assert candidate[:position] + candidate[position + len(insertion):] == old_allow_raw
        before[allow_path], after[allow_path] = old_allow_raw, candidate

    destination = landing / 'registration'
    destination.mkdir(exist_ok=False)
    # Preserve failure evidence even if an isolated canonical process writes a
    # partial candidate and exits zero. No W output is written in this block.
    (destination / 'method.py.txt').write_bytes(Path(__file__).read_bytes())
    for relative, raw in errata_before.items():
        saved = destination / 'before' / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        saved.write_bytes(raw)
    stage_proof = {'status': 'CANONICAL_PREPARATION', 'live_writes': [],
                   'baseline_commit': head, 'governing_source_commit': governing,
                   'method': pin(Path(__file__).read_bytes()),
                   'accepted_cli_pins': {'errata_sha256': arguments.reviewed_errata_sha256, 'review_freeze_sha256': arguments.review_freeze_sha256},
                   'inputs': [{'path': str(path), **pin(raw)} for path, raw in captured.items()],
                   'expected_added': expected_added, 'source_spine': spine_identity,
                   'quote_bindings': quote_bindings,
                   'reviewed_errata': {'path': str(review / 'bank-ready-errata.json'), **pin(incoming_raw)}}
    def save_stage():
        (destination / 'canonical-proof.json').write_text(json.dumps(stage_proof, ensure_ascii=False, indent=2) + '\n')
    save_stage()
    try:
        errata_after = canonical_candidates(destination, dependencies, readonly, errata_before, incoming_raw,
                                             expected_added, old_errata, original_spine, spine_identity)
        stage_proof['status'] = 'PASS'
    except BaseException:
        stage_proof.update(status='FAILED_BEFORE_PUBLICATION', failure=traceback.format_exc())
        raise
    finally:
        save_stage()
    before.update(errata_before)
    after.update(errata_after)
    # The allowance is also a guarded target when no addition is requested.
    before.setdefault(allow_path, old_allow_raw)
    after.setdefault(allow_path, old_allow_raw)
    modes = {}
    for relative in before:
        target = worktree / relative
        assert target.resolve().is_relative_to(worktree.resolve()), ('Target outside worktree', relative)
        assert not target.is_symlink() and stat.S_ISREG(target.stat().st_mode), ('Nonregular live target', relative)
        modes[relative] = stat.S_IMODE(target.stat().st_mode)
    records, patches = [], []
    for relative in before:
        for label, content in [('before', before[relative]), ('after', after[relative])]:
            target = destination / label / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
            assert target.read_bytes() == content
        patches.extend(difflib.unified_diff(before[relative].decode().splitlines(True), after[relative].decode().splitlines(True),
                                           fromfile='a/' + relative, tofile='b/' + relative))
        records.append({'path': relative, 'before_sha256': pin(before[relative])['sha256'],
                        'after_sha256': pin(after[relative])['sha256'], 'mode': modes[relative]})
    (destination / 'exact-change.diff').write_text(''.join(patches))
    method = Path(__file__).read_bytes()
    (destination / 'method.py.txt').write_bytes(method)
    proof = {'status': 'PREPARED', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'page': page, 'segments': sequences, 'baseline_commit': head, 'governing_source_commit': governing, 'files': records,
             'method': pin(method), 'inputs': [{'path': str(path), **pin(raw)} for path, raw in captured.items()],
             'errata': expected_added, 'prior_errata_retained': len(old_errata),
             'source_spine': spine_identity, 'quote_bindings': quote_bindings,
             'accepted_cli_pins': stage_proof['accepted_cli_pins'],
             'head_allowances': wanted, 'requested_allowances': requested,
             'allowance_span_bindings': bindings, 'written_files': [],
             'attempted_files': [], 'recovery': [],
             'integration_limit': 'Canonical prose retains its inherited historical coverage sentence; it is not current campaign coverage and is not altered by this helper.',
             'scope': 'Exact registry/index update, frozen allowances and canonical errata sidecar/prose only; no semantic judgment, source correction or machine-gloss promotion.'}

    def save_proof():
        (destination / 'proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')

    save_proof()  # Candidates, preimages, diff and PREPARED proof precede W writes.
    try:
        assert git('rev-parse', 'HEAD').decode().strip() == head
        for path, raw in captured.items():
            assert path.read_bytes() == raw, ('Input changed after preparation', path)
        assert source_pin(original_spine) == spine_identity
        # Verify ALL five live preimages and modes before the FIRST write.
        # Recheck each target at its own write too; a changed target is never
        # knowingly overwritten. This is not an atomic multi-file transaction.
        for relative in before:
            target = worktree / relative
            assert not target.is_symlink() and stat.S_IMODE(target.stat().st_mode) == modes[relative]
            assert target.read_bytes() == before[relative], relative
        for relative in before:
            if after[relative] == before[relative]:
                continue
            target = worktree / relative
            assert target.resolve().is_relative_to(worktree.resolve()) and not target.is_symlink()
            assert stat.S_IMODE(target.stat().st_mode) == modes[relative]
            assert target.read_bytes() == before[relative], relative
            proof['attempted_files'].append(relative)
            save_proof()
            (worktree / relative).write_bytes(after[relative])
            assert (worktree / relative).read_bytes() == after[relative]
            assert stat.S_IMODE((worktree / relative).stat().st_mode) == modes[relative]
            proof['written_files'].append(relative)
            save_proof()
        for relative in before:
            assert (worktree / relative).read_bytes() == after[relative]
            assert stat.S_IMODE((worktree / relative).stat().st_mode) == modes[relative]
        assert source_pin(original_spine) == spine_identity
        assert git('rev-parse', 'HEAD').decode().strip() == head
        for path, raw in captured.items():
            if path not in {worktree / relative for relative in after}:
                assert path.read_bytes() == raw, ('Input changed during publication', path)
        proof['status'] = 'PASS'
    except BaseException:
        proof.update(status='FAILED', failure=traceback.format_exc())
        # Roll back only complete candidate bytes we can recognize as ours.
        # Truncated writes or concurrent changes require manual recovery from
        # recorded preimages; never overwrite an unrecognized current value.
        for relative in reversed(proof['attempted_files']):
            target = worktree / relative
            recovery = {'path': relative}
            try:
                current = target.read_bytes()
                recovery['observed'] = pin(current)
                if target.is_symlink() or stat.S_IMODE(target.stat().st_mode) != modes[relative]:
                    recovery['status'] = 'MANUAL_RECOVERY_REQUIRED_MODE_OR_SYMLINK'
                elif current == before[relative]:
                    recovery['status'] = 'ALREADY_PREIMAGE'
                elif current == after[relative]:
                    target.write_bytes(before[relative])
                    assert target.read_bytes() == before[relative]
                    recovery['status'] = 'ROLLED_BACK'
                else:
                    recovery['status'] = 'MANUAL_RECOVERY_REQUIRED_UNRECOGNIZED_BYTES'
            except BaseException:
                recovery.update(status='MANUAL_RECOVERY_REQUIRED', failure=traceback.format_exc())
            proof['recovery'].append(recovery)
        proof['preimages_restored'] = all((worktree / path).is_file() and not (worktree / path).is_symlink()
                                         and (worktree / path).read_bytes() == raw
                                         and stat.S_IMODE((worktree / path).stat().st_mode) == modes[path]
                                         for path, raw in before.items())
        raise
    finally:
        save_proof()
    print(json.dumps({'status': proof['status'], 'page': page, 'segments': sequences,
                      'baseline_commit': head, 'governing_source_commit': governing,
                      'prior_errata_retained': len(old_errata), 'added_errata': [entry['item_id'] for entry in expected_added],
                      'head_allowance_additions': len(additions), 'written_files': proof['written_files'],
                      'proof': str(destination / 'proof.json'), 'method': proof['method']}, indent=2))


if __name__ == '__main__':
    main()
