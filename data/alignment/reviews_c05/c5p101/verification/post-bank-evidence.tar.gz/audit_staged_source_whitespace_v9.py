"""Audit every staged whitespace warning without decoding legacy source bytes.

Preserve canonical source and CRLF CSV bytes. Unexpected warnings fail closed.
Run after staging a reviewed page; stage this proof before committing.
"""
from collections import defaultdict
import datetime
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys


def verify_native_fidelity_summary(raw, grouped, pin, rel):
    """Recognize only the exact C05 301–303 historical finalize-evidence-01 log.

    This class preserves native print separators, not source or semantic errors.
    Every provenance item must be the unique original manifest entry and match
    its independently frozen copy. No native program is executed here.
    """
    assert (page, first) == (101, 301)
    assert set(pin) == {'kind', 'bytes', 'sha256', 'provenance'}
    assert (len(raw), hashlib.sha256(raw).hexdigest()) == (
        433, '776e6f649453314c00cae5f9561444979c9091437625dcc27d5d832d6d24460e')
    assert dict(grouped) == {'trailing whitespace.': [1, 2, 3, 4]}
    base = batch / 'tibetan'
    used = set()

    def witness(relative):
        original_path = str(base / relative)
        matches = [m for m in manifest if m['original'] == original_path]
        assert len(matches) == 1, original_path
        record = matches[0]
        assert record == pin['provenance'][relative]
        assert set(record) == {'original', 'copy', 'bytes', 'sha256'}
        copied = Path(record['copy'])
        assert not copied.is_absolute() and '..' not in copied.parts
        assert (review_root / copied).resolve().is_relative_to(review_root.resolve())
        frozen = review_freeze[str(copied)]
        value = Path(original_path).read_bytes()
        assert value == (review_root / copied).read_bytes()
        assert len(value) == record['bytes'] == frozen['bytes']
        assert hashlib.sha256(value).hexdigest() == record['sha256'] == frozen['sha256']
        used.add(relative)
        return value

    native = 'evidence/native/'
    assert witness(native + 'finalize-evidence-01.stdout') == raw
    assert pin['provenance'][native + 'finalize-evidence-01.stdout']['copy'] == rel
    assert witness(native + 'finalize-evidence-01.stderr') == b''
    helper = witness('finalize_evidence.py')
    assert helper == witness(native + 'finalize-evidence-01.input.py')
    assert (len(helper), hashlib.sha256(helper).hexdigest()) == (
        8764, 'd7ffa15b41b2d7560b584ceb7dd3c171ee94cbab0cd8829f317d0f0114ec63aa')
    invocation = json.loads(witness(native + 'finalize-evidence-01.json'))
    assert type(invocation['exit']) is int and invocation['exit'] == 0
    assert invocation == dict(command=['python3', str(base.relative_to(art.parent) / 'finalize_evidence.py')],
                              cwd=str(art.parent), environment={'PYTHONDONTWRITEBYTECODE': '1'}, exit=0)
    gates = json.loads(witness('evidence/gate-runs.json'))
    names = ('test_no_broken_words.py', 'test_no_split_syllables.py',
             'test_no_degenerate_members.py', 'test_no_supplied_span_head.py')
    assert type(gates) is list and len(gates) == len(names)
    expected = b''
    for gate, name in zip(gates, names):
        witness('validation-runtime/tools/' + name)
        assert type(gate['exit']) is int and gate['exit'] == 0
        assert gate == dict(
            command=['/opt/homebrew/opt/python@3.14/bin/python3.14', str(base / 'validation-runtime/tools' / name)],
            cwd=str(wt), environment={'PYTHONDONTWRITEBYTECODE': '1'}, exit=0,
            stdout_file='native/' + name + '.stdout', stderr_file='native/' + name + '.stderr',
            scope='Three exact proposal bodies only; unchanged tool bytes from pinned Git object; original pinned span-head allowance.')
        stdout = witness(native + name + '.stdout')
        stderr = witness(native + name + '.stderr')
        assert stderr == b''
        expected += (' '.join((name, 'EXIT=0', stdout.decode().strip(), stderr.decode().strip())) + '\n').encode()
    expected += b'All original source pins still match; physical complete records and targeted fidelity gates verified.\n'
    assert raw == expected
    lines = raw.split(b'\n')
    assert len(lines) == 6 and lines[-1] == b''
    assert all(line.endswith(b' ') and not line.endswith(b'  ') for line in lines[:4])
    assert set(pin['provenance']) == used
    return [pin['provenance'][item]['original'] for item in sorted(used)]

art = Path(__file__).resolve().parent
wt = art.parent / 'campaign-worktree'
page, first = map(int, sys.argv[1:3])
assert len(sys.argv) in (3, 4)
freeze_name = sys.argv[3] if len(sys.argv) == 4 else 'review-freeze.json'
assert freeze_name in ('review-freeze.json', 'freeze.json')
batch = art / f'C05-{first}-{first+2}'
out = batch / 'landing'
target = out / 'source-whitespace-proof.json'
assert not target.exists(), 'Preserve earlier proof before another audit'
run = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=wt, capture_output=True)
(out / 'staged-diff-check.stdout').write_bytes(run.stdout)
(out / 'staged-diff-check.stderr').write_bytes(run.stderr)
(out / 'staged-diff-check.exit').write_text(str(run.returncode) + '\n')
assert run.returncode in (0, 2) and not run.stderr
manifest = json.loads((batch / 'semantic-review/original-to-copy-manifest.json').read_text())
physical = defaultdict(list)
for record in manifest:
    if record['original'].endswith('ReadingASCII.txt'):
        raw = Path(record['original']).read_bytes()
        assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
        physical[(len(raw), record['sha256'])].append(record['original'])
csv_paths = {
    'docs/geshe_michael_roach_dictionary.csv',
    'docs/geshe_michael_roach_dictionary_reverse.csv',
    'docs/geshe_michael_roach_dictionary_by_course.csv',
    'docs/geshe_michael_roach_dictionary_changes.csv',
}
issues = defaultdict(lambda: defaultdict(list))
header = re.compile(rb'^([^+\n]+):([0-9]+): (.+)$')
for line in run.stdout.split(b'\n'):
    match = header.match(line)
    if match:
        path, number, warning = match.groups()
        issues[path.decode('utf-8')][warning.decode('ascii')].append(int(number))
    else:
        assert not line.strip() or line.startswith(b'+'), repr(line[:160])
exact_path = out / 'review-whitespace-exact-pins.json'
exact = json.loads(exact_path.read_text()) if exact_path.exists() else {}
review_root = batch / 'semantic-review'
review_freeze = {}
if exact:
    for record in json.loads((review_root / freeze_name).read_text())['files']:
        recorded_path = Path(record['path'])
        relative_path = recorded_path.relative_to(review_root) if recorded_path.is_absolute() else recorded_path
        assert (review_root / relative_path).resolve().is_relative_to(review_root.resolve())
        assert str(relative_path) not in review_freeze
        review_freeze[str(relative_path)] = record
files = {}
for path, grouped in issues.items():
    raw = (wt / path).read_bytes()
    staged = subprocess.check_output(['git', 'show', ':' + path], cwd=wt)
    assert staged == raw, path
    digest = hashlib.sha256(raw).hexdigest()
    if path in csv_paths:
        assert set(grouped) == {'trailing whitespace.'}, (path, grouped.keys())
        lines = raw.split(b'\n')
        assert all(lines[n-1].endswith(b'\r') for n in grouped['trailing whitespace.']), path
        reason = 'Canonical CSV CRLF; every warning line verified to end in CR before LF'
        originals = []
    elif path == f'data/alignment/reviews_c05/c5p{page}/review.md':
        assert set(grouped) == {'new blank line at EOF.'}, grouped.keys()
        frozen = (batch / 'semantic-review/review.md').read_bytes()
        accepted = json.loads((out / 'root-semantic-acceptance-proof.json').read_text())
        assert raw == frozen and digest == accepted['review_sha256']
        lines = raw.split(b'\n')
        assert all(not b''.join(lines[n-1:]).strip() for n in grouped['new blank line at EOF.'])
        reason = 'Exact accepted review bytes; only verified empty trailing lines at EOF'
        originals = [str(batch / 'semantic-review/review.md')]
    elif path.removeprefix(f'data/alignment/reviews_c05/c5p{page}/') in exact:
        assert path.startswith(f'data/alignment/reviews_c05/c5p{page}/'), path
        rel = path.removeprefix(f'data/alignment/reviews_c05/c5p{page}/')
        pin = exact[rel]
        assert digest == pin['sha256'] == review_freeze[rel]['sha256']
        assert len(raw) == pin['bytes'] == review_freeze[rel]['bytes']
        original = review_root / rel
        assert raw == original.read_bytes()
        lines = raw.split(b'\n')
        if pin['kind'] == 'physical_bytes':
            witness = Path(pin['witness']['path'])
            witness_raw = witness.read_bytes()
            assert len(witness_raw) == pin['witness']['bytes']
            assert hashlib.sha256(witness_raw).hexdigest() == pin['witness']['sha256']
            lo, hi = pin['byte_range']
            assert 0 <= lo < hi <= len(witness_raw) and witness_raw[lo:hi] == raw
            assert set(grouped) <= {'trailing whitespace.', 'space before tab in indent.', 'new blank line at EOF.'}
        elif pin['kind'] == 'physical_source_lines':
            assert set(grouped) == {'trailing whitespace.'}
            witnesses = pin['line_witnesses']
            assert set(witnesses) == {str(n) for n in grouped['trailing whitespace.']}
            for number in grouped['trailing whitespace.']:
                item = witnesses[str(number)]
                witness = Path(item['witness']['path'])
                witness_raw = witness.read_bytes()
                assert len(witness_raw) == item['witness']['bytes']
                assert hashlib.sha256(witness_raw).hexdigest() == item['witness']['sha256']
                assert (len(witness_raw), hashlib.sha256(witness_raw).hexdigest()) in physical
                lo, hi = item['byte_range']
                assert 0 <= lo < hi <= len(witness_raw)
                assert witness_raw[lo:hi] == lines[number-1]
                assert lo == 0 or witness_raw[lo-1:lo] == b'\n'
                assert witness_raw[hi:hi+1] in (b'\r', b'\n')
        elif pin['kind'] == 'native_generator_summary':
            assert set(grouped) == {'trailing whitespace.'}
            expected = b''
            for summary in pin['summaries']:
                assert summary['seq'] in range(first, first+3)
                values = {}
                for key in ('body', 'stderr', 'exit'):
                    witness = summary[key]
                    value = Path(witness['path']).read_bytes()
                    assert len(value) == witness['bytes'] and hashlib.sha256(value).hexdigest() == witness['sha256']
                    assert any(m['original'] == witness['path'] and m['bytes'] == len(value) and m['sha256'] == witness['sha256'] for m in manifest)
                    values[key] = value
                exit_code = values['exit'].decode('ascii').strip()
                assert re.fullmatch(r'-?\d+', exit_code)
                expected += f"{summary['seq']} EXIT={exit_code} body_bytes={len(values['body'])} ".encode('ascii') + values['stderr'] + b'\n'
            assert raw == expected
            assert all(lines[n-1].endswith(b' ') for n in grouped['trailing whitespace.'])
        elif pin['kind'] == 'native_fidelity_summary':
            native_originals = verify_native_fidelity_summary(raw, grouped, pin, rel)
        elif pin['kind'] == 'blank_eof':
            assert set(grouped) == {'new blank line at EOF.'}
            assert all(not b''.join(lines[n-1:]).strip() for n in grouped['new blank line at EOF.'])
        elif pin['kind'] == 'physical_chunk_stdout':
            assert set(grouped) == {'trailing whitespace.'}
            witness = Path(pin['witness']['path'])
            witness_raw = witness.read_bytes()
            assert len(witness_raw) == pin['witness']['bytes']
            assert hashlib.sha256(witness_raw).hexdigest() == pin['witness']['sha256']
            assert (len(witness_raw), hashlib.sha256(witness_raw).hexdigest()) in physical
            lo, hi = pin['source_byte_range']
            start, end = pin['output_byte_range']
            assert 0 <= lo < hi <= len(witness_raw) and 0 <= start < end <= len(raw)
            assert raw[start:end] == witness_raw[lo:hi]
            offsets = [0]
            for line in lines[:-1]:
                offsets.append(offsets[-1] + len(line) + 1)
            assert all(start <= offsets[n-1] and offsets[n-1] + len(lines[n-1]) <= end for n in grouped['trailing whitespace.'])
        elif pin['kind'] == 'printed_corpus_row':
            assert set(grouped) == {'trailing whitespace.'}
            assert set(pin['source_rows']) == {str(n) for n in grouped['trailing whitespace.']}
            database = sqlite3.connect((wt / 'build/hgm_spine_v27_2.db').as_uri() + '?mode=ro', uri=True)
            try:
                database.execute('PRAGMA query_only=ON')
                for n in grouped['trailing whitespace.']:
                    row = pin['source_rows'][str(n)]
                    assert row['course'] == 'C05' and isinstance(row['seq'], int)
                    value = database.execute('SELECT wylie FROM corpus_segments WHERE course=? AND seq=?', (row['course'], row['seq'])).fetchone()
                    assert value is not None
                    assert lines[n-1] == ('ROW C05 ' + str(row['seq']) + ' ' + value[0] + ' ').encode('utf-8')
            finally:
                database.close()
        else:
            assert set(grouped) == {'trailing whitespace.'}
            expected = b' ' if pin['kind'] == 'diff_context' else b'local_after_common_prefix: '
            assert pin['kind'] in ('diff_context', 'empty_report_field')
            assert all(lines[n-1] == expected for n in grouped['trailing whitespace.'])
        reason = 'Exact independently frozen evidence: verified EOF/diff/report spacing, original physical bytes/lines/chunks, or an exact original Wylie row followed by the recorded print separator'
        if pin['kind'] == 'native_fidelity_summary':
            reason = 'Exact frozen native fidelity log reconstructed from four original recorded stdout/stderr pairs and zero-exit command metadata; only four terminal print separators'
            originals = [str(original)] + native_originals
        elif pin['kind'] in ('physical_bytes', 'physical_chunk_stdout'):
            originals = [str(original), pin['witness']['path']]
        elif pin['kind'] == 'physical_source_lines':
            originals = [str(original)] + [item['witness']['path'] for item in pin['line_witnesses'].values()]
        else:
            originals = [str(original)]
    else:
        assert path.startswith(f'data/alignment/reviews_c05/c5p{page}/'), path
        originals = physical[(len(raw), digest)]
        assert originals, ('Unclassified source warning', path, len(raw), digest)
        assert raw == Path(originals[0]).read_bytes(), path
        reason = 'Complete original physical source bytes retained exactly'
    files[path] = dict(bytes=len(raw), sha256=digest, reason=reason,
                       original_paths=sorted(set(originals)), issues=dict(grouped))
assert bool(issues) == (run.returncode == 2)
proof = dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             baseline_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=wt).decode().strip(),
             review_freeze_name=freeze_name,
             review_freeze_sha256=hashlib.sha256((review_root / freeze_name).read_bytes()).hexdigest(),
             git_diff_check_exit=run.returncode,
             warning_count=sum(len(lines) for groups in issues.values() for lines in groups.values()),
             all_warnings_accounted_for=True, files=files,
             raw_log_kept_external=str(out / 'staged-diff-check.stdout'),
             raw_log_bytes=len(run.stdout), raw_log_sha256=hashlib.sha256(run.stdout).hexdigest(),
             method='Parse all ASCII diagnostic headers; compare each cited file to the index. Verify complete source identity, CSV CRLF, exact frozen EOF/report/diff spacing, bounded original physical source chunks, or exact read-only corpus rows plus the recorded print separator. No normalization or source mutation.')
target.write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items() if k != 'files'}, indent=2))
print(json.dumps({p: sum(map(len, r['issues'].values())) for p, r in files.items()}, indent=2))
