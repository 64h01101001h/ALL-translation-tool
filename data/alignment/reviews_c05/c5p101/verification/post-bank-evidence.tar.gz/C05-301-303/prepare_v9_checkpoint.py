"""Record root's code review and preserve the failed v8 audit before exact v9 pins."""
from pathlib import Path
import datetime, hashlib, json

B = Path(__file__).resolve().parent
A = B.parent
P = A / 'native-log-whitespace-v9-preparation'
def pin(raw): return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def read(p): return json.loads(p.read_bytes())
def save(p,d):
    assert not p.exists(), p
    p.write_text(json.dumps(d, indent=2)+'\n')

report=read(P/'control-report.json')
assert report['status']=='ALL_ISOLATED_CONTROLS_PASS' and report['total_cases']==33
assert pin((A/'audit_staged_source_whitespace_v9.py').read_bytes())==report['v9']==dict(bytes=16608,sha256='b3029500b9001e4cee44f5db6de000f6e5c7b163da6f15a418c71a5b2b7b7e86')
assert pin((A/'audit_staged_source_whitespace_v8.py').read_bytes())==report['v8_unchanged']
assert (A/'audit_staged_source_whitespace_v8.py').read_bytes()==(P/'v8-recovered-byte-identical.py.txt').read_bytes()
assert pin((P/'candidate-native-log-pin.json').read_bytes())==report['candidate']
for row in report['results']:
    assert row['passed']
    d=P/'control-results'/row['case']
    if row['version']=='v9-isolated-function':
        assert 'AssertionError' in (d/'caught-stderr.txt').read_text()
    else:
        d=d/row['version']
        assert int((d/'exit.txt').read_text())==row['actual_exit']
        assert pin((d/'stderr.bin').read_bytes())['sha256']==row['stderr_sha256']
        assert (row['actual_exit']==0)==(row['expected']=='accept')
for path, identity in read(P/'protected-identities-before.json').items():
    assert pin(Path(path).read_bytes())==identity
assert read(P/'protected-identities-before.json')==read(P/'protected-identities-after.json')
save(B/'whitespace-v9-root-review.json',dict(verdict='APPROVE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),v9=report['v9'],controls=pin((P/'control-report.json').read_bytes()),review='Root fully read all three diff hunks and the complete 16544-byte control source/report. The 71-line new handler accepts only one fixed 433-byte historical log and fixed producer helper, requires all 18 original manifest/frozen witnesses, exact native commands and integer zero exits, empty stderr, reconstructed complete output, and warning lines 1–4. Existing v8 source recovered byte-identically after removing additions. All33 actual controls and35 protected identities verified. One synthetic fixture construction failure is preserved; no production source, semantic gate or evidence normalization.',limit='Private evidence whitespace classification only. Actual production audit still required.'))
old=B/'landing/v8-audit-attempt01-preserved'
old.mkdir(exist_ok=False)
records=[]
for name in ('staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit','review-whitespace-exact-pins.json'):
    p=B/'landing'/name; raw=p.read_bytes(); (old/name).write_bytes(raw)
    assert (old/name).read_bytes()==raw
    records.append(dict(original=str(p),copy=str(old/name),**pin(raw)))
save(old/'manifest.json',dict(reason='Initial v8 refused four original print separators; preserve exact diagnostic and pins before v9 attempt02.',files=records))
target=B/'landing/review-whitespace-exact-pins.json'
pins=read(target); extra=read(P/'candidate-native-log-pin.json')
assert len(extra)==1 and not (set(extra)&set(pins))
merged={**pins,**extra}
target.write_text(json.dumps(merged,indent=2)+'\n')
assert all(read(target)[k]==v for k,v in pins.items())
save(B/'v9-pin-preparation-proof.json',dict(status='PASS',old_pin_count=len(pins),new_pin_count=len(merged),only_added=list(extra),preserved_manifest=str(old/'manifest.json'),source_and_semantic_bytes_unchanged=True))
print('PASS: root v9 code review recorded, failed v8 preserved, exactly one native-log pin added.')
