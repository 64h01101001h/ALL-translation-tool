"""Capture exact argv/cwd/stdout/stderr/exit for a preparation-only command."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

out = Path(__file__).resolve().parent / 'commands' / sys.argv[1]
out.mkdir(parents=True, exist_ok=False)
command = sys.argv[2:]
assert command
record = dict(command=command, cwd=str(Path.cwd()), started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), environment={'PYTHONDONTWRITEBYTECODE': '1'})
(out / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
run = subprocess.run(command, capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
(out / 'stdout.bin').write_bytes(run.stdout)
(out / 'stderr.bin').write_bytes(run.stderr)
(out / 'exit.txt').write_text(str(run.returncode) + '\n')
record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['exit'] = run.returncode
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
sys.stdout.buffer.write(run.stdout)
sys.stderr.buffer.write(run.stderr)
sys.exit(run.returncode)
