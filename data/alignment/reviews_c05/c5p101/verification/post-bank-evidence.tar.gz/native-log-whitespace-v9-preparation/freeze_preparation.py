"""Freeze completed candidate/control records without copying fixture trees."""
from pathlib import Path
import datetime
import hashlib
import json

out = Path(__file__).resolve().parent
target = out / 'preparation-freeze.json'
assert not target.exists()
report = json.loads((out / 'control-report.json').read_bytes())
assert report['status'] == 'ALL_ISOLATED_CONTROLS_PASS' and report['total_cases'] == 33
assert report['all_protected_bytes_unchanged']
paths = [out.parent / 'audit_staged_source_whitespace_v9.py']
for path in out.rglob('*'):
    rel = path.relative_to(out)
    if not path.is_file() or 'fixtures' in rel.parts or '.git' in rel.parts:
        continue
    if rel.parts[:2] == ('commands', '05-freeze'):
        continue  # This recorder is still running; all prior commands are complete.
    paths.append(path)
files = []
for path in sorted(paths):
    raw = path.read_bytes()
    files.append(dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
freeze = dict(status='PREPARED_FOR_ROOT_REVIEW_ONLY', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              production_v9_executed=False, native_programs_executed=False,
              files=files, file_count=len(files),
              exclusions=['Disposable fixture trees, whose per-case inputs/commands/results are frozen separately', 'This freeze itself', 'The still-running 05-freeze command recorder'],
              scope='Candidate helper, one-entry pin proposal, full diff, preparation/control sources, final and failed control records, protected before/after identities, and review instructions. No stage/landing edit.')
target.write_text(json.dumps(freeze, indent=2) + '\n')
print(json.dumps(dict(status=freeze['status'], freeze=str(target), files=len(files), bytes=target.stat().st_size, sha256=hashlib.sha256(target.read_bytes()).hexdigest(), helper=report['v9'], candidate=report['candidate'], cases=report['total_cases']), indent=2))
