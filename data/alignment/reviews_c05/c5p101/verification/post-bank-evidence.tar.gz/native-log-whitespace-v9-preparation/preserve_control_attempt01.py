"""Preserve the first synthetic-control attempt before correcting its fixture."""
from pathlib import Path
import hashlib
import json

out = Path(__file__).resolve().parent
attempt = out / 'attempts/attempt-01'
attempt.mkdir(parents=True, exist_ok=False)
source = (out / 'controls.py').read_bytes()
(attempt / 'controls.py.txt').write_bytes(source)
for name in ('fixtures', 'control-results'):
    (out / name).rename(attempt / name)
record = dict(status='PRESERVED_FAILED_FIXTURE_ATTEMPT', control_source_sha256=hashlib.sha256(source).hexdigest(),
              cause='Legacy diff-context fixture ended with a space-only line, causing both trailing-whitespace and blank-EOF warnings. Existing v8 correctly rejected it. Add a nonblank sentinel to test only the intended existing diff_context class.',
              helper_changed=False, production_audit_executed=False)
(attempt / 'note.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
