"""Create an additive v9 candidate and one pin; never execute the production audit."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ART = OUT.parent
BATCH = ART / 'C05-301-303'
REVIEW = BATCH / 'semantic-review'
V8_SHA = '514df93b7583ca152140f00b3ca2edc4c9317e38054808c0927adb9089412450'

ADDITION = '''

def verify_native_fidelity_summary(raw, grouped, pin, rel):
    """Recognize only the exact C05 301–303 historical finalize-evidence-01 log.

    This class preserves native print separators, not source or semantic errors.
    Every provenance item must be the unique original manifest entry and match
    its independently frozen copy. No native program is executed here.
    """
    assert (page, first) == (101, 301)
    assert set(pin) == {'kind', 'bytes', 'sha256', 'provenance'}
    assert (len(raw), hashlib.sha256(raw).hexdigest()) == (
        433, '776e6f649453314c00cae5f9561444979c9091437625dcc27d5d832d6d24460e')
    assert dict(grouped) == {'trailing whitespace.': [1, 2, 3, 4]}
    base = batch / 'tibetan'
    used = set()

    def witness(relative):
        original_path = str(base / relative)
        matches = [m for m in manifest if m['original'] == original_path]
        assert len(matches) == 1, original_path
        record = matches[0]
        assert record == pin['provenance'][relative]
        assert set(record) == {'original', 'copy', 'bytes', 'sha256'}
        copied = Path(record['copy'])
        assert not copied.is_absolute() and '..' not in copied.parts
        assert (review_root / copied).resolve().is_relative_to(review_root.resolve())
        frozen = review_freeze[str(copied)]
        value = Path(original_path).read_bytes()
        assert value == (review_root / copied).read_bytes()
        assert len(value) == record['bytes'] == frozen['bytes']
        assert hashlib.sha256(value).hexdigest() == record['sha256'] == frozen['sha256']
        used.add(relative)
        return value

    native = 'evidence/native/'
    assert witness(native + 'finalize-evidence-01.stdout') == raw
    assert pin['provenance'][native + 'finalize-evidence-01.stdout']['copy'] == rel
    assert witness(native + 'finalize-evidence-01.stderr') == b''
    helper = witness('finalize_evidence.py')
    assert helper == witness(native + 'finalize-evidence-01.input.py')
    assert (len(helper), hashlib.sha256(helper).hexdigest()) == (
        8764, 'd7ffa15b41b2d7560b584ceb7dd3c171ee94cbab0cd8829f317d0f0114ec63aa')
    invocation = json.loads(witness(native + 'finalize-evidence-01.json'))
    assert type(invocation['exit']) is int and invocation['exit'] == 0
    assert invocation == dict(command=['python3', str(base.relative_to(art.parent) / 'finalize_evidence.py')],
                              cwd=str(art.parent), environment={'PYTHONDONTWRITEBYTECODE': '1'}, exit=0)
    gates = json.loads(witness('evidence/gate-runs.json'))
    names = ('test_no_broken_words.py', 'test_no_split_syllables.py',
             'test_no_degenerate_members.py', 'test_no_supplied_span_head.py')
    assert type(gates) is list and len(gates) == len(names)
    expected = b''
    for gate, name in zip(gates, names):
        witness('validation-runtime/tools/' + name)
        assert type(gate['exit']) is int and gate['exit'] == 0
        assert gate == dict(
            command=['/opt/homebrew/opt/python@3.14/bin/python3.14', str(base / 'validation-runtime/tools' / name)],
            cwd=str(wt), environment={'PYTHONDONTWRITEBYTECODE': '1'}, exit=0,
            stdout_file='native/' + name + '.stdout', stderr_file='native/' + name + '.stderr',
            scope='Three exact proposal bodies only; unchanged tool bytes from pinned Git object; original pinned span-head allowance.')
        stdout = witness(native + name + '.stdout')
        stderr = witness(native + name + '.stderr')
        assert stderr == b''
        expected += (' '.join((name, 'EXIT=0', stdout.decode().strip(), stderr.decode().strip())) + '\\n').encode()
    expected += b'All original source pins still match; physical complete records and targeted fidelity gates verified.\\n'
    assert raw == expected
    lines = raw.split(b'\\n')
    assert len(lines) == 6 and lines[-1] == b''
    assert all(line.endswith(b' ') and not line.endswith(b'  ') for line in lines[:4])
    assert set(pin['provenance']) == used
    return [pin['provenance'][item]['original'] for item in sorted(used)]
'''

def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new, 1)

def main():
    v8 = ART / 'audit_staged_source_whitespace_v8.py'
    v9 = ART / 'audit_staged_source_whitespace_v9.py'
    assert identity(v8)['sha256'] == V8_SHA
    assert not v9.exists()
    source = v8.read_text()
    source = replace_once(source, "\nart = Path(__file__).resolve().parent", ADDITION + "\nart = Path(__file__).resolve().parent")
    source = replace_once(source, "        elif pin['kind'] == 'blank_eof':", "        elif pin['kind'] == 'native_fidelity_summary':\n            native_originals = verify_native_fidelity_summary(raw, grouped, pin, rel)\n        elif pin['kind'] == 'blank_eof':")
    source = replace_once(source, "        if pin['kind'] in ('physical_bytes', 'physical_chunk_stdout'):", "        if pin['kind'] == 'native_fidelity_summary':\n            reason = 'Exact frozen native fidelity log reconstructed from four original recorded stdout/stderr pairs and zero-exit command metadata; only four terminal print separators'\n            originals = [str(original)] + native_originals\n        elif pin['kind'] in ('physical_bytes', 'physical_chunk_stdout'):")
    v9.write_text(source)

    manifest = json.loads((REVIEW / 'original-to-copy-manifest.json').read_bytes())
    freeze = {r['path']: r for r in json.loads((REVIEW / 'review-freeze.json').read_bytes())['files']}
    base = BATCH / 'tibetan'
    names = ('test_no_broken_words.py', 'test_no_split_syllables.py', 'test_no_degenerate_members.py', 'test_no_supplied_span_head.py')
    required = ['finalize_evidence.py', 'evidence/gate-runs.json']
    required += ['evidence/native/finalize-evidence-01.' + ext for ext in ('stdout', 'stderr', 'input.py', 'json')]
    for name in names:
        required += ['validation-runtime/tools/' + name, 'evidence/native/' + name + '.stdout', 'evidence/native/' + name + '.stderr']
    provenance = {}
    protected = [v8, ART / 'prepare_review_whitespace_pins.py', REVIEW / 'original-to-copy-manifest.json', REVIEW / 'review-freeze.json']
    for relative in required:
        original = base / relative
        matches = [m for m in manifest if m['original'] == str(original)]
        assert len(matches) == 1
        record = matches[0]
        assert identity(original) == {key: record[key] for key in ('bytes', 'sha256')}
        copied = REVIEW / record['copy']
        assert original.read_bytes() == copied.read_bytes()
        assert identity(copied) == {key: freeze[record['copy']][key] for key in ('bytes', 'sha256')}
        provenance[relative] = record
        protected += [original, copied]
    summary = provenance['evidence/native/finalize-evidence-01.stdout']
    candidate = {summary['copy']: dict(kind='native_fidelity_summary', bytes=summary['bytes'], sha256=summary['sha256'], provenance=provenance)}
    (OUT / 'candidate-native-log-pin.json').write_text(json.dumps(candidate, indent=2) + '\n')
    (OUT / 'protected-identities-before.json').write_text(json.dumps({str(p): identity(p) for p in sorted(set(protected))}, indent=2) + '\n')
    print(json.dumps(dict(status='PREPARED_ONLY', helper=str(v9), helper_identity=identity(v9), v8_identity=identity(v8), candidate=str(OUT / 'candidate-native-log-pin.json'), provenance_items=len(provenance)), indent=2))

if __name__ == '__main__':
    main()
