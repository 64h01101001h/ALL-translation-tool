Prepared native-log whitespace v9 candidate
=========================================

This preparation recognizes only the historical C05 301–303 Tibetan native
`finalize-evidence-01.stdout`: 433 bytes, SHA-256
`776e6f649453314c00cae5f9561444979c9091437625dcc27d5d832d6d24460e`.
Its four warning lines are the exact single spaces emitted before an empty
stderr print argument. The complete fifth line and final LF are also verified.
No production v9 audit, native test, generator, builder, or gate was run here.
The current staged tree and landing directory were not edited.

Review these files
------------------

- `../audit_staged_source_whitespace_v9.py`: saved production candidate.
  16,608 bytes; SHA-256
  `b3029500b9001e4cee44f5db6de000f6e5c7b163da6f15a418c71a5b2b7b7e86`.
- `candidate-native-log-pin.json`: one additive pin entry, outside landing.
  8,735 bytes; SHA-256
  `f2fa47e74b02cd357067aa559f54e22cfe551d45e419c18025abd1e65b640094`.
- `v8-to-v9.diff`: complete three-hunk diff. The new function is followed by
  one dispatch addition and one class-specific proof-reason/originals addition.
- `control-report.json`, `controls.py`, `control-results/`: exact positive,
  adversarial, and old-behavior control results and native subprocess records.
- `protected-identities-before.json` and `protected-identities-after.json`:
  all 35 checked originals, frozen copies, manifest, freeze, old preparer,
  and v8 remain byte-identical.
- `v8-recovered-byte-identical.py.txt`: removing precisely the three additions
  recovers the entire original v8 source, 12,077 bytes, SHA-256
  `514df93b7583ca152140f00b3ca2edc4c9317e38054808c0927adb9089412450`.
- `preparation-freeze.json`: final helper/package identities. Disposable Git
  fixture trees are excluded; their exact inputs and commands are retained in
  the frozen control records. No proof tree was recursively copied.

What the class verifies
-----------------------

The new `native_fidelity_summary` class is deliberately restricted to page 101,
first segment 301, the complete fixed log digest/size, and the exact fixed
8,764-byte original helper digest. The pin names 18 provenance records: helper,
captured helper input, outer run metadata/stdout/stderr, gate-run metadata,
four named script sources, and the four recorded native stdout/stderr pairs.
For every record the validator requires one exact original manifest entry,
the identical pin descriptor, an in-review copy, the matching independent
freeze entry, matching original/copy bytes, and matching sizes and hashes.

The recorded outer invocation and each gate command must have the precise
known interpreter/script/cwd/environment/scope values. All exits must be
integer zero (booleans and strings are refused), and all stderr must be empty.
The four known tests must occur exactly once in their original order. Their
frozen stdout bytes reconstruct the four Python print lines, and the final
literal message reconstructs the complete log. Only trailing-whitespace
warnings at exactly [1, 2, 3, 4], each one final print separator, are accepted.
Extra pin/provenance fields and unrelated warnings remain refused.

Verification outcome
--------------------

All 33 final control cases pass: 29 complete audit subprocess cases and four
direct malformed-warning cases using the saved function extracted by AST.
The positive v9 fixture exits 0 with empty stderr and a four-warning proof.
Original v8 rejects that newly named class. Adversarial cases reject edited
logs even after repinning, extra/doubled spaces, helper changes, nonzero/bool/
string exits, unsupported/reordered gate names, nonempty stderr, changed gate
stdout, missing/duplicate manifest witnesses, missing freeze/provenance,
changed original/copy bytes, extra pin/provenance fields, and an unrelated
warning file. Direct controls reject missing/wrong/duplicate warning indices
and an extra warning class.

The legacy-positive fixture includes CSV CRLF, complete original source,
physical-byte pins, and diff-context spacing. V8 and v9 both exit 0; their
entire proofs are identical after removing the timestamp. Both also refuse
an unclassified warning. This sampled behavioral comparison is supplemented
by exact whole-source recovery of unchanged v8, not a claim that every old
class was separately retested.

The first control attempt exited 1 because the synthetic legacy diff-context
fixture accidentally ended with a space-only line, adding a blank-EOF warning
that existing v8 correctly rejects. The complete first source and results are
preserved under `attempts/attempt-01/`; the correction adds a nonblank fixture
sentinel. V9 did not change. Final command `04-isolated-controls` exits 0.

`commands/` records the exact preparation command argv, cwd, environment
override, stdout, stderr, and exit. Each full audit/control setup subprocess
has the same records under `control-results/`. Four direct warning controls
record their inputs and caught assertion traceback rather than claiming a
separate process exit. Fixtures individually copy only the needed originals;
their recorded metadata paths are rebased and repinned in synthetic copies.
No synthetic gate metadata asserts that those tests were rerun.

Root integration after independent review
----------------------------------------

1. Check the candidate, helper, full diff, control report and the protected
   identities against `preparation-freeze.json`.
2. Preserve the failed production v8 stdout/stderr/exit evidence already held
   by root. Confirm no earlier whitespace proof will be overwritten.
3. Merge the one candidate map entry into the existing landing exact-pin map.
   Require that its key is absent, and preserve all existing pins exactly.
   Do not replace the whole existing map with this one-entry proposal.
4. Run the reviewed helper once from the real campaign worktree with page 101,
   first 301, and the existing `review-freeze.json`; capture actual stdout,
   stderr, and exit. Inspect the resulting proof for this four-warning class
   plus every previously supported warning class. This preparation is not that
   production proof and does not approve any semantic content or source change.

This rule is intentionally not reusable for another batch, helper revision,
log, interpreter command, or invocation layout. Such changes fail closed and
need a separately reviewed extension. Existing v8 assertions and proof rules
remain intact. Like v8, this assertion-based audit must be run without Python
optimization (`-O` or `PYTHONOPTIMIZE`), which disables assertions.
