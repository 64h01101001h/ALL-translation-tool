"""Exercise the saved v9 source only in small, isolated synthetic Git fixtures.

Native stdout/helper bytes are copied individually from the frozen originals.
Recorded cwd/command paths are rebased and repinned solely inside each fixture.
No native gate, generator, builder, production audit, or source mutation runs.
"""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import os
import subprocess
import sys
import traceback

OUT = Path(__file__).resolve().parent
ART = OUT.parent
V8 = ART / 'audit_staged_source_whitespace_v8.py'
V9 = ART / 'audit_staged_source_whitespace_v9.py'
PROPOSAL = json.loads((OUT / 'candidate-native-log-pin.json').read_bytes())
REL, PIN = next(iter(PROPOSAL.items()))
NATIVE = 'evidence/native/'
LOG = NATIVE + 'finalize-evidence-01.stdout'
NAMES = ('test_no_broken_words.py', 'test_no_split_syllables.py', 'test_no_degenerate_members.py', 'test_no_supplied_span_head.py')
ORIGINALS = {rel: Path(r['original']).read_bytes() for rel, r in PIN['provenance'].items()}
RESULTS = []

def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def call(command, cwd, log):
    log.mkdir(parents=True, exist_ok=False)
    write_json(log / 'command.json', dict(command=command, cwd=str(cwd), environment={'PYTHONDONTWRITEBYTECODE': '1'}))
    run = subprocess.run(command, cwd=cwd, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, capture_output=True)
    (log / 'stdout.bin').write_bytes(run.stdout)
    (log / 'stderr.bin').write_bytes(run.stderr)
    (log / 'exit.txt').write_text(str(run.returncode) + '\n')
    return run

def fixture(label):
    root = OUT / 'fixtures' / label
    assert not root.exists()
    a = root / 'campaign-artifacts'
    b = a / 'C05-301-303'
    s = b / 'semantic-review'
    w = root / 'campaign-worktree'
    landing = b / 'landing'
    w.mkdir(parents=True)
    landing.mkdir(parents=True)
    a.joinpath(V8.name).write_bytes(V8.read_bytes())
    a.joinpath(V9.name).write_bytes(V9.read_bytes())
    files = copy.deepcopy(ORIGINALS)
    invocation = json.loads(files[NATIVE + 'finalize-evidence-01.json'])
    invocation['cwd'] = str(root)
    files[NATIVE + 'finalize-evidence-01.json'] = (json.dumps(invocation, indent=2) + '\n').encode()
    gates = json.loads(files['evidence/gate-runs.json'])
    for gate, name in zip(gates, NAMES):
        gate['cwd'] = str(w)
        gate['command'][1] = str(b / 'tibetan/validation-runtime/tools' / name)
    files['evidence/gate-runs.json'] = (json.dumps(gates, indent=2) + '\n').encode()
    return dict(label=label, root=root, a=a, b=b, s=s, w=w, landing=landing, files=files)

def materialize(f):
    provenance = {}
    frozen = {}
    for relative, raw in f['files'].items():
        original = f['b'] / 'tibetan' / relative
        original.parent.mkdir(parents=True, exist_ok=True)
        original.write_bytes(raw)
        copied = PIN['provenance'][relative]['copy']
        target = f['s'] / copied
        target.parent.mkdir(parents=True, exist_ok=True)
        # Empty stderr aliases intentionally share a frozen original copy. When a
        # negative control changes one stderr, give that changed fixture a unique copy.
        if target.exists() and target.read_bytes() != raw:
            copied = 'fixture-only/' + relative.replace('/', '__')
            target = f['s'] / copied
            target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        provenance[relative] = dict(original=str(original), copy=copied, **identity(raw))
        frozen[copied] = dict(path=copied, **identity(raw))
    f['pin'] = dict(kind='native_fidelity_summary', **identity(f['files'][LOG]), provenance=provenance)
    f['manifest'] = list(provenance.values())
    f['freeze'] = frozen
    f['staged'] = {'data/alignment/reviews_c05/c5p101/' + REL: f['files'][LOG]}

def save_inputs(f):
    write_json(f['s'] / 'original-to-copy-manifest.json', f['manifest'])
    write_json(f['s'] / 'review-freeze.json', dict(files=list(f['freeze'].values()), fixture_only=True))
    write_json(f['landing'] / 'review-whitespace-exact-pins.json', f.get('pins', {REL: f['pin']}))
    for rel, raw in f['staged'].items():
        target = f['w'] / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    log = OUT / 'control-results' / f['label']
    for n, command in enumerate((
        ['git', 'init', '-q', '-b', 'fixture'],
        ['git', '-c', 'user.name=Whitespace Fixture', '-c', 'user.email=fixture@example.invalid', '-c', 'commit.gpgsign=false', 'commit', '-q', '--allow-empty', '-m', 'Isolated fixture baseline'],
        ['git', 'add', '--', *f['staged']],
    )):
        run = call(command, f['w'], log / f'setup-{n}')
        assert run.returncode == 0, run.stderr
    write_json(log / 'fixture-context.json', dict(
        fixture_only=True,
        limit='Only fixed native/helper stdout bytes retained from production. Metadata paths rebased in synthetic copies. No native tests executed.',
        pin=f.get('pins', {REL: f['pin']}), manifest=f['manifest'], freeze=list(f['freeze'].values()),
        staged={rel: identity(raw) for rel, raw in f['staged'].items()}))

def audit(f, version, accept):
    path = f['a'] / ('audit_staged_source_whitespace_' + version + '.py')
    log = OUT / 'control-results' / f['label'] / version
    run = call([sys.executable, '-B', str(path), '101', '301'], f['root'], log)
    target = f['landing'] / 'source-whitespace-proof.json'
    accepted = run.returncode == 0 and target.exists()
    assert accepted == accept, (f['label'], version, run.returncode, run.stderr.decode())
    if accept:
        assert not run.stderr
        proof = json.loads(target.read_bytes())
        assert proof['all_warnings_accounted_for'] is True
        (log / target.name).write_bytes(target.read_bytes())
        target.unlink()  # This is a disposable fixture proof, never a production proof.
    else:
        assert run.returncode != 0 and not target.exists()
        assert b'AssertionError' in run.stderr or b'KeyError' in run.stderr
        proof = None
    for name in ('staged-diff-check.stdout', 'staged-diff-check.stderr', 'staged-diff-check.exit'):
        (log / name).write_bytes((f['landing'] / name).read_bytes())
    RESULTS.append(dict(case=f['label'], version=version, expected='accept' if accept else 'reject', actual_exit=run.returncode, passed=True, proof=proof is not None, stderr_sha256=identity(run.stderr)['sha256']))
    return proof

def mutate_json(f, relative, edit):
    value = json.loads(f['files'][relative])
    edit(value)
    f['files'][relative] = (json.dumps(value, indent=2) + '\n').encode()

def run_case(label, change_files=None, change_inputs=None):
    f = fixture(label)
    if change_files:
        change_files(f)
    materialize(f)
    if change_inputs:
        change_inputs(f)
    save_inputs(f)
    audit(f, 'v9', False)

def warning_controls(f):
    tree = ast.parse(V9.read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'verify_native_fidelity_summary')
    env = dict(page=101, first=301, batch=f['b'], art=f['a'], wt=f['w'], review_root=f['s'], review_freeze=f['freeze'], manifest=f['manifest'], Path=Path, hashlib=hashlib, json=json)
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(V9) + ':isolated-function', 'exec'), env)
    function = env['verify_native_fidelity_summary']
    for label, grouped in (
        ('warning-index-missing', {'trailing whitespace.': [1, 2, 3]}),
        ('warning-index-wrong', {'trailing whitespace.': [1, 2, 3, 5]}),
        ('warning-index-duplicate', {'trailing whitespace.': [1, 2, 3, 4, 4]}),
        ('warning-kind-extra', {'trailing whitespace.': [1, 2, 3, 4], 'new blank line at EOF.': [5]}),
    ):
        try:
            function(f['files'][LOG], grouped, f['pin'], REL)
        except AssertionError:
            detail = traceback.format_exc()
        else:
            raise AssertionError(label + ' was accepted')
        log = OUT / 'control-results' / label
        log.mkdir(parents=True)
        (log / 'caught-stderr.txt').write_text(detail)
        write_json(log / 'input.json', dict(grouped=grouped, fixture=str(f['root']), method='Exact saved v9 function extracted by AST; no production top-level execution'))
        RESULTS.append(dict(case=label, version='v9-isolated-function', expected='reject', actual_exception='AssertionError', passed=True, proof=False))

def legacy_controls():
    f = fixture('legacy-positive')
    materialize(f)
    f['staged'] = {}
    f['pins'] = {}
    raw = b'Original source line \r\nSecond original line \r\n'
    witness = f['root'] / 'physical/C05ReadingASCII.txt'
    witness.parent.mkdir()
    witness.write_bytes(raw)
    full = 'legacy/full-source.txt'
    f['manifest'].append(dict(original=str(witness), copy=full, **identity(raw)))
    f['staged']['data/alignment/reviews_c05/c5p101/' + full] = raw
    f['staged']['docs/geshe_michael_roach_dictionary.csv'] = b'first,second\r\n1,2\r\n'
    for rel, value, pin in (
        ('legacy/physical.txt', raw.splitlines(keepends=True)[0], dict(kind='physical_bytes', witness=dict(path=str(witness), **identity(raw)), byte_range=[0, len(raw.splitlines(keepends=True)[0])])),
        ('legacy/context.txt', b'--- a\n+++ b\n \n context sentinel\n', dict(kind='diff_context')),
    ):
        target = f['s'] / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value)
        f['pins'][rel] = dict(**pin, **identity(value))
        f['freeze'][rel] = dict(path=rel, **identity(value))
        f['staged']['data/alignment/reviews_c05/c5p101/' + rel] = value
    save_inputs(f)
    before = audit(f, 'v8', True)
    after = audit(f, 'v9', True)
    for proof in (before, after):
        proof.pop('checked_at')
    assert before == after, 'v8/v9 changed existing-class output'

    f = fixture('legacy-unclassified')
    materialize(f)
    f['pins'] = {}
    f['staged'] = {'data/alignment/reviews_c05/c5p101/unclassified.txt': b'Arbitrary unrelated trailing space \n'}
    save_inputs(f)
    audit(f, 'v8', False)
    audit(f, 'v9', False)

def main():
    assert identity(V8.read_bytes()) == dict(bytes=12077, sha256='514df93b7583ca152140f00b3ca2edc4c9317e38054808c0927adb9089412450')
    # Reverse precisely the three additions; the entire remaining source must be v8.
    from prepare import ADDITION
    recovered = V9.read_text().replace(ADDITION, '', 1)
    recovered = recovered.replace("        elif pin['kind'] == 'native_fidelity_summary':\n            native_originals = verify_native_fidelity_summary(raw, grouped, pin, rel)\n", '', 1)
    recovered = recovered.replace("        if pin['kind'] == 'native_fidelity_summary':\n            reason = 'Exact frozen native fidelity log reconstructed from four original recorded stdout/stderr pairs and zero-exit command metadata; only four terminal print separators'\n            originals = [str(original)] + native_originals\n        elif pin['kind'] in ('physical_bytes', 'physical_chunk_stdout'):", "        if pin['kind'] in ('physical_bytes', 'physical_chunk_stdout'):", 1)
    assert recovered.encode() == V8.read_bytes()
    (OUT / 'v8-recovered-byte-identical.py.txt').write_bytes(recovered.encode())
    diff = ''.join(difflib.unified_diff(V8.read_text().splitlines(keepends=True), V9.read_text().splitlines(keepends=True), fromfile=V8.name, tofile=V9.name))
    (OUT / 'v8-to-v9.diff').write_text(diff)
    compile(V9.read_bytes(), str(V9), 'exec')

    positive = fixture('native-positive')
    materialize(positive)
    save_inputs(positive)
    proof = audit(positive, 'v9', True)
    assert proof['warning_count'] == 4 and len(proof['files']) == 1
    assert next(iter(proof['files'].values()))['issues'] == {'trailing whitespace.': [1, 2, 3, 4]}
    assert len(next(iter(proof['files'].values()))['original_paths']) == 19
    audit(positive, 'v8', False)
    warning_controls(positive)

    run_case('edited-log-repinned', lambda f: f['files'].__setitem__(LOG, f['files'][LOG].replace(b'90 English', b'91 English')))
    run_case('extra-log-warning-repinned', lambda f: f['files'].__setitem__(LOG, f['files'][LOG] + b'Extra line \n'))
    run_case('double-print-separator-repinned', lambda f: f['files'].__setitem__(LOG, f['files'][LOG].replace(b'pages \n', b'pages  \n', 1)))
    run_case('helper-edited-repinned', lambda f: [f['files'].__setitem__(r, f['files'][r] + b'# edited\n') for r in ('finalize_evidence.py', NATIVE + 'finalize-evidence-01.input.py')])
    run_case('finalize-exit-one', lambda f: mutate_json(f, NATIVE + 'finalize-evidence-01.json', lambda r: r.__setitem__('exit', 1)))
    run_case('finalize-exit-bool', lambda f: mutate_json(f, NATIVE + 'finalize-evidence-01.json', lambda r: r.__setitem__('exit', False)))
    run_case('gate-exit-one', lambda f: mutate_json(f, 'evidence/gate-runs.json', lambda r: r[0].__setitem__('exit', 1)))
    run_case('gate-exit-bool', lambda f: mutate_json(f, 'evidence/gate-runs.json', lambda r: r[0].__setitem__('exit', False)))
    run_case('gate-exit-string', lambda f: mutate_json(f, 'evidence/gate-runs.json', lambda r: r[0].__setitem__('exit', '0')))
    run_case('gate-unsupported-name', lambda f: mutate_json(f, 'evidence/gate-runs.json', lambda r: r[0]['command'].__setitem__(1, str(f['b'] / 'tibetan/validation-runtime/tools/arbitrary.py'))))
    run_case('gate-order-changed', lambda f: mutate_json(f, 'evidence/gate-runs.json', lambda r: r.reverse()))
    run_case('gate-stderr-nonempty', lambda f: f['files'].__setitem__(NATIVE + NAMES[0] + '.stderr', b'error\n'))
    run_case('finalize-stderr-nonempty', lambda f: f['files'].__setitem__(NATIVE + 'finalize-evidence-01.stderr', b'error\n'))
    run_case('gate-stdout-edited-repinned', lambda f: f['files'].__setitem__(NATIVE + NAMES[0] + '.stdout', b'changed real output\n'))
    run_case('manifest-missing-witness', change_inputs=lambda f: f['manifest'].remove(f['pin']['provenance'][NATIVE + NAMES[0] + '.stdout']))
    run_case('manifest-duplicate-witness', change_inputs=lambda f: f['manifest'].append(copy.deepcopy(f['manifest'][0])))
    run_case('freeze-missing-witness', change_inputs=lambda f: f['freeze'].pop(f['pin']['provenance'][NATIVE + NAMES[0] + '.stdout']['copy']))
    run_case('copy-edited-without-repin', change_inputs=lambda f: (f['s'] / f['pin']['provenance'][NATIVE + NAMES[0] + '.stdout']['copy']).write_bytes(b'changed copy\n'))
    run_case('original-edited-without-repin', change_inputs=lambda f: Path(f['pin']['provenance'][NATIVE + NAMES[0] + '.stdout']['original']).write_bytes(b'changed original\n'))
    run_case('pin-provenance-missing', change_inputs=lambda f: f['pin']['provenance'].pop(NATIVE + NAMES[0] + '.stdout'))
    run_case('pin-provenance-extra', change_inputs=lambda f: f['pin']['provenance'].__setitem__('arbitrary', {}))
    run_case('pin-field-extra', change_inputs=lambda f: f['pin'].__setitem__('waive_whitespace', True))
    run_case('extra-unclassified-file', change_inputs=lambda f: f['staged'].__setitem__('data/alignment/reviews_c05/c5p101/extra.txt', b'Unrelated extra warning \n'))
    legacy_controls()

    before = json.loads((OUT / 'protected-identities-before.json').read_bytes())
    after = {path: identity(Path(path).read_bytes()) for path in before}
    assert before == after, 'A protected original, frozen copy, manifest, freeze, v8, or preparer changed'
    write_json(OUT / 'protected-identities-after.json', after)
    report = dict(status='ALL_ISOLATED_CONTROLS_PASS', results=RESULTS,
                  total_cases=len(RESULTS), v8_unchanged=identity(V8.read_bytes()),
                  v9=identity(V9.read_bytes()), candidate=identity((OUT / 'candidate-native-log-pin.json').read_bytes()),
                  protected_files_checked=len(before), all_protected_bytes_unchanged=True,
                  exact_v8_recovered_after_removing_three_additions=True,
                  production_v9_executed=False, native_programs_executed=False,
                  limit='Synthetic local Git fixtures and direct malformed-warning controls only. Production audit and independent code review belong to root.')
    write_json(OUT / 'control-report.json', report)
    print(json.dumps({k: v for k, v in report.items() if k != 'results'}, indent=2))

if __name__ == '__main__':
    main()
