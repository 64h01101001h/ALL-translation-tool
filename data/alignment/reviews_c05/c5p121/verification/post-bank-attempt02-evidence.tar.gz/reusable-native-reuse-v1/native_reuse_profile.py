"""Exact English native-pair reuse for the existing C05 v1 closure interface.

Opt in with this profile, pinned native_reuse_profile/native_reuse_selection
artifacts and an explicit root profile_method approval. The adopted core stays
byte-identical. Only root native-input verification and profile approval change.
"""
from pathlib import Path
import argparse
import json
import closure
from closure import Closure, Invalid, exact, need, pin, read, save, selected, under

CORE_PIN={'bytes':42003,'sha256':'d0ae21561851c25ac03d229b4856610480a4a75ba9dafcb1d8ee252866173904'}
CAPTURE={'execution.json','stdin.bin','stdout.bin','stderr.bin','exit.txt'}
ANGLES=('tibetan','english','reconciled')
MODES=('generator','resolver')
VIEW_FILES={'command_and_result':'execution.json','stdin':'stdin.bin','stdout':'stdout.bin','stderr':'stderr.bin','exit':'exit.txt'}


def count(doc,key,value):
    need(type(doc[key]) is int and doc[key]==value,'Native count differs: '+key)


class NativeReuseClosure(Closure):
    def verify_root_inputs(self,root,proposal,sequences):
        need(pin(Path(closure.__file__).read_bytes())==CORE_PIN,'Unchanged adopted core required')
        need(root['status']=='PASS_ROOT_INPUTS' and root['baseline']==self.base
             and root['source_origin']==proposal['commit'],'Root source/input acceptance')
        count(root,'root_generator_runs',0);count(root,'root_resolver_runs',0)
        need(len(sequences)==3 and sequences==list(range(sequences[0],sequences[0]+3)), 'Three consecutive native segments required')
        need(set(root['inventories'])==set(ANGLES),'Native inventory angles')
        freezes={}
        for angle in ANGLES:
            inv=root['inventories'][angle];p=self.b/angle/'freeze.json'
            f=json.loads(exact(p,inv['freeze']));freezes[angle]=f
            need(f['source_origin_git_commit']==proposal['commit'],'Native frozen source origin')
            count(inv,'files',len(f['files']));count(f,'file_count',len(f['files']))
        rec=freezes['reconciled']
        need(exact(self.b/'reconciled/freeze.json',root['inventories']['reconciled']['freeze'])==self.artifact('reconciliation_freeze'),'Root reconciliation freeze binding')
        selpath=self.b/'reconciled/native-selection.json'
        need(self.c['artifacts']['native_reuse_selection']['path']==str(selpath),'Explicit frozen native-selection path')
        raw=self.artifact('native_reuse_selection');need(raw==exact(selpath,rec['files']['native-selection.json']),'Frozen native selection binding')
        selection=json.loads(raw);count(selection,'selected_capture_version',1)
        need([x['seq']for x in selection['selected']]==sequences,'Selected native sequence order')
        choices={x['seq']:x for x in selection['selected']}
        records=root['native_captures'];keys=[(x['angle'],x['seq'],x['mode'])for x in records]
        expected={(a,s,m)for a in ANGLES for s in sequences for m in MODES}
        need(len(keys)==18 and len(set(keys))==18 and set(keys)==expected,'Complete18 selected native view keys')
        docs={};captures={};identities={}
        for angle in ANGLES:
            for seq in sequences:
                docs[angle,seq]={n:exact(under(self.b/angle,f'{seq}/{n}'),freezes[angle]['files'][f'{seq}/{n}'])
                                 for n in ('spec.json','body.html','resolved-ranges.json')}
                spec=json.loads(docs[angle,seq]['spec.json'])
                need(spec['course']=='C05' and len(spec['segments'])==1 and spec['segments'][0]['seq']==seq,'Frozen native spec segment')
        for row in records:
            need(set(row)=={'angle','seq','mode','path','execution'},'Native view schema')
            a,s,m=row['angle'],row['seq'],row['mode'];key=(a,s,m);rel=f'native/{s}-{m}-v1';p=under(self.b/a,rel)
            need(type(s) is int and row['path']==str(p),'Canonical native view path')
            need({q.name for q in p.iterdir()}==CAPTURE,'Complete five-file native capture')
            raw={n:exact(p/n,freezes[a]['files'][rel+'/'+n])for n in CAPTURE}
            need(pin(raw['execution.json'])==row['execution'],'Root selected execution pin')
            ex=json.loads(raw['execution.json']);count(ex,'exit',0)
            need(raw['exit.txt']==b'0\n' and raw['stderr.bin']==b'','Native success/empty stderr bytes')
            need(set(ex['streams'])=={'stdin','stdout','stderr'},'Native stream inventory')
            for n in ('stdin','stdout','stderr'):need(ex['streams'][n]==pin(raw[n+'.bin']),'Recorded native stream identity: '+n)
            need(type(ex['argv']) is list and ex['argv'][-1]==m and bool(ex['cwd']) and bool(ex['utc']),'Native execution mode/identity metadata')
            need(raw['stdin.bin']==docs[a,s]['spec.json'],'Native stdin equals complete spec')
            output='body.html'if m=='generator'else'resolved-ranges.json'
            need(raw['stdout.bin']==docs[a,s][output],'Native output equals frozen '+output)
            captures[key]=raw;identities[key]=pin(raw['execution.json'])['sha256']
        # Original runs stay six distinct executions per mode. Only a whole,
        # same-sequence English pair may be reused by the reconciled view.
        originals={(a,s,m):v for (a,s,m),v in identities.items()if a!='reconciled'}
        for m in MODES:need(len({v for (a,s,mode),v in originals.items()if mode==m})==6,'Six distinct original executions per mode')
        reused=[]
        for s in sequences:
            matches=[]
            for m in MODES:
                same=[(a,t)for (a,t,mode),v in originals.items()if mode==m and v==identities['reconciled',s,m]]
                need(same in ([],[('english',s)]),'Reuse must identify same-sequence English original')
                matches.append(same)
            need(matches[0]==matches[1],'Generator/resolver reuse must be paired')
            reuse=bool(matches[0]);item=choices[s]
            need(set(item['selected'])==set(MODES),'Selected generator/resolver pair')
            need(item['mode']==('EXACT_ORIGINAL_ENGLISH_REUSE'if reuse else'NEW_EXECUTION'),'Selected reuse mode')
            if reuse:
                need(docs['reconciled',s]==docs['english',s],'Reused complete spec/note/body/ranges must remain unchanged')
                reused.append(s)
            for m in MODES:
                raw=captures['reconciled',s,m];entry=item['selected'][m];rel=f'native/{s}-{m}-v1'
                need(set(entry)==({'path','files','original_path'}if reuse else{'path','files'}),'Selected native entry schema')
                need(entry['path']==rel and entry['files']=={n:pin(v)for n,v in raw.items()},'Selected full native pins')
                if reuse:
                    need(entry['original_path']==str(self.b/'english'/rel) and raw==captures['english',s,m],'Exact original five-file paired reuse')
        unique={m:len({v for (a,s,mode),v in identities.items()if mode==m})for m in MODES}
        new=3-len(reused)
        need(unique['generator']==unique['resolver']==6+new,'Distinct new pairs and unique execution totals')
        for k,v in {'verified_native_generations':unique['generator'],'verified_native_resolvers':unique['resolver'],
                    'unique_original_generations':6,'unique_original_resolvers':6,'reconciler_generations':new,
                    'reconciler_resolvers':new,'reused_english_pairs':len(reused)}.items():count(root,k,v)
        for k,v in {'original_pairs':6,'new_reconciler_pairs':new,'exact_reused_english_pairs':len(reused),
                    'total_actual_unique_pairs':6+new,'total_angle_segment_views':9,'root_and_reviewer_runs':0}.items():count(selection,k,v)
        for k,v in {'new_generator_runs':new,'new_resolver_runs':new,'reused_original_native_pairs':len(reused),
                    'total_actual_unique_native_pairs':6+new,'total_angle_segment_views':9}.items():count(rec,k,v)
        review=self.doc('review');frozen=self.doc('semantic_freeze')
        need([x['seq']for x in review['segments']]==sequences,'Review native segment order')
        need(review['reconciliation_freeze_sha256']==frozen['reconciliation_freeze_sha256']==pin((self.b/'reconciled/freeze.json').read_bytes())['sha256'],'Review native reconciliation binding')
        for k,v in {'original_pairs':6,'new_reconciler_pairs':new,'exact_english_reused_pairs':len(reused),
                    'actual_unique_pairs':6+new,'selected_angle_segment_views':9,'reviewer_generator_runs':0,'reviewer_resolver_runs':0}.items():count(review['native_history'],k,v)
        for row in review['segments']:
            s=row['seq'];reuse=s in reused
            for n,prefix in [('spec.json','spec'),('body.html','body')]:
                rel=f'reviewed-final/{s}/{n}';raw=exact(under(self.b/'semantic-review',rel),frozen['files'][rel])
                need(raw==docs['reconciled',s][n] and pin(raw)=={'bytes':row[prefix+'_bytes'],'sha256':row[prefix+'_sha256']},'Reviewed complete native input/body')
            for m in MODES:
                e=row['native_evidence'][m]
                need(set(e)==set(VIEW_FILES)|{'mode'},'Review native evidence schema')
                need(e['mode']==('EXACT_ORIGINAL_ENGLISH_REUSE'if reuse else'NEW_RECONCILIATION_EXECUTION_REVIEWED_BY_CAPTURE_IDENTITY'),'Review native reuse mode')
                for field,n in VIEW_FILES.items():
                    rel=f'native/reconciled/{s}-{m}-v1/{n}'
                    need(e[field]==rel and exact(under(self.b/'semantic-review',rel),frozen['files'][rel])==captures['reconciled',s,m][n],'Reviewed selected native capture pin/copy')
        self.native_reuse_proof={'selected_views':18,'views_per_mode':9,'unique_executions':unique,'original_pairs':6,
                                'new_pairs':new,'reused_english_sequences':reused,'complete_pair_reuse_verified':True,
                                'selection':selected(self.c['artifacts']['native_reuse_selection']),
                                'limits':'Frozen capture identities and exact paired copies; no engine run, new semantic judgment or environmental attestation.'}

    def approval(self,receipt):
        d=read(receipt);raw=Path(__file__).read_bytes()
        need(d['profile_method']==pin(raw) and self.artifact('native_reuse_profile')==raw,'Exact native-reuse profile opt-in/approval')
        need(pin(Path(closure.__file__).read_bytes())==CORE_PIN,'Unchanged adopted core required')
        super().approval(receipt)
        (self.o/'executed-profile.py.txt').write_bytes(raw)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('staged','execute'))
    p.add_argument('--config',required=True);p.add_argument('--root-review',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();run=NativeReuseClosure(a.config,a.output,retrospective=False)
    try:
        run.approval(a.root_review)
        result=run.execute()if a.mode=='execute'else dict(run.verify(),status='PASS_NATIVE_REUSE_LIVE_STAGED_VERIFICATION',tree=run.staged())
        result['native_capture_reuse']=run.native_reuse_proof
        save(run.o/'proof.json',result);print(json.dumps(result,indent=2))
    except (Invalid,KeyError,OSError,ValueError,closure.tarfile.TarError)as exc:
        save(run.o/'failure.json',{'status':'FAIL_CLOSED','error':str(exc),'mode':a.mode});raise


if __name__=='__main__':main()
