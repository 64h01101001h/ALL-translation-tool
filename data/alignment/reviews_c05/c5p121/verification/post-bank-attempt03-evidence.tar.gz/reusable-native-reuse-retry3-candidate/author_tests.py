"""Synthetic caller-admission tests; no campaign commands, Git or CTest runs.

Tiny fixture streams deliberately say SYNTHETIC. The real verify_callers,
check_native and check_ctest validators consume them. Temporary fixtures are
removed afterward; test source and actual test-process streams are retained.
"""
from pathlib import Path
import ast
import importlib.util
import json
import tempfile
import unittest
import closure as current
import native_reuse_profile as profile

C = Path(__file__).resolve().parent
OLD = C.parent / 'reusable-native-reuse-v1'
spec = importlib.util.spec_from_file_location('prior_closure_retry3_test', OLD / 'closure.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
FIRST = 'compact-closure-caller'
SECOND = 'compact-closure-attempt02-caller'
THIRD = 'compact-closure-attempt03-caller'


class CallerAdmission(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='synthetic-callers-', dir=C)
        self.addCleanup(self.temp.cleanup)
        self.b = Path(self.temp.name)
        self.recorder = b'SYNTHETIC RECORDER IDENTITY; NOT EXECUTED\n'
        self.roles = {role: role.replace('_', '-') + '-caller' for role in sorted(current.ROLES)}
        self.c = {'required_roles': self.roles, 'historical_failures': {}, 'callers': {}, 'active_caller': FIRST}
        for name in self.roles.values():
            self.capture(name, 0)

    def capture(self, name, code):
        d = self.b / name
        d.mkdir(exist_ok=True)
        stdout = b'SYNTHETIC NATIVE FIXTURE; NO CAMPAIGN PROCESS RAN\n'
        if name == self.roles['tests']:
            stdout += ''.join(f'{i}/17 Test #{i}: {n} ... Passed 0.01 sec\n'
                              for i, n in enumerate(sorted(current.TESTS), 1)).encode()
            stdout += b'100% tests passed, 0 tests failed out of 17\n'
        stderr = b'SYNTHETIC FAILURE STREAM\n' if code else b''
        cmd = {'argv': ['SYNTHETIC_NOT_EXECUTED', name], 'cwd': str(self.b)}
        ex = dict(cmd, recorder_sha256=current.sha(self.recorder), exit=code,
                  stdin_bytes=0, stdout_bytes=len(stdout), stderr_bytes=len(stderr),
                  stdout_sha256=current.sha(stdout), stderr_sha256=current.sha(stderr))
        data = {'command.json': json.dumps(cmd).encode(), 'execution.json': json.dumps(ex).encode(),
                'stdin.bin': b'', 'stdout.bin': stdout, 'stderr.bin': stderr, 'exit.txt': f'{code}\n'.encode()}
        for n, raw in data.items():
            (d / n).write_bytes(raw)
        self.c['callers'][name] = {n: current.pin(raw) for n, raw in data.items()}

    def setup_attempt(self, n):
        self.c['active_caller'] = [FIRST, SECOND, THIRD][n - 1]
        for name in [FIRST, SECOND][:n - 1]:
            self.capture(name, 1)
            self.c['historical_failures'][name] = {'exit': 1, 'reason': 'Synthetic actual recorded failure for admission test.'}

    def run_guard(self, module=current):
        obj = object.__new__(module.Closure)
        obj.c, obj.b, obj.retrospective = self.c, self.b, False
        obj.artifact = lambda key: self.recorder if key == 'recorder' else self.fail('Unexpected artifact read')
        module.Closure.verify_callers(obj)
        self.assertEqual(set(obj.native), set(self.c['callers']))

    def reject(self, message, module=current):
        with self.assertRaisesRegex(module.Invalid, message):
            self.run_guard(module)

    def test_first_unchanged_full_native_acceptance(self):
        self.run_guard(prior)
        self.run_guard()

    def test_second_unchanged_full_native_acceptance(self):
        self.setup_attempt(2)
        self.run_guard(prior)
        self.run_guard()

    def test_third_both_prior_failures_accepts_full_native(self):
        self.setup_attempt(3)
        self.reject('Invalid active caller exemption', prior)
        self.run_guard()

    def test_third_missing_first_failure(self):
        self.setup_attempt(3)
        del self.c['historical_failures'][FIRST]
        self.reject('first-closure failure')

    def test_third_missing_second_failure(self):
        self.setup_attempt(3)
        del self.c['historical_failures'][SECOND]
        self.reject('second-closure failure')

    def test_third_wrong_first_declared_exit(self):
        self.setup_attempt(3)
        self.c['historical_failures'][FIRST]['exit'] = 2
        self.capture(FIRST, 2)
        self.reject('first-closure failure')

    def test_third_wrong_second_declared_exit(self):
        self.setup_attempt(3)
        self.c['historical_failures'][SECOND]['exit'] = 2
        self.capture(SECOND, 2)
        self.reject('second-closure failure')

    def test_third_native_exit_must_match_declared_failure(self):
        self.setup_attempt(3)
        self.capture(SECOND, 2)
        self.reject('Unexpected native exit')

    def test_required_passing_role_cannot_be_failure(self):
        self.setup_attempt(3)
        self.c['historical_failures'][self.roles['tests']] = {'exit': 1, 'reason': 'Synthetic forbidden bypass'}
        self.reject('Failure bypass targets a required passing gate')

    def test_extra_actual_caller_rejected(self):
        self.setup_attempt(3)
        (self.b / 'unlisted-extra-caller').mkdir()
        self.reject('Unexpected or missing caller directory')

    def test_completed_active_caller_rejected(self):
        self.setup_attempt(3)
        d = self.b / THIRD
        d.mkdir()
        (d / 'execution.json').write_bytes(b'{}')
        self.reject('Active caller already completed')

    def test_active_caller_cannot_be_prebound(self):
        self.setup_attempt(3)
        self.capture(THIRD, 0)
        self.reject('Invalid active caller exemption')

    def test_failure_must_be_bound(self):
        self.setup_attempt(3)
        del self.c['callers'][SECOND]
        self.reject('Unbound required caller')

    def test_failure_reason_required(self):
        self.setup_attempt(3)
        self.c['historical_failures'][SECOND]['reason'] = ''
        self.reject('Unreviewable failure bypass')

    def test_second_missing_first_refusal_unchanged(self):
        self.setup_attempt(2)
        del self.c['historical_failures'][FIRST]
        self.reject('first-closure failure', prior)
        self.reject('first-closure failure')

    def test_fourth_caller_not_implicitly_authorized(self):
        self.setup_attempt(3)
        self.c['active_caller'] = 'compact-closure-attempt04-caller'
        self.reject('Invalid active caller exemption')

    def test_core_outside_changed_method_byte_identical(self):
        old, new = (OLD / 'closure.py').read_bytes(), (C / 'closure.py').read_bytes()
        prefix = b'    def verify_callers(self):\n'
        suffix = b'    def verify_production(self, baseline, review):\n'
        self.assertEqual(old.split(prefix)[0], new.split(prefix)[0])
        self.assertEqual(old.split(suffix)[1], new.split(suffix)[1])
        old_method = old.split(prefix)[1].split(suffix)[0]
        new_method = new.split(prefix)[1].split(suffix)[0]
        marker = b'        actual = '
        self.assertEqual(old_method.split(marker)[1], new_method.split(marker)[1])
        self.assertEqual(old_method.split(b'        active = ')[0], new_method.split(b'        active = ')[0])

    def test_profile_only_docstring_and_core_pin_change(self):
        trees = [ast.parse(p.read_text()) for p in (OLD / 'native_reuse_profile.py', C / 'native_reuse_profile.py')]
        def normalized(tree):
            tree.body = [node for i, node in enumerate(tree.body)
                         if i != 0 and not (isinstance(node, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'CORE_PIN' for t in node.targets))]
            return ast.dump(tree, include_attributes=False)
        self.assertEqual(normalized(trees[0]), normalized(trees[1]))
        self.assertEqual(profile.CORE_PIN, current.pin((C / 'closure.py').read_bytes()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
