import json,gzip,sqlite3,hashlib,subprocess,shutil
from pathlib import Path
A=Path(__file__).resolve().parents[1];R=A.parents[2];W=R/'campaign-worktree';E=A/'evidence';P=E/'pinned'
def digest(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def dump(p,x):put(p,(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode())
b=json.loads((A.parent/'proposal-baseline.json').read_text());pins={};git_records=[]
for name in ['source.json','context.json','baseline.json','proposal-baseline.json']:
 raw=(A.parent/name).read_bytes();put(E/name,raw);pins[name]={'original':str(A.parent/name),**digest(raw)}
put(E/'proposal-protocol.md',(R/'campaign-artifacts/proposal-protocol.md').read_bytes())
for rel in list(b['governing_git_pins'])+['engines/hgm_tools.py']:
 argv=['git','show',b['commit']+':'+rel];r=subprocess.run(argv,cwd=W,capture_output=True);assert r.returncode==0 and not r.stderr
 raw=r.stdout;expected=b['governing_git_pins'].get(rel);assert expected is None or digest(raw)=={k:expected[k] for k in ['bytes','sha256']}
 put(P/rel,raw);git_records.append({'argv':argv,'cwd':str(W),'exit':r.returncode,'stderr':'','stdout_file':str((P/rel).relative_to(A)),**digest(raw)})
for key,rec in b['source_pins'].items():
 path=Path(rec['path']);raw=path.read_bytes();assert digest(raw)=={k:rec[k] for k in ['bytes','sha256']};pins[key]=rec
 if key=='physical':put(E/'C05ReadingASCII.txt',raw)
db=sqlite3.connect('file:'+str(W/'build/hgm_spine_v27_2.db')+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');db.row_factory=sqlite3.Row
query='SELECT * FROM corpus_segments WHERE course=? AND seq BETWEEN ? AND ? ORDER BY seq';rows=[dict(r) for r in db.execute(query,('C05',319,333))]
for name in ['source','context']:
 for row in json.loads((E/(name+'.json')).read_text()):
  actual=next(r for r in rows if r['seq']==row['seq']);assert all(actual[k]==v for k,v in row.items())
dump(E/'original-spine-context.json',{'sql':query,'parameters':['C05',319,333],'records':rows})
terms=['gzhan','sde pa','dmyal ba','myong',"'gyur","'dod pa","'gro ba",'gnyis','rig','mthong','mthong bas spang bya','spang bya','gnag','nag po','dkar','las','skyes','sbyor ba','rtsa ba','gsum','de','mjug thogs','mjug','byung','phyir','brnab sems','sogs','dge ba','bcas','chags','sdang','gti mug','med','rtsa','brnab','sems']
m=json.load(gzip.open(W/'data/hgm_dictionary_v27_2.json.gz','rt'));selected={key:[{'index':i,'record':x} for i,x in enumerate(m[key]) if x.get('wylie') in terms]for key in ['unified_entries','curated_entries','glossary_entries']}
dump(E/'master-lexical.json',{'match':'exact wylie field; no variant matching','terms':terms,'counts':{k:len(v)for k,v in selected.items()},'records':selected})
queries=[('exact-325','SELECT * FROM corpus_segments WHERE wylie=? ORDER BY id',[rows[6]['wylie']]),('exact-326','SELECT * FROM corpus_segments WHERE wylie=? ORDER BY id',[rows[7]['wylie']]),('exact-327','SELECT * FROM corpus_segments WHERE wylie=? ORDER BY id',[rows[8]['wylie']]),('mjug-thogs','SELECT * FROM corpus_segments WHERE wylie LIKE ? ORDER BY id',['%mjug thogs%']),('gngsde','SELECT * FROM corpus_segments WHERE wylie LIKE ? ORDER BY id',['%gngsde%']),('dkar-ending','SELECT * FROM corpus_segments WHERE wylie LIKE ? ORDER BY id',['%mthong bas spang bya gnag%'])]
for name,sql,params in queries:
 rec=[dict(r)for r in db.execute(sql,params)];dump(E/('corpus-'+name+'.json'),{'sql':sql,'parameters':params,'count':len(rec),'records':rec});print(name,len(rec))
dump(E/'provenance.json',{'status':'PASS_READ_ONLY_ORIGINAL_INPUT_CAPTURE','source_origin_git_commit':b['commit'],'source_origin_course_boundary':324,'actual_baseline':json.loads((E/'baseline.json').read_text()),'pins':pins,'immutable_git_reads':git_records,'sqlite_mode':'ro; PRAGMA query_only=ON','independence':'English-first; no Tibetan-angle or reconciliation content consulted. Existing English helper code only used as packaging template.'})
print('master counts', {k:len(v)for k,v in selected.items()});print('PASS original snapshots, immutable governance, complete lexical records and selected full corpus records')
