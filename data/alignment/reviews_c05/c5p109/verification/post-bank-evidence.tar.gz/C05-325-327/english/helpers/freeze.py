import json,hashlib,datetime,re
from pathlib import Path
A=Path(__file__).resolve().parents[1];E=A/'evidence'
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not(A/'freeze.json').exists()
pins=load(E/'proposal-baseline.json')['source_pins']
for name,x in pins.items():
 raw=Path(x['path']).read_bytes();assert len(raw)==x['bytes']and sha(raw)==x['sha256'],name
raw=(E/'C05ReadingASCII.txt').read_bytes();normalized=re.sub(rb'\s+',b' ',raw);proof=[]
for row in load(E/'source.json'):
 fields={}
 for field in ['acip','english']:
  needle=row[field].encode('ascii');at=normalized.find(needle);assert at>=0,(row['seq'],field)
  fields[field]={'exact_after_ascii_whitespace_folding':True,'normalized_start_byte':at,'normalized_end_byte_exclusive':at+len(needle),'original_field':row[field]}
 proof.append({'seq':row['seq'],'fields':fields})
dump(E/'physical-field-proof.json',{'method':'ASCII whitespace folding of the exact full physical source bytes only; no punctuation/letter edits','original_bytes':len(raw),'original_sha256':sha(raw),'records':proof,'verse325_syllable_counts':[len(x.split())for x in load(E/'source.json')[0]['wylie'].split(',')if x.strip()],'publication_identity_inference':False})
dump(E/'reading-and-scope.json',{'producer':'Codex independent English-first','source_context_read':list(range(319,334)),'material_corpus_read':['C05:325','C05:326','C05:327','C05:328','C05:329','C05:333','C16:852','C16:858','ILL:590','ILL:591','AK:292'],'source_and_actual_baseline_commit':'daad5db6ea6207085dc820101b3a2e9aaf942417','governance':'Original Git object copies under pinned; course-shape section used. Current mutable governance was checked against source-origin pins when captured.','isolation':'No Tibetan-angle or reconciliation content consulted. Prior English helper source and packaging schema were read; prior linguistic claims were not used for these proposals.','reading_limits':'Large combined tool displays truncated ancillary lexical/reference metadata. Material HGM gloss, tier, contextual and relevant register fields were reread in bounded displays; all selected complete objects remain preserved. No claim to have individually read every incidental Sanskrit or corpus metadata string.','scope':'Proposal only. Source/master/worktree/shared batch data unchanged. No API, registration, staging, commits or production work.'})
files={str(p.relative_to(A)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(A.rglob('*'))if p.is_file()and p.name!='freeze.json'}
freeze={'schema':'c05-independent-proposal-freeze-v1','producer':'Codex independent English-first proposal','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_origin_git_commit':'daad5db6ea6207085dc820101b3a2e9aaf942417','source_course_boundary':324,'segments':[325,326,327],'acceptance_baseline_consumed':{'commit':'daad5db6ea6207085dc820101b3a2e9aaf942417','course_boundary':324,'receipt':'evidence/baseline.json'},'semantic_status':'PROPOSAL_ONLY; independent reconciliation and review required','files':files,'file_count':len(files),'counts':load(A/'summary.json')['total'],'original_external_sources':pins,'complete_evidence_strategy':'87 unique complete master records and38 unique complete corpus records verified against original JSON. Full physical source retained once; whole original spine/master/corpus pins without bulk copies.','native_generator_runs':3,'native_resolver_runs':3,'native_failures':0}
dump(A/'freeze.json',freeze);print(json.dumps({'freeze':str(A/'freeze.json'),'bytes':(A/'freeze.json').stat().st_size,'sha256':sha((A/'freeze.json').read_bytes()),'file_count':len(files),'counts':freeze['counts']},indent=2))
