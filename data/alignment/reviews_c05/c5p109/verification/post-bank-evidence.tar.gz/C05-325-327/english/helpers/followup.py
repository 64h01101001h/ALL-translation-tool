import json,gzip,sqlite3,hashlib
from pathlib import Path
A=Path(__file__).resolve().parents[1];E=A/'evidence';W=A.parents[2]/'campaign-worktree'
def dump(name,x):(E/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
terms=['gnag pa','nag','gnag',"'dod",'sbyor','gngsde pa','spang bar bya ba','dkar gnag','rtsa gsum','las skyes','mthong bas']
m=json.load(gzip.open(W/'data/hgm_dictionary_v27_2.json.gz','rt'));data={k:[{'index':i,'record':r}for i,r in enumerate(m[k])if r.get('wylie')in terms]for k in ['unified_entries','curated_entries','glossary_entries']};dump('master-followup.json',{'match':'exact wylie only','terms':terms,'counts':{k:len(v)for k,v in data.items()},'records':data})
db=sqlite3.connect('file:'+str(W/'build/hgm_spine_v27_2.db')+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');db.row_factory=sqlite3.Row
for name,pattern in [('dmyal-myoung','%dmyal ba myong%'),('spang-bya-gnag','%spang%gnag%'),('english-white-black','%According to others, understood%')]:
 field='english'if name=='english-white-black'else'wylie';sql='SELECT * FROM corpus_segments WHERE '+field+' LIKE ? ORDER BY id';rows=[dict(r)for r in db.execute(sql,[pattern])];dump('corpus-'+name+'.json',{'sql':sql,'parameters':[pattern],'count':len(rows),'records':rows});print(name,len(rows))
raw=(E/'C05ReadingASCII.txt').read_bytes();lo=raw.index(b',GZHAN NI DMYAL');hi=raw.index(b'[IV.272-6]',lo)+len(b'[IV.272-6]');extent=raw[lo:hi];assert extent.isascii();(E/'source-325-327-extent.txt').write_bytes(extent);dump('physical-extent.json',{'original_path':json.loads((E/'proposal-baseline.json').read_text())['source_pins']['physical']['path'],'start_byte':lo,'end_byte_exclusive':hi,'bytes':len(extent),'sha256':hashlib.sha256(extent).hexdigest(),'encoding_of_this_extent_only':'ASCII','whole_original_file':'C05ReadingASCII.txt'})
r=json.loads((E/'pinned/docs/errata_register.json').read_text());terms=['gngsde','gng','gzhan dkar','C05:325','C05:326'];dump('errata-register-screen.json',{'register_file':'pinned/docs/errata_register.json','rows':len(r),'method':'case-insensitive literal substring of complete JSON record; all matching records retained','queries':{t:[x for x in r if t.lower()in json.dumps(x,ensure_ascii=False).lower()]for t in terms},'class_references':[x for x in r if x['item_id']in ['E-071','E-106','E-107']]})
for k,xs in data.items():
 for x in xs:
  r=x['record'];print(k,json.dumps({k:v for k,v in r.items()if k in ['wylie','hgm_gloss','hgm_glosses','hgm_evidence','hopkins_english','status']},ensure_ascii=False))
