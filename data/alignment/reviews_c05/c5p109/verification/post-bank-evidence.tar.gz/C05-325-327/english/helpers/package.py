import json,hashlib,html,re,gzip,datetime
from pathlib import Path
A=Path(__file__).resolve().parents[1];E=A/'evidence';W=A.parents[2]/'campaign-worktree'
def load(p):return json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
source={r['seq']:r for r in load(E/'source.json')};corpus=json.load(gzip.open(W/'data/full_parallel_corpus_v32.json.gz','rt'));selected=set();queries=[]
for p in [E/'original-spine-context.json',*sorted(E.glob('corpus-*.json'))]:
 x=load(p)
 for r in x['records']:
  assert json.loads(r['raw'])==corpus[r['id']-1];selected.add(r['id'])
 if 'count'in x:assert x['count']==len(x['records'])
 queries.append({'file':str(p.relative_to(A)),'sql':x['sql'],'parameters':x['parameters'],'count':len(x['records'])})
dump(E/'query-index.json',queries)
master=json.load(gzip.open(W/'data/hgm_dictionary_v27_2.json.gz','rt'));selected_master=set()
for name in ['master-lexical.json','master-followup.json']:
 x=load(E/name)
 for coll,rs in x['records'].items():
  actual=[{'index':i,'record':r}for i,r in enumerate(master[coll])if r.get('wylie')in x['terms']];assert actual==rs
  for r in rs:selected_master.add((coll,r['index']))
summary=[]
for seq in [325,326,327]:
 p=A/str(seq);specb=(p/'spec.json').read_bytes();s=load(p/'spec.json')['segments'][0]['spans'];body=(p/'body.html').read_bytes();resolved=load(p/'resolved-ranges.json');planned=load(p/'decisions.json')['spans']
 assert [{k:x[k]for k in ['id','d','tib','eng','seq','tib_range','eng_range']}for x in resolved]==[{k:x[k]for k in ['id','d','tib','eng','seq','tib_range','eng_range']}for x in planned]
 for tool,content in [('generator',body),('resolver',(p/'resolved-ranges.json').read_bytes())]:
  n=A/'native'/f'{seq}-{tool}-v1';assert(n/'stdin.bin').read_bytes()==specb and(n/'stdout.bin').read_bytes()==content and(n/'stderr.bin').read_bytes()==b'' and(n/'exit.txt').read_text()=='0\n'
 for side,field in [('tib','wylie'),('eng','english')]:
  m=re.search('<div class="'+side+'"><div class="lab">.*?</div>\\n(.*?)\\n</div>',body.decode(),re.S);assert m;assert html.unescape(re.sub('<[^>]+>','',m[1]))==source[seq][field]
 err=load(p/'errata.json')
 for x in err:x.pop('course',None);x.pop('segment',None);x['seq']=seq
 dump(p/'errata.json',err)
 counts={'spans':len(s),'nulls':sum(x['eng']is None for x in s),'d5_total':sum(x['d']==5 for x in s),'nonnull_d5':sum(x['d']==5 and x['eng']is not None for x in s),'d7':sum(x['d']==7 for x in s),'d6':sum(x['d']==6 for x in s),'errata_proposed':len(err)}
 proof={'seq':seq,'status':'PASS_MECHANICAL_ONLY','generator_exit':0,'stderr_bytes':0,'spec_bytes':len(specb),'spec_sha256':sha(specb),'body_bytes':len(body),'body_sha256':sha(body),'source_text_exact_after_markup_removal':True,'intended_ranges_equal_canonical':True,'native_generator_path':f'native/{seq}-generator-v1','native_resolver_path':f'native/{seq}-resolver-v1','counts':counts};dump(p/'verification.json',proof);summary.append(proof)
 audit={'seq':seq,'categories':{'TIBETAN_SPELLING':'One LOW/PROBABLE editorial question with all five grounds in errata.json.'if err else'No new spelling defect established; rtsa/rtsa ba and sbyor/sbyor ba are ordinary verse abbreviations, not silently expanded.','ENGLISH_TYPO':'No new typo established. Exact capitalization, line compression and punctuation remain unchanged.','ENGLISH_FACTUAL_ERROR':{325:'The final White and black exceeds the surviving dkar. This is the same incomplete-source question, not a second allegation against English.',326:'The two alternative schools are distinguished; desire realm/hell and seeing classifications are internally consistent with the neighboring verse.',327:'One shared no negates all three poisons; C05:333 explicitly repeats no for each. No reading that makes dislike/ignorance virtuous is proposed.'}[seq],'INGEST_ARTEFACT':'Original physical extent preserves the observed passage. No publication-level original or ingestion-loss inference is made. Bracketed verse references are apparatus; English is below1500cap.','FORMATTING':'The transition and following72heading in326 are preserved as unaligned source material under the known following-heading class; no duplicate filed.'if seq==326 else'Original verse capitalization and shads remain verbatim; no normalization proposed.'},'evidence':{'complete_source':'../evidence/original-spine-context.json','physical_original_and_extent':'../evidence/physical-extent.json','counted_original_corpus_queries':'../evidence/query-index.json','complete_lexical_records':['../evidence/master-lexical.json','../evidence/master-followup.json'],'prior196register':'../evidence/errata-register-screen.json'},'limitations':'Digital copies are not independent publications. Both proposed corrections remain human editorial questions; no source or master changes.'};dump(p/'errata-review.json',audit)
 challenge={325:'Challenge the source-tail question first: dkar claims only White, while the final English black remains unpaired.',326:'Challenge the six distinct las occurrences and the first gnyis ka/two versus explanatory both; no semantic conclusion follows merely from resolver success.',327:'Challenge the shared med/no scope and temporal mjug thogs/just subsequent; no positive dislike/ignorance reading is intended.'}[seq]
 dec=load(p/'decisions.json');lines=[f'# C05:{seq} — Codex independent English-first proposal',challenge,'PROVISIONAL. Proposal origin and actual captured baseline: daad5db6ea6207085dc820101b3a2e9aaf942417, through324.',f"Counts: {counts['spans']} spans, {counts['nonnull_d5']} non-null d5, {counts['d7']} d7, {counts['d6']} d6, {counts['nulls']} nulls, {counts['errata_proposed']} proposed errata.",*dec['rationales'],*dec['omissions'],f"Actual generator: EXIT=0; empty stderr; body {len(body)} bytes / SHA256 {sha(body)}.",'Actual canonical resolver: EXIT=0, empty stderr, every intended source and English range matched. Full row occurrence positions are in decisions.json.',f'Exact native stdin/stdout/stderr/exit/execution records: ../native/{seq}-generator-v1 and ../native/{seq}-resolver-v1.','Complete original evidence is stored once under ../evidence; query-index.json, master-lexical.json, master-followup.json and physical-extent.json identify every material source.','errata-review.json covers all five categories; candidate errata preserve five refutation grounds and require human review. No source/master/production modification or paid API; no semantic acceptance claimed.']
 assert 10<=len(lines)<=25;(p/'report.md').write_text('\n'.join(lines)+'\n')
dump(A/'summary.json',{'producer':'Codex independent English-first proposal','segments':summary,'total':{k:sum(x['counts'][k]for x in summary)for k in summary[0]['counts']},'source_origin_git_commit':'daad5db6ea6207085dc820101b3a2e9aaf942417','actual_baseline_git_commit':'daad5db6ea6207085dc820101b3a2e9aaf942417','course_boundary':324,'master_changes':False,'production_changes':False,'semantic_status':'PROPOSAL_ONLY'})
dump(E/'final-evidence-verification.json',{'status':'PASS','unique_complete_master_records_compared_to_original':len(selected_master),'unique_complete_corpus_records_compared_to_original':len(selected),'original_corpus_total':len(corpus),'native_generators':3,'native_resolvers':3,'generator_and_resolver_failures':0,'all_intended_ranges_exact':True,'all_body_plaintexts_exact':True,'method':'Metadata/byte validation only; no generation/resolver reruns.'})
print(json.dumps({'status':'PASS','totals':load(A/'summary.json')['total'],'original_corpus_records':len(selected),'original_master_records':len(selected_master)},indent=2))
