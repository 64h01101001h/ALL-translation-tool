"""Current-batch receipt of existing native/source identities; no generation."""
from pathlib import Path
import datetime, hashlib, json, subprocess

B = Path(__file__).resolve().parent
W = B.parent.parent / 'campaign-worktree'
read = lambda p: json.loads(p.read_bytes())
def pin(p):
    raw = p.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def save(p, value):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
base, origin = read(B/'baseline.json'), read(B/'proposal-baseline.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip() == base['commit'] == origin['commit']
assert base['course_boundary'] == 324
inventories = {}
for name in ('tibetan','english','reconciled'):
    f = B/name/'freeze.json'
    rows = read(f)['files']
    assert isinstance(rows, dict)
    for rel, expected in rows.items():
        assert pin(f.parent/rel) == expected, rel
    inventories[name] = dict(freeze=pin(f), files=len(rows))
assert inventories['reconciled']['freeze']['sha256'] == 'd358419ae63c87725020ca3d88a4e7d00af9dc0ff61bd5a6f5a1b2fb412c330b'
for r in origin['source_pins'].values():
    assert pin(Path(r['path'])) == {k:r[k] for k in ('bytes','sha256')}, r['path']
prior = read(B/'proposal-verification/report.json')
assert len(prior) == 6
for row in prior:
    for mode in ('generator','resolver'):
        native = row['native'][mode]
        for name, expected in native['files'].items():
            assert pin(Path(native['path'])/name) == expected
        assert read(Path(native['path'])/'execution.json')['exit'] == 0
assert read(B/'proposal-resolver-caller/execution.json')['exit'] == 0
source = {r['seq']:r for r in read(B/'source.json')}
resolved, captures = [], []
for seq in range(325,328):
    folder = B/'reconciled'/str(seq)
    verification = read(folder/'verification.json')
    for mode in ('generator','resolver'):
        native = (folder/verification['native_'+mode+'_path']).resolve()
        ex = read(native/'execution.json')
        assert ex['exit'] == 0 and (native/'exit.txt').read_text().strip() == '0'
        assert (native/'stderr.bin').read_bytes() == b''
        for stream in ('stdin','stdout','stderr'):
            assert pin(native/(stream+'.bin')) == ex['streams'][stream]
        assert (native/'stdin.bin').read_bytes() == (folder/'spec.json').read_bytes()
        if mode == 'generator':
            assert (native/'stdout.bin').read_bytes() == (folder/'body.html').read_bytes()
        else:
            rows = read(native/'stdout.bin')
            assert rows == read(folder/'resolved-ranges.json')
            for row in rows:
                for field, language in (('tib','wylie'),('eng','english')):
                    extent = row[field+'_range']
                    if row[field] is None:
                        assert extent is None
                    else:
                        assert source[seq][language][extent[0]:extent[1]] == row[field]
                resolved.append({k:row[k] for k in ('seq','id','d','tib','eng','tib_range','eng_range')})
        captures.append(dict(seq=seq, mode=mode, path=str(native), execution=pin(native/'execution.json')))
assert len(resolved) == 78
save(B/'root-reconciliation-verification/resolved-spans.json', resolved)
proof = dict(status='PASS_ROOT_INPUTS', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             baseline=base['commit'], source_origin=origin['commit'], root_generator_runs=0,
             verified_native_generations=9, verified_native_resolvers=9, inventories=inventories,
             original_native_report=pin(B/'proposal-verification/report.json'),
             original_canonical_range_check=pin(B/'proposal-verification/root-resolved-spans.json'),
             final_native_captures=captures, original_spans=154, final_spans=78,
             method=pin(Path(__file__)), limits='Existing native results reused by exact identity; no new generator or resolver invocation. Semantic judgment is separate.')
save(B/'root-current-inputs/proof.json', proof)
print(json.dumps(proof, indent=2))
