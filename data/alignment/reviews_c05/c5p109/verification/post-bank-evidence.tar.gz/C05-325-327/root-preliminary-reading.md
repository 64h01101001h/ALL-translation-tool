# Root reading before final reconciliation

This records reading and provisional judgments, not semantic acceptance.
The actual source origin and acceptance baseline are both
`daad5db6ea6207085dc820101b3a2e9aaf942417`, through C05:324.

I read the complete three source rows and all context rows 319–333, the
original physical byte windows in `root-physical-context.json`, both complete
specifications and reports, every original span rationale and all material
omissions. The two immutable inventories contain 116 Tibetan-first and 111
English-first files. Their six recorded generator results and six recorded
resolver results were checked without regenerating bodies. An independent
call to the existing canonical resolver reproduced all 154 original ranges.
These checks establish identity and resolution, not semantic truth.

Lexical reading included all fifteen complete distinct records in the neutral
preparation, and complete material records for the experience constructions,
`'gyur`, `myong`, `mthong`, `mthong bas`, `spang bya`, `spang bar bya ba`,
`bcas`, `gzhan`, `de`, `sogs`, `med`, `rig`, and `gnyis` in the original
proposal evidence. I do not claim to have read every record gathered by both
analysts. Reference Sanskrit/Hopkins/LC and unrelated provisional glosses
remain distinct from local GMR wording.

- C05:325 has four different `gzhan` occurrences and two desire references.
  The second experience expression is elliptical; the first cannot be reused.
  `su` can own the explicit categorical “as”. The seeing/elimination relation
  is an active English recast of the source construction. Keeping the whole
  inflected seeing unit is defensible; separating agentive `-s` is not.
- C05:326 contains six `las` occurrences with different roles. Four explicit
  deed nouns, one pronominalized deed reference, and one ablative must not be
  conflated. The single `rig` closes the two-color classification and can
  align once with that clause's second “understood”; the first English
  repetition remains unclaimed. The two `dkar gnag` compounds each have
  their own tighter white/black members.
- The complete master entry for `myong bar 'gyur ba` includes “bring one an
  experience”; the separate `'gyur` glossary also includes “bring”. Those
  are counterevidence to an automatic rejection, but they do not establish
  an independent local causative atom. The source construction expresses
  coming to experience. The narrower `myong`/“experience” correspondence
  is defensible; leave any uncertain decomposition unbanked.
- C05:327's `sogs` is an enumerative particle owning the closing gesture
  “and the rest”, without a supplied noun. `bcas` is a lexical accompaniment
  predicate here despite English “with”. `rnams` can receive the explicit
  plural-fusion null if review confirms its scope over the virtues and
  their stages. It must not be described as absence of plural meaning.
- The one `med`/“no” scopes desire, dislike and ignorance together. Complete
  context 333 states all three negatives explicitly. The repeated root
  noun and final arising verb are elliptical, so neither borrows another
  English occurrence or receives an uncertainty null.
- The physical ASCII ends 325 in `DKAR` and starts the next passage with
  `GNGSDE PA`. A lost or displaced `GNAG` is a hypothesis, not an established
  restoration. English “and black” and the malformed opening remain
  unbanked. The two original errata assessments disagree on classification;
  preserve both and assess probable source defects separately from an
  uncertain correction mechanism. Digital copies are not independent
  publication witnesses.

The final reconciliation, five-ground errata rulings and independent skeptic
remain outstanding. No source, master, canonical register, or accepted page
is changed by this note.
