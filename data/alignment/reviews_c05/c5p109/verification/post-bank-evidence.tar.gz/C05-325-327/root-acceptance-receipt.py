"""Record root's completed semantic reading and verify the frozen intake."""
from pathlib import Path
import datetime, hashlib, json
B=Path(__file__).resolve().parent
S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
freeze=read(S/'freeze.json')
assert pin(S/'freeze.json')['sha256']=='53fb1978359932d1871993f323ac4f298df0b01712d2f947180024b5bab05444'
for relative,expected in freeze['files'].items():
    assert pin(S/relative)==expected,relative
assert freeze['file_count']==len(freeze['files'])==223
review=read(S/'review.json')
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==review['source_origin_git_commit']==base
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read complete source325–327, context319–333, physical windows and six excerpts; all six original specs/reports,154 original span rationales and omissions,44 grouped dispositions,78 final rationales,17 final omissions, and all five corrected rationale records. Root read all15 distinct neutral master objects plus complete material experience/gyur/myong/seeing/elimination/color/gzhan/de/sogs/med/rig/gnyis/gro-ba records, all original Tibetan five-ground screens and both original English errata screens; full E044/E071/E076/E106/E107/E111/E121/E147, material C05/C16 context and ILL590/591 temporal parallels. Root read complete final independent review, all78 independent span judgments,17 independent omission judgments, both five-ground verdicts, findings resolution and reading receipt. Exact original/reconciled/native proof is reused; inventory identity is not a claim to reading every gathered master object.'
decision='Approve the78 proposed spans provisionally. At325 myong/experience is narrow and second experience remains elliptical; each gzhan keeps its own occurrence, su/as and rig/understood express the fronted classification, seeing uses bare mthong while whole bas stays omitted, and final dkar owns White only. At326 the glossary bring counterevidence is preserved but isolated gyur/bring remains insufficiently supported; two de/ones pairs remain uncertain. One rig/su owns second understood/as only; noun and ablative las roles remain distinct; intact later sde pa uses second groups; each color compound has its own tighter members. At327 the temporal compound owns just subsequent, de owns them, sogs carries the full enumerative gesture, lexical bcas owns with, rnams has affirmative plural fusion into virtues, and the one med/no scopes all three roots as333 confirms. Repeated or supplied wording remains unbanked without false uncertainty nulls.'
errata='Retain two LOW/PROBABLE human-review observations about the DKAR tail and GNGSDE opening. They may share one boundary cause. Complete physical text predates ingest, verse compression or a source mark is possible, and E111 has a clean LDOG spill unlike this unproved GNAG hypothesis. No independent corrected witness, specific restoration, mechanism or independent defect count is established. The full linked skeptical decision accompanies the register observations.'
utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
intake=dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=base,
            prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
            reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,
            semantic_files_verified=223,limits='Intake identity plus root reading; production checks follow.')
save(B/'root-reconciliation-intake.json',intake)
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,
    actual_baseline=base,source_origin=base,page='c5p109',segments=[325,326,327],
    counts=dict(spans=78,nulls=1,nonnull_d5=60,total_d5=60,d7=4),review_freeze=pin(S/'freeze.json'),
    review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
    read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-preliminary-reading.md')),
    semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
    allowances=read(S/'span-head-allow-needed.json'),
    actual_failure='Root input attempt01 used the wrong resolved artifact filename and failed before any output or mutation. Preserved original method and native failure; corrected filename passed attempt02. No generator or resolver rerun.',
    limits='Machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[325,326,327],semantic_files=223),indent=2))
