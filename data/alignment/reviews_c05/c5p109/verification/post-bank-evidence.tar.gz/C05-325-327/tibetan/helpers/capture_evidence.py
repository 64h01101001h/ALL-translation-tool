"""Tibetan-first original source/evidence capture; read-only sources, no proposals."""
from pathlib import Path
import json,gzip,sqlite3,subprocess,hashlib,os,datetime,re
P=Path(__file__).resolve().parents[1];B=P.parent;A=B.parent;W=A.parent/'campaign-worktree';E=P/'evidence';E.mkdir()
ORIGIN='daad5db6ea6207085dc820101b3a2e9aaf942417'
def read(p):return json.loads(p.read_bytes())
def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return dict(bytes=n,sha256=h.hexdigest())
def put(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
origin=read(B/'proposal-baseline.json');assert origin['commit']==ORIGIN and origin['course_boundary']==324
pins=[]
for rel,rec in origin['governing_git_pins'].items():
 raw=subprocess.check_output(['git','show',ORIGIN+':'+rel],cwd=W);dst=E/'pinned'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
 assert pin(dst)=={k:rec[k]for k in ('bytes','sha256')};pins.append(dict(repository_relative_path=rel,original_git_commit=ORIGIN,**pin(dst)))
rel='engines/hgm_tools.py';raw=subprocess.check_output(['git','show',ORIGIN+':'+rel],cwd=W);dst=E/'pinned'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);pins.append(dict(repository_relative_path=rel,original_git_commit=ORIGIN,**pin(dst)))
assert pin(W/'tools/gen_alignment_page.py')==pin(E/'pinned/tools/gen_alignment_page.py')
for name in ('source.json','context.json','proposal-baseline.json','baseline.json'):copy(B/name,E/name)
copy(A/'proposal-protocol.md',E/'proposal-protocol.md')
references=[Path.home()/'Desktop/HGM DICTIONARY - TRANSLATION APP',Path.home()/'ACIP Software Developmeent/Gofer Developmetn Files',Path.home()/"ACIP Software Developmeent/Ven. Phil's Development Folder/Mac_OSX/ACIPHypercontext Tool",Path.home()/"ACIP Software Developmeent/Ven. Phil's Development Folder/Mac_OSX/LokeshChandraDictionary",Path.home()/"ACIP Software Developmeent/Ven. Phil's Development Folder/Mac_OSX/CreateLokeshChandraDIctionary",Path.home()/"ACIP Software Developmeent/Ven. Phil's Development Folder/Mac_OSX/FixLokeshChandra",Path.home()/'ACIP Software Developmeent/tibetan-spellchecker',Path.home()/'Tibetan Translation Tool']
access=[dict(path=str(p),readable=os.access(p,os.R_OK))for p in references];assert all(x['readable']for x in access)
put(E/'required-access.json',access);put(E/'git-pins.json',pins)
for name,rec in origin['source_pins'].items():assert pin(Path(rec['path']))=={k:rec[k]for k in ('bytes','sha256')}
put(E/'source-pins.json',origin['source_pins'])
db=sqlite3.connect(Path(origin['source_pins']['spine']['path']).as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON')
rows=[dict(r)for r in db.execute("select * from corpus_segments where course='C05' and seq between 319 and 333 order by seq")]
for r,s in zip(rows,read(E/'context.json')):assert all(r[k]==v for k,v in s.items())
assert len(rows)==15;put(E/'full-source-context-rows.json',rows)
master=json.load(gzip.open(origin['source_pins']['master']['path'],'rt'));corpus=json.load(gzip.open(origin['source_pins']['corpus']['path'],'rt'))
terms=['gzhan','ni','dmyal ba',"myong 'gyur",'dang',"'dod",'gnyis','su','rig','mthong bas','mthong','spang bya','gnag','dkar','las skyes','skyes','sde pa','gngsde pa',"myong bar 'gyur ba",'las','de','nag po',"'dod pa","'gro ba",'gnyis ka','rig go','zhes zer','yang','spang bar bya ba',"spang bar bya ba'i","'dod do",'sbyor ba','rtsa ba','gsum','de yi','mjug thogs','byung','phyir','brnab sems','sogs','dge ba','sbyor','mjug','bcas','rnams','chags','sdang','gti mug','med','gnag pa','mthong bas spang bya','mthong bas spang bar bya ba','dkar gnag','chags sdang gti mug med']
lex=[]
for term in terms:
 records=[dict(collection=c,index=i,entry=r)for c in ('unified_entries','curated_entries','glossary_entries')for i,r in enumerate(master[c])if r.get('wylie')==term]
 lex.append(dict(term=term,query=dict(field='wylie',equals=term),count=len(records),master_records=records))
put(E/'full-lexical-evidence.json',lex)
queries=[];external=[]
def query(field,value,exact=False,label=None):
 sql=f'select * from corpus_segments where {field}=? order by id'if exact else f'select * from corpus_segments where instr({field},?)>0 order by id'
 rr=[dict(r)for r in db.execute(sql,(value,))];queries.append(dict(sql=sql,params=[value],count=len(rr),rows=rr,label=label))
 er=[dict(corpus_index=i,record=r)for i,r in enumerate(corpus)if (r.get(field)==value if exact else value in r.get(field,''))]
 external.append(dict(label=label,field=field,operation='equals'if exact else 'contains',value=value,count=len(er),records=er))
for r in read(E/'source.json'):
 for field in ('acip','wylie','english'):query(field,r[field],True,f"{r['seq']}-{field}-exact")
for field,value,label in [('acip','GNGSDE','326-literal-prefix'),('wylie',"sde pa gzhan ni dmyal ba",'326-groups'),('english','According to the claim of certain other groups','326-english-groups'),('wylie',"dmyal ba myong bar 'gyur ba'i las",'326-experience-deeds'),('wylie',"gzhan ni dmyal ba myong 'gyur",'325-verse-opening'),('english','White and black, others that come from desire','325-verse-closing'),('wylie','mthong bas spang bya gnag','325-seeing'),('wylie','sbyor ba rtsa ba gsum las skyes','327-undertaking'),('acip','GNAG SDE PA','326-boundary-comparison'),('wylie','gngsde','326-wylie-prefix')]:query(field,value,False,label)
put(E/'corpus-query-evidence.json',queries);put(E/'external-corpus-evidence.json',external);db.close()
physical=Path(origin['source_pins']['physical']['path']);copy(physical,E/'C05ReadingASCII.txt.bin');raw=physical.read_bytes();ext=[]
for r in read(E/'source.json'):
 for field in ('acip','english'):
  value=r[field].encode('ascii');pattern=rb'[\t\n\r\f\v ]+'.join(re.escape(t)for t in value.split());matches=list(re.finditer(pattern,raw));assert len(matches)==1;m=matches[0]
  assert b' '.join(m.group().split())==value
  ext.append(dict(seq=r['seq'],field=field,start=m.start(),end=m.end(),bytes=len(m.group()),sha256=hashlib.sha256(m.group()).hexdigest(),original_text=m.group().decode('ascii'),ascii_whitespace_collapse_equals_spine=True))
put(E/'physical-source-proof.json',ext)
register=read(E/'pinned/docs/errata_register.json');direct=[r for r in register if r.get('segment')in ('C05:325','C05:326','C05:327')]
classes=[r for r in register if r['item_id']in ('E-044','E-071','E-076','E-107','E-111','E-121')or 'following' in r.get('evidence','').lower()and 'heading' in r.get('evidence','').lower()]
put(E/'registered-complete-records.json',dict(register_count=len(register),direct_batch_records=direct,selected_classes=classes))
put(E/'source-verification.json',dict(source_origin_git_commit=ORIGIN,source_course_boundary=324,actual_baseline_copy='baseline.json',actual_baseline_commit=read(E/'baseline.json')['commit'],actual_baseline_not_semantic_acceptance=True,complete_context_rows=15,lexical_queries=len(lex),master_record_claims=sum(q['count']for q in lex),sql_queries=len(queries),external_queries=len(external),physical_fields=len(ext),no_spine_copy=True,no_source_edits=True))
print(json.dumps(dict(lexical_queries=len(lex),master_record_claims=sum(q['count']for q in lex),corpus_queries=[dict(label=q['label'],count=q['count'])for q in queries],register_count=len(register),direct_batch_records=direct)))
