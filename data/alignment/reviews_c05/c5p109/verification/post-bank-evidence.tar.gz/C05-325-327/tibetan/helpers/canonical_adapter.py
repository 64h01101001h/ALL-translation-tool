import pathlib,sys,sqlite3,json
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'evidence/pinned/tools'));import gen_alignment_page as G
b=json.loads((P/'evidence/proposal-baseline.json').read_text());G.B.SPINE=b['source_pins']['spine']['path'];connect=sqlite3.connect
def ro(database,*a,**kw):
 assert str(database)==G.B.SPINE
 return connect('file:'+str(database)+'?mode=ro',uri=True)
G.sqlite3.connect=ro
if __name__=='__main__':G.main()
