"""Independent Tibetan-first choices, with explicit intended literal occurrences."""
from pathlib import Path
import json,re
P=Path(__file__).resolve().parents[1];E=P/'evidence'
source={r['seq']:r for r in json.loads((E/'source.json').read_bytes())}
ORIGIN='daad5db6ea6207085dc820101b3a2e9aaf942417'
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def occurrences(text,piece):
 if piece is None:return []
 return [[m.start(),m.start()+len(piece)]for m in re.finditer('(?='+re.escape(piece)+')',text)]
def words(text,piece):
 return [r for r in occurrences(text,piece)if (not piece[0].isalnum()or r[0]==0 or not text[r[0]-1].isalnum())and(not piece[-1].isalnum()or r[1]==len(text)or not text[r[1]].isalnum())]
def make(seq,title,claims,omissions,note):
 d=P/str(seq);d.mkdir();s=source[seq];spans=[];dec=[];parent=None
 for i,(t,e,depth,ti,ei,reason) in enumerate(claims,1):
  obj=dict(id='w'+str(i),d=depth,tib=t,eng=e)
  tr=words(s['wylie'],t)[ti-1];er=words(s['english'],e)[ei-1]if e is not None else None
  if depth==7:
   assert parent is not None and parent['d']==5
   pr=next(r for r in dec if r['id']==parent['id'])
   assert pr['tib_range'][0]<=tr[0]<tr[1]<=pr['tib_range'][1] and tr!=pr['tib_range']
   assert pr['eng_range'][0]<=er[0]<er[1]<=pr['eng_range'][1] and er!=pr['eng_range']
   pf=parent['id'];function='Unique strictly tighter color member of the immediately preceding d5 compound group.'
  else:
   parent=obj;pf=None;function='Lexical word or whole inflected lexical unit.'if depth==5 else 'Standalone grammatical or discourse particle.'
  if e is None:
   obj.update(cls='plural',nul='Plural rnams is grammatically fused into the plural noun virtues; no separate English token. It does not assert absence of plural meaning.')
  spans.append(obj)
  dec.append(dict(**obj,seq=seq,tib_range=tr,eng_range=er,rationale=reason,source_function=function,parent=pf,
      literal_tibetan_occurrences=occurrences(s['wylie'],t),literal_english_occurrences=occurrences(s['english'],e),
      source_evidence='../evidence/source.json',full_lexical_evidence='../evidence/full-lexical-evidence.json; ../evidence/supplemental-full-lexical-evidence.json'))
 flat=[r for r in dec if r['d']!=7 and r['eng']is not None];order=[r['id']for r in sorted(flat,key=lambda r:r['eng_range'])]
 # Intent is authored from these exact local occurrences. The actual canonical
 # resolver later checks it independently; this helper is not a resolver substitute.
 spec=dict(course='C05',segments=[dict(seq=seq,title=title,spans=spans,eng_order=order,note='PROVISIONAL machine alignment by Codex, independent Tibetan-first proposal. '+note+' No source or hgm_gloss is changed.')])
 put(d/'spec.json',spec);put(d/'decisions.json',dict(producer='Codex independent Tibetan-first proposer',source_origin_git_commit=ORIGIN,
     range_convention='Zero-based half-open character offsets in complete original source fields; explicitly selected local occurrences.',spans=dec,material_omissions=omissions,eng_order=order))
 put(d/'errata.json',[])
 # Full unwrapped extents, not just a list of highlighted concerns.
 out={}
 for side,field in [('tib','wylie'),('eng','english')]:
  intervals=sorted(r[side+'_range']for r in dec if r['d']!=7 and r[side+'_range']is not None);cursor=0;gaps=[]
  for a,b in intervals:
   assert a>=cursor,(seq,side,a,cursor)
   if a>cursor:gaps.append(dict(range=[cursor,a],text=s[field][cursor:a]))
   cursor=b
  if cursor<len(s[field]):gaps.append(dict(range=[cursor,len(s[field])],text=s[field][cursor:]))
  out[field]=gaps
 put(d/'complete-unwrapped-extents.json',out)
 print(seq,len(spans))
def omit(t,reason):return dict(tib=t,reason=reason,decision='unbanked; not a null')

make(325,'other views of black and white deeds',[
 ('gzhan','others',5,1,1,'First gzhan names the other proponents at the verse opening. The master’s unrelated auto-quoted a bodhisattva is retained as metadata, not substituted for this source use.'),
 ('dmyal ba','hell',5,1,1,'The first destination is hell; exclude supplied For a and keep the complete Tibetan noun.'),
 ("myong 'gyur",'experience',5,1,1,'First experience expression belongs to hell; the one literal English experience is here, not in the later elliptical desire clause.'),
 ("'dod",'desire',5,1,1,'First abbreviated desire-realm term selects the first desire in other desire; no realm word is invented.'),
 ('gzhan','other',5,2,1,'Second gzhan modifies the other destinations in desire. English other is singular adjectival here, unlike the two proponents and final others.'),
 ('gnyis','two',5,1,1,'The first view calls the other desire-realm deeds the two colors; only two is claimed, not the article.'),
 ('su','as',6,1,1,'Terminative su belongs to gnyis su rig, categorical understanding as the two. English moves understood as before the two alternatives.'),
 ('rig','understood',5,1,1,'Rig supplies the shared understanding predicate at the verse opening in English; the source verb remains at the end of its two alternatives.'),
 ('gzhan','Others',5,3,1,'Third gzhan introduces a distinct second view at English Others, rather than the later other deeds.'),
 ('mthong bas','seeing',5,1,1,'Whole inflected seeing term is the eliminative agent in the relative construction; bas stays with its noun. The source’s passive-to-active English recast supplies no separate by.'),
 ('spang bya','eliminates',5,1,1,'The complete abandonment predicate is rendered actively as eliminates under seeing; exact HGM spang bya includes eliminates. English what is not added to the lexical span.'),
 ('gnag','black',5,1,1,'This black is the explicit gnag of the third verse line, attached to seeing-eliminated deeds. It does not own the later black after White.'),
 ("'dod pa",'desire',5,1,2,'Whole desire term in the fourth line selects final desire after come from.'),
 ('las','from',6,1,1,'Ablative las marks the desire origin in the final line; it is not the noun deeds.'),
 ('skyes','come',5,1,1,'The final line’s arising verb owns come, with from assigned to its ablative.'),
 ('gzhan','others',5,4,2,'Fourth gzhan refers to the other deeds that come from desire, at final lower-case others; it is not another group of proponents.'),
 ('dkar','White',5,1,1,'The final source word is only dkar and owns only White. The following English and black is withheld because this source line lacks a corresponding gnag.'),
],[omit('ni / dang','Topic framing and coordination are redistributed across the verse’s English punctuation and According to frame; no independent atom is established for these particles.'),
    omit("myong 'gyur (second)",'Second experience construction is elliptical in the English for other desire; do not force it onto for or reuse the first experience.'),
    omit('final dkar / absent gnag','Only White is aligned. The six-syllable final source line and the next row’s GNGSDE prefix raise a possible loss/boundary problem, but the physical file has the same text and no independent corrected same-passage witness was found. No correction or extra black mapping is supplied.'),
    omit('English frame words','According to, those, For a, articles, the second for, what, is and relative that remain outside the lexical atoms; no unsupported source ownership is forced.')],
 'Repeated others/desire and the two viewpoints are occurrence-specific. The second experience expression is elliptical. Final dkar owns only White; the additional English black and uncertain following source prefix are not forced into alignment.')

make(326,'prose on the other classifications',[
 ('gzhan','other',5,1,1,'First other modifies the first group of proponents; corrupted gngsde pa is separately withheld.'),
 ('dmyal ba','hells',5,1,1,'The first experiential destination is the hells; the English article and preposition are excluded.'),
 ("myong bar 'gyur ba'i",'experience',5,1,1,'Whole inflected experience expression describes the first deeds. Only experience is claimed; generic bring one an is not assigned without separate Tibetan participants.'),
 ('las','deeds',5,1,1,'First lexical las is the subject deeds that bring the hell experience, not a later classification noun.'),
 ('de','ones',5,1,1,'This de resumes those first deeds; English nominal ones occurs with the first quoted black predicate.'),
 ('nag po','black',5,1,1,'Complete nag po names the first black classification; quotes and nominal ones are separate.'),
 ('dang','And',6,1,1,'First dang coordinates the hell case with the other births, rendered by sentence-initial And.'),
 ("'dod pa'i",'desire realm',5,1,1,'Complete inflected desire-realm noun modifies birth; the realm reading is explicit in this English and in HGM’s full dod pa entry.'),
 ("'gro ba",'birth',5,1,1,'Here gro ba is the destination/type of birth, not a living being. The complete glossary record includes birth; curated living being(s) is retained as distinct evidence.'),
 ('gzhan','other',5,2,2,'Second gzhan modifies birth in some other birth; it does not select the next other groups.'),
 ("myong bar 'gyur ba'i",'experience',5,2,2,'Second complete experience expression belongs to the non-hell desire-realm births. It selects the second experience, with bring one an still unclaimed.'),
 ('dkar gnag','white and black',5,1,1,'First whole dual-color compound is the predicate category of those other births. The two color members below are each unique and tighter inside it.'),
 ('dkar','white',7,1,1,'White member of the first dual-color compound, inside its own English parent.'),
 ('gnag','black',7,1,2,'Black member of the first dual-color compound; English first black is already the separate hell predicate.'),
 ("gnyis ka'i",'two',5,1,1,'Whole inflected pair term selects the two in the explanatory category statement; English repeats the pair sense as both later, which is not claimed a second time.'),
 ('las','deeds',5,3,2,'Third source las is the explicit category noun after the two colors and their pair term; it owns deeds after the colon, not the earlier anaphoric those.'),
 ('su','as',6,1,2,'First su belongs to classification under rig. It selects the as following the second understood; the further as after the colon repeats that frame.'),
 ('rig','understood',5,1,2,'The shared source rig closes both alternatives. It is aligned once to the second explicit English understood, nearest its completed classification; the first repetition remains unwrapped.'),
 ('zer','claim',5,1,1,'The source reporting verb zer supplies the first group’s claim. English nominalizes this reporting predicate in According to the claim of; it is not the later assert.'),
 ('yang','Still',6,1,1,'Yang introduces the additional rival group at Still other groups.'),
 ('sde pa','groups',5,1,2,'This is the later intact standalone sde pa after yang, selecting the second groups. No substring is extracted from opening gngsde.'),
 ('gzhan','other',5,3,3,'Third gzhan modifies the second named groups of proponents, after Still.'),
 ('mthong bas','seeing',5,1,1,'Whole inflected seeing noun is the agent of elimination in this nominalized source construction. English expands the doctrinal reference with path of, which is left unwrapped.'),
 ("spang bar bya ba'i",'eliminates',5,1,1,'The complete inflected abandonment predicate supplies eliminates in GMR’s active relative clause. The exact uninflected headword has HGM eliminates; its LC-only longer compound does not replace that evidence.'),
 ('las','deeds',5,4,3,'Fourth source las is the seeing-eliminated deeds, corresponding to deeds in those kinds of deeds before the English relative clause.'),
 ('de','ones',5,2,2,'Second de resumes the seeing-eliminated deeds, at the second nominal ones after black.'),
 ('gnag pa','black',5,1,3,'Whole gnag pa is the second group’s black predicate, outside either dual-color compound.'),
 ('dang','while',6,2,1,'Second dang coordinates the black class with the contrasting other desire-born deeds, rendered while.'),
 ("'dod pa",'desire',5,2,2,'The later uninflected desire noun is the origin of the remaining deeds; it selects final desire, not the earlier desire realm.'),
 ('las','from',6,5,1,'Fifth las is an ablative after desire, not one of the four nominal deeds occurrences.'),
 ('skyes pa','come',5,1,1,'Whole nominalized arising word supplies come in the last relative clause; that is supplied linkage.'),
 ('gzhan','other',5,4,4,'Fourth other modifies the final deeds arising from desire, not the proponents.'),
 ('dkar gnag','white and black',5,2,2,'Second dual-color compound describes the remaining desire-born deeds and has its own two contained color members.'),
 ('dkar','white',7,2,2,'White member of the second compound, never the first compound’s English white.'),
 ('gnag','black',7,3,4,'Black member of the second compound; the intervening standalone gnag pa belongs to the seeing-eliminated class.'),
 ("gnyis ka'i",'both',5,2,2,'Second whole pair term owns final both in the second group’s classification; the first English both belongs to the earlier repeated two explanation.'),
 ('las','deeds',5,6,4,'Final nominal las supplies the deeds of this final class; English puts the same class noun in other deeds before its descriptive relative.'),
 ("'dod",'assert',5,3,1,'Final dod is the reporting verb for the second group, rendered assert near that group’s English opening; it is not either desire noun.'),
],[omit('gngsde pa','Opening literal gngsde pa is not normalized or split to steal an internal sde substring. Its groups and the prefix remain unbanked pending independent source scrutiny; physical source agrees with the literal anomaly.'),
    omit('las (second nominal occurrence)','The subject noun of the second alternative is rendered anaphorically as those. The later explicit category las owns deeds after the colon; no las→those dictionary pair is proposed.'),
    omit('ni / go / zhes / do / final su','These topic, quotative, terminal and categorical contributions are carried by the restructured reporting/copular frames. No unique separate English atom is claimed here.'),
    omit('rig / gnyis ka repeated English renderings','The single rig is rendered understood twice; bank only the second. First gnyis ka is rendered two and both; bank only two. No source unit is cloned to cover explanatory repetition.'),
    omit('English participants and expansion','Generic one, articles, relative words, certain, those kinds, and path of are left unwrapped. The first groups cannot be assigned by silently correcting gngsde.'),
    omit('English transition and apparatus','The final transition about the fifth group and possessions, stars, page number 72 and following heading have no corresponding Tibetan in this row and remain intact and unwrapped; the heading class is already registered.')],
 'The malformed opening is preserved and unbanked. Whole experience predicates are paired narrowly with experience; generic participants and explanatory repeats remain unwrapped. The two dual-color compounds and reporting predicates select their own clauses; source/title apparatus remains verbatim.')

make(327,'undertakings and the three roots',[
 ('sbyor ba','undertakings',5,1,1,'The first sbyor ba names the undertaking stages in plural English; the later abbreviated undertaking is a separate source occurrence.'),
 ('rtsa ba','root',5,1,1,'Whole root noun belongs to the first root three, not the later anaphoric these three.'),
 ('gsum','three',5,1,1,'First numeral owns first three after root.'),
 ('las','from',6,1,1,'First ablative marks origin from the three roots.'),
 ('skyes','come',5,1,1,'First arising verb supplies first come, with its from assigned separately.'),
 ('de yi','them',5,1,1,'Whole inflected demonstrative identifies the roots after which the mental misdeeds occur. English them is its complement in subsequent to them; the full master’s lastly gloss is a different usage, not a local reading.'),
 ('mjug thogs','just subsequent',5,1,1,'The established temporal compound means immediate succession; just subsequent expresses that unit without absorbing the independent pronoun them.'),
 ('byung','occur',5,1,1,'Occurrence verb in the reason clause owns occur; the English subject they is a supplied anaphoric restatement.'),
 ('phyir','Because',6,1,1,'Causal postposition closes the Tibetan reason clause and is fronted as Because in English.'),
 ('brnab sems','Coveting',5,1,1,'Whole coveting compound denotes the first mental misdeed; no degenerate member is added to the single English word.'),
 ('sogs','and the rest',6,1,1,'Enumerative particle owns only the closing gesture and the rest, without importing a supplied noun such as misdeeds. This whole gesture is HGM-attested.'),
 ('gsum','three',5,2,2,'Second numeral selects three in these three. The repeated root noun is implicit in the English anaphor, not falsely paired with these.'),
 ('las','from',6,3,2,'Third las is the origin case of coveting and the rest, at the second lower-case from; the earlier temporal las is not this ablative.'),
 ('skyes','come',5,2,2,'Second arising predicate supplies the second come, in the mental-deed line.'),
 ('dge ba','virtues',5,1,1,'Whole virtue noun selects virtues, excluding The; its plural form also carries the grammatical rnams contribution noted below.'),
 ('sbyor','undertaking',5,2,1,'Later abbreviated sbyor is the undertaking stage included with virtues, not the earlier plural undertakings.'),
 ('dang','and',6,1,2,'This dang joins undertaking and conclusion. Earlier and belongs to the separately aligned sogs gesture.'),
 ('mjug','conclusion',5,2,1,'Later standalone mjug names the conclusion stage, not the mjug inside temporal mjug thogs.'),
 ('bcas','with',5,1,1,'Whole lexical accompaniment predicate bcas applies to undertaking and conclusion; its HGM with equivalent is explicit, not chosen by English part of speech.'),
 ('rnams',None,6,1,0,'Plural rnams scopes the virtues with their stages. English plural virtues realizes the number grammatically, with no independent word for rnams. The null records this fusion, not a missing or disputed meaning.'),
 ('chags','desire',5,1,1,'First coordinated root in the final negative list is desire; the shared no is assigned to med rather than copied into each root.'),
 ('sdang','dislike',5,1,1,'Second coordinated root is dislike; it remains under the one shared negative predicate.'),
 ('gti mug','ignorance',5,1,1,'Whole ignorance compound is the third coordinated root; no unsupported members divide the single English noun.'),
 ('med','no',5,1,1,'Lexical negative existential med denies the coordinated three roots; English uses one shared no at the list opening. The following prose at 333 makes all three negatives explicit, without changing this verse.'),
 ('las','From',6,4,1,'Final ablative is the capitalized From for the virtue line; it is distinct from the two earlier from occurrences.'),
],[omit('rtsa (second)','The second root noun is implicit in English these three; no rtsa→these mapping or false null is supplied.'),
    omit('las (temporal occurrence)','The postposition in de yi mjug thogs las is redistributed in the temporal relation subsequent to them; no independent las→to atom is asserted.'),
    omit('skyes (final)','Final arising predicate is elliptical in the English line From no desire, dislike, ignorance. The relation is present as a whole; no uncertain standalone verb mapping or null is manufactured.'),
    omit('English anaphora and articles','The, they and these remain outside lexical pairs. C16:852 repeats this exact verse in all three fields; this digital equality is not evidence of independent publication or authority to alter it.')],
 'One rnams plural null records fusion into virtues. Repeated origin and arising words belong to separate lines. The final negative existential scopes desire, dislike and ignorance together; elliptical root/arising content is left unbanked. C16 text equality is not publication independence.')
