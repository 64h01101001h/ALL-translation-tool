"""Complete three frozen .py copies excluded by the legacy landing suffix filter."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
S=B/'semantic-review'
D=B.parent.parent/'campaign-worktree/data/alignment/reviews_c05/c5p109'
freeze=json.loads((S/'freeze.json').read_bytes())
paths=['governing/engines/hgm_tools.py','governing/tools/build_alignment_layer.py','governing/tools/gen_alignment_page.py']
assert sorted(p for p in freeze['files'] if not (D/p).exists())==paths
rows=[]
for p in paths:
 raw=(S/p).read_bytes(); expected=freeze['files'][p]
 assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==expected
 (D/p).parent.mkdir(parents=True,exist_ok=True)
 with (D/p).open('xb') as f:f.write(raw)
 assert (D/p).read_bytes()==raw
 rows.append(dict(path=p,**expected))
proof=dict(status='PASS_EXACT_FROZEN_COPY_COMPLETION',files=rows,reason='Legacy landing extension allowlist omitted .py governance files. No data/generator/source changes or overwrites; actual failed landed acceptance retained.')
(B/'landing/governing-copy-completion.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
