"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read complete337–339 source, context331–345 and six physical extents; all109 original span rationales,19 original omissions,30 source-category judgments and material five grounds. Root material reading comprises45 complete master objects, five complete corpus wrappers/records and two focused339 query results, as scoped by root reading receipts. Root read and authored the four specific reconciliation rulings; all55 final rationale origins were verified against exact English originals, with51 repeated common prefixes reused by exact identity and four specific reasons and all19 final omissions read. Root read all55 independent final-span judgments, all19 independent omission judgments and complete independent errata assessments. Reviewer110 complete master-object inventory is not claimed as root reading. Freeze checks are distinct from semantic reading. No generator or resolver rerun.'
decision='Approve55 provisional spans. Retain rmongs pa/lack of understanding at d5 and leave cher/deep-seated uncertain/unbanked. Add the independently attested strict lta/views member inside the second log lta compound. Tighten dug gsum to three poisons, with dug/poisons and gsum/three members; leave all/of the mind outside. Final339 yin owns shared consist of across four categories, with both distinct ming/Names,names and only the second dang/and. First dang, ni/no and expanded list framing remain distributed/uncertain, not false nulls. Other common pairs and repeated predicates retain exact original boundaries and source-specific rationales; whole technical compounds are not speculatively split. Final specs/body/ranges exactly equal the English originals after root comparison and independent review.'
errata='No new erratum or allowance. Preserve source spelling, physical punctuation and numbered heading. Metaphor, mental-poisons expansion and list formatting do not establish source defects. Existing200 register records remain unchanged. Exact parallel digital records show persistence, not independent publications.'

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p113',segments=[337,338,339],counts=dict(spans=55,nulls=0,nonnull_d5=35,total_d5=35,d7=8),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-original-reading-addendum.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Six unique original generator/resolver pairs verified. Reconciled55 spans reuse three exact English native pairs: zero new reconciler, reviewer or root generator/resolver executions. Actual read and assembly failure histories preserved.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[337,338,339],semantic_files=len(freeze['files']))))
