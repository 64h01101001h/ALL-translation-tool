"""Verify existing frozen source/native identities; never invoke a generator."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys
B=Path(__file__).resolve().parent
W=B.parent.parent/'campaign-worktree'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base,origin=read(B/'baseline.json'),read(B/'proposal-baseline.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()==base['commit']=='58b6799188c8cb95f9095fea7cdc6bbf4d653894'
assert base['course_boundary']==336 and origin['course_boundary']==333
inventories={}
for angle in ('tibetan','english','reconciled'):
    f=B/angle/'freeze.json';rows=read(f)['files']
    assert isinstance(rows,dict)
    for rel,expected in rows.items(): assert pin(f.parent/rel)==expected,rel
    inventories[angle]=dict(freeze=pin(f),files=len(rows))
assert len(sys.argv)==2 and inventories['reconciled']['freeze']['sha256']==sys.argv[1]
for item in origin['source_pins'].values():
    assert pin(Path(item['path']))=={k:item[k] for k in ('bytes','sha256')}
source={r['seq']:r for r in read(B/'source.json')}
captures=[];resolved=[];original_spans=0
for angle in ('tibetan','english','reconciled'):
    for seq in range(337,340):
        folder=B/angle/str(seq);spec=read(folder/'spec.json')
        spans=spec['segments'][0]['spans']
        if angle!='reconciled':original_spans+=len(spans)
        version=1
        for mode in ('generator','resolver'):
            native=B/angle/'native'/f'{seq}-{mode}-v{version}'
            ex=read(native/'execution.json')
            assert ex['exit']==0 and (native/'exit.txt').read_text().strip()=='0'
            assert (native/'stderr.bin').read_bytes()==b''
            for stream in ('stdin','stdout','stderr'):
                e=ex['streams'][stream] if 'streams' in ex else {k:ex[stream][k] for k in ('bytes','sha256')}
                assert pin(native/(stream+'.bin'))==e
            assert (native/'stdin.bin').read_bytes()==(folder/'spec.json').read_bytes()
            if mode=='generator':assert (native/'stdout.bin').read_bytes()==(folder/'body.html').read_bytes()
            else:
                rows=read(native/'stdout.bin')
                assert len(rows)==len(spans)
                for sp,row in zip(spans,rows):
                    assert {k:row[k] for k in ('id','d','tib','eng')}=={k:sp[k] for k in ('id','d','tib','eng')}
                    assert row['seq']==seq
                    for field,lang in (('tib','wylie'),('eng','english')):
                        extent=row[field+'_range']
                        if row[field] is None:assert extent is None
                        else:assert source[seq][lang][extent[0]:extent[1]]==row[field]
                    if angle=='reconciled':resolved.append({k:row[k] for k in ('seq','id','d','tib','eng','tib_range','eng_range')})
                if angle=='reconciled':assert rows==read(folder/'resolved-ranges.json')
            captures.append(dict(angle=angle,seq=seq,mode=mode,path=str(native),execution=pin(native/'execution.json')))
assert original_spans==109 and len(resolved)==55
for mode in ('generator','resolver'):
    assert len({x['execution']['sha256'] for x in captures if x['mode']==mode})==6,mode
for seq in range(337,340):
    for f in ('spec.json','body.html','resolved-ranges.json'):
        assert (B/'reconciled'/str(seq)/f).read_bytes()==(B/'english'/str(seq)/f).read_bytes()
save(B/'root-reconciliation-verification/resolved-spans.json',resolved)
proof=dict(status='PASS_ROOT_INPUTS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 baseline=base['commit'],source_origin=origin['commit'],root_generator_runs=0,root_resolver_runs=0,
 verified_native_generations=9,verified_native_resolvers=9,
 unique_original_generations=6,unique_original_resolvers=6,reconciler_generations=0,reconciler_resolvers=0,reused_english_pairs=3,
 count_scope='Nine selected native pairs comprise six distinct original executions and three exact English-pair reuses for unchanged reconciled specs. No new reconciler generator or resolver was run. Packaging failures remain in their immutable histories.',
 historical_successful_native_captures=[],inventories=inventories,native_captures=captures,
 original_spans=109,final_spans=55,method=pin(Path(__file__)),
 limits='Exact existing source, native streams, selected spec/body and source ranges verified. No generator/resolver rerun; no semantic acceptance inferred.')
save(B/'root-current-inputs/proof.json',proof)
print(json.dumps(dict(status=proof['status'],selected_generators=9,selected_resolvers=9,historical_generators=0,historical_resolvers=0,original_spans=109,final_spans=55)))
