"""Prepare root acceptance from the future exact independent review; not run by author.

Usage (root only, after actual reading): root-acceptance-receipt.py REVIEW_FREEZE_SHA256
This is the G receipt adapted to H data and the existing empty-errata policy.
"""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert (B/'root-final-review-reading.json').is_file() and (B/'root-assembled-reading.json').is_file()
assert pin(B/'root-reconciliation-decisions.json')==dict(bytes=14486,sha256='04038304fc5b2385f9cc4b594b86924a802618d073423a3c50f751655ade98b8')
choices=read(B/'root-reconciliation-decisions.json')
assert choices['expected']==dict(spans=117,by_segment=[25,48,44],nonnull_d5=71,d7=7,nulls=1,new_errata=0)
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
    assert obj['source_origin_git_commit']=='0e7bced24593f1980576bad8710e0d1364218b9a'
    assert obj['later_supplied_acceptance_baseline']=='f614639348a03fa30cc53db1b27c6b2034df43cb'
    assert obj['later_baseline_accepted_through']==354
    assert [obj[k] for k in ('total_spans','total_nulls','total_word_pairs','total_d7')]==[117,1,71,7]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert base==choices['actual_baseline']=='f614639348a03fa30cc53db1b27c6b2034df43cb'
assert origin==choices['source_origin']=='0e7bced24593f1980576bad8710e0d1364218b9a'
inputs=read(B/'root-current-inputs/proof.json')
assert inputs['status']=='PASS_ROOT_INPUTS' and inputs['baseline']==base and inputs['source_origin']==origin
assert inputs['verified_native_generations']==9 and inputs['verified_native_resolvers']==9
assert inputs['original_spans']==225 and inputs['final_spans']==117
resolved=read(S/'resolved-spans.json');assert resolved==read(B/'root-reconciliation-verification/resolved-spans.json')
assert [sum(x['seq']==s for x in resolved)for s in (355,356,357)]==[25,48,44]
counts=dict(spans=len(resolved),nulls=sum(x['eng']is None for x in resolved),nonnull_d5=sum(x['d']==5 and x['eng']is not None for x in resolved),total_d5=sum(x['d']==5 for x in resolved),d7=sum(x['d']==7 for x in resolved))
assert counts==dict(spans=117,nulls=1,nonnull_d5=71,total_d5=71,d7=7)
assembled=read(B/'root-assembled-reading.json');final=read(B/'root-final-review-reading.json')
assert assembled['status']=='ROOT_ASSEMBLED_READING_BOUND_TO_IMMUTABLE_RECONCILIATION'
assert assembled['reconciliation_freeze']==pin(B/'reconciled/freeze.json')
for rel,p in assembled['files'].items():assert pin(B/rel)==p,rel
assert all(f'reconciled/{s}/{n}'in assembled['files']for s in (355,356,357)for n in ('spec.json','final-rationales.json','omissions.json'))
assert final['status']=='ROOT_PERSONAL_FINAL_REVIEW_READING_COMPLETE'
assert final['review_freeze']==pin(S/'freeze.json') and final['review']==pin(S/'review.json')
assert assembled['reading'].strip() and final['reading'].strip()
reading='Root assembled reading: '+assembled['reading']+' Final independent-review reading: '+final['reading']+' These are actual root-authored receipts; no material-object reading count is inferred from hash checks or the independent reviewer inventory.'
assert read(S/'bank-ready-errata.json')==[]
assert read(S/'span-head-allow-needed.json')=={'pages_c05':{}}
for seq in (355,356,357):assert read(S/f'reviewed-final/{seq}/errata.json')==[]
utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 reading=reading,semantic_files_verified=len(freeze['files']),limits='Exact immutable identity plus separately completed root reading; production checks still follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,source_origin=origin,page='c5p119',segments=[355,356,357],counts=counts,
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading.json'),final_independent_reading=pin(B/'root-final-review-reading.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision='Approve the117 provisional spans25/48/44 selected by the exact root decisions and subsequently independently reviewed. All root rulings, adopted rationale corrections and retained omissions remain in their immutable records.',
 root_rulings=choices['rulings'],errata_decision='No new errata or head allowance. Preserve the unfiled LOW/UNCERTAIN357 final-fragment question and full counterevidence, including TCS02:75. Ordinary empty-errata production must retain all204 actual-baseline register entries; the proposal-origin register had202.',errata=[],allowances={'pages_c05':{}},
 native_history='Nine unique generator/resolver pairs: six originals plus three changed355–357 reconciliation pairs, with nine selected views and no copied substitute run. Root/reviewer no native reruns. Preserve the first standard proposal-origin capture exit1 at the clean-worktree guard, successful standard attempt02, Tibetan setup failure and root reading/choices history. These do not satisfy required passing production roles.',
 limits='Provisional only; no source/master correction, hgm_gloss promotion, MAIN application or phone acceptance. This receipt does not execute production or closure.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[355,356,357],semantic_files=len(freeze['files']))))
