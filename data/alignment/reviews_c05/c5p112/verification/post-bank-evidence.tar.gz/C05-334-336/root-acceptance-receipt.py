"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read complete source334–336, context328–342, six full physical extents, all115 original span rationales and23 grouped omission records, all30 material original-category grounds, all63 final specs/rationales and25 final omission records. Material master/corpus readings, including53 complete master objects, six complete C05/C16 parallel records and four focused query results, are scoped in root-reconciliation-reading-addendum.json and root-frozen-reconciliation-reading.json. Root authored exact reconciliation decisions and read revision2 corrected erratum. Root read the independent review, all63 independent final-span judgments, all25 independent omission judgments, complete errata verdicts and the resolved finding. The independent reviewer separately read111 unique master objects and45 complete material corpus records; root does not claim that complete inventory as its own reading. Frozen identity/native checks remain separate from semantic reading. No root generator/resolver rerun.'
decision='Approve63 provisional spans. In334 retain outline la/to and both distinct las lam parents, their transparent action/path members, and don/meaning within sgra don; omit sgra/literal and expanded framing. In335 preserve raw ma byin lan/Stealing on exact HGM attestation without normalizing LAN or inventing child pairs. First sole dang has relocated list coordination and remains uncertain/unbanked, not null. Flat rdzogs/completion, par/to and byed/brought have lexical and local resultative support. Distinct log par/Mistaken and lta ba/views members are transparent. Whole agentives own their corresponding by occurrences; final three counts roots, not acts. In336 tighten ce na to ask at d3, excluding supplied One may. First answer dang has affirmative comma-fusion null; the second owns explicit and. Question rnams/gang gang/gis remain distributed and unbanked. Three here counts acts, and repeated completion/causative pairs own their distinct source occurrences. No source or HGM wording is rewritten.'
errata='Retain one LOW/PROBABLE English source anomaly the their in334, preserving both plausible repairs then their or their as uncertain. Revision2 correctly describes enumeration framed by first and finally; literal second is not present. Exact C16 repetition proves persistence, not independent publication or ingest mechanism. Reject the proposed335 LAN-to-LEN correction as insufficiently established despite conventional LEN counterevidence; exact raw whole-term attestation supports only preservation, not a normative spelling claim. Existing199 errata remain unchanged. No head allowance.'

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p112',segments=[334,335,336],counts=dict(spans=63,nulls=1,nonnull_d5=36,total_d5=36,d7=13),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-frozen-reconciliation-reading.json'),material_addendum=pin(B/'root-reconciliation-reading-addendum.json'),root_decisions=pin(B/'root-reconciliation-decisions.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Six original and three reconciled generator/resolver results verified without rerunning them. No root input generator/resolver run.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[334,335,336],semantic_files=len(freeze['files']))))
