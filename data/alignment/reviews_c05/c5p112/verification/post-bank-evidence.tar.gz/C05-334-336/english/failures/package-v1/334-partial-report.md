C05:334 — Codex independent English-first; PROVISIONAL proposal only.
Challenge byed pa/committed first: the performance nominal becomes an English passive; the full glossary attests committed, while the way these paths are stays unwrapped.
Counts: 14 spans; 8 non-null d5 pairs; 8 total d5; 5 d7; 0 nulls; 1 proposed errata.
Source origin 662a74015519ea5f0616fa50700f873b96429675 through327. No through333 acceptance baseline has been consumed.
Complete source/context328–342 was checked against SQLite URI mode=ro; six original physical ASCII byte extents equal complete ACIP/English fields after whitespace collapse.
Full material master objects, query result sets and original corpus records are preserved once under ../evidence, with exact source/Git identities and collection/index provenance.
C16:859 repeats the 334 Tibetan and prose including the their, but heading number36 replaces73; 335/336 have complete equal-field parallels at C16:860/861. Publication independence is unproved.
decisions.json gives every intended range, rationale and omission. errata-review.json applies five grounds to all five source-error categories.
Actual canonical generator EXIT=0; stdout/body=2811 bytes; stderr=0 bytes; body SHA256 6806450bab938e7062f80f195f4e50feeebff38e0f9c3df42c8359fe3743ea35.
Actual canonical resolver EXIT=0; stderr=0; all intended ranges agree. Native captures: ../native/334-generator-v1 and ../native/334-resolver-v1.
Spec SHA256 fae8906489fa853556f15b8ac6246003d467b8203db4489578b6700ffdb7a9fb. Complete source text is exact after markup removal. One generator and one resolver ran per final spec.
No native failures. One earlier read-only brief-path lookup failure is preserved; the correct immutable Git brief was then read in full.
No source/master changes, hgm_gloss promotion, other-angle access or semantic acceptance is claimed.
