C05:335 — Codex independent English-first; PROVISIONAL proposal only.
Challenge MA BYIN LAN/Stealing first: the exact whole form is glossary-attested and retained, but the nearby LEN form and uncertain source lineage remain explicit counterevidence. No lan member is claimed.
Counts: 26 spans; 16 non-null d5 pairs; 16 total d5; 4 d7; 0 nulls; 0 proposed errata.
Source origin 662a74015519ea5f0616fa50700f873b96429675 through327. No through333 acceptance baseline has been consumed.
Complete source/context328–342 was checked against SQLite URI mode=ro; six original physical ASCII byte extents equal complete ACIP/English fields after whitespace collapse.
Full material master objects, query result sets and original corpus records are preserved once under ../evidence, with exact source/Git identities and collection/index provenance.
C16:859 repeats the 334 Tibetan and prose including the their, but heading number36 replaces73; 335/336 have complete equal-field parallels at C16:860/861. Publication independence is unproved.
decisions.json gives every intended range, rationale and omission. errata-review.json applies five grounds to all five source-error categories.
Actual canonical generator EXIT=0; stdout/body=4206 bytes; stderr=0 bytes; body SHA256 c09dd1fc56fbf3d70ea5d3a3e7a6e4ccc4c677c5313694fce0bc37c6be82d807.
Actual canonical resolver EXIT=0; stderr=0; all intended ranges agree. Native captures: ../native/335-generator-v1 and ../native/335-resolver-v1.
Spec SHA256 e301bab499cbcb5fe0ea39154b7e95303d621dd7c1f53062d519fe14a2bd6d49. Complete source text is exact after markup removal. One generator and one resolver ran per final spec.
No native failures. Two packaging/read failures are preserved: an initial wrong brief path and a null-annotation text check; the existing F null-exclusion rule fixes the latter without changing any spec/body/native capture.
No source/master changes, hgm_gloss promotion, other-angle access or semantic acceptance is claimed.
