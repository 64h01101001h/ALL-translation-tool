C05:336 — Codex independent English-first; PROVISIONAL proposal only.
Challenge the first answer dang null first: its coordination is concretely realized by the comma after taking life, while the second dang owns and; this is a punctuation-fusion judgment.
Counts: 18 spans; 10 non-null d5 pairs; 10 total d5; 2 d7; 1 nulls; 0 proposed errata.
Source origin 662a74015519ea5f0616fa50700f873b96429675 through327. No through333 acceptance baseline has been consumed.
Complete source/context328–342 was checked against SQLite URI mode=ro; six original physical ASCII byte extents equal complete ACIP/English fields after whitespace collapse.
Full material master objects, query result sets and original corpus records are preserved once under ../evidence, with exact source/Git identities and collection/index provenance.
C16:859 repeats the 334 Tibetan and prose including the their, but heading number36 replaces73; 335/336 have complete equal-field parallels at C16:860/861. Publication independence is unproved.
decisions.json gives every intended range, rationale and omission. errata-review.json applies five grounds to all five source-error categories.
Actual canonical generator EXIT=0; stdout/body=3515 bytes; stderr=0 bytes; body SHA256 288f8f64c82a96e124c4ddab3c070a168cb2276a1053c6599e66539737c8f42b.
Actual canonical resolver EXIT=0; stderr=0; all intended ranges agree. Native captures: ../native/336-generator-v1 and ../native/336-resolver-v1.
Spec SHA256 0c0b3b58ad6eed47329ec7b72ab901493df1e5d05170f82025bc6f407d202d0c. Complete source text is exact after markup removal. One generator and one resolver ran per final spec.
No native failures. Two packaging/read failures are preserved: an initial wrong brief path and a null-annotation text check; the existing F null-exclusion rule fixes the latter without changing any spec/body/native capture.
No source/master changes, hgm_gloss promotion, other-angle access or semantic acceptance is claimed.
