C05:335 — Codex TIBETAN-FIRST, PROVISIONAL proposal; source origin662a74015519ea5f0616fa50700f873b96429675 through327.
First review targets: resultative par/to versus complement par/as and the relocated first-list dang/and. Keep completion predicates in their own clauses.
Raw MA BYIN LAN/Stealing is fully HGM-attested; the proposed LEN spelling is only LOW/PROBABLE with counterevidence retained. LOG G-YEM is also preserved.
Every proposed span has exact source/English ranges and its local rationale in original-decisions.json; all gaps are in unwrapped-source-intervals.json.
Full five-ground screens, including dictionary counterevidence, actual witnesses/counts and registered classes: five-ground-screens.json.
Complete source/context328–342,83 master objects,6 full corpus records and6 physical extents were read; evidence and actual read-only calls remain beside this proposal.
C16:859 differs in folio36 versus73; other source prose and both Tibetan fields agree.335/860 and336/861 match all three complete text fields. Publication independence is unestablished.
Measured: 27 spans; 0 nulls; 18 nonnull d5 word pairs; 18 total d5; 2 d7; 1 LOW/PROBABLE errata candidates.
Generator EXIT=0; stderr empty; body 4373 bytes; SHA256 a10dfee4bdfa6aa0df8369b3463564a07776ebc93218e8acc15b91dab8e3f4b3.
Resolver EXIT=0; stderr empty; actual ranges equal intended-ranges.json. Native argv/input/output/error/exit: ../native/335-generator-v1 and ../native/335-resolver-v1.
Spec 4503 bytes; SHA256 608995691613914a6ccbc005efac8f8b7c7a817d652a046e2b085c72e21d4ccc. Both source columns reconstruct exactly from native output.
No original/spec-generation failures. No W mutation, hgm_gloss promotion, acceptance or registration. Root source-reading receipt is not claimed.
