C05:336 — Codex TIBETAN-FIRST, PROVISIONAL proposal; source origin662a74015519ea5f0616fa50700f873b96429675 through327.
First review targets: the two par/to relations and ce na/One may ask. The joint rnams gang gang gis/what-each-different recast remains uncertain and unbanked.
DANG PO NI and apparatus stay unpaired; no First is invented. Shared interrogative/distributive wording is omitted with reasons rather than falsely nulled.
Every proposed span has exact source/English ranges and its local rationale in original-decisions.json; all gaps are in unwrapped-source-intervals.json.
Full five-ground screens, including dictionary counterevidence, actual witnesses/counts and registered classes: five-ground-screens.json.
Complete source/context328–342,83 master objects,6 full corpus records and6 physical extents were read; evidence and actual read-only calls remain beside this proposal.
C16:859 differs in folio36 versus73; other source prose and both Tibetan fields agree.335/860 and336/861 match all three complete text fields. Publication independence is unestablished.
Measured: 18 spans; 0 nulls; 10 nonnull d5 word pairs; 10 total d5; 3 d7; 0 LOW/PROBABLE errata candidates.
Generator EXIT=0; stderr empty; body 3351 bytes; SHA256 5e79e399e7f59eb9d2b766489c38d63178b4171314e336ebe427b30978ce1c3e.
Resolver EXIT=0; stderr empty; actual ranges equal intended-ranges.json. Native argv/input/output/error/exit: ../native/336-generator-v1 and ../native/336-resolver-v1.
Spec 3276 bytes; SHA256 0f921b21732f61dacb499fc5d84b525c650abc2a7f112fa56ff2150cccabb1dd. Both source columns reconstruct exactly from native output.
No original/spec-generation failures. No W mutation, hgm_gloss promotion, acceptance or registration. Root source-reading receipt is not claimed.
