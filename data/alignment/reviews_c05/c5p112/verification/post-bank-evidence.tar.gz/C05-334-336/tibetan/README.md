C05:334–336 — independent Tibetan-first PROVISIONAL proposals.

Source/proposal origin is 662a74015519ea5f0616fa50700f873b96429675 through327. Actual acceptance baseline remains a separate later role; no root source-reading receipt, reconciliation, semantic acceptance or registration is claimed. No other334–336 proposal was read.

The three native generators and three native resolvers each ran exactly once and exited0 with empty stderr. Every actual range equals its preselected intent and both full source texts reconstruct exactly.57 total spans contain36 nonnull d5 word pairs and7 d7 compound members; there are no nulls.

Two LOW/PROBABLE editorial candidates retain all five grounds:334 the their → then their is a proposed repair with an alternative deletion possible;335 MA BYIN LAN → MA BYIN LEN is an orthographic question, with the exact raw HTG2016 stealing attestation preserved as counterevidence. Neither is a verified correction. The trailing334 folio/heading is an already registered class, unpaired and not newly filed.

Read reading-receipt.json for actual full model-reading scope. All83 complete master objects, six complete corpus records, six physical extents and source/context328–342 were read.43 lexical queries and4 targeted corpus queries were executed;9 neutral full-field query captures were reused without rerun. These identities do not establish publication independence. In particular,334 and C16:859 share the anomaly but have different folios73/36.

Every span rationale, omitted correspondence and selected range is in SEQ/original-decisions.json. Resultative/complement par, serial coordination and transparent compound members remain explicit independent-review targets. The joint336 interrogative/distributive wording is omitted with uncertainty. All reference comparanda and auto-mined records retain their actual status.

Both packaging executions passed. The second adds the standard original absolute path to immutable-Git copy records, retaining commit and repository-relative path; the exact first method and prior manifest remain under package-native. No source query, generator or resolver was rerun for that metadata completion. No W or source edits, hgm_gloss promotion, paid generation, account actions or release occurred.
