"""Preserve immutable evidence once by content, with every original path recorded.

For evidence files only. Keep individual specs/bodies/reports in their required
per-segment locations. Historical repository snapshots need their explicit Git
pins and are not handled by this helper. No source file is modified.

Usage: python3 copy_evidence_once.py REVIEW_DIR MANIFEST_JSON ORIGINAL...
"""
from pathlib import Path
import hashlib
import json
import sys


def preserve(review_dir, manifest_path, originals):
    review_dir = Path(review_dir).resolve()
    manifest_path = Path(manifest_path).resolve()
    assert manifest_path.is_relative_to(review_dir)
    records = json.loads(manifest_path.read_text()) if manifest_path.exists() else []
    assert isinstance(records, list)
    by_original = {r['original']: r for r in records}
    assert len(by_original) == len(records)
    by_digest = {}
    validated_copies = {}

    def identity(stat):
        return (stat.st_dev, stat.st_ino, stat.st_mode, stat.st_size,
                stat.st_mtime_ns, stat.st_ctime_ns)

    for record in records:
        copy = (review_dir / record['copy']).resolve()
        assert copy.is_relative_to(review_dir)
        # Metadata only invalidates a byte-derived result for this actual path.
        current_identity = identity(copy.stat())
        cached = validated_copies.get(copy)
        if cached is None or cached[0] != current_identity:
            raw = copy.read_bytes()
            assert identity(copy.stat()) == current_identity, 'Destination changed during verification'
            cached = (current_identity, len(raw), hashlib.sha256(raw).hexdigest())
            validated_copies[copy] = cached
        assert cached[1] == record['bytes'] and cached[2] == record['sha256']
        by_digest.setdefault((record['sha256'], record['bytes']), record['copy'])
    del validated_copies  # No cache survives into original reads or writes.
    added = 0
    for original in originals:
        original = Path(original).resolve()
        raw = original.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        key = (digest, len(raw))
        relative = by_digest.get(key)
        if relative is None:
            suffix = original.suffix.lower()
            if suffix not in ('.json', '.md', '.html', '.stderr', '.stdout', '.log', '.txt', '.bin', '.exit'):
                suffix = suffix + '.txt' if suffix in ('.py', '.sql', '.sh') else '.bin'
            relative = 'proposal-inputs/evidence/' + digest + suffix
            copy = review_dir / relative
            copy.parent.mkdir(parents=True, exist_ok=True)
            if copy.exists():
                assert copy.read_bytes() == raw
            else:
                copy.write_bytes(raw)
                added += 1
            by_digest[key] = relative
        copy = review_dir / relative
        assert copy.read_bytes() == raw and original.read_bytes() == raw
        record = dict(original=str(original), copy=relative, sha256=digest, bytes=len(raw))
        if str(original) in by_original:
            assert by_original[str(original)] == record, 'Preserve changed originals as explicit historical versions'
        else:
            records.append(record)
            by_original[str(original)] = record
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    return dict(original_records=len(records), distinct_copies=len({r['copy'] for r in records}), new_copies=added)


if __name__ == '__main__':
    assert len(sys.argv) >= 4
    print(json.dumps(preserve(sys.argv[1], sys.argv[2], sys.argv[3:]), indent=2))
