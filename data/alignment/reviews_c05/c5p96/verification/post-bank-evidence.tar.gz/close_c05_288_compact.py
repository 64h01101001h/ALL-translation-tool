"""Bind existing passing evidence to the exact staged tree, then checkpoint privately.

No generators, tests, source edits, integration, or prior proof trees are repeated.
Every Git command has a native record. Refuses a second invocation's output path.
"""
from pathlib import Path
import datetime, hashlib, io, json, os, subprocess, tarfile

A = Path(__file__).resolve().parent
R = A.parent
W = R / 'campaign-worktree'
B = A / 'C05-286-288'
O = B / 'compact-closure'
BASE = '129e86afae8431aacfb1ee1cee65d8635dd265b8'
V = W / 'data/alignment/reviews_c05/c5p96/verification'
REPRO = Path('/Volumes/Oct2024(8TB)/Codex-ACI-Alignment-20260915-01a09398/compact-reproduction-through288')
O.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(b): return dict(bytes=len(b), sha256=sha(b))
def read(p): return json.loads(p.read_bytes())
def save(p, d): p.write_text(json.dumps(d, indent=2, ensure_ascii=False)+'\n')
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(label, *args, allowed=(0,)):
    d=O/label; d.mkdir()
    argv=['git', *args]; started=utc()
    save(d/'command.json',dict(argv=argv,cwd=str(W),started_at=started,environment_overrides={'GIT_OPTIONAL_LOCKS':'0'}))
    (d/'stdin.bin').write_bytes(b'')
    result=subprocess.run(argv,cwd=W,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1'),input=b'',capture_output=True)
    for n,b in [('stdout.bin',result.stdout),('stderr.bin',result.stderr),('exit.txt',f'{result.returncode}\n'.encode())]: (d/n).write_bytes(b)
    save(d/'execution.json',dict(argv=argv,cwd=str(W),started_at=started,finished_at=utc(),exit=result.returncode,stdout=pin(result.stdout),stderr=pin(result.stderr)))
    assert result.returncode in allowed,(label,result.returncode)
    return result.stdout
def names(b): return [x.decode() for x in b.split(b'\0') if x]

assert git('incoming','rev-parse','HEAD').decode().strip()==BASE
assert not git('unstaged-entry','diff','--name-only','-z')
frozen=read(B/'semantic-review/review-freeze.json')
assert frozen['verdict']=='APPROVE' and frozen['open_findings']==[]
assert (frozen['total_spans'],frozen['total_nulls'],frozen['total_word_pairs'])==(137,5,99)
reviewroot=W/'data/alignment/reviews_c05/c5p96'
for row in frozen['files']:
    original=(B/'semantic-review'/row['path']).read_bytes()
    assert pin(original)=={k:row[k] for k in ('bytes','sha256')}
    assert (reviewroot/row['path']).read_bytes()==original
assert (reviewroot/'review-freeze.json').read_bytes()==(B/'semantic-review/review-freeze.json').read_bytes()
for seq in (286,287,288):
    assert (reviewroot/f'{seq}-reconciliation.md').read_bytes()==(B/f'reconciled/{seq}/report.md').read_bytes()
for caller in ('root-semantic-acceptance-caller','root-materialize-caller','root-landed-copy-caller','root-register-caller','root-register-copy-check-caller','root-canonical-builders-caller','ctest-17-caller','root-retention-caller','root-course-csv-caller','root-compact-reproduction-caller','root-compact-bank-caller','root-stage-data-caller','root-whitespace-audit-caller'):
    d=B/caller; ex=read(d/'execution.json')
    assert ex['exit']==0 and (d/'exit.txt').read_bytes()==b'0\n'
    for stream in ('stdout','stderr'):
        raw=(d/f'{stream}.bin').read_bytes()
        assert len(raw)==ex[f'{stream}_bytes'] and sha(raw)==ex[f'{stream}_sha256']
build=read(B/'landing/canonical-builds-once.json')
assert build['status']=='PASS' and build['baseline_commit']==BASE
for path,h in build['output_sha256'].items(): assert sha((W/path).read_bytes())==h,path
repro=read(REPRO/'proof.json')
assert repro['status']=='PASS' and repro['baseline_commit']==BASE and len(repro['outputs'])==7
for row in repro['outputs']: assert pin((W/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
wh=read(B/'landing/source-whitespace-proof.json')
assert wh['all_warnings_accounted_for'] and wh['baseline_head']==BASE and wh['warning_count']==43922
assert sha((A/'audit_staged_source_whitespace_v7.py').read_bytes())==read(B/'compact-reproduction-review/whitespace-v7-review.json')['v7_sha256']
assert read(B/'compact-reproduction-review/whitespace-v7-review.json')['verdict']=='APPROVE'
assert sha((B/'landing/staged-diff-check.stdout').read_bytes())==wh['raw_log_sha256']
for path,row in wh['files'].items(): assert pin((W/path).read_bytes())=={k:row[k] for k in ('bytes','sha256')}

# Archive only evidence produced after the first compact bank, once.
inputs=[B/'landing'/n for n in ('source-whitespace-proof.json','review-whitespace-exact-pins.json','staged-diff-check.stdout','staged-diff-check.stderr','staged-diff-check.exit')]
for caller in ('root-whitespace-audit-caller','root-compact-bank-caller','root-stage-data-caller'):
    inputs.extend(sorted(p for p in (B/caller).rglob('*') if p.is_file()))
inputs.extend([A/'audit_staged_source_whitespace_v6.py',A/'audit_staged_source_whitespace_v7.py',Path(__file__).resolve()])
inputs.extend(sorted(p for p in (B/'compact-reproduction-review').rglob('*') if p.is_file()))
inputs=sorted(set(inputs)); members=[]
archive=V/'post-bank-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'x:gz') as tf:
    for p in inputs:
        raw=p.read_bytes(); name=str(p.relative_to(A)); info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644
        tf.addfile(info,io.BytesIO(raw)); members.append(dict(original=str(p),member=name,**pin(raw)))
with tarfile.open(archive,'r:gz') as tf:
    assert tf.getnames()==[m['member'] for m in members]
    for m in members: assert tf.extractfile(m['member']).read()==Path(m['original']).read_bytes()
save(V/'post-bank-manifest.json',dict(archive=pin(archive.read_bytes()),members=members,all_members_byte_equal=True,scope='Actual late whitespace, bank/stage callers and bounded method evidence. Earlier native-evidence archive unchanged.'))
git('stage-post-bank','add','--',str(archive.relative_to(W)),str((V/'post-bank-manifest.json').relative_to(W)))
paths=names(git('staged-paths','diff','--cached','--name-only','-z'))
fixed=set(build['output_sha256'])-{'data/hgm_dictionary_v27_2.json.gz','data/full_parallel_corpus_v32.json.gz'}
fixed.update(['data/alignment/pages_c05/c5p95.html','data/alignment/pages_c05/c5p96.html','data/alignment/pages_c05/index.html','data/alignment/specs_c05/c5p96.json','tools/build_alignment_layer.py'])
assert fixed.issubset(paths)
assert all(p in fixed or p.startswith('data/alignment/reviews_c05/c5p96/') for p in paths)
records=[]
index={}
for row in git('accepted-index-entries','ls-files','--stage','-z').split(b'\0'):
    if not row: continue
    meta,path=row.split(b'\t',1);mode,oid,stage=meta.split()
    assert stage==b'0' and path.decode() not in index
    index[path.decode()]=(mode.decode(),oid.decode())
for i,path in enumerate(paths):
    raw=(W/path).read_bytes()
    # Git's blob hash verifies the exact staged bytes, without copying each blob again.
    mode,oid=index[path]
    assert mode=='100644',path
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid,path
    records.append(dict(path=path,git_blob=oid,**pin(raw)))
assert not git('unstaged-final','diff','--name-only','-z')
diag=git('final-whitespace','diff','--cached','--check',allowed=(2,))
assert diag==(B/'landing/staged-diff-check.stdout').read_bytes()
tree=git('accepted-index-tree','write-tree').decode().strip()
save(O/'accepted-index.json',dict(status='PASS',baseline=BASE,tree=tree,files=records,semantic_frozen_files=len(frozen['files']),seven_outputs_match_reproduction=True,whitespace_diagnostic_unchanged=pin(diag),source_archives_unchanged=True))
git('commit-data','commit','-m','Bank reviewed provisional C05 alignments for segments 286–288')
data=git('data-head','rev-parse','HEAD').decode().strip()
assert git('data-parent','rev-parse',data+'^').decode().strip()==BASE
assert git('data-tree','rev-parse',data+'^{tree}').decode().strip()==tree

entry=f'''
## C05 286–288 verified — {utc()}

Private DATA commit {data}; incoming {BASE}. C05 coverage is 288/511, with 223 segments remaining (289–511). Independent original proposals, reconciliation and fresh semantic review accepted 137 provisional spans: 99 non-null depth-5 correspondences and five nulls, plus three source anchors. A wrong-clause negation in an original proposal was corrected before acceptance. No source errata or new head allowances were required. GMR wording remains verbatim; nothing is promoted into hgm_gloss.

Both canonical builders ran once in 13.67 seconds; all 17 fidelity suites passed once in 11.46 seconds. Independent complete-byte reproduction of all seven generated outputs passed with the actual incoming CSV seed and producer date 2026-09-14. All 45,481 prior links and existing notes, trees, evidence and CSV content were retained. Totals: 45,621 links, 11,943 nulls, 1,624 notes, 11 trees, 7,102 heads and 15,587 pairs. ACIP is evidenced on 7,099 of 7,102 heads; five source-linked spans remain unproved. CSV rows main/reverse/course/changes: 22,594/22,254/24,177/48. One existing klung→stream row gained newly witnessed KLUNG ACIP from C05:287.

Source specs, complete review decisions and readable semantic evidence are banked under reviews_c05/c5p96. Exact native checks are retained in its compact verification archives and manifests. All 43,922 whitespace warnings in 20 files were accounted for by exact original-source or canonical CSV formatting; final staged diagnostics are byte-identical to the accepted audit. No source bytes were normalized. Final accepted index and Git closure records are in campaign-artifacts/C05-286-288/compact-closure outside the checkout. Immutable evidence is stored once and proposal/review stages overlap; no fidelity or semantic gate was removed.

Generated HTML/CSV consumption paths in the isolated checkout are refreshed and mechanically verified. MAIN remains OPEN_NO_APPLICATION. Private iOS pack remains FAILED_UNACCEPTED for four inherited C01 semantic findings; no installation, new native/device/rendering or saved data-root acceptance is claimed. Installed resources through171 remain unchanged. Keep the external evidence drive connected. Continue C05 before C06; C13 remains blocked upstream. Existing one-minute automation ends 2026-09-15 at 13:00 UTC, then checkpoint and pause. No spending, paid API, account messages, releases or changes to others' work.
'''
assert not any(line.endswith(' ') for line in entry.splitlines())
rawentry=entry.encode(); (O/'ledger-entry.md').write_bytes(rawentry)
ledgers=['data/alignment/C05_CAMPAIGN.md','docs/handoff/HANDOFF_LOG.md','docs/superpowers/plans/2026-09-12-aci-alignment-campaign.md']
ledger_records=[]
for i,path in enumerate(ledgers):
    old=git(f'ledger-before-{i}','show',data+':'+path)
    assert (W/path).read_bytes()==old and rawentry not in old
    with (W/path).open('ab') as f: f.write(rawentry)
    assert (W/path).read_bytes()==old+rawentry
    ledger_records.append(dict(path=path,before=pin(old),after=pin(old+rawentry)))
assert set(names(git('ledger-changes','diff','--name-only','-z')))==set(ledgers)
git('stage-ledgers','add','--',*ledgers)
assert set(names(git('staged-ledger-paths','diff','--cached','--name-only','-z')))==set(ledgers)
assert not git('ledger-whitespace','diff','--cached','--check')
git('commit-docs','commit','-m','Record verified C05 coverage through segment 288 and integration limits')
final=git('final-head','rev-parse','HEAD').decode().strip()
assert git('docs-parent','rev-parse',final+'^').decode().strip()==data
assert set(names(git('docs-changes','diff','--name-only','-z',data,final)))==set(ledgers)
for i,row in enumerate(ledger_records):
    after=git(f'ledger-final-{i}','show',final+':'+row['path'])
    old=(O/f'ledger-before-{i}/stdout.bin').read_bytes()
    assert after==old+rawentry==(W/row['path']).read_bytes()
assert not git('final-tracked-state','status','--porcelain','--untracked-files=no')
untracked=names(git('untracked','ls-files','--others','--exclude-standard','-z'))
assert untracked==['data/teaching/dcc_captions'],untracked
proof=dict(status='PASS_FIXED_PRIVATE_CHECKPOINT',utc=utc(),incoming=BASE,data=data,final=final,coverage=288,remaining=223,accepted_index_tree=tree,data_tree_equals_accepted_index=True,ledgers=ledger_records,all_prior_ledger_bytes_preserved=True,tracked_clean=True,untracked=untracked,main='OPEN_NO_APPLICATION',phone='FAILED_UNACCEPTED; no installation; installed through171 unchanged')
save(O/'proof.json',proof)
for name in ('CAMPAIGN_STATUS.md','CAMPAIGN_CONTINUATION.md'):
    (O/(name+'.before')).write_bytes((R/name).read_bytes())
status=f'''# ACI campaign status

Updated {proof['utc']}

Verified C05: **288/511**, with **223 segments remaining**. DATA {data}; final DOCS {final}. All 137 current provisional spans passed fresh semantic review, both builders, all 17 fidelity suites, retention and exact seven-output reproduction. Fixed index/tree and append-only ledger binding: campaign-artifacts/C05-286-288/compact-closure/proof.json.

289–291: reconciliation frozen (109 spans), fresh independent semantic review active. Actual through288 landing baseline is the immediate next capture; proposal/reconciliation source origin remains historical129e86af through285.

292–294: both independent proposals frozen, awaiting root intake and fresh reconciliation. No worktree mutation hold. Immutable governing snapshots preserve their explicit original Git versions.

Efficiency: overlap proposal/reconciliation/review stages; reuse unchanged passing checks; bank evidence once in compact exact archives. No recursive old audit copies or repeated full production checks for bookkeeping.

MAIN OPEN_NO_APPLICATION; private phone pack FAILED_UNACCEPTED/no installation; installedthrough171 unchanged. External evidence drive required. C05 before C06, C13 blocked. Verbatim GMR/provisional/no hgm_gloss promotion; no spending/APIs/account messages/releases/others-overwrites.

One-minute automation deadline Tuesday September15,2026 at07:00 America/Denver (13:00UTC); safely checkpoint and pause then.
'''
(R/'CAMPAIGN_STATUS.md').write_text(status)
with (R/'CAMPAIGN_CONTINUATION.md').open('a') as f:
    f.write('\n## Compact C05 288 closure — '+proof['utc']+'\n\n'+status.split('\n\n',2)[2]+'\nNEXT: capture actual C05-289-291/baseline.json with capture_next_baseline.py 289 290 291 from this clean committed boundary and inform active reviewer. Finish semantic review before landing97. Inspect frozen292–294 originals, verify six canonical bodies and ordered ranges, then dispatch fresh reconciliation. Do not repeat any successful286–288 generator, builder, test, reproduction, bank or closure. Preserve all failed attempts and source evidence. Exact native closure is beside proof.json; compact late verification archive is separately mapped.\n')
for name in ('CAMPAIGN_STATUS.md','CAMPAIGN_CONTINUATION.md'): (O/(name+'.after')).write_bytes((R/name).read_bytes())
print(json.dumps(proof,indent=2))
