APPROVE — corrected bank_compact_verification.py.

Exact SHA-256: `515bcf7dde92639da8c30277fc393ba698e62d62238139886f9bb53ee75598c4`.

B1/B2 are resolved: seven distinct expected outputs are checked against current W bytes and both production/reproduction records; baseline and batch identities are bound. Both external seeds must exist and byte-equal the actual Git CSV and their recorded pins. The added CTest stdout fields match the external recorder.

Selected current evidence and native streams are archived with a readable manifest and complete byte verification. The active recorder is excluded until it has finished. Historical recursive evidence trees and redundant seed copies are not selected; the external seed dependency is stated. Future staging/commit/checkpoint completion is explicitly left separate.

Initial findings and the scoped correction review are preserved in banking-review-initial.json and banking-review-correction.json. Source inspection, AST parsing and upstream field checks passed. No archive/build/helper production run or W mutation was performed. An interrupted synthetic prefix harness attempt is preserved as incomplete and is not counted as passing validation.
