from pathlib import Path
from datetime import date
import sqlite3
print("producer_date", date.today(), flush=True)
con = sqlite3.connect("source.db")
print("source_value", con.execute("SELECT value FROM source").fetchone()[0], flush=True)
try:
    con.execute("UPDATE source SET value='changed'")
except sqlite3.OperationalError as exc:
    print("sqlite_write_refused", str(exc), flush=True)
else:
    raise RuntimeError("unexpected writable SQLite connection")
Path('/Users/adamderickandrade/Documents/ChatGPT/Geshe Michael Roach Tib _ Eng Alignment/campaign-artifacts/C05-286-288/compact-reproduction-review/evidence/forbidden-write.txt').write_text("must not be written")
