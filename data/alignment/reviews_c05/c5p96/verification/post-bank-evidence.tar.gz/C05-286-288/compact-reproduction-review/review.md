APPROVE — no actionable findings in the compact reproduction helpers.

Reviewed exact SHA-256:

- `reproduce_generated_outputs.py`: `f8b56afad204b9774e40a20378842980d5463ca3b3a9b7a91ab19be5767a8321`
- `run_reproduction_readonly.py`: `7917fb3c6e3a78377c4ae82d091c9e1ae1b765db723a8f1e286c7d9b55be8da7`

The copied dependency set covers the current layer, view and export builders. The registry import does not call main; the isolated layer and view each run once, in that order, with the view invoking exports. Registry/page ordering matches the canonical lexical sorts. The actual incoming CSV seed is bound to baseline Git bytes and checked before the view; the frozen producer date reaches the canonical date.today() call.

The fresh workspace is outside W, the spine is copied and opened read-only, and all seven complete output byte strings must equal both frozen production outputs and live W outputs. Inputs are pinned and checked unchanged. Handled failures retain the destination, traceback and available execution records.

One tiny isolated negative probe passed: fixed date and SQL reads worked; a SQL update and out-of-scope file write were refused; the database stayed byte-identical, failure guard evidence remained, and no bytecode was created. See `evidence/guard-failure-probe/result.json`. No canonical builder or whole-data build was run for this review.

Approval covers the helper implementation only. The actual seven-output run remains to be executed. Production retention remains the separate verify_landed_batch.py / verify_course_csv.py checks; no semantic, MAIN, UI, native or device approval is inferred.
