REQUEST CHANGES — initial banking helper review.

- B1: Require the seven expected distinct output paths, bind proof batch/baseline identities, and check current W output bytes against production/reproduction hashes. Initial lines 26–30 trusted seven possibly duplicated/stale records.
- B2: Verify both retained external seed files against the actual baseline Git CSV and recorded pins before claiming external seed retention. Initial lines 59/103 excluded the seed but never checked its existence.

These findings were sent to root before correction. No exact initial helper hash/local snapshot was captured before the edit. The corrected source is reviewed separately.
