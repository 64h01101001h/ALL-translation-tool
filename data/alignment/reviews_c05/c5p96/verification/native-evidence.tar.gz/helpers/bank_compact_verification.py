"""Bank explicit verification evidence once, without recursive campaign copies.

Usage: python3 -B bank_compact_verification.py PAGE FIRST REPRODUCTION_DIR
Run after semantic acceptance, actual builders, 17 fidelity tests, retention and
independent reproduction. Native streams are exact archive members; the main
specs/reviews remain ordinary readable files in the page's banked review folder.
"""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import tarfile
import sys

artifacts = Path(__file__).resolve().parent
worktree = artifacts.parent / 'campaign-worktree'
page, first = map(int, sys.argv[1:3])
batch = artifacts / f'C05-{first}-{first+2}'
reproduction = Path(sys.argv[3]).resolve()
landing = batch / 'landing'
destination = worktree / f'data/alignment/reviews_c05/c5p{page}/verification'
assert not destination.exists()
read = lambda path: json.loads(path.read_bytes())
baseline = read(batch / 'baseline.json')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree).decode().strip()
assert head == baseline['commit'] and baseline['course_boundary'] == first - 1
sequences = list(range(first, first + 3))
review = read(batch / 'semantic-review/review.json')
assert review['verdict'] == 'APPROVE' and review['open_findings'] == []
assert [item['seq'] for item in review['segments']] == sequences
builds = read(landing / 'canonical-builds-once.json')
assert builds['status'] == 'PASS'
assert builds['baseline_commit'] == head and builds['page'] == page and builds['first_segment'] == first
reproduced = read(reproduction / 'proof.json')
assert reproduced['status'] == 'PASS' and len(reproduced['outputs']) == 7
assert reproduced['baseline_commit'] == head and reproduced['segments'] == sequences
expected_outputs = {'data/alignment/alignment_full_v1.json', 'data/alignment/alignment_evidence_v1.json'} | {
    'docs/geshe_michael_roach_dictionary' + suffix for suffix in ('.html', '.csv', '_reverse.csv', '_by_course.csv', '_changes.csv')}
assert {item['path'] for item in reproduced['outputs']} == expected_outputs
for item in reproduced['outputs']:
    raw = (worktree / item['path']).read_bytes()
    assert len(raw) == item['bytes']
    assert hashlib.sha256(raw).hexdigest() == item['sha256'] == builds['output_sha256'][item['path']]
incoming_csv = subprocess.check_output(['git', 'show', head + ':docs/geshe_michael_roach_dictionary.csv'], cwd=worktree)
assert (landing / 'previous-main-csv-seed.bin').read_bytes() == (reproduction / 'seed/previous-main-csv-seed.bin').read_bytes() == incoming_csv
seed_pin = {'bytes': len(incoming_csv), 'sha256': hashlib.sha256(incoming_csv).hexdigest()}
assert reproduced['seed'] == seed_pin
assert all(builds['previous_main_csv_seed'][key] == value for key, value in seed_pin.items())
tests = read(batch / 'ctest-17-caller/execution.json')
assert tests['exit'] == 0
test_stdout = (batch / 'ctest-17-caller/stdout.bin').read_bytes()
assert len(test_stdout) == tests['stdout_bytes'] and hashlib.sha256(test_stdout).hexdigest() == tests['stdout_sha256']


def verify_ctest_success(stdout):
    expected = {'constitution', 'gen_alignment_page', 'alignment_gate_coverage', 'alignment_builder',
                'dictionary_exports', 'no_broken_words', 'no_split_syllables', 'no_phonetics_in_layer',
                'no_degenerate_members', 'no_supplied_span_head', 'layer_matches_spine', 'evidence_matches_spine',
                'errata_quotes_hold', 'view_matches_layer', 'generated_docs_in_sync', 'builder_sees_every_span',
                'errata_name_their_witnesses'}
    passed = re.findall(rb'^\s*(\d+)/17 Test\s+#\d+:\s+(\w+)\s+\.{2,}\s+Passed\s+[\d.]+\s+sec\s*$', stdout, re.M)
    assert len(passed) == len(re.findall(rb'^\s*\d+/\d+ Test\s+#', stdout, re.M)) == 17
    assert sorted(int(index) for index, _ in passed) == list(range(1, 18))
    assert {name.decode() for _, name in passed} == expected
    assert any(line in stdout.splitlines() for line in (b'100% tests passed out of 17', b'100% tests passed, 0 tests failed out of 17'))


verify_ctest_success(test_stdout)
retention = read(landing / 'retention-source-check.json')
assert retention['baseline_commit'] == head and retention['page'] == f'c5p{page}' and retention['segments'] == sequences
assert retention['review_tuples_and_source_ranges_match'] and retention['source_hashes_unchanged']
assert retention['prior_notes_trees_evidence_and_acip_retained']
assert retention['prior_csv_content_and_references_retained']
course = read(landing / 'course-csv-check.json')
assert course['all_depths_counts_and_metadata_match_main_csv_refs']
assert course['baseline_commit'] == head
assert course['course_csv_sha256'] == hashlib.sha256((worktree / 'docs/geshe_michael_roach_dictionary_by_course.csv').read_bytes()).hexdigest()

members = {}


def include(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members, name
    members[name] = path


def directory(path, prefix, excluded=()):
    for source in sorted(path.rglob('*')):
        if source.is_file() and source.name not in excluded:
            include(source, prefix + '/' + str(source.relative_to(path)))


# These are bounded current-batch directories, never past review/reproduction trees.
directory(landing, 'landing', excluded=('previous-main-csv-seed.bin',))
for caller in sorted(batch.glob('*-caller')):
    # The recorder for this bank invocation is still running; bank it later.
    if (caller / 'execution.json').is_file():
        directory(caller, 'callers/' + caller.name)
for name in ('baseline.json', 'root-original-angle-findings.json', 'root-original-angle-review-targets.md',
             'root-reconciliation-intake.json'):
    if (batch / name).exists():
        include(batch / name, 'root/' + name)
for name in ('proof.json', 'input-manifest.json', 'registered-pages.json'):
    include(reproduction / name, 'reproduction/' + name)
directory(reproduction / 'executions', 'reproduction/executions')
directory(reproduction / 'method', 'reproduction/method')
directory(batch / 'compact-reproduction-review', 'method-review')
for name in ('record_external_step.py', 'run_generator_readonly.py', 'run_tool_readonly_sqlite.py',
             'verify_semantic_acceptance.py', 'land_reviewed_page_v2.py', 'register_reviewed_page.py',
             'verify_review_copy_and_register.py', 'run_reviewed_builders_once.py', 'verify_landed_batch.py',
             'verify_course_csv.py', 'reproduce_generated_outputs.py', 'run_reproduction_readonly.py',
             'bank_compact_verification.py'):
    include(artifacts / name, 'helpers/' + name)

destination.mkdir()
manifest = []
archive = destination / 'native-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as output:
    for name, source in sorted(members.items()):
        raw = source.read_bytes()
        output.add(source, arcname=name, recursive=False)
        manifest.append({'original': str(source), 'member': name, 'bytes': len(raw),
                         'sha256': hashlib.sha256(raw).hexdigest()})
with tarfile.open(archive, 'r:gz') as stored:
    assert stored.getnames() == [x['member'] for x in manifest]
    for item in manifest:
        raw = stored.extractfile(item['member']).read()
        assert raw == Path(item['original']).read_bytes()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
(destination / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = {'status': 'PASS', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'page': page, 'segments': list(range(first, first+3)), 'semantic_review': review,
           'fidelity_tests': {'passed': 17, 'failed': 0, 'execution': tests}, 'retention': retention,
           'course_csv': course, 'reproduction_outputs': reproduced['outputs'],
           'archive': {'file': archive.name, 'members': len(manifest), 'bytes': archive.stat().st_size,
                       'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
           'external_reproduction_inputs': str(reproduction),
           'seed_retention': 'Actual incoming CSV seed is retained externally and byte-bound to baseline Git CSV; not redundantly copied into this archive.',
           'integration_limits': 'Isolated desktop-consumable outputs only. MAIN remains OPEN_NO_APPLICATION. Private phone pack FAILED_UNACCEPTED for four inherited C01 mappings; no install. Installed through171 unchanged. External evidence drive required.',
           'later_proofs': 'Staging/whitespace/commit/checkpoint evidence follows separately; it is not claimed to be an input to its own earlier archive.'}
(destination / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'archive_members': len(manifest), 'archive_bytes': archive.stat().st_size,
                  'summary': str(destination / 'summary.json')}, indent=2))
