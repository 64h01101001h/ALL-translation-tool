"""Run an unchanged isolated builder with a recorded date and read-only SQLite."""
from pathlib import Path
import datetime
import json
import os
import runpy
import sqlite3
import sys

sys.dont_write_bytecode = True
workspace = Path(sys.argv[1]).resolve()
tool, fixed_date, record_name = sys.argv[2:]
scope = workspace.parent
target = (workspace / tool).resolve()
record = Path(record_name).resolve()
assert target.is_relative_to(workspace) and target.is_file()
assert record.is_relative_to(scope)
connections = []
real_connect = sqlite3.connect


def readonly(database, *args, **kwargs):
    assert not args
    path = Path(database).resolve()
    assert path.is_relative_to(workspace) and path.is_file()
    kwargs['uri'] = True
    uri = path.as_uri() + '?mode=ro'
    connection = real_connect(uri, **kwargs)
    connection.execute('PRAGMA query_only=ON')
    assert connection.execute('PRAGMA query_only').fetchone()[0] == 1
    connections.append({'database': str(path), 'uri': uri, 'query_only': 1})
    return connection


sqlite3.connect = readonly
real_date = datetime.date


class ProducerDate(real_date):
    @classmethod
    def today(cls):
        return cls.fromisoformat(fixed_date)


datetime.date = ProducerDate


def audit(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes)):
        flags = args[2]
        if isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
            assert Path(os.fsdecode(args[0])).resolve().is_relative_to(scope), (event, args[0])
    if event in ('os.rename', 'os.remove', 'os.mkdir', 'os.rmdir', 'os.truncate'):
        for path in args[:2] if event == 'os.rename' else args[:1]:
            if isinstance(path, (str, bytes)):
                assert Path(os.fsdecode(path)).resolve().is_relative_to(scope), (event, path)


sys.addaudithook(audit)
sys.argv = [str(target)]
try:
    runpy.run_path(str(target), run_name='__main__')
finally:
    record.write_text(json.dumps({'sqlite_connections': connections, 'date_override': fixed_date,
                                  'write_scope': str(scope), 'bytecode_disabled': True}, indent=2) + '\n')
