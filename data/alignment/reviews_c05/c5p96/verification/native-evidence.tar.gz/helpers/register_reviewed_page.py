"""Register a landed three-segment C05 page with no errata/head allowances.

Usage: python3 -B register_reviewed_page.py PAGE FIRST
Preserve exact preimages and a small patch; refuse unexpected existing state.
Nonempty independently accepted errata/allowances require their established
specific registration path instead of silently being discarded here.
"""
from pathlib import Path
import ast
import datetime
import difflib
import hashlib
import json
import subprocess
import sys

artifacts = Path(__file__).resolve().parent
worktree = artifacts.parent / 'campaign-worktree'
page, first = map(int, sys.argv[1:])
sequences = list(range(first, first + 3))
assert page * 3 == sequences[-1]
batch = artifacts / f'C05-{first}-{first+2}'
review = batch / 'semantic-review'
landing = batch / 'landing'
baseline = json.loads((batch / 'baseline.json').read_bytes())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree).decode().strip() == baseline['commit']
for filename in ('root-semantic-acceptance-proof.json', 'root-frozen-input-copy-check.json'):
    checked = json.loads((landing / filename).read_bytes())
    assert checked['page'] == page and checked['segments'] == sequences
    assert checked['exact_final_hashes_counts_and_ranges']
assert json.loads((review / 'bank-ready-errata.json').read_bytes()) == []
assert json.loads((review / 'span-head-allow-needed.json').read_bytes()) == {}
assert (worktree / f'data/alignment/pages_c05/c5p{page}.html').is_file()

registry = 'tools/build_alignment_layer.py'
index = 'data/alignment/pages_c05/index.html'
before = {relative: (worktree / relative).read_bytes() for relative in (registry, index)}
old_line = f'    "c5p{page-1}": {list(range(first-3, first))},\n'
new_line = f'    "c5p{page}": {sequences},\n'
source = before[registry].decode()
assert source.count(old_line) == 1 and f'"c5p{page}"' not in source
after = {registry: source.replace(old_line, old_line + new_line).encode()}
ast.parse(after[registry])
assert after[registry].replace(new_line.encode(), b'', 1) == before[registry]
old_coverage = f'Reviewed campaign coverage: {first-1} of 511 source segments.'
new_coverage = f'Reviewed campaign coverage: {first+2} of 511 source segments.'
old_entry = f'<li><a href="c5p{page-1}.html">Page {page-1} · segments {first-3}–{first-1}</a></li>'
new_entry = f'<li><a href="c5p{page}.html">Page {page} · segments {first}–{first+2}</a></li>'
source = before[index].decode()
assert source.count(old_coverage) == source.count(old_entry) == 1
assert f'c5p{page}.html' not in source
after[index] = source.replace(old_coverage, new_coverage).replace(old_entry, old_entry + '\n' + new_entry).encode()
assert after[index].replace(new_coverage.encode(), old_coverage.encode(), 1).replace(('\n' + new_entry).encode(), b'', 1) == before[index]

destination = landing / 'registration'
destination.mkdir(exist_ok=False)
records = []
patches = []
for relative in before:
    for label, content in [('before', before[relative]), ('after', after[relative])]:
        target = destination / label / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    patches.extend(difflib.unified_diff(before[relative].decode().splitlines(True), after[relative].decode().splitlines(True), fromfile='a/' + relative, tofile='b/' + relative))
    records.append({'path': relative, 'before_sha256': hashlib.sha256(before[relative]).hexdigest(),
                    'after_sha256': hashlib.sha256(after[relative]).hexdigest()})
(destination / 'exact-change.diff').write_text(''.join(patches))
# Every candidate and preimage is durable before the first repository mutation.
for relative in before:
    assert (worktree / relative).read_bytes() == before[relative], relative
for relative in before:
    (worktree / relative).write_bytes(after[relative])
    assert (worktree / relative).read_bytes() == after[relative]
proof = {'status': 'PASS', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'page': page,
         'segments': sequences, 'baseline_commit': baseline['commit'], 'files': records,
         'errata': [], 'head_allowances': {}, 'scope': 'Exact registry/index update only; no source or generated-output changes.'}
(destination / 'proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
