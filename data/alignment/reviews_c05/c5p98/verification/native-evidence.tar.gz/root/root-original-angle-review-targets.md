# Post-freeze root challenges, C05 292–294

Root read all six full original specs/reports/notes and the current source, the
withheld preparation leads, and complete selected positive HGM variants. Both
original manifests (268 files) and six actual root canonical body replays passed;
all 210 original ranges are in proposal-verification/root-resolved-spans.json.
Current original-source SQL queries and source/context fields were reopened in
reconciliation-source-origin.json. No original proposal was changed.

292: Decide lexical versus phrase depth for drang don and dgongs pa can from
their actual established status and wording. HGM2403 explicitly includes both
have to interpret and must be interpreted to establish their real meaning.
Do not narrow or demote these solely because they are long English renderings;
equally do not let that positive record license unrelated framing. Preserve the
first and second technical skye mched equivalents. Compare both la sogs pa
boundaries, including HGM19208's positive and other such; report exact licenses
if the head gate requires one. Recover the negative existential and consequence
where defensible: med par and thal are positively rendered, not absent. Compare
the complete recipient recast with the tight attested disciples unit; no invented
members. Track two Tibetan mdo versus three English sutras and two reporting
gsungs pa occurrences; distinguish quoted says from prefatory states.

293: Both original analysts corrected actual occurrence errors despite initial
generator success; preserve and account for those superseded decisions. Keep
point, true meaning, meaning of the original statement, and final saying-frame
separate. The complete dgongs pa can HGM rendering is positively attested; its
depth requires an established-unit decision. Inspect skyon med parent/members,
both outer-object compounds, both as relations and the final negative existential.
The first actually existing and yod/grub pa distribution must be explained.

294: HGM13452 'bras bu med pa has a positive bare equivalent. Challenge BOTH
the Tibetan proposal's broad nothing but bare limbs and the English proposal's
complete omission: a tight bare correspondence may retain valid lexical evidence
while leaving supplied limbs unwrapped. Full-source contextual reading decides.
Do not invent a fruit→limbs member. Compare lexical mig shes→sees (positive
HGM14365) for the two earlier clauses against the English proposal's collective
visual consciousness assignment. Choose one coherent occurrence plan and record
all shared renderings; never double-bank the collective English phrase. The final
mig shes resolves to Tibetan[385,393] / English[598,618] in both current originals.
The three tshad mar song ba constructions are distinct from two tshad ma nouns.
Consider the full phrase and the positive song ba→so; no arbitrary silence/null.
Check all three temporal clauses, the consequent must and closing causal Why for
defensible recovery. Preserve one rnag khrag versus two English reprises; actual
and genuine have different source licensors. Check every member and grammar null.

No erratum is established by these challenges. C15:437's English differences and
P7:35's truncated ending must retain their exact limits; no publication or
ingestion independence inferred. Source suspicions need all five grounds and
complete raw source witnesses. Record dispositions for every original tuple and
material omission; agreement and mechanical PASS alone do not approve semantics.
