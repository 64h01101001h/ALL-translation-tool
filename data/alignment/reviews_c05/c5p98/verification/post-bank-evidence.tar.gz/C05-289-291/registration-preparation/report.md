Prepared `campaign-artifacts/register_reviewed_page_v2.py` for root review.

SHA-256: `61385cac76347db810088339a02f53d3edfbff5bbc2abf3bb83253ef1c425e7b`. The original helper remains byte-identical.

The new helper adds only allowances named in the fresh approved frozen review, ties each key to the exact current landed d5/d7 spec span, and rejects duplicate/conflicting keys or unrelated classes/pages/spans. Zero new errata remains required. Existing allowance bytes are preserved by an insertion with inverse-byte and full-mapping checks.

PREPARED proof, exact before/after files, diff and method bytes are saved before W writes. Changed inputs are refused; partial writes retain a FAILED record and exact recovery evidence. Historical governance is permitted only for the exact proposal-baseline commit proven to be an ancestor of the actual acceptance HEAD. Acceptance proofs remain bound to the actual HEAD.

All 21 final fixtures passed: 5 positive registrations, 15 pre-mutation refusals, and one injected second-write failure that preserved the evidence and completed-file record. The fixtures use isolated repositories; synthetic approval records and the provisional C05:290 sogs proposal carry no semantic endorsement. Initial 18-case results and the root-requested origin correction are preserved separately.

No production registration, W/index modification, builder or global test rerun occurred. The authoritative semantic-review allowance file must use the canonical class-to-key map or either established list format accepted by verify_review_copy_and_register.py; the reconciler’s proposal schema is not a substitute.
