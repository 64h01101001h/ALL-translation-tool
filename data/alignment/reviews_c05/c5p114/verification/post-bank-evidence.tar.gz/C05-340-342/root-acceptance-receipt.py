"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read complete340–342 source, context334–348 and six physical extents; all152 original span rationales,29 original omissions,30 source-category judgments/material grounds,27 full master objects and five full corpus wrappers/records. Root read all73 final selected objects, all37 final omission/disposition reasons, all12 non-ACCEPT span disposition reasons, and current changed rationales. All73 final rationale origins verified exact against originals previously personally read; exact repeated originals reused by identity. Root authored ten revision2 rulings and preserves his incorrect revision1 positive-pleasant judgment and its independent correction. Root read all73 independent final-span judgments, independent omission and source-error dispositions in the exact final review. Reviewer127 master objects are not claimed as root reading. Freeze equality is distinct from semantic reading.'
decision='Approve73 provisional spans27/15/31. Segment340 retains exact English27 originals: whole mi snyan pa/unpleasant and permitted negative mi/un; positive pleasant interior cut is rejected under Rule8. Both ni/is, gcod/take and distributed framing stay unbanked. Segment341 selects lexical nang/within, flat dbang/force plus intact gis/by; both la links and both byung ba predicates sharing one English occur remain unbanked with scope reasons and no false null. Segment342 retains whole bsdus pa/part of, with kyis unbanked; adds strict hyphen-delimited dge/virtues inside mi dge/non-virtues. MED is a separate negative existential with no explicit English exponent and a self-contained verb-null reason. All uncertain omissions preserve source wording and both original opinions.'
errata='No new erratum or allowance. Complete original LOW/UNCERTAIN342 source question remains deferred human-review evidence; possible intentional object-focused abbreviation and absence of a corrected same-passage witness prevent banked factual-error claim. E-120 and357/362 are contextual support, not correction authority. Existing200 register records remain unchanged. MED null records absence of rendering rather than translator intent.'

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p114',segments=[340,341,342],counts=dict(spans=73,nulls=1,nonnull_d5=49,total_d5=50,d7=8),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-selected.json'),root_decisions=pin(B/'root-reconciliation-decisions-v2.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Eleven actual unique generator/resolver pairs: six original, three successful superseded revision1, and two new revision2 for341342. Final340 reuses exact English340 native records; selected9 capture views contain eight unique executions. Reviewer/root zero native executions. Root input receipt first failed only on nonexistent optional command.json assumption; five actual native files verified by successful corrected attempt02. Failure and old helper preserved.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[340,341,342],semantic_files=len(freeze['files']))))
