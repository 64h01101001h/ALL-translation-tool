"""Record root semantic acceptance after reading the exact independent freeze."""
from pathlib import Path
import datetime,hashlib,json,sys
B=Path(__file__).resolve().parent;S=B/'semantic-review'
read=lambda p:json.loads(p.read_bytes())
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert len(sys.argv)==2
assert pin(S/'freeze.json')['sha256']==sys.argv[1]
freeze=read(S/'freeze.json');review=read(S/'review.json')
for rel,expected in freeze['files'].items():assert pin(S/rel)==expected,rel
assert freeze['file_count']==len(freeze['files'])
for obj in (freeze,review):
    assert all(obj[k]=='APPROVE' for k in ('verdict','spec_verdict','quality_verdict'))
    assert obj['open_findings']==[]
base=read(B/'baseline.json')['commit'];origin=read(B/'proposal-baseline.json')['commit']
assert review['later_supplied_acceptance_baseline']==base
assert review['source_origin_git_commit']==origin
assert read(B/'root-current-inputs/proof.json')['status']=='PASS_ROOT_INPUTS'
assert read(S/'resolved-spans.json')==read(B/'root-reconciliation-verification/resolved-spans.json')
reading='Root read all119 original span objects/rationales and31 original omissions; complete343–345 source,337–351 context and six physical extents, all30 category judgments/material grounds and all4 original spelling proposals. Root material reading covers44 full master objects and five full corpus wrappers/records, separately pinned; reviewer119-master/20-corpus inventory is not claimed as root reading. Root read all three singular original spec notes and corrected344 shared-death note before its only changed generation. Root read independent preliminary assessment before issuing final root choices, then checked all selected61 spans by exact original identity and current source-specific reconciliation reasons. Root read all61 independent final-span judgments, complete final omission judgments and both complete independent spelling assessments before this acceptance. Freeze equality and native verification are distinct from semantic reading.'
decision='Approve61 provisional spans22/19/20.343 keeps exact English originals: RO terminating-particle punctuation-fusion null at born period, SOGS/or whatever with local grammatical PAR/in, and strict BYED/commits inside agent noun; raw PHYER remains unbanked.344 omits BOTH SHI BA predicates sharing one die, retains explicit positive BYUNG/occurred versus the elided negative question verb, keeps MI/not at d6 and secure LAS/action,LAM/path,DNGOS/actual members. The final344note now agrees with those decisions.345 keeps MI BYUNG/cannot occur at phrase d3 and flat MA/never d6 plus BYAS PA/went through d5; glossary inclusion alone does not establish a negative compound, and no d7 hangs from the phrase. Discontinuous temporal negatives and anaphoric body/act expansions remain unbanked with reasons, without false absence claims.'
errata='Accept two LOW/PROBABLE human spelling questions from exact English originals, preserving all four original candidates and counterevidence.343 PHYER is compared with PHYIR in internal same-verse quotations372/889; exact physical/C16 PHYER and metre limit certainty.344 MTSAN BSNUN contrasts with MTSON weapon-strike lexical/different-context usage; repeated MTSAN and no corrected same-passage witness preclude confirmation. Neither is a new demonstrated ingest defect. Raw forms stay unbanked; no source/master correction or head allowance. The existing200 register records must be retained; actual assigned IDs follow verified registration.'

utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
save(B/'root-reconciliation-intake.json',dict(status='PASS_ROOT_CURRENT_INTAKE',utc=utc,baseline=base,source_origin=origin,
 prior_root_checks=pin(B/'root-current-inputs/proof.json'),review_freeze=pin(S/'freeze.json'),
 reconciliation_freeze=pin(B/'reconciled/freeze.json'),reading=reading,semantic_files_verified=len(freeze['files']),
 limits='Frozen identity plus separate root reading; production checks follow.'))
save(B/'root-semantic-disposition.json',dict(verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',utc=utc,actual_baseline=base,
 source_origin=origin,page='c5p115',segments=[343,344,345],counts=dict(spans=61,nulls=1,nonnull_d5=39,total_d5=39,d7=4),
 review_freeze=pin(S/'freeze.json'),review_json=pin(S/'review.json'),reconciliation_freeze=pin(B/'reconciled/freeze.json'),
 read_evidence=dict(completed=reading,preliminary_reading=pin(B/'root-assembled-reading.json'),material_addendum=pin(B/'root-material-reading-addendum.json'),root_decisions=pin(B/'root-reconciliation-decisions-v2.json')),
 semantic_decision=decision,errata_decision=errata,errata=read(S/'bank-ready-errata.json'),
 allowances=read(S/'span-head-allow-needed.json'),
 native_history='Seven actual unique native pairs:6original and1changed344reconciler; unchanged343345reuseexactEnglishspec/body/ranges/native. Nine selected capture views include2duplicates; root/reviewer0newnative runs. Pre-generation singular-note/eng_order correction preserved with firstrootdecision and exact old/new note; no superseded candidate generation or production rerun.',
 limits='All machine alignments remain provisional. No source/master correction, hgm_gloss promotion, MAIN application or phone acceptance.'))
print(json.dumps(dict(status='PASS_ROOT_CURRENT_INTAKE',root_verdict='APPROVE_ROOT_SEMANTIC_ACCEPTANCE',segments=[343,344,345],semantic_files=len(freeze['files']))))
