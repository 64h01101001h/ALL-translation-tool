"""Nonempty LOW/PROBABLE errata closure for the standard C05 v1 DICT interface.

The shared semantic, source, production, native, archive and commit gates are unchanged.
This route accepts no new head allowances. Live use requires exact root review.
"""
from pathlib import Path
import argparse
import json
import stat
from closure import (Closure, Invalid, check_scope, exact, need, pin, read,
                     relpath, save, selected, sha, under)

SIDECAR='docs/errata_register.json'
PROSE='docs/ERRATA_REGISTER.md'
ALLOW='data/alignment/span_head_allow.json'
OUTPUT_REGISTERS={SIDECAR,PROSE}
GUARDED={SIDECAR,PROSE,ALLOW,'tools/build_alignment_layer.py','data/alignment/pages_c05/index.html'}
FIELDS=('kind','found','expected','evidence','severity','confidence')

class ErrataClosure(Closure):
    def verify_policy_inputs(self):
        incoming=self.doc('errata')
        need(not self.retrospective, 'v1 errata route supports live closure only')
        need(type(incoming) is list and incoming, 'v1 errata nonempty editorial questions')
        need(all(type(r['seq']) is int and r['seq'] in self.seqs for r in incoming),
             'v1 errata editorial questions belong to current accepted sequences')
        for item in incoming:
            need(set(item)=={'seq',*FIELDS} and item['severity']=='LOW' and item['confidence']=='PROBABLE',
                 'v1 errata tentative editorial scope')
        need(self.doc('head_allowances')=={'pages_c05':{}},'v1 errata no new allowance')
        before=self.git('show',self.base+':'+SIDECAR)
        old=json.loads(before)
        need(before==json.dumps(old,ensure_ascii=False,indent=1).encode(),'v1 errata canonical old register bytes')
        need(type(old) is list and old,'v1 errata existing stable register')
        self.prior_errata_count=len(old)
        ids=[int(r['item_id'][2:]) for r in old]
        need(len(set(ids))==len(ids),'v1 errata unique prior errata IDs')
        signatures={(r['segment'],r['found'][:60]) for r in old}
        expected=[]
        for n,r in enumerate(incoming,max(ids)+1):
            signature=(f"C05:{r['seq']}",r['found'][:60])
            need(signature not in signatures,'v1 errata no duplicate register signature');signatures.add(signature)
            expected.append(dict(item_id=f'E-{n:03d}',course='C05',segment=f"C05:{r['seq']}",
                **{k:r[k] for k in FIELDS},note='filed from the alignment batch, spine-verified on merge'))
        after=under(self.w,SIDECAR).read_bytes()
        need(after==json.dumps(old+expected,ensure_ascii=False,indent=1).encode()
             and after[:len(before)-2]==before[:-2],'v1 errata exact canonical additions/prior bytes retained')
        self.expected_errata=expected;self.work_identity(SIDECAR,after)
        unchanged=under(self.w,ALLOW).read_bytes()
        need(unchanged==self.git('show',self.base+':'+ALLOW),'v1 errata allowance unchanged');self.work_identity(ALLOW,unchanged)

    def verify_registration_scope(self,reg):
        need(reg['errata']==self.expected_errata and reg['prior_errata_retained']==self.prior_errata_count
             and reg['head_allowances']==reg['requested_allowances']=={'pages_c05':{}},'v1 errata exact registration delta')
        need(reg['accepted_cli_pins']=={'errata_sha256':self.checked['errata']['sha256'],
                                      'review_freeze_sha256':self.checked['semantic_freeze']['sha256']},'v1 errata exact accepted CLI pins')
        folder=self.b/'landing/registration'
        canonical=read(folder/'canonical-proof.json')
        need(canonical['status']=='PASS' and canonical['baseline_commit']==self.base
             and canonical['expected_added']==self.expected_errata,'v1 errata actual canonical register pass')
        cleanup=read(folder/'staging-spine-cleanup.json')
        need(cleanup['status']=='REMOVED_VERIFIED_OWNED_COPY','v1 errata actual staging source identity')
        for relative,row in cleanup['retained_files'].items():exact(under(folder,relative),row)
        native=folder/'native'
        labels={'baseline-prose','merge-dry-run','merge-apply','new-prose','quotes-hold','witnesses-named','prose-reproduction'}
        need(set(p.name for p in native.iterdir())==labels,'v1 errata seven actual canonical invocations')
        for label in labels:
            d=native/label
            need(set(p.name for p in d.iterdir())=={'command.json','stdin.bin','stdout.bin','stderr.bin','exit'},'v1 errata canonical native inventory')
            need((d/'exit').read_bytes()==b'0\n' and (d/'stdin.bin').read_bytes()==b'', 'v1 errata canonical native exit/stdin')
            command=read(d/'command.json')
            need(command['stdin_bytes']==0 and Path(command['cwd'])==folder/'canonical-stage/campaign-worktree',
                 'v1 errata actual canonical invocation cwd')
        for path in OUTPUT_REGISTERS:
            raw=(folder/'canonical-stage/campaign-worktree'/path).read_bytes()
            need(raw==(folder/'after'/path).read_bytes()==under(self.w,path).read_bytes(),'v1 errata canonical output exact current bytes')
            self.work_identity(path,raw)

    def verify_registration_inputs(self,reg):
        rows=reg['files'];need(type(rows) is list and len(rows)==5 and {r['path'] for r in rows}==GUARDED,
                              'v1 errata five guarded preimages')
        outputs={r['path']:r for r in rows}
        changed=[r['path'] for r in rows if r['before_sha256']!=r['after_sha256']]
        need(set(changed)==GUARDED-{ALLOW} and reg['written_files']==reg['attempted_files']==changed
             and reg['recovery']==[],'v1 errata exactly four successful writes and no recovery')
        seen=set()
        for row in reg['inputs']:
            p=Path(row['path']);relative=str(p.relative_to(self.w)) if p.is_relative_to(self.w) else None
            if relative in outputs:
                need(relative not in seen,'v1 errata duplicate registration input');seen.add(relative)
                out=outputs[relative];before=self.git('show',self.base+':'+relative);after=under(self.w,relative).read_bytes()
                need(pin(before)==selected(row) and sha(before)==out['before_sha256'] and sha(after)==out['after_sha256'],
                     'v1 errata exact before/after registration identities')
                need(out['mode']==stat.S_IMODE(under(self.w,relative).stat().st_mode)==(0o755 if relative=='tools/build_alignment_layer.py' else 0o644),
                     'v1 errata unchanged guarded mode')
                self.work_identity(relative,after)
            else:exact(p,row)
        need(seen==GUARDED,'v1 errata all guarded input preimages')

    def check_staged_scope(self,paths):
        need(OUTPUT_REGISTERS<=set(paths),'v1 errata registered sidecar/prose must be staged')
        check_scope([p for p in paths if p not in OUTPUT_REGISTERS],self.page)

    def approval(self,receipt):
        d=read(receipt);need(d['profile_method']==pin(Path(__file__).read_bytes()),'v1 errata exact profile approval')
        super().approval(receipt)
        (self.o/'executed-profile.py.txt').write_bytes(Path(__file__).read_bytes())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('staged','execute'))
    p.add_argument('--config',required=True);p.add_argument('--root-review',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();run=ErrataClosure(a.config,a.output,retrospective=False)
    try:
        run.approval(a.root_review)
        result=run.execute() if a.mode=='execute' else dict(run.verify(),status='PASS_V1_ERRATA_LIVE_STAGED_VERIFICATION',tree=run.staged())
        save(run.o/'proof.json',result);print(json.dumps(result,indent=2))
    except (Invalid,KeyError,OSError,ValueError) as exc:
        save(run.o/'failure.json',{'status':'FAIL_CLOSED','error':str(exc),'mode':a.mode});raise

if __name__=='__main__':main()
